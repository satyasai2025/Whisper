/**
 * Sunrise computation for a given date and location.
 * Returns decimal hour (local time) of sunrise.
 *
 * Method: Standard NOAA solar position algorithm (simplified)
 * Accuracy: ±1-2 minutes for latitudes between 60S and 60N
 *
 * This is used ONLY for:
 *   - BL/HL/GL computation (elapsed minutes since sunrise)
 *   - Upagraha Group B computation
 *   - Hora computation in Panchanga
 *
 * Not used for planet positions (VSOP87 handles that).
 */

'use strict';

const DEG = Math.PI / 180;
const RAD = 180 / Math.PI;

/**
 * Compute approximate sunrise time as decimal hour (local mean time).
 *
 * @param {number} year
 * @param {number} month  1-12
 * @param {number} day
 * @param {number} lat    latitude in degrees (N positive)
 * @param {number} lon    longitude in degrees (E positive)
 * @param {number} gmtOffset  hours east of GMT
 * @returns {number} sunrise as decimal hour in local clock time, or 6.0 if computation fails
 */
function computeSunrise(year, month, day, lat, lon, gmtOffset) {
  try {
    // Julian date
    const JD = dateToJD(year, month, day);

    // Days since J2000.0
    const n = JD - 2451545.0;

    // Mean longitude and anomaly of Sun (degrees)
    const L = (280.46 + 0.9856474 * n) % 360;
    const g = (357.528 + 0.9856003 * n) % 360;

    // Ecliptic longitude
    const lambda = L + 1.915 * Math.sin(g * DEG) + 0.020 * Math.sin(2 * g * DEG);

    // Obliquity of ecliptic
    const epsilon = 23.439 - 0.0000004 * n;

    // Right ascension and declination
    const sinLambda = Math.sin(lambda * DEG);
    const RA_raw = Math.atan2(Math.cos(epsilon * DEG) * sinLambda, Math.cos(lambda * DEG)) * RAD;
    const RA = ((RA_raw % 360) + 360) % 360;
    const dec = Math.asin(Math.sin(epsilon * DEG) * sinLambda) * RAD;

    // Hour angle for sunrise (sun center at -0.833° elevation including refraction)
    const cosH = (Math.cos(90.833 * DEG) - Math.sin(lat * DEG) * Math.sin(dec * DEG))
                 / (Math.cos(lat * DEG) * Math.cos(dec * DEG));

    if (cosH < -1 || cosH > 1) {
      // Polar day or night
      return 6.0;
    }

    const H = Math.acos(cosH) * RAD; // degrees

    // Equation of time (approximate)
    const EqT = 4 * (L - RA); // minutes

    // Sunrise in UTC hours
    const sunriseUTC = 12 - H / 15 - EqT / 60 - lon / 15;

    // Convert to local time
    const sunriseLocal = sunriseUTC + gmtOffset;

    return ((sunriseLocal % 24) + 24) % 24;
  } catch(e) {
    return 6.0; // fallback
  }
}

function dateToJD(year, month, day) {
  // Standard algorithm
  const a = Math.floor((14 - month) / 12);
  const y = year + 4800 - a;
  const m = month + 12 * a - 3;
  return day + Math.floor((153 * m + 2) / 5) + 365 * y
         + Math.floor(y / 4) - Math.floor(y / 100) + Math.floor(y / 400) - 32045;
}

/**
 * Compute approximate sunset time as decimal hour (local clock time).
 * Uses same algorithm as sunrise but with +H for hour angle.
 */
function computeSunset(year, month, day, lat, lon, gmtOffset) {
  try {
    const JD = dateToJD(year, month, day);
    const n  = JD - 2451545.0;
    const L  = (280.46 + 0.9856474 * n) % 360;
    const g  = (357.528 + 0.9856003 * n) % 360;
    const lambda  = L + 1.915 * Math.sin(g * DEG) + 0.020 * Math.sin(2 * g * DEG);
    const epsilon = 23.439 - 0.0000004 * n;
    const sinLambda = Math.sin(lambda * DEG);
    const RA_raw = Math.atan2(Math.cos(epsilon * DEG) * sinLambda, Math.cos(lambda * DEG)) * RAD;
    const RA  = ((RA_raw % 360) + 360) % 360;
    const dec = Math.asin(Math.sin(epsilon * DEG) * sinLambda) * RAD;
    const cosH = (Math.cos(90.833 * DEG) - Math.sin(lat * DEG) * Math.sin(dec * DEG))
                 / (Math.cos(lat * DEG) * Math.cos(dec * DEG));
    if (cosH < -1 || cosH > 1) return 18.0;
    const H = Math.acos(cosH) * RAD;
    const EqT = 4 * (L - RA);
    const sunsetUTC   = 12 + H / 15 - EqT / 60 - lon / 15;
    const sunsetLocal = sunsetUTC + gmtOffset;
    return ((sunsetLocal % 24) + 24) % 24;
  } catch(e) {
    return 18.0;
  }
}

module.exports = { computeSunrise, computeSunset };
