/**
 * Birth Time Rectification (BTR) Questionnaire Engine
 * 
 * Purpose: Generate chart-specific yes/no questions from dasha periods.
 * User answers → system checks if chart confirms → BTR score 0-100.
 * 
 * Philosophy:
 *   - Questions are SPECIFIC (what happened in a named period)
 *   - NOT vague ("did you feel good in 2022?")
 *   - Questions tied to VERIFIABLE dasha lord significations
 *   - Each answer either confirms or contradicts chart prediction
 *   - Final score = how well chart matches lived experience
 * 
 * Source: PVR textbook Ch.8 (karakatva), Ch.13 (MD results), Ch.14 (longevity)
 */

'use strict';

// ── MD/AD lord significations for question generation ─────────────────────────
// What themes does each planet's MD/AD typically bring?
const MD_SIGNIFICATIONS = {
  Sun: {
    positive: ['recognition at work','authority/leadership','father-figure connections','government/official dealings','career advancement','self-confidence peak'],
    negative: ['ego conflicts with superiors','health issues (heart/eyes)','father\'s health concerns','reduction in team support'],
    domains: ['career','health','father','authority']
  },
  Moon: {
    positive: ['emotional fulfillment','mother\'s wellbeing','property/home changes','travel','public recognition','new relationships'],
    negative: ['mental stress/anxiety','mother\'s health issues','frequent relocations','emotional instability'],
    domains: ['family','health','travel','property']
  },
  Mars: {
    positive: ['property purchase','sibling support','courage in new ventures','physical energy peak','sports/athletics'],
    negative: ['accidents/injuries','conflicts with siblings','surgery','legal disputes','arguments'],
    domains: ['property','siblings','health','litigation']
  },
  Mercury: {
    positive: ['business expansion','educational achievements','communication/writing success','skill development','trade profits'],
    negative: ['communication breakdowns','nervous disorders','business disputes','educational setbacks'],
    domains: ['career','education','business','communication']
  },
  Jupiter: {
    positive: ['marriage/partnership','children birth','financial growth','spiritual growth','guru connection','promotion'],
    negative: ['weight gain','overconfidence setbacks','children concerns','financial over-extension'],
    domains: ['marriage','children','wealth','education','spirituality']
  },
  Venus: {
    positive: ['marriage/partnership','creative success','luxury purchases (vehicle/home)','artistic recognition','romantic happiness'],
    negative: ['relationship complications','overspending','indulgence-related issues'],
    domains: ['marriage','romance','art','luxury','vehicles']
  },
  Saturn: {
    positive: ['disciplined career growth','property through hard work','responsibility increases','long-term planning success','service recognition'],
    negative: ['delays and obstacles','health issues (joints/bones)','separation from family','depression periods','loss of comfort'],
    domains: ['career','health','delays','discipline']
  },
  Rahu: {
    positive: ['foreign connections','unconventional success','sudden gains','technology/modern field success','breaks from tradition'],
    negative: ['confusion and illusion','sudden reversals','foreign/unknown risks','deception by others'],
    domains: ['foreign','career','sudden events','technology']
  },
  Ketu: {
    positive: ['spiritual awakening','past skills resurfacing','research/investigation success','detachment bringing clarity'],
    negative: ['sudden losses','isolation','accidents','mysterious health issues','relationship endings'],
    domains: ['spirituality','health','sudden events','endings']
  }
};

// ── AD modifier — how AD colors MD theme ─────────────────────────────────────
const AD_MODIFIER = {
  Sun:     { emphasis: 'authority and self', timing: 'sharp/sudden' },
  Moon:    { emphasis: 'emotions and family', timing: 'gradual' },
  Mars:    { emphasis: 'action and conflict', timing: 'quick/forceful' },
  Mercury: { emphasis: 'intellect and trade', timing: 'varied' },
  Jupiter: { emphasis: 'expansion and wisdom', timing: 'steady' },
  Venus:   { emphasis: 'relationships and comfort', timing: 'pleasant' },
  Saturn:  { emphasis: 'delay and hard work', timing: 'slow/grinding' },
  Rahu:    { emphasis: 'unusual and foreign', timing: 'sudden' },
  Ketu:    { emphasis: 'spiritual and endings', timing: 'abrupt' }
};

// ── Question templates per domain ─────────────────────────────────────────────
const QUESTION_TEMPLATES = {
  marriage: [
    'Did you get married or enter a serious long-term partnership?',
    'Did a significant romantic relationship begin or deepen considerably?',
    'Did you get engaged or have a commitment ceremony?'
  ],
  children: [
    'Was a child born in your family (your own or close family member)?',
    'Did you have significant news related to children (pregnancy, adoption)?'
  ],
  career: [
    'Did you start a new job, change careers, or receive a significant promotion?',
    'Did you start your own business or become self-employed?',
    'Did you receive an award, recognition, or important title at work?'
  ],
  property: [
    'Did you purchase, build, or move into a new home or property?',
    'Did you make a major real estate transaction?'
  ],
  health: [
    'Did you experience a significant health issue or undergo surgery?',
    'Was there a serious illness (yours or immediate family)?'
  ],
  foreign: [
    'Did you travel abroad or relocate to a foreign country?',
    'Did you have major connections with foreign people or organizations?'
  ],
  education: [
    'Did you complete an important degree or certification?',
    'Did you begin or complete significant formal education?'
  ],
  wealth: [
    'Did you experience a major financial gain, inheritance, or windfall?',
    'Did you make a large investment or financial decision that paid off?'
  ],
  loss: [
    'Did you experience a significant financial loss or setback?',
    'Did you go through a period of debt or financial difficulty?'
  ],
  separation: [
    'Did an important relationship end (marriage, partnership, close friendship)?',
    'Did you separate from or lose a significant person in your life?'
  ],
  fatherEvent: [
    'Did your father experience a significant health issue or life change?',
    'Did your father pass away or move away during this period?'
  ],
  motherEvent: [
    'Did your mother experience a significant health issue or life change?',
    'Did your mother pass away or move away during this period?'
  ],
  spiritual: [
    'Did you have a significant spiritual awakening or begin a spiritual practice?',
    'Did you connect with a guru, teacher, or spiritual community?'
  ]
};

// ── Planet → expected domains during MD/AD ────────────────────────────────────
// Based on PVR Ch.8, Ch.13 planet karakatva + functional nature
function getExpectedDomains(mdLord, adLord, bodies, lagnaCode, karakas) {
  const domains = [];
  const added = new Set();

  function add(d) { if (!added.has(d)) { domains.push(d); added.add(d); } }

  // Primary domain from MD lord
  const mdSig = MD_SIGNIFICATIONS[mdLord];
  if (mdSig) mdSig.domains.forEach(d => add(d));

  // Chara karaka connections (HIGHEST priority)
  if (karakas?.DK === mdLord || karakas?.DK === adLord) add('marriage');
  if (karakas?.AMK === mdLord || karakas?.AMK === adLord) add('career');
  if (karakas?.PK === mdLord || karakas?.PK === adLord) add('children');
  if (karakas?.MK === mdLord || karakas?.MK === adLord) add('motherEvent');
  if (karakas?.BK === mdLord || karakas?.BK === adLord) add('fatherEvent');
  if (karakas?.GK === mdLord || karakas?.GK === adLord) add('health');

  // AD lord adds secondary domains
  const adSig = MD_SIGNIFICATIONS[adLord];
  if (adSig) adSig.domains.slice(0, 2).forEach(d => add(d));

  // Natural karaka connections
  if (mdLord === 'Jupiter' || adLord === 'Jupiter') { add('marriage'); add('children'); add('wealth'); }
  if (mdLord === 'Venus'   || adLord === 'Venus')   { add('marriage'); add('wealth'); }
  if (mdLord === 'Saturn'  || adLord === 'Saturn')  { add('career'); add('health'); }
  if (mdLord === 'Sun')                              { add('career'); add('fatherEvent'); }
  if (mdLord === 'Moon')                             { add('motherEvent'); add('property'); add('foreign'); }
  if (mdLord === 'Mars')                             { add('property'); add('health'); }
  if (mdLord === 'Mercury')                          { add('career'); add('education'); }
  if (mdLord === 'Rahu'    || adLord === 'Rahu')    { add('foreign'); add('career'); }
  if (mdLord === 'Ketu'    || adLord === 'Ketu')    { add('spiritual'); add('separation'); }

  return domains;
}

/**
 * BTR Question Types:
 * 1. Specific Events (marriage, job etc.)
 * 2. Period Quality (good/bad phase)
 * 3. Personality Traits (lagna + Moon based)
 */

const BTR_PERIOD_QUALITY = {
  Sun:     { good: 'recognition, authority, leadership, confidence', bad: 'ego conflicts, health issues, father concerns' },
  Moon:    { good: 'emotional fulfillment, family harmony, public success', bad: 'anxiety, mental stress, family issues' },
  Mars:    { good: 'energy, courage, physical vitality, action', bad: 'accidents, conflicts, anger, surgery' },
  Mercury: { good: 'sharp intellect, business success, communication wins', bad: 'nervous issues, business disputes, confusion' },
  Jupiter: { good: 'expansion, wisdom, financial growth, luck', bad: 'overconfidence, weight gain, children concerns' },
  Venus:   { good: 'relationships, comfort, beauty, creative success', bad: 'relationship complications, overspending' },
  Saturn:  { good: 'disciplined growth, career stability, hard-earned success', bad: 'delays, depression, obstacles, loneliness' },
  Rahu:    { good: 'unconventional success, foreign gains, sudden rise', bad: 'confusion, deception, illusion, sudden reversals' },
  Ketu:    { good: 'spiritual clarity, past skills resurfacing, research', bad: 'losses, isolation, mysterious health issues, endings' }
};

const BTR_PERSONALITY_TRAITS = {
  Ta: [
    { q: 'Do you find comfort in routine, stability, and material security?', expected: true },
    { q: 'Are you known for being patient, steady, and reliable?', expected: true },
    { q: 'Do you enjoy beauty, good food, music, or arts in daily life?', expected: true },
    { q: 'Do you tend to resist change and prefer to stick to what works?', expected: true },
  ],
  Ge: [
    { q: 'Are you quick-thinking, curious, and enjoy variety in life?', expected: true },
    { q: 'Do you have good communication skills and adapt easily?', expected: true },
  ],
  Cn: [
    { q: 'Are you emotionally sensitive and deeply connected to family?', expected: true },
    { q: 'Do you tend to be nurturing and protective of loved ones?', expected: true },
  ],
  Le: [
    { q: 'Do you naturally take leadership roles and enjoy recognition?', expected: true },
    { q: 'Are you generous, warm-hearted, and drawn to creative expression?', expected: true },
  ],
  Vi: [
    { q: 'Are you detail-oriented, analytical, and drawn to precision?', expected: true },
    { q: 'Do you tend to be critical (of yourself or others) and health-conscious?', expected: true },
  ],
  Li: [
    { q: 'Do you value harmony, beauty, and balanced relationships?', expected: true },
    { q: 'Are you naturally diplomatic and good at seeing both sides?', expected: true },
  ],
  Sc: [
    { q: 'Are you intense, perceptive, and drawn to depth/mystery?', expected: true },
    { q: 'Do you have strong emotional reactions but keep them private?', expected: true },
  ],
  Sg: [
    { q: 'Do you love freedom, philosophy, and expanding your horizons?', expected: true },
    { q: 'Are you optimistic, direct, and drawn to wisdom/teaching?', expected: true },
  ],
  Cp: [
    { q: 'Are you disciplined, ambitious, and focused on long-term goals?', expected: true },
    { q: 'Do you take responsibilities seriously and build things steadily?', expected: true },
  ],
  Aq: [
    { q: 'Are you drawn to ideas, reform, and unconventional thinking?', expected: true },
    { q: 'Do you value independence and have a humanitarian streak?', expected: true },
  ],
  Pi: [
    { q: 'Are you imaginative, empathetic, and spiritually inclined?', expected: true },
    { q: 'Do you tend to be selfless and drawn to artistic or mystical pursuits?', expected: true },
  ],
  Ar: [
    { q: 'Are you energetic, pioneering, and quick to start new things?', expected: true },
    { q: 'Do you have a competitive, independent spirit?', expected: true },
  ],
};

function generateBTRQuestions(chart, options = {}) {
  const { fromAge = 18, toAge = 65, maxQ = 15 } = options;
  const birthYear = chart.native?.year || 1976;
  const karakas   = chart.analysis?.jaimini?.allCharaKarakas || {};
  const bodies    = chart.bodies || {};
  const lagnaCode = chart.lagna?.signCode;
  const moonCode  = bodies?.Moon?.signCode;
  const gender    = chart.native?.gender || 'female';
  const questions = [];
  const usedDomains = new Set();

  // Type 3: Personality traits (Lagna)
  const lagnaTraits = BTR_PERSONALITY_TRAITS[lagnaCode] || [];
  lagnaTraits.slice(0,2).forEach((trait,i) => {
    questions.push({
      id:`personality_lagna_${i}`, type:'personality',
      periodLabel:`${lagnaCode} Lagna`, ageLabel:'Lifetime', domain:'personality',
      question:trait.q,
      chartPrediction:`${lagnaCode} Lagna: classic trait (PVR Ch.2)`,
      expectedAnswer:trait.expected, answer:null
    });
  });

  // Moon sign trait
  if (moonCode && moonCode !== lagnaCode) {
    const moonTraits = BTR_PERSONALITY_TRAITS[moonCode] || [];
    if (moonTraits[0]) {
      questions.push({
        id:'personality_moon_0', type:'personality',
        periodLabel:`${moonCode} Moon`, ageLabel:'Lifetime', domain:'personality',
        question:moonTraits[0].q,
        chartPrediction:`Moon in ${moonCode}: emotional nature`,
        expectedAnswer:moonTraits[0].expected, answer:null
      });
    }
  }

  // Dasha-based questions
  const dashas = Array.isArray(chart.vimshottariDashas)
    ? chart.vimshottariDashas
    : Object.values(chart.vimshottariDashas || {});

  let eventQ = 0, qualityQ = 0;

  for (const md of dashas) {
    if (!md.antardashas) continue;
    for (const ad of md.antardashas) {
      const adYear = new Date(ad.startDate).getFullYear();
      const adAge  = adYear - birthYear;
      if (adAge < fromAge || adAge > toAge) continue;
      if (questions.length >= maxQ) break;

      const mdLord = md.lord, adLord = ad.lord;
      const useQuality = (qualityQ < 4 && eventQ >= qualityQ + 2);

      if (useQuality) {
        const quality = BTR_PERIOD_QUALITY[mdLord];
        if (quality) {
          questions.push({
            id:`period_${mdLord}_${adLord}_${ad.startDate.slice(0,7)}`,
            type:'period_quality',
            periodLabel:`${mdLord} MD / ${adLord} AD`,
            ageLabel:`age ${adAge}`,
            startDate: ad.startDate,
            endDate: ad.endDate,
            domain:'period_quality',
            question:`From ${ad.startDate.slice(0,7).replace('-','/')} to ${ad.endDate?.slice(0,7).replace('-','/')||'...'} — was this overall a positive and fulfilling phase of life?`,
            chartPrediction:`${mdLord} MD positive themes: ${quality.good}`,
            negativeIndication:`${mdLord} MD difficult themes: ${quality.bad}`,
            expectedAnswer:null, answer:null
          });
          qualityQ++;
        }
      } else {
        const domains = getExpectedDomains(mdLord, adLord, bodies, lagnaCode, karakas);
        const lastDomain = questions.filter(q=>q.type==='event').slice(-1)[0]?.domain;
        const freshDomain = domains.find(d => {
          const c = [...usedDomains].filter(u=>u===d).length;
          return c < 2 && d !== lastDomain;
        }) || domains.find(d => [...usedDomains].filter(u=>u===d).length < 2);
        if (!freshDomain) continue;
        const templates = QUESTION_TEMPLATES[freshDomain] || [];
        if (!templates.length) continue;
        const tidx = questions.filter(q=>q.domain===freshDomain).length % templates.length;
        questions.push({
          id:`event_${mdLord}_${adLord}_${ad.startDate.slice(0,7)}`,
          type:'event',
          periodLabel:`${mdLord} MD / ${adLord} AD`,
          ageLabel:`age ${adAge}`,
          startDate: ad.startDate,
          endDate: ad.endDate,
          domain:freshDomain,
          question:templates[tidx],
          chartPrediction:buildChartPrediction(mdLord, adLord, freshDomain, karakas, gender),
          expectedAnswer:null, answer:null
        });
        usedDomains.add(freshDomain);
        eventQ++;
      }
    }
    if (questions.length >= maxQ) break;
  }

  return questions;
}




function buildChartPrediction(mdLord, adLord, domain, karakas, gender) {
  const predictions = [];

  // Why does chart expect this domain in this period?
  if (domain === 'marriage') {
    if (karakas.DK === mdLord) predictions.push(`${mdLord} is Darakaraka (DK — chara karaka of spouse) in MD`);
    if (karakas.DK === adLord) predictions.push(`${adLord} is Darakaraka (DK) in AD`);
    if (['Venus','Jupiter'].includes(mdLord)) predictions.push(`${mdLord} is natural karaka of marriage/relationships`);
    if (gender === 'female' && mdLord === 'Jupiter') predictions.push('Jupiter = sthira karaka of husband in female chart');
    if (gender === 'male' && mdLord === 'Venus') predictions.push('Venus = sthira karaka of wife in male chart');
  }
  if (domain === 'career') {
    if (karakas.AMK === mdLord) predictions.push(`${mdLord} is Amatyakaraka (AMK — career significator) in MD`);
    if (karakas.AMK === adLord) predictions.push(`${adLord} is Amatyakaraka in AD`);
    if (['Sun','Saturn'].includes(mdLord)) predictions.push(`${mdLord} is natural career significator`);
  }
  if (domain === 'children') {
    if (karakas.PK === mdLord) predictions.push(`${mdLord} is Putrakaraka (PK — children significator) in MD`);
    if (['Jupiter','Moon'].includes(mdLord)) predictions.push(`${mdLord} is natural significator of children`);
  }
  if (domain === 'fatherEvent') {
    if (karakas.PiK === mdLord || mdLord === 'Sun') predictions.push('Sun is natural karaka of father');
    if (mdLord === 'Saturn') predictions.push('Saturn = longevity significator; 9th house relates to father');
  }
  if (domain === 'motherEvent') {
    if (karakas.MK === mdLord) predictions.push(`${mdLord} is Matrikaraka (MK) in MD`);
    if (mdLord === 'Moon') predictions.push('Moon is natural karaka of mother');
  }

  if (!predictions.length) {
    const sig = MD_SIGNIFICATIONS[mdLord];
    if (sig) predictions.push(`${mdLord} MD activates: ${sig.domains.slice(0,3).join(', ')}`);
  }

  return predictions.join('; ');
}

/**
 * Score BTR answers against chart verification.
 * 
 * @param {object[]} questions  - from generateBTRQuestions, with .answer filled
 * @param {object}   chart      - full chart
 * @param {object}   transitFn  - function(date) → transit positions
 * @returns {object} BTR score result
 */
async function scoreBTRAnswers(questions, chart, transitFn) {
  const { verifyPastEvent } = require('../engine/event-verifier');

  const answered = questions.filter(q => q.answer !== null && q.answer !== undefined);
  if (!answered.length) return { score: null, message: 'No answers provided yet.' };

  const yesAnswers = answered.filter(q => q.answer === true);
  const noAnswers  = answered.filter(q => q.answer === false);

  let totalPoints = 0, earnedPoints = 0;
  const results = [];

  for (const q of answered) {
    totalPoints += 10;
    const gender = chart.native?.gender || 'female';

    // Map domain to event key
    const DOMAIN_TO_EVENT = {
      marriage: 'marriage', children: 'children', career: 'firstJob',
      property: 'housePurchase', health: 'majorIllness', foreign: 'foreignTravel',
      education: 'education', wealth: 'wealth', fatherEvent: 'deathOfFather',
      motherEvent: 'deathOfMother', spiritual: 'children' // approximation
    };
    const eventKey = DOMAIN_TO_EVENT[q.domain] || 'marriage';

    // Use midpoint of AD period for verification
    const midDate = q.startDate;

    let verificationScore = 0;
    try {
      const transitData = await transitFn(midDate);
      const vResult = verifyPastEvent({ eventKey, eventDate: midDate, eventLabel: q.question, chart, transitData, gender });
      verificationScore = vResult.finalScore || 0;
    } catch(e) {
      verificationScore = 30; // default if transit fails
    }

    const chartPredicts = verificationScore >= 45; // chart thinks event should happen

    // Scoring logic:
    // User said YES + Chart predicts YES → confirms chart (10 pts)
    // User said NO  + Chart predicts NO  → also confirms chart (8 pts)
    // User said YES + Chart predicts NO  → possible birth time issue (2 pts)
    // User said NO  + Chart predicts YES → possible birth time issue (3 pts)

    let pts = 0, interpretation = '';
    if (q.answer === true && chartPredicts) {
      pts = 10; interpretation = 'Chart confirms this event ✅';
    } else if (q.answer === false && !chartPredicts) {
      pts = 8; interpretation = 'Chart correctly predicted absence of this event ✅';
    } else if (q.answer === true && !chartPredicts) {
      pts = 2; interpretation = 'Event occurred but chart signal weak — possible birth time offset ⚠️';
    } else {
      pts = 3; interpretation = 'Chart expected this event but it didn\'t occur ⚠️';
    }

    earnedPoints += pts;

    results.push({
      questionId:     q.id,
      question:       q.question,
      period:         q.periodLabel,
      ageLabel:       q.ageLabel,
      domain:         q.domain,
      userAnswer:     q.answer,
      chartPredicts,
      verificationScore,
      points:         pts,
      maxPoints:      10,
      interpretation,
    });
  }

  const rawScore = totalPoints > 0 ? Math.round((earnedPoints / totalPoints) * 100) : 0;

  // Reliability assessment
  let reliability, message, recommendation;
  if (rawScore >= 70) {
    reliability = 'high';
    message = 'Birth time is reliable. Charts can be trusted for analysis.';
    recommendation = 'Proceed with predictions. Divisional charts (D9, D10, D60) can be used confidently.';
  } else if (rawScore >= 50) {
    reliability = 'moderate';
    message = 'Birth time is probably close but may need minor adjustment.';
    recommendation = 'Use D1 and D9 analysis confidently. Be cautious with D10, D12, D60.';
  } else if (rawScore >= 35) {
    reliability = 'low';
    message = 'Birth time may be off by 30–60 minutes. Rectification recommended.';
    recommendation = 'Use Lagna and Moon analysis primarily. Avoid birth-time-sensitive charts.';
  } else {
    reliability = 'very_low';
    message = 'Birth time appears significantly wrong. Major rectification needed.';
    recommendation = 'Focus on Moon sign analysis only. Do not use Lagna-sensitive techniques.';
  }

  return {
    score: rawScore,
    reliability,
    message,
    recommendation,
    answeredCount: answered.length,
    yesCount: yesAnswers.length,
    noCount: noAnswers.length,
    earnedPoints,
    totalPoints,
    results,
  };
}

module.exports = { generateBTRQuestions, scoreBTRAnswers, MD_SIGNIFICATIONS, QUESTION_TEMPLATES };
