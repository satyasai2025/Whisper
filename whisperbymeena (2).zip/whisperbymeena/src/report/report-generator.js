/**
 * Report Generator
 *
 * Consolidates a fully-parsed + analyzed chart (and its logged events)
 * into a single, self-contained, printable HTML document. Design goals:
 *
 *  - SELF-CONTAINED: all CSS inlined, no external assets — the file opens
 *    and prints correctly offline, anywhere.
 *  - PRINT-FRIENDLY: a print stylesheet makes "Save as PDF" from the
 *    browser produce a clean document (the user's stated lightweight,
 *    no-heavy-library preference — no server-side PDF engine needed).
 *  - FAITHFUL TO THE TOOL'S ETHOS: every confidence flag, source citation,
 *    and caveat that appears in the live UI also appears in the report.
 *    The report does not "upgrade" interpretive rules into facts or strip
 *    caveats for brevity — that would defeat the whole point.
 *
 * This module produces a STRING of HTML. The server serves it with a
 * Content-Disposition header so the browser offers it as a download.
 */

function esc(s) {
  if (s === null || s === undefined) return '';
  return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

const ORD = n => ({ 1:'1st',2:'2nd',3:'3rd',4:'4th',5:'5th',6:'6th',7:'7th',8:'8th',9:'9th',10:'10th',11:'11th',12:'12th' }[n] || `${n}th`);

function section(title, inner) {
  if (!inner) return '';
  return `<section><h2>${esc(title)}</h2>${inner}</section>`;
}

function table(headers, rows) {
  if (!rows.length) return '<p class="muted">None.</p>';
  return `<table>
    <thead><tr>${headers.map(h => `<th>${esc(h)}</th>`).join('')}</tr></thead>
    <tbody>${rows.map(r => `<tr>${r.map(c => `<td>${c}</td>`).join('')}</tr>`).join('')}</tbody>
  </table>`;
}

function renderNativeBlock(native, panchanga) {
  if (!native) return '';
  const rows = [
    ['Name', esc(native.name)],
    ['Date of birth', esc(native.dateOfBirth)],
    ['Time of birth', esc(native.timeOfBirth)],
    ['Place', esc(native.placeOfBirth)],
    ['Coordinates', native.coordinates ? `${native.coordinates.latitude}, ${native.coordinates.longitude}` : '—']
  ];
  if (panchanga) {
    rows.push(['Janma Nakshatra', esc(panchanga.janmaNakshatra)]);
    rows.push(['Tithi', esc(panchanga.tithi)]);
    rows.push(['Vaar', esc(panchanga.vaar)]);
  }
  return `<table class="kv">${rows.map(([k, v]) => `<tr><th>${k}</th><td>${v}</td></tr>`).join('')}</table>`;
}

function renderBodiesBlock(bodies) {
  const order = ['Lagna', 'Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn', 'Rahu', 'Ketu'];
  const rows = order.filter(n => bodies[n]).map(n => {
    const b = bodies[n];
    return [esc(n), `${b.degrees}° ${esc(b.sign)}`, `${esc(b.nakshatra)}-${b.pada}`, `H${b.house}`, esc(b.navamsa), b.charaKaraka ? esc(b.charaKaraka) : '—'];
  });
  return table(['Body', 'Position', 'Nakshatra', 'House', 'Navamsa', 'Karaka'], rows);
}

function renderFunctionalNature(fn) {
  if (!fn?.classifications) return '';
  const rows = Object.entries(fn.classifications)
    .filter(([, c]) => c.classification !== 'Not classified')
    .map(([p, c]) => {
      const flags = [];
      if (c.isYogakaraka) flags.push('Yogakaraka');
      if (c.isMaraka) flags.push('Maraka');
      if (c.isBadhakesh) flags.push('Badhakesh');
      return [esc(p), esc(c.classification), c.housesRuled ? c.housesRuled.join(', ') : '—', flags.join(', ') || '—'];
    });
  let html = '';
  if (fn.badhaka) html += `<p class="muted">Badhaka house: ${fn.badhaka.badhakaHouse} (${esc(fn.badhaka.badhakaSign)}) — Badhakesh: ${esc(fn.badhaka.badhakesh)}</p>`;
  return html + table(['Planet', 'Functional Nature', 'Rules', 'Flags'], rows);
}

function renderDignity(dig) {
  if (!dig?.classifications) return '';
  const rows = Object.entries(dig.classifications).map(([p, d]) => [esc(p), esc(d.tier), esc(d.detail)]);
  return table(['Planet', 'Dignity', 'Detail'], rows);
}

function renderDignityShort(dig) {
  if (!dig?.classifications) return '';
  const rows = Object.entries(dig.classifications).map(([p, d]) => [esc(p), esc(d.tier)]);
  return table(['Planet', 'Dignity'], rows);
}

function renderNavamsa(nav) {
  if (!nav || nav._warning) return `<p class="muted">${esc(nav?._warning || 'Not available.')}</p>`;
  let html = `<p class="caveat">${esc(nav.birthTimeCaveat)}</p>`;
  html += `<p class="muted">D9 Lagna: ${esc(nav.d9LagnaSign)}</p>`;
  const rows = Object.entries(nav.confirmation).map(([p, c]) =>
    [esc(p) + (c.isVargottama ? ' (Vargottama)' : ''), esc(c.d1Tier), esc(c.d9Tier), esc(c.read)]);
  return html + table(['Planet', 'D1', 'D9', 'Confirmation'], rows);
}

function renderJaimini(j) {
  if (!j || j._warning) return `<p class="muted">${esc(j?._warning || 'Not available.')}</p>`;
  const ak = j.atmakaraka, kl = j.karakamsaLagna, id = j.ishtaDevataIndicators;
  return `
    <p class="caveat">${esc(j.caveats.birthTime)}</p>
    <table class="kv">
      <tr><th>Atmakaraka</th><td>${esc(ak.planet)} — ${esc(ak.d1Sign)} ${ak.d1DegreeInSign}°, House ${ak.d1House}, ${esc(ak.nakshatra)} (pada ${ak.nakshatraPada})</td></tr>
      <tr><th>Karakamsa Lagna</th><td>${esc(kl.sign)} — occupants: ${esc(kl.occupants.join(', ') || 'none')}</td></tr>
      <tr><th>Ishta Devata indicators</th><td>12th from KL: ${esc(id.twelfthFromKarakamsa)}, lord ${esc(id.twelfthLord)}${id.twelfthOccupants.length ? ', occupants: ' + esc(id.twelfthOccupants.join(', ')) : ''} <em>(indicators only — no deity named)</em></td></tr>
    </table>`;
}

function renderYogas(yogas) {
  if (!yogas) return '';
  let html = '';
  const block = (title, items) => {
    if (!items || items.length === 0) return `<p><strong>${title}:</strong> <span class="muted">none detected</span></p>`;
    return `<p><strong>${title}:</strong></p><ul>${items.map(i => `<li>${esc(i)}</li>`).join('')}</ul>`;
  };
  html += block('Parivartana', yogas.parivartana.map(p => p.detail));
  html += block('Gajakesari', yogas.gajakesari ? [yogas.gajakesari.detail] : []);
  html += block('Raja Yoga', yogas.rajaYogas.map(r => r.detail));
  html += block('Dhana Yoga', yogas.dhanaYogas.map(d => d.detail));
  html += block('Vipreet Raja Yoga', yogas.vipreetRajaYogas.map(v => `${v.name}: ${v.detail}`));
  return html;
}

function renderArudhas(aru) {
  if (!aru?.arudhas) return '';
  const rows = Object.entries(aru.arudhas).map(([k, a]) => {
    if (a.error) return [esc(k), esc(a.error), '', ''];
    return [esc(k) + (a.alias ? ` (${esc(a.alias)})` : ''), `H${a.bhava} ${esc(a.bhavaSign)}`, esc(a.lord), `H${a.finalArudhaHouse}`];
  });
  return table(['Arudha', 'Bhava', 'Lord', 'Result'], rows);
}

function renderClassicalRules(rules) {
  if (!rules || !rules.length) return '<p class="muted">No rules matched.</p>';
  const special = rules.filter(r => r.category === 'special');
  const houseLord = rules.filter(r => r.category === 'house-lord-placement');

  const ruleLine = r => `
    <div class="rule">
      <span class="badge badge-${esc(r.sourceConfidence)}">${esc(r.sourceConfidence)}</span>
      <strong>${esc(r.trigger)}</strong>
      <div>${esc(r.effect)}</div>
      <div class="src">— ${esc(r.source.text)}${r.source.area ? ', ' + esc(r.source.area) : ''}</div>
      ${r.caveat ? `<div class="caveat">⚠ ${esc(r.caveat)}</div>` : ''}
    </div>`;

  let html = special.map(ruleLine).join('');
  html += `<h3>House-lord placements (${houseLord.length})</h3>`;
  html += houseLord.map(ruleLine).join('');
  html += `<p class="caveat">Confidence flags: <strong>direct</strong> = widely-agreed classical statement; <strong>interpretive</strong> = paraphrase, verify exact wording; <strong>synthesized</strong> = combined/modern practice. This is a curated subset of testable hypotheses, not the whole of any text, and never a fixed prediction.</p>`;
  return html;
}

function fmtDashaCtx(ctx) {
  if (!ctx) return '—';
  if (ctx.mahadasha !== undefined) return `${esc(ctx.mahadasha)}${ctx.antardasha ? ' → ' + esc(ctx.antardasha) : ''}${ctx.pratyantardasha ? ' → ' + esc(ctx.pratyantardasha) : ''}`;
  if (ctx.major !== undefined) return `${esc(ctx.major)}${ctx.sub ? ' → ' + esc(ctx.sub) : ''}`;
  return '—';
}

const DASHA_LABELS = {
  vimshottari: 'Vimshottari', narayana: 'Narayana', ashtottari: 'Ashtottari',
  moola: 'Moola', yogini: 'Yogini', vimshottariTribhagi: 'Vim. Tribhagi',
  kalachakra: 'Kalachakra', sudasa: 'Sudasa', lagnaKendradi: 'Lagna Kendradi',
  drigdasa: 'Drigdasa', shoola: 'Shoola', niryanaShoola: 'Niryana Shoola'
};

function renderEvents(events) {
  if (!events || !events.length) return '<p class="muted">No events logged.</p>';
  const sorted = [...events].sort((a, b) => a.date.localeCompare(b.date));
  return sorted.map(ev => {
    const dc = ev.dashaContext || {};
    const dashaRows = Object.entries(DASHA_LABELS)
      .filter(([k]) => dc[k])
      .map(([k, label]) => `<tr><th>${label}</th><td>${fmtDashaCtx(dc[k])}</td></tr>`).join('');

    let convHtml = '';
    if (ev.convergence && ev.convergence.houseConvergence) {
      const dyn = ev.convergence.houseConvergence.filter(h => h.dynamicCount > 0).slice(0, 5);
      if (dyn.length) {
        convHtml = `<table><thead><tr><th>House</th><th>Theme</th><th>Active lords</th><th>How</th></tr></thead><tbody>` +
          dyn.map(h => `<tr><td>H${h.house}</td><td>${esc(h.themes.slice(0, 2).join(' / '))}</td><td>${h.dynamicCount}</td><td>${h.viaRulership.length ? 'rules: ' + esc(h.viaRulership.join(', ')) : ''}${h.viaAspect.length ? '; aspects: ' + esc(h.viaAspect.join(', ')) : ''}</td></tr>`).join('') +
          `</tbody></table>`;
      }
    }

    return `
      <div class="event">
        <div class="event-head"><strong>${esc(ev.date)}</strong> — <span class="cat">${esc(ev.category)}</span> — ${esc(ev.description)}</div>
        <table class="kv">${dashaRows}</table>
        ${convHtml ? `<p class="muted">Indicator convergence (dynamic — rulership/aspect of active lords):</p>${convHtml}` : ''}
      </div>`;
  }).join('');
}

function generateReport(chart, events) {
  const a = chart.analysis || {};
  const native = chart.native || {};
  const generatedAt = new Date().toISOString().split('T')[0];

  const body = [
    section('Native & Panchanga', renderNativeBlock(native, chart.panchanga)),
    section('Planetary Positions', renderBodiesBlock(chart.bodies || {})),
    section('Functional Nature (this Lagna)', renderFunctionalNature(a.functionalNature)),
    section('Dignity (Avastha)', renderDignity(a.dignity)),
    section('D9 (Navamsa) — D1 Confirmation', renderNavamsa(a.navamsa)),
    section('Atmakaraka & Karakamsa Lagna (Jaimini)', renderJaimini(a.jaimini)),
    section('Yogas', renderYogas(a.yogas)),
    section('Arudha Padas', renderArudhas(a.arudhas)),
    section('Classical Rules (this chart)', renderClassicalRules(a.matchedRules)),
    section('Personal Events & Convergence', renderEvents(events))
  ].join('');

  return `<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<title>Jyotish Report — ${esc(native.name || 'Chart')}</title>
<style>
  body { font-family: Georgia, 'Times New Roman', serif; color: #2c2520; max-width: 900px; margin: 0 auto; padding: 32px 24px; line-height: 1.5; }
  h1 { font-size: 1.8rem; border-bottom: 3px solid #8b7355; padding-bottom: 8px; margin-bottom: 4px; }
  .subtitle { color: #8b7355; margin-bottom: 28px; font-size: 0.9rem; }
  h2 { font-size: 1.25rem; color: #5c4a35; border-bottom: 1px solid #d4c4a8; padding-bottom: 4px; margin-top: 28px; }
  h3 { font-size: 1rem; color: #6b5535; margin-top: 16px; }
  table { border-collapse: collapse; width: 100%; margin: 10px 0; font-size: 0.85rem; }
  th, td { border: 1px solid #e0d5c0; padding: 6px 9px; text-align: left; vertical-align: top; }
  th { background: #f5ede0; color: #5c4a35; }
  table.kv th { width: 200px; }
  .muted { color: #8b7355; font-size: 0.85rem; }
  .caveat { color: #8a5a24; font-size: 0.8rem; background: #faf3e6; padding: 6px 10px; border-left: 3px solid #c0a060; margin: 8px 0; }
  ul { margin: 4px 0 12px; padding-left: 22px; }
  li { margin-bottom: 3px; font-size: 0.85rem; }
  .rule { margin-bottom: 10px; padding: 8px 10px; background: #fbf8f2; border-left: 2px solid #d4c4a8; font-size: 0.84rem; }
  .rule .src { color: #8b7355; font-style: italic; font-size: 0.78rem; margin-top: 2px; }
  .badge { display: inline-block; font-size: 0.66rem; padding: 1px 6px; border-radius: 8px; text-transform: uppercase; margin-right: 4px; }
  .badge-direct { background: #d6e8c8; color: #2e4a1f; }
  .badge-interpretive { background: #f5e6c8; color: #7a5a1f; }
  .badge-synthesized { background: #e0dcf0; color: #443a6a; }
  .event { margin-bottom: 18px; padding: 10px 12px; border: 1px solid #e0d5c0; border-radius: 4px; }
  .event-head { margin-bottom: 6px; }
  .cat { text-transform: uppercase; font-size: 0.75rem; color: #8b7355; letter-spacing: 0.5px; }
  .footer { margin-top: 40px; padding-top: 16px; border-top: 1px solid #d4c4a8; color: #8b7355; font-size: 0.78rem; }
  @media print {
    body { padding: 0; max-width: none; }
    section { page-break-inside: avoid; }
    h2 { page-break-after: avoid; }
    .event, .rule { page-break-inside: avoid; }
  }
</style></head>
<body>
  <h1>Jyotish Analysis Report</h1>
  <div class="subtitle">${esc(native.name || 'Chart')} · Generated ${generatedAt} · Taurus-style auditable analysis</div>
  ${body}
  <div class="footer">
    Generated by WhisperByMeena. This report consolidates classical indicators and hypotheses with their sources and confidence flags.
    It does not predict outcomes — it lays out evidence for the reader to interpret. Birth-time-sensitive layers (D9, Karakamsa) are
    flagged accordingly. Classical rules are a curated subset of testable hypotheses, not the whole of any text.
  </div>
</body></html>`;
}

module.exports = { generateReport };
