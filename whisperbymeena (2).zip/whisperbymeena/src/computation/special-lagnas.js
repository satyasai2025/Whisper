/**
 * Special Lagnas — BL, HL, GL, SL
 * Source: PVR Narasimha Rao "Vedic Astrology: An Integrated Approach" Ch.5
 *
 * Ch.5.2 Bhaava Lagna (BL) — p.45-46
 *   "moves at rate of 1° per 4 minutes (15° per hour)"
 *   Formula: Sun_at_sunrise + elapsed_minutes_since_sunrise
 *   Note: "BL is defined only for completeness. We will not use it in this book." (footnote 10)
 *
 * Ch.5.3 Hora Lagna (HL) — p.46-47
 *   "moves at rate of 1/2° per minute (30° per hour)"
 *   Formula: Sun_at_sunrise + elapsed_minutes / 2
 *   Use: "HL shows money and wealth" (p.49)
 *
 * Ch.5.4 Ghati Lagna (GL) — p.47-48
 *   "moves at rate of 1°15' per minute (75° per hour)"
 *   Formula: Sun_at_sunrise + elapsed_minutes × 5/4
 *   Use: "GL shows power and authority" (p.49)
 *   Warning: "GL is more sensitive to birthtime errors than normal lagna" (p.48)
 *            "If birthtime changes by 1 minute, GL changes by 1.25°"
 *
 * Ch.5.7 Sree Lagna (SL) — p.49+
 *   Used in Sudasa computation (Ch.20)
 *   Formula: fraction_of_nakshatra_traversed_by_Moon × 360 + Lagna_longitude
 *   "Sree Lagna moves twice as fast as lagna" (p.439)
 *
 * Validated examples in book:
 *   Example 7 (BL): elapsed=766 min, Sun_sunrise=294°17' → BL=340°17' (Pi 10°17')
 *   Example 8 (HL): elapsed=766 min, Sun_sunrise=294°17' → HL=317°17' (Aq 17°17')
 *   Example 9 (GL): elapsed=766 min, Sun_sunrise=294°17' → GL=171°47' (Vi 21°47')
 */

'use strict';

const SIGN_NAMES = [
  'Aries','Taurus','Gemini','Cancer','Leo','Virgo',
  'Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'
];
const SIGN_CODES = ['Ar','Ta','Ge','Cn','Le','Vi','Li','Sc','Sg','Cp','Aq','Pi'];

function lonToSign(lon) {
  const l = ((lon % 360) + 360) % 360;
  const idx = Math.floor(l / 30);
  return {
    longitude: l,
    signIndex: idx,
    sign: SIGN_NAMES[idx],
    signCode: SIGN_CODES[idx],
    degreeInSign: l % 30
  };
}

/**
 * Compute Bhaava Lagna (BL).
 * Source: Ch.5.2, Example 7
 *
 * @param {number} sunAtSunrise  - Sun's sidereal longitude at sunrise (degrees)
 * @param {number} elapsedMinutes - minutes elapsed from sunrise to birth time
 * @returns {object} BL sign info
 */
function computeBL(sunAtSunrise, elapsedMinutes) {
  // Ch.5.2: "advancement of BL since sunrise = elapsed minutes (in degrees)"
  // i.e. 1° per minute → BL moves 1° per 4 minutes... wait:
  // "moves at 1° per 4 minutes" = 15° per hour = elapsed_minutes × (1/4)... 
  // BUT Example 7: elapsed=766 min → advancement=766°
  // That means 1° per 1 minute... but book says 1° per 4 minutes?
  // Re-reading: "Convert the difference into minutes. The result is the
  //  advancement of bhavalagna since sunrise, in degrees."
  // 766 min → 766° advancement → confirms 1° per minute for BL
  // This contradicts "15° per hour"? Let me re-check:
  // "moves at rate of one rasi per 2 hours" = 30° per 2 hours = 15° per hour
  // 15° per hour = 15/60 per minute = 0.25° per minute
  // But example says 766 min → 766°... 
  // Wait, re-reading p.45: "BL moves at 1° per 4 minutes"
  // 1° per 4 min = 0.25°/min. So 766 min × 0.25 = 191.5°
  // 294.283 + 191.5 = 485.783 → -360 = 125.783° = Le 5°47' NOT Pi 10°17'
  // But book example says Pi 10°17'...
  // Let me re-read the formula step:
  // "(2) Find the difference between birthtime and sunrise time. Convert to minutes."
  // "(3) Add Sun's longitude at sunrise to the above number."
  // i.e. step 3 says ADD THE MINUTES DIRECTLY (not multiply by 0.25)
  // So: 294.283 + 766 = 1060.283 - 720 = 340.283° = Pi 10°17' ✓ MATCHES EXAMPLE
  // Conclusion: The formula is Sun_sunrise + elapsed_minutes (direct addition, no multiplier)
  // This means BL moves 1° per minute = 60°/hour = 1 rasi per 30 minutes?
  // But book says "1 rasi per 2 hours"... this is a contradiction in the book text
  // Resolution: The EXAMPLE is the authoritative check. Follow the example, not the prose.
  // BL = Sun_sunrise + elapsed_minutes (degrees)
  const lon = ((sunAtSunrise + elapsedMinutes) % 360 + 360) % 360;
  return lonToSign(lon);
}

/**
 * Compute Hora Lagna (HL).
 * Source: Ch.5.3, Example 8 (validated)
 *
 * @param {number} sunAtSunrise  - Sun's sidereal longitude at sunrise (degrees)
 * @param {number} elapsedMinutes - minutes elapsed from sunrise to birth time
 * @returns {object} HL sign info
 */
function computeHL(sunAtSunrise, elapsedMinutes) {
  // Ch.5.3 formula step (3): "Divide the number [elapsed minutes] by 2.
  //   The result is the advancement of horalagna since sunrise, in degrees."
  // Example 8: 766/2 = 383; 294.283 + 383 = 677.283; -360 = 317.283° = Aq 17°17' ✓
  const advancement = elapsedMinutes / 2;
  const lon = ((sunAtSunrise + advancement) % 360 + 360) % 360;
  return lonToSign(lon);
}

/**
 * Compute Ghati Lagna (GL).
 * Source: Ch.5.4, Example 9 (validated)
 *
 * @param {number} sunAtSunrise  - Sun's sidereal longitude at sunrise (degrees)
 * @param {number} elapsedMinutes - minutes elapsed from sunrise to birth time
 * @returns {object} GL sign info + sensitivity warning
 */
function computeGL(sunAtSunrise, elapsedMinutes) {
  // Ch.5.4 formula step (3): "Multiply the number by 5. Divide by 4.
  //   The result is the advancement of ghatilagna since sunrise, in degrees."
  // Example 9: 766 × 5/4 = 957.5; 294.283 + 957.5 = 1251.783; -1080 = 171.783° = Vi 21°47' ✓
  const advancement = (elapsedMinutes * 5) / 4;
  const lon = ((sunAtSunrise + advancement) % 360 + 360) % 360;
  return {
    ...lonToSign(lon),
    // Ch.5.5 (1): "If birthtime changes by 1 minute, GL changes by 1.25°"
    sensitivityPerMinute: 1.25,
    warning: 'GL changes 1.25° per minute of birth time error (Ch.5.5). Use only with reliable birth time.'
  };
}

/**
 * Compute Sree Lagna (SL).
 * Source: Ch.5.7; also Ch.20 (Sudasa uses SL as seed)
 *
 * Formula (Ch.5.7):
 *   (1) Find nakshatra occupied by Moon
 *   (2) Find fraction of nakshatra traversed by Moon
 *   (3) Find same fraction of zodiac (360°)
 *   (4) Add Lagna longitude to the above
 *   (5) Expunge multiples of 360°
 *
 * Sensitivity (p.439): "Sree Lagna moves twice as fast as lagna"
 * "If birthtime changes by m minutes, SL changes by m/2 degrees"
 *
 * @param {number} moonLon   - Moon's sidereal longitude (degrees)
 * @param {number} lagnaLon  - Lagna sidereal longitude (degrees)
 * @returns {object} SL sign info
 */
function computeSL(moonLon, lagnaLon) {
  const NAK_SPAN = 360 / 27; // 13.333°
  const moonL = ((moonLon % 360) + 360) % 360;

  // Step 2: fraction of nakshatra already traversed
  const degInNak = moonL % NAK_SPAN;
  const fraction = degInNak / NAK_SPAN; // 0 to 1

  // Step 3: same fraction of zodiac
  const fractionOfZodiac = fraction * 360;

  // Step 4: add Lagna longitude
  const slLon = ((lagnaLon + fractionOfZodiac) % 360 + 360) % 360;

  return {
    ...lonToSign(slLon),
    sensitivityPerMinute: 0.5, // p.439: SL moves m/2 degrees per m minutes of birth time error
    note: 'SL is seed for Sudasa computation (Ch.20). Sensitivity: 0.5°/min of birth time error.'
  };
}

/**
 * Compute all special lagnas.
 * Requires: Sun longitude at sunrise, elapsed minutes since sunrise, Moon longitude, Lagna longitude.
 *
 * @param {object} params
 * @param {number} params.sunAtSunrise   - Sun sidereal longitude at sunrise
 * @param {number} params.elapsedMinutes - minutes from sunrise to birth time
 * @param {number} params.moonLon        - Moon sidereal longitude at birth
 * @param {number} params.lagnaLon       - Lagna sidereal longitude at birth
 * @returns {object} { BL, HL, GL, SL }
 */
function computeSpecialLagnas({ sunAtSunrise, elapsedMinutes, moonLon, lagnaLon }) {
  return {
    BL: computeBL(sunAtSunrise, elapsedMinutes),
    HL: computeHL(sunAtSunrise, elapsedMinutes),
    GL: computeGL(sunAtSunrise, elapsedMinutes),
    SL: computeSL(moonLon, lagnaLon)
  };
}

module.exports = { computeSpecialLagnas, computeBL, computeHL, computeGL, computeSL };
