/**
 * Planetary Relationships (Graha Maitri)
 *
 * Source hierarchy: BPHS (Brihat Parashara Hora Shastra), Ch. 4-6 —
 * Naisargika (natural) and Tatkalika (temporal) friendship, combined
 * into the classical five-fold (Panchadha) relationship.
 *
 * Three layers:
 *   1. Naisargika Maitri (natural relationship) — fixed, same in every chart.
 *   2. Tatkalika Maitri (temporal relationship) — depends on house distance
 *      between the two planets in THIS chart.
 *   3. Panchadha Maitri (five-fold) — natural + temporal combined into one
 *      of 5 grades: Adhi Mitra, Mitra, Sama, Shatru, Adhi Shatru.
 *
 * NOTE ON RAHU/KETU: BPHS's core Naisargika Maitri chapter covers only the
 * seven classical grahas (Sun through Saturn). Rahu and Ketu have no
 * sign-lordship of their own, so classical tradition has no single settled
 * rule for their natural friendships. The widely-used convention (followed
 * here) is DISPOSITOR SUBSTITUTION: a node's natural relationships are taken
 * to be those of the planet that rules the sign the node occupies. This is
 * a derived convention, not literal BPHS text — flagged accordingly in the
 * output so it carries appropriately less weight in analysis.
 */

const { SIGN_INDEX, SIGN_LORDS, normalizePlanetName } = require('../parser/utils/constants');

const CLASSICAL_PLANETS = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn'];

// Naisargika (natural) relationships — BPHS Ch. 4
const NATURAL_RELATIONSHIPS = {
  Sun:     { friends: ['Moon', 'Mars', 'Jupiter'],          neutral: ['Mercury'],                    enemies: ['Venus', 'Saturn'] },
  Moon:    { friends: ['Sun', 'Mercury'],                   neutral: ['Mars', 'Jupiter', 'Venus', 'Saturn'], enemies: [] },
  Mars:    { friends: ['Sun', 'Moon', 'Jupiter'],           neutral: ['Venus', 'Saturn'],             enemies: ['Mercury'] },
  Mercury: { friends: ['Sun', 'Venus'],                     neutral: ['Mars', 'Jupiter', 'Saturn'],   enemies: ['Moon'] },
  Jupiter: { friends: ['Sun', 'Moon', 'Mars'],               neutral: ['Saturn'],                      enemies: ['Mercury', 'Venus'] },
  Venus:   { friends: ['Mercury', 'Saturn'],                neutral: ['Mars', 'Jupiter'],             enemies: ['Sun', 'Moon'] },
  Saturn:  { friends: ['Mercury', 'Venus'],                 neutral: ['Jupiter'],                     enemies: ['Sun', 'Moon', 'Mars'] }
};

function getNaturalRelationship(planetA, planetB) {
  if (planetA === planetB) return 'self';
  const rel = NATURAL_RELATIONSHIPS[planetA];
  if (!rel) return null; // Rahu/Ketu handled by caller via dispositor substitution
  if (rel.friends.includes(planetB)) return 'friend';
  if (rel.enemies.includes(planetB)) return 'enemy';
  if (rel.neutral.includes(planetB)) return 'neutral';
  return null;
}

/**
 * Tatkalika (temporal) relationship — based on house distance between
 * the two planets' current sign positions in THIS chart.
 * Planets in houses 2,3,4,10,11,12 from a given planet = temporary friend.
 * Planets in houses 1,5,6,7,8,9 from a given planet = temporary enemy.
 * (House 1 here means same sign / conjunction.)
 */
function getTemporalRelationship(signIndexA, signIndexB) {
  const distance = ((signIndexB - signIndexA + 12) % 12) + 1; // 1-12
  const friendDistances = [2, 3, 4, 10, 11, 12];
  return friendDistances.includes(distance) ? 'friend' : 'enemy';
}

/**
 * Panchadha Maitri — combine natural (3-state) + temporal (2-state)
 * into the classical five-fold relationship.
 */
const PANCHADHA_TABLE = {
  'friend|friend':   'Adhi Mitra (Great Friend)',
  'friend|enemy':    'Sama (Neutral)',
  'neutral|friend':  'Mitra (Friend)',
  'neutral|enemy':   'Shatru (Enemy)',
  'enemy|friend':    'Sama (Neutral)',
  'enemy|enemy':     'Adhi Shatru (Great Enemy)'
};

function getPanchadhaMaitri(natural, temporal) {
  if (natural === 'self') return 'self';
  if (!natural) return null;
  return PANCHADHA_TABLE[`${natural}|${temporal}`] || null;
}

/**
 * Compute the full relationship matrix for all planets present in `bodies`.
 * Rahu/Ketu get natural relationships via dispositor substitution.
 */
function computeRelationships(bodies) {
  const planets = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn', 'Rahu', 'Ketu']
    .filter(p => bodies[p]);

  // Determine effective "natural relationship source" for each planet
  // (itself for the 7 classical grahas; its sign dispositor for nodes)
  const naturalSource = {};
  const dispositorNote = {};
  for (const p of planets) {
    if (CLASSICAL_PLANETS.includes(p)) {
      naturalSource[p] = p;
    } else {
      // Rahu/Ketu — substitute with dispositor (lord of occupied sign)
      const dispositor = SIGN_LORDS[bodies[p].signCode];
      naturalSource[p] = dispositor;
      dispositorNote[p] = dispositor;
    }
  }

  const matrix = {};
  for (const a of planets) {
    matrix[a] = {};
    const signIdxA = SIGN_INDEX[bodies[a].signCode];

    for (const b of planets) {
      if (a === b) {
        matrix[a][b] = { natural: 'self', temporal: 'self', panchadha: 'self' };
        continue;
      }
      const signIdxB = SIGN_INDEX[bodies[b].signCode];

      const natural = getNaturalRelationship(naturalSource[a], naturalSource[b]);
      const temporal = getTemporalRelationship(signIdxA, signIdxB);
      const panchadha = getPanchadhaMaitri(natural, temporal);

      matrix[a][b] = { natural, temporal, panchadha };
    }
  }

  return {
    matrix,
    dispositorSubstitutions: dispositorNote, // e.g. { Rahu: 'Venus', Ketu: 'Mars' }
    methodology: {
      natural: 'BPHS Ch. 4 — Naisargika Maitri (fixed). Rahu/Ketu use dispositor substitution (derived convention, not literal BPHS text).',
      temporal: 'BPHS Ch. 6 — Tatkalika Maitri (computed from house distance in this chart).',
      panchadha: 'Natural + Temporal combined into the classical five-fold relationship.'
    }
  };
}

module.exports = {
  computeRelationships,
  getNaturalRelationship,
  getTemporalRelationship,
  getPanchadhaMaitri,
  NATURAL_RELATIONSHIPS,
  CLASSICAL_PLANETS
};
