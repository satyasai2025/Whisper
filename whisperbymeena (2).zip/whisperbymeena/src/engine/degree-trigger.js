/**
 * Phase 7 + Phase 10 Implementation
 * 
 * Phase 7:  Transit Karma Nakshatra Activation
 *           When a transiting planet passes through the nakshatra of the 10th house
 *           (Karma nakshatra), it activates career/status events.
 * 
 * Phase 10: Degree Trigger
 *           When a transiting planet comes within orb of a natal planet, lagna,
 *           or dasha lord — it triggers that natal planet's significations.
 *           
 *           Orbs (from classical practice + PVR approach):
 *             0–1°  : Exact trigger — strongest activation
 *             1–3°  : Close trigger — strong activation  
 *             3–5°  : Wide trigger  — moderate activation
 *             >5°   : No trigger
 * 
 * Note: Degree trigger is NOT explicitly in PVR textbook as a standalone chapter,
 * but emerges from transit conjunction/aspect principles and is widely used
 * in Parashari tradition. We implement it as an additional precision layer.
 */

'use strict';

const { getNakshatra, getNavTara, getFullLongitude, NAKSHATRAS } = require('../computation/nakshatra');

const SIGN_CODES = ['Ar','Ta','Ge','Cn','Le','Vi','Li','Sc','Sg','Cp','Aq','Pi'];

// ── Orb definitions ───────────────────────────────────────────────────────────
const ORB_LEVELS = [
  { max: 1.0, label: 'Exact',    strength: 'very_strong', score: 30, description: 'Exact degree trigger — peak activation' },
  { max: 3.0, label: 'Close',    strength: 'strong',      score: 20, description: 'Close degree trigger — strong activation' },
  { max: 5.0, label: 'Wide',     strength: 'moderate',    score: 10, description: 'Wide degree trigger — moderate activation' },
];

// Event-specific sensitive points
// Which natal points matter most for each event type?
const EVENT_SENSITIVE_POINTS = {
  marriage:    ['Venus','Jupiter','Moon','Rahu','Lagna','DK','UL_lord'],
  children:    ['Jupiter','Moon','Mars','Sun','PK'],
  career:      ['Saturn','Sun','Mercury','Lagna','10th_lord','AMK','GL_lord'],
  firstJob:    ['Saturn','Sun','Mercury','Jupiter','AMK'],
  promotion:   ['Sun','Jupiter','Saturn','10th_lord','AMK'],
  housePurchase:['Mars','Moon','Saturn','4th_lord'],
  foreignTravel:['Rahu','Jupiter','Moon','9th_lord','12th_lord'],
  majorIllness: ['Saturn','Mars','Rahu','Ketu','6th_lord','8th_lord'],
  surgery:      ['Mars','Ketu','Saturn','8th_lord'],
  deathOfFather:['Sun','Saturn','9th_lord'],
  deathOfMother:['Moon','Saturn','4th_lord'],
  wealth:       ['Jupiter','Venus','Mercury','2nd_lord','11th_lord'],
  education:    ['Mercury','Jupiter','5th_lord'],
  litigation:   ['Mars','Rahu','Saturn','6th_lord','7th_lord'],
};

/**
 * Get full longitude of lagna
 */
function getLagnaLongitude(chart) {
  const lagnaCode = chart.lagna?.signCode;
  const lagnaIdx  = SIGN_CODES.indexOf(lagnaCode);
  const degInSign = chart.lagna?.degreeInSign || 0;
  return lagnaIdx * 30 + degInSign;
}

/**
 * Build map of all sensitive natal longitudes for a chart
 */
function buildSensitivePoints(chart) {
  const bodies = chart.bodies || {};
  const points  = {};

  // 9 planets
  const PLANETS = ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn','Rahu','Ketu'];
  PLANETS.forEach(p => {
    const lon = getFullLongitude(bodies[p]);
    if (lon != null) points[p] = { lon, type: 'planet', label: p };
  });

  // Lagna
  const lagnaLon = getLagnaLongitude(chart);
  points['Lagna'] = { lon: lagnaLon, type: 'lagna', label: 'Lagna' };

  // House lords (by sign)
  const SIGN_LORDS = {
    Ar:'Mars',Ta:'Venus',Ge:'Mercury',Cn:'Moon',Le:'Sun',Vi:'Mercury',
    Li:'Venus',Sc:'Mars',Sg:'Jupiter',Cp:'Saturn',Aq:'Saturn',Pi:'Jupiter'
  };
  const lagnaIdx = SIGN_CODES.indexOf(chart.lagna?.signCode);
  if (lagnaIdx >= 0) {
    for (let h = 1; h <= 12; h++) {
      const houseSign = SIGN_CODES[(lagnaIdx + h - 1) % 12];
      const houseLord = SIGN_LORDS[houseSign];
      const lordBody  = bodies[houseLord];
      const lordLon   = lordBody ? getFullLongitude(lordBody) : null;
      if (lordLon != null) {
        points[`H${h}_lord`] = { lon: lordLon, type: 'house_lord', label: `H${h} lord (${houseLord})`, planet: houseLord };
      }
    }
  }

  // Chara karakas
  const karakas = chart.analysis?.jaimini?.allCharaKarakas || {};
  Object.entries(karakas).forEach(([role, planet]) => {
    const lon = getFullLongitude(bodies[planet]);
    if (lon != null) points[role] = { lon, type: 'chara_karaka', label: `${role} (${planet})`, planet };
  });

  // Special lagnas (GL, HL, SL)
  if (chart.specialLagnas?.GL) {
    const glLon = SIGN_CODES.indexOf(chart.specialLagnas.GL.signCode) * 30 + (chart.specialLagnas.GL.degreeInSign || 0);
    points['GL'] = { lon: glLon, type: 'special_lagna', label: 'Ghati Lagna (GL)' };
  }

  // Arudha Lagna (AL = A1)
  const al = chart.analysis?.arudhas?.arudhas?.A1;
  if (al?.finalArudhaHouse && lagnaIdx >= 0) {
    const alSignIdx = (lagnaIdx + al.finalArudhaHouse - 1) % 12;
    const alLon = alSignIdx * 30;
    points['AL'] = { lon: alLon, type: 'arudha', label: 'Arudha Lagna (AL)' };
  }

  return points;
}

/**
 * Phase 10: Check degree triggers for a single transiting planet
 * 
 * @param {string} planet      - transiting planet name
 * @param {number} transitLon  - transit sidereal longitude
 * @param {object} natalPoints - from buildSensitivePoints()
 * @param {string} eventKey    - event type (to filter relevant natal points)
 * @param {object} chart       - full chart (for DK etc.)
 * @returns {object[]} triggers found
 */
function checkDegreeTriggers(planet, transitLon, natalPoints, eventKey, chart) {
  const triggers  = [];
  const sensitive = EVENT_SENSITIVE_POINTS[eventKey] || Object.keys(natalPoints);

  // Build lookup: which natal points to check for this event
  const checkPoints = new Set();
  sensitive.forEach(key => {
    // Handle aliases
    if (key === 'DK') {
      const dk = chart.analysis?.jaimini?.allCharaKarakas?.DK;
      if (dk) checkPoints.add(dk); // actual planet name
    } else if (key === 'AMK') {
      const amk = chart.analysis?.jaimini?.allCharaKarakas?.AMK;
      if (amk) checkPoints.add(amk);
    } else if (key === 'PK') {
      const pk = chart.analysis?.jaimini?.allCharaKarakas?.PK;
      if (pk) checkPoints.add(pk);
    } else if (key === 'UL_lord') {
      // Lord of UL house
      const ul = chart.analysis?.arudhas?.arudhas?.A12;
      if (ul?.lord) checkPoints.add(ul.lord);
    } else if (key === 'GL_lord') {
      checkPoints.add('GL');
    } else {
      checkPoints.add(key);
    }
  });

  // Always add Lagna and active dasha lords
  checkPoints.add('Lagna');

  // Check each natal point
  Object.entries(natalPoints).forEach(([key, natal]) => {
    if (!checkPoints.has(key) && !checkPoints.has(natal.planet) && !checkPoints.has(natal.label)) {
      // Not relevant for this event
      return;
    }

    const orb = angularDistance(transitLon, natal.lon);
    const level = ORB_LEVELS.find(l => orb <= l.max);
    if (!level) return;

    triggers.push({
      transitPlanet:  planet,
      transitLon:     +transitLon.toFixed(4),
      natalPoint:     key,
      natalLabel:     natal.label,
      natalLon:       +natal.lon.toFixed(4),
      orb:            +orb.toFixed(4),
      orbLabel:       level.label,
      strength:       level.strength,
      score:          level.score,
      description:    `${planet} (transit ${formatLon(transitLon)}) ${level.label.toLowerCase()} trigger on natal ${natal.label} (${formatLon(natal.lon)}) — orb ${orb.toFixed(2)}°`,
    });
  });

  return triggers.sort((a, b) => a.orb - b.orb);
}

/**
 * Phase 10: Full degree trigger analysis for all transit planets vs natal chart
 */
function analyzeDegreeTriggersForDate(chart, transitPlanets, eventKey) {
  const natalPoints = buildSensitivePoints(chart);
  const allTriggers = [];
  let totalScore    = 0;
  let exactCount    = 0;

  const TRANSIT_PLANETS = ['Jupiter','Saturn','Rahu','Ketu','Mars','Sun','Venus','Mercury','Moon'];

  TRANSIT_PLANETS.forEach(planet => {
    const pos = transitPlanets[planet];
    if (!pos) return;
    const tLon = pos.longitude || pos.siderealLongitude ||
                 (SIGN_CODES.indexOf(pos.signCode) * 30 + (pos.degreeInSign || 0));

    const triggers = checkDegreeTriggers(planet, tLon, natalPoints, eventKey, chart);
    triggers.forEach(t => {
      allTriggers.push(t);
      totalScore += t.score;
      if (t.orbLabel === 'Exact') exactCount++;
    });
  });

  // Cap score
  const cappedScore = Math.min(totalScore, 40);

  return {
    triggers: allTriggers.sort((a, b) => a.orb - b.orb),
    totalScore,
    cappedScore,
    exactCount,
    closeTriggers: allTriggers.filter(t => t.orb <= 3),
    summary: allTriggers.length === 0
      ? 'No degree triggers found'
      : `${allTriggers.length} trigger(s): ${exactCount} exact, ${allTriggers.filter(t=>t.orb<=3&&t.orb>1).length} close, ${allTriggers.filter(t=>t.orb>3).length} wide`,
  };
}

// ── Phase 7: Karma Nakshatra Activation ───────────────────────────────────────

/**
 * Phase 7: Check if transit planets activate Karma Nakshatra
 * Karma nakshatra = nakshatra of 10th house cusp
 * 
 * When a planet transits through karma nakshatra, it activates career/status themes.
 * When it transits through 19th nakshatra from karma (karma + 18), it activates
 * the "fulfillment of karma" point.
 */
function analyzeKarmaNakshatraActivation(chart, transitPlanets, eventKey) {
  const lagnaLon = getLagnaLongitude(chart);

  // 10th house starts at lagna + 270° (9 signs forward)
  const tenthLon      = (lagnaLon + 270) % 360;
  const karmaNak      = getNakshatra(tenthLon);

  // Moon natal nakshatra for Nav Tara
  const moonBody      = chart.bodies?.Moon;
  const moonLon       = getFullLongitude(moonBody);
  const moonNak       = moonLon != null ? getNakshatra(moonLon) : null;

  const activations   = [];
  const PLANETS       = ['Jupiter','Saturn','Rahu','Ketu','Mars','Sun','Venus','Mercury'];

  PLANETS.forEach(planet => {
    const pos = transitPlanets[planet];
    if (!pos) return;

    const tLon = pos.longitude || pos.siderealLongitude ||
                 (SIGN_CODES.indexOf(pos.signCode) * 30 + (pos.degreeInSign || 0));
    const tNak = getNakshatra(tLon);

    // Check 1: Transiting through karma nakshatra
    if (tNak.index === karmaNak.index) {
      activations.push({
        planet,
        type: 'karma_nakshatra',
        nakshatra: tNak.name,
        description: `${planet} transiting through Karma Nakshatra (${karmaNak.name}) — career/status themes activated`,
        score: 15,
        isStrong: true
      });
    }

    // Check 2: Transiting nakshatra lord = karma nakshatra lord
    if (tNak.lord === karmaNak.lord && tNak.index !== karmaNak.index) {
      activations.push({
        planet,
        type: 'karma_nak_lord_connection',
        nakshatra: tNak.name,
        description: `${planet} in ${tNak.name} (lord: ${tNak.lord}) — same lord as Karma Nakshatra (${karmaNak.name}). Secondary career activation.`,
        score: 8,
        isStrong: false
      });
    }

    // Check 3: For career events — transit planet nakshatra = 10th lord's natal nakshatra
    if (['career','firstJob','promotion','businessStart'].includes(eventKey)) {
      const tenthLordBody = findHouseLord(chart, 10);
      if (tenthLordBody) {
        const tenthLordNakLon = getFullLongitude(tenthLordBody);
        const tenthLordNak = tenthLordNakLon != null ? getNakshatra(tenthLordNakLon) : null;
        if (tenthLordNak && tNak.index === tenthLordNak.index) {
          activations.push({
            planet,
            type: 'tenth_lord_nakshatra',
            nakshatra: tNak.name,
            description: `${planet} in same nakshatra as natal 10th lord — career activation`,
            score: 10,
            isStrong: false
          });
        }
      }
    }

    // Check 4: Nav Tara from Moon — transit planet's nakshatra quality
    if (moonNak) {
      const tara = getNavTara(moonNak.index, tNak.index);
      if (tara.name === 'Sadhana' || tara.name === 'Mitra' || tara.name === 'Param Mitra') {
        // Already counted in transit analyzer, so just add context here
      }
    }
  });

  const totalScore = Math.min(activations.reduce((s, a) => s + a.score, 0), 30);

  return {
    karmaNakshatra: { name: karmaNak.name, lord: karmaNak.lord, index: karmaNak.index },
    activations,
    totalScore,
    isActive: activations.length > 0,
    summary: activations.length === 0
      ? `Karma Nakshatra (${karmaNak.name}) not activated by any transit today`
      : `${activations.length} karma nakshatra activation(s): ${activations.map(a=>a.planet).join(', ')}`
  };
}

// ── Helper functions ──────────────────────────────────────────────────────────

function angularDistance(lon1, lon2) {
  const diff = Math.abs(lon1 - lon2) % 360;
  return Math.min(diff, 360 - diff);
}

function formatLon(lon) {
  const SIGN_NAMES = ['Ar','Ta','Ge','Cn','Le','Vi','Li','Sc','Sg','Cp','Aq','Pi'];
  const sigIdx = Math.floor(((lon % 360) + 360) % 360 / 30);
  const deg    = ((lon % 360) + 360) % 360 % 30;
  return SIGN_NAMES[sigIdx] + ' ' + deg.toFixed(2) + '°';
}

function findHouseLord(chart, houseNum) {
  const SIGN_LORDS = {
    Ar:'Mars',Ta:'Venus',Ge:'Mercury',Cn:'Moon',Le:'Sun',Vi:'Mercury',
    Li:'Venus',Sc:'Mars',Sg:'Jupiter',Cp:'Saturn',Aq:'Saturn',Pi:'Jupiter'
  };
  const lagnaIdx = SIGN_CODES.indexOf(chart.lagna?.signCode);
  if (lagnaIdx < 0) return null;
  const houseSign = SIGN_CODES[(lagnaIdx + houseNum - 1) % 12];
  const lord = SIGN_LORDS[houseSign];
  return chart.bodies?.[lord] || null;
}

/**
 * Combined Phase 7 + Phase 10 analysis
 * Use this in event verification for full trigger analysis
 */
function analyzePhase7And10(chart, transitPlanets, eventKey, eventDate) {
  const degreeTriggers   = analyzeDegreeTriggersForDate(chart, transitPlanets, eventKey);
  const karmaNakshatra   = analyzeKarmaNakshatraActivation(chart, transitPlanets, eventKey);

  const combinedScore    = Math.min(degreeTriggers.cappedScore + karmaNakshatra.totalScore, 50);

  const highlights = [];
  if (degreeTriggers.exactCount > 0) {
    highlights.push(`${degreeTriggers.exactCount} exact degree trigger(s)`);
  }
  if (karmaNakshatra.isActive) {
    highlights.push(`Karma nakshatra (${karmaNakshatra.karmaNakshatra.name}) activated`);
  }

  return {
    date:           eventDate,
    degreeTriggers,
    karmaNakshatra,
    combinedScore,
    highlights,
    summary: highlights.length > 0 ? highlights.join(' + ') : 'No degree or karma nakshatra trigger',
  };
}

module.exports = {
  analyzePhase7And10,
  analyzeDegreeTriggersForDate,
  analyzeKarmaNakshatraActivation,
  buildSensitivePoints,
  checkDegreeTriggers,
  EVENT_SENSITIVE_POINTS,
  ORB_LEVELS,
};
