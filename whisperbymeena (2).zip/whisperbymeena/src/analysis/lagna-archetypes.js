/**
 * LAGNA ARCHETYPES — Structural Character Template per Ascendant
 *
 * Source: "Blank chart reading.pdf" (a modern teaching resource using the
 * "Kal Purush Kundli" / natural-zodiac comparison technique — i.e. reading
 * what is STRUCTURALLY true for a given Lagna sign before looking at the
 * individual's actual planetary positions). For any person with a given
 * Lagna, certain facts are ALWAYS true regardless of their specific birth
 * data: which planets rule which houses (a fixed structural consequence
 * of the Lagna sign), and which planets are classically exalted/
 * debilitated in that Lagna sign. This module captures those STRUCTURAL
 * facts plus the resource's psychological synthesis built on top of them.
 *
 * ============================ HONESTY NOTE ============================
 * This is a TEMPLATE/BASELINE layer, not the final word on anyone's
 * character. Two people with the same Lagna sign share this structural
 * starting point but differ enormously based on: where their OWN planets
 * actually sit (not just the classical sign-debility, which is the same
 * for everyone with that Lagna), their Moon's nakshatra, their dasha
 * history, and everything else this tool already analyzes. This layer
 * answers "what does this Lagna sign structurally set up," not "what is
 * this specific person like."
 *
 * The struct/lord-rulership facts (which planet rules which house for
 * this Lagna) are directly derivable from BPHS (sign lordships) and are
 * marked 'direct'. The psychological synthesis (e.g. "Leo Lagna people
 * often display regal bearing") is this resource's own modern teaching
 * voice — informed by, but not a verbatim quote of, classical texts —
 * and is marked 'synthesized'.
 * =========================================================================
 */

const { SOURCES } = require('./rules/schema');

const LAGNA_ARCHETYPES = {
  Ar: {
    name: 'Aries',
    coreNature: 'Self-centered in the literal sense (focused on the self/identity), assertive, natural leader, strongly goal-focused.',
    structuralNotes: [
      'Mars (Lagna lord) also rules the 8th house — a recurring structural theme of accidents/sudden physical events alongside resilience and the courage to push through them.',
      'Sun is classically exalted in Aries — supports natural confidence.',
      'Saturn is classically debilitated in Aries — a structural tendency toward impatience, difficulty with slow/methodical work.',
      'Mars feels strong in the 10th house from Aries (own-sign-adjacent dynamic) — supports ambition and career drive.',
      'Mars is debilitated when found in the 4th house from Aries — a structural theme of preferring to be away from home/domestic settling.'
    ],
    confidence: 'synthesized'
  },
  Ta: {
    name: 'Taurus',
    coreNature: 'Strength and stability (the Bull); significant mental and physical resilience; slow to anger but intense if provoked.',
    structuralNotes: [
      'Venus (Lagna lord) is classically exalted in Pisces — when Venus reaches the 11th house from Taurus (Pisces), it supports financial gain.',
      'Mercury is classically exalted in Virgo — in the 5th house from Taurus, supporting sharp intellect.',
      'Venus is classically debilitated in Virgo — also the 5th house from Taurus, a structural theme of some emotional/romantic restraint even amid practical relationship stability.',
      'Jupiter rules the 8th house from Taurus — a structural theme of sudden disruptions/controversies, sometimes with income tied to exactly those disruptive matters.'
    ],
    confidence: 'synthesized'
  },
  Ge: {
    name: 'Gemini',
    coreNature: 'A dual sign — versatile, communicative, can be inconsistent without focus; strong potential once direction is found.',
    structuralNotes: [
      'Mercury (Lagna lord) governs communication strongly for this Lagna.',
      'Mercury is classically exalted in Virgo, the 4th house from Gemini — supports comfort, property, vehicles.',
      'Mercury is classically debilitated in Pisces, the 10th house from Gemini — a structural theme of career ups and downs.',
      'Venus is classically exalted in Pisces, also the 10th house from Gemini — supports success through arts/knowledge fields.',
      'Mars rules the 6th and 11th houses from Gemini — supports competitive drive, sports, and gains through competition.'
    ],
    confidence: 'synthesized'
  },
  Cn: {
    name: 'Cancer',
    coreNature: 'Highly emotional, strong attachment to home; decisions often led by feeling over pure logic.',
    structuralNotes: [
      'Mercury rules the 3rd and 12th houses from Cancer — a structural theme of emotion influencing communication/decision-making more than detached logic.',
      'Moon is classically exalted in Taurus, the 11th house from Cancer — supports public connection, a "people\'s figure" quality.',
      'Saturn rules the 7th house from Cancer — a structural theme around partnership being more private/secretive, or an age-gap with a partner.'
    ],
    confidence: 'synthesized'
  },
  Le: {
    name: 'Leo',
    coreNature: 'Regal bearing (the Lion); wants to lead and be looked up to; drawn to recognition, status, and politics/public life.',
    structuralNotes: [
      'Sun (Lagna lord) is classically debilitated in Libra, the 3rd house from Leo — a structural tension between an outward "kingly" display and inner courage/follow-through; may prefer delegating effort to others.',
      'Sun is classically exalted in Aries, the 9th house from Leo — supports strong fortune and benefit through father/father-figures.',
      'Mars rules the 4th house from Leo — supports gains from property/land and support from the mother.',
      'Jupiter rules the 8th house from Leo — a recurring structural theme of scandal/notoriety alongside significant inheritance.'
    ],
    confidence: 'synthesized'
  },
  Vi: {
    name: 'Virgo',
    coreNature: 'Highly analytical, detail-oriented, drawn to precision and "purity"/correctness in whatever they study; often more introverted.',
    structuralNotes: [
      'Mercury (Lagna lord) supports structure-seeking and systematic thinking.',
      'A documented tendency toward deep-diving a topic then losing interest and moving on — sometimes mistaken for attention difficulty.',
      'Venus is classically debilitated in Virgo itself — a structural theme of approaching relationships more logically/calculatively than emotionally, with some tendency toward detachment.',
      'A preference for independent, individual work over team settings; doesn\'t need external validation.'
    ],
    confidence: 'synthesized'
  },
  Li: {
    name: 'Libra',
    coreNature: 'The scales — seeks balance; strongly independent and hard-working toward personal goals; an ongoing internal-vs-external balancing act.',
    structuralNotes: [
      'Libra runs nearly opposite to the natural zodiac (Kal Purush) reference, so several planets that are naturally strong end up classically debilitated for this Lagna — a structural source of friction.',
      'A documented tendency toward public-facing work (politics, marketing, public dealing), though social circle/advisors don\'t always serve the native well.'
    ],
    confidence: 'synthesized'
  },
  Sc: {
    name: 'Scorpio',
    coreNature: 'Deep, complex, private ("mysterious"); drawn to the occult, secrets, and psychology; hard to fully know from the outside.',
    structuralNotes: [
      'A documented tendency to question traditional/inherited approaches to religion and learning rather than accept them as-is.',
      'A documented tendency toward dominance in close relationships.',
      'Strong "poker face" capacity — what is happening internally is often not visible externally.'
    ],
    confidence: 'synthesized'
  },
  Sg: {
    name: 'Sagittarius',
    coreNature: 'Happy-go-lucky and philosophical; drawn to spirituality and big-picture meaning.',
    structuralNotes: [
      'Jupiter (Lagna lord) supports a naturally fortunate, good-humored baseline disposition.',
      'A documented tendency toward social awkwardness from being very direct/blunt, sometimes speaking without filtering first.',
      'A documented tendency toward quick, under-planned financial decisions.'
    ],
    confidence: 'synthesized'
  },
  Cp: {
    name: 'Capricorn',
    coreNature: 'Patient, slow-and-steady achiever (the crocodile) — calm on the surface, decisive when it matters; intensely ambitious and focused.',
    structuralNotes: [
      'Success tends to arrive later rather than early, built through sustained hard work and negotiation rather than confrontation.',
      'Often prefers a simple lifestyle despite material success — little interest in showing off.',
      'A documented tendency for Jupiter, Moon, and Sun to land in classically stressful positions for this Lagna, contributing to internal struggle even amid outward success.'
    ],
    confidence: 'synthesized'
  },
  Aq: {
    name: 'Aquarius',
    coreNature: 'Humanitarian, philosophical, scientifically curious; drawn to big ideas and systems.',
    structuralNotes: [
      'Strong draw toward knowledge generally, with a documented pull toward science, medicine, and modern energy/technology fields.',
      'Social circle and friendships carry outsized importance for this Lagna.',
      'A documented tendency for excessive philosophizing to narrow practical vision, sometimes affecting health or marriage matters.'
    ],
    confidence: 'synthesized'
  },
  Pi: {
    name: 'Pisces',
    coreNature: 'Soft-spoken, nurturing, self-sacrificing; oriented toward deeper/spiritual meaning over material pursuit; can seem "elsewhere" or unfocused at times (the fish swimming against the current).',
    structuralNotes: [
      'Jupiter (Lagna lord) supports wisdom and learning; Jupiter in the 5th house from Pisces is considered a particularly good placement for this Lagna.',
      'Money is often spent on social/spiritual causes rather than accumulated.',
      'Seeks stability in marriage/relationships, though Venus\'s placement can complicate this for a given individual.'
    ],
    confidence: 'synthesized'
  }
};

/**
 * NAKSHATRA ESSENCE — Genuine character synthesis per nakshatra
 *
 * Source: the Learner's own 27-nakshatra deep-dive collection (a modern
 * teaching series — devta/swami/symbol grounded in BPHS, layered with
 * the teacher's own psychological synthesis). This is NOT a verbatim
 * transcript — it is a condensed essence capturing the core psychological
 * theme of each nakshatra, in the same Hinglish voice that material uses.
 *
 * COVERAGE NOTE: only nakshatras with strong, directly-verified source
 * coverage are included with full essence text. The rest are intentionally
 * absent rather than guessed — calling code falls back to structural facts
 * only (sign/house/pada/lord) for those, never a fabricated paraphrase.
 */
const NAKSHATRA_ESSENCE = {
  Ashwini: 'Healing aur fast action ki nakshatra — pehla mover, doctor/surgeon/healer energy. Speed aur initiative inki taaqat hai; thodi sensitivity dusron ke emotions ke prati cultivate karni padti hai.',
  Bharani: 'Bhaar (responsibility) uthaane ki nakshatra — Agni tattva, Yama devta se juda. Andar ek bada energy-explosion hota hai jo lambe samay tak dabkar phir achanak action mein nikalta hai. Bina ek bade goal ke ye energy khud ko hi nuksaan pahuncha sakti hai — ek spasht lakshya milte hi ye log asambhav lagne wali cheezein paa lete hain.',
  Krittika: 'Kaatne aur transform karne ki nakshatra — Kartikeya (divine commander) se juda, Rakshasa guna. Inhe clearly pata hota hai kya chahiye, aur poori force se uss goal ke peeche jaate hain. High-competition fields (medicine, law, politics, military) mein khilte hain. Gussa jaldi aata hai — yahi sambhalna padta hai.',
  Punarvasu: 'Restoration aur protection ki nakshatra — Aditi devta se juda. Counseling, guidance, healthcare, nurturing fields mein naturally achhe. Itna dete hain doosron ko ki khud khaali ho jaate hain — apne liye bhi receive karna seekhna padta hai.',
  Pushya: 'Nourishing nakshatra — poora Karka (Cancer) rashi mein, Saturn swami. Discipline ke saath nurturing — care organized aur structured hota hai, bas Cancer ki pure emotional flow nahi.',
  Ashlesha: 'Naga (serpent) devta se judi nakshatra, Mercury swami. Gehri, secretive, observant nature — dusron ko bina kuch bole padh lete hain, lekin khud thoda guarded rehte hain.',
  Chitra: '"Yeh kyun bana? Isse behtar kaise banaya jaaye?" — building/creating ki nakshatra. Bachchon ke saath deep connection. Spiritual aur material dono ko saath jeete hain. Perfectionism trap — perfect family/perfect world dikhane ki koshish mein asli conflicts chhupa dete hain, jo baad mein zyada nuksaan karta hai.',
  Jyeshtha: 'Indra se judi — power, focus, deserving hone ki nakshatra. Sabse bada challenge: madad maangne mein pride aana, aur balanced communication (na poori tarah chup, na bina soche bolna). Sachhe gurus ki sangat inke liye crucial hai.',
  Mula: 'Jad (root) ki nakshatra — Nirriti devta se judi, hidden foundation-level kaam. "Moola waali shaadi mat karo" jaisi galat-fahmiyan hain — asal mein ye transformative hote hain, destructive nahi. Andheron mein kaam karte hain lekin poora ecosystem unhi par tika hota hai.',
  'Purva Ashadha': 'Haathi-dant (elephant tusk) — khoobsurti, power, authority ek saath. Bhog (enjoyment) aur moksha dono ki taraf khinchaav. Ego ko tool ki tarah use karna seekhna hota hai, dushman ki tarah nahi.',
  'Uttara Ashadha': '"Baad ki jeet" — jo achieve ho gaya use sambhalna. Unusual intelligence jo doosre nahi dekh paate, charismatic presence, apne hi family ko bhi objectively dekhne ki kshamta. Andar se ek divine-guidance jaisi awaaz aati hai jo rarely galat hoti hai.',
  Shravana: 'Sunne ki nakshatra — Vishnu devta, room ka mood instantly padh lena. Bina structure ke bikhar jaate hain (Chandra easily influenced hota hai) — roz ek hi routine inhe profession ke top tak le jaata hai.',
  Dhanishta: 'Damru (drum) — andar se khokha, lekin wahi khaalipan se sabse powerful dhwani nikalti hai. Ashta Vasu se judi, rebellious streak — lekin maturity ke bina ye rebellion purposeless ban sakti hai.',
  'Purva Bhadrapada': '"Bhadra" naam ke bawajood ye sabse ugra (intense) nakshatron mein se ek hai — do duniyaon ke beech gateway. Andar bahut zyada intensity hoti hai jo bahar se seedha-saadha dikhne ke peeche chhupi hoti hai.'
};

/**
 * MOON-RASHI NATURE — the sign's core emotional/mental theme when it is
 * the MOON's sign (not the Lagna). Same underlying sign-nature as the
 * Lagna archetype's coreNature, reframed for what it means as an INNER,
 * emotional baseline rather than outward behavior — since the Moon
 * governs manas (mind), the same sign expresses very differently here
 * than it does at the Lagna.
 */
const MOON_RASHI_NATURE = {
  Ar: 'Mann (mind) bechain aur action-oriented rehta hai — emotional security tabhi milti hai jab kuch naya shuru kiya jaaye ya koi challenge ho.',
  Ta: 'Mann ko stability aur comfort chahiye — emotional security bhautik suraksha (ghar, paisa, routine) se judi hoti hai.',
  Ge: 'Mann hamesha curious aur do-tarah ka rehta hai — emotional satisfaction baatcheet, naye ideas, aur mental stimulation se aata hai.',
  Cn: 'Yahi Chandra ki apni rashi hai — sabse deep emotional sensitivity, ghar/parivaar se gehra lagav, mood doosron ke environment se bahut jaldi influence hota hai.',
  Le: 'Mann ko recognition aur warmth chahiye — emotional security tab milti hai jab feel ho ki dekha/appreciate kiya ja raha hai.',
  Vi: 'Mann analytical aur kuch hadd tak self-critical rehta hai — emotional comfort order aur usefulness se aata hai, pure feeling-expression se nahi.',
  Li: 'Mann ko harmony aur balance chahiye — akele hone se zyada relationships mein emotional security milti hai, lekin decision lena mushkil ho sakta hai.',
  Sc: 'Gehri, intense, private emotional nature — feelings asaani se share nahi hote, lekin jo bhi feel hota hai woh bahut gehra hota hai.',
  Sg: 'Mann ko freedom aur meaning chahiye — emotional security badi tasveer (philosophy, growth, adventure) se aati hai, chhote details se nahi.',
  Cp: 'Mann reserved aur disciplined rehta hai — emotions zaahir kam karte hain, security achievement aur structure se aati hai.',
  Aq: 'Mann thoda detached aur idea-oriented rehta hai — emotional connection community/larger-cause se zyada hota hai, ek-on-one intimacy se kam.',
  Pi: 'Mann sabse zyada sensitive aur permeable hota hai — doosron ke emotions bhi apne jaise feel hote hain; emotional boundaries banana ek lifelong practice hai.'
};

module.exports = { LAGNA_ARCHETYPES, NAKSHATRA_ESSENCE, MOON_RASHI_NATURE };
