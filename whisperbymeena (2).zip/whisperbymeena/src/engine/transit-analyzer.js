/**
 * Transit Analysis Module — Complete
 * Activated houses + their lords + karaka impact + sukshma dasha
 * 
 * For any given date, computes:
 *   1. Sukshma dasha (MD/AD/PD/SD) at that moment
 *   2. Each transiting planet's house position from natal lagna
 *   3. House lord of that house (natal) — what domain it governs
 *   4. Natural karaka of that house — core signification
 *   5. Transit quality: Vedha, Moorti, Tara, BAV/SAV, Kakshya
 *   6. Combined impact score per planet
 *   7. Overall day quality
 */

'use strict';

const SIGN_CODES = ['Ar','Ta','Ge','Cn','Le','Vi','Li','Sc','Sg','Cp','Aq','Pi'];
const SIGN_NAMES = ['Aries','Taurus','Gemini','Cancer','Leo','Virgo',
                    'Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'];

const NAKSHATRA_NAMES = [
  'Aswini','Bharani','Krittika','Rohini','Mrigasira','Aardra',
  'Punarvasu','Pushyami','Asresha','Makha','Poorva Phalguni','Uttara Phalguni',
  'Hasta','Chitra','Swaati','Visaakha','Anooraadha','Jyeshtha',
  'Moola','Poorvaashaadha','Uttaraashaadha','Sravanam','Dhanishtha','Satabhishak',
  'Poorvaabhaadra','Uttaraabhaadra','Revati'
];

// ── House significations ───────────────────────────────────────────────────────
const HOUSE_SIGNIFICATIONS = {
  1:  { domain: 'Self, Body, Personality, Health',       naturalKaraka: 'Sun',     karakaRole: 'Soul, vitality' },
  2:  { domain: 'Wealth, Family, Speech, Food',          naturalKaraka: 'Jupiter', karakaRole: 'Wealth expansion' },
  3:  { domain: 'Siblings, Courage, Communication',      naturalKaraka: 'Mars',    karakaRole: 'Courage, siblings' },
  4:  { domain: 'Home, Mother, Happiness, Property',     naturalKaraka: 'Moon',    karakaRole: 'Mind, mother' },
  5:  { domain: 'Children, Intelligence, Past Merit',    naturalKaraka: 'Jupiter', karakaRole: 'Children, wisdom' },
  6:  { domain: 'Enemies, Disease, Service, Debts',      naturalKaraka: 'Mars',    karakaRole: 'Conflict, health' },
  7:  { domain: 'Spouse, Partnership, Business',         naturalKaraka: 'Venus',   karakaRole: 'Love, partnership' },
  8:  { domain: 'Longevity, Transformation, Secrets',    naturalKaraka: 'Saturn',  karakaRole: 'Obstacles, delay' },
  9:  { domain: 'Fortune, Father, Dharma, Guru',         naturalKaraka: 'Jupiter', karakaRole: 'Luck, wisdom' },
  10: { domain: 'Career, Karma, Status, Authority',      naturalKaraka: 'Saturn',  karakaRole: 'Discipline, karma' },
  11: { domain: 'Gains, Desires, Network, Elder Siblings', naturalKaraka: 'Jupiter', karakaRole: 'Fulfillment' },
  12: { domain: 'Losses, Liberation, Foreign, Sleep',   naturalKaraka: 'Saturn',  karakaRole: 'Detachment' },
};

// ── Natural planetary significations ─────────────────────────────────────────
const PLANET_KARAKATVA = {
  Sun:     'Soul, father, authority, health, vitality, government',
  Moon:    'Mind, mother, emotions, fluids, public, travel',
  Mars:    'Energy, siblings, property, surgery, accidents, ambition',
  Mercury: 'Intelligence, speech, business, education, friends, skill',
  Jupiter: 'Wisdom, children, wealth, guru, law, spirituality, luck',
  Venus:   'Love, spouse, beauty, vehicles, arts, luxury, agreements',
  Saturn:  'Discipline, career, servants, delays, obstacles, longevity',
  Rahu:    'Foreign matters, unconventional paths, obsession, illusion',
  Ketu:    'Spiritual liberation, past life, detachment, mysticism',
};

// ── Gochar good houses from Moon ───────────────────────────────────────────────
// Good houses from natal Moon for each transiting planet
// Source: PVR textbook Ch.25, Table 63 (Vedha Sthaanas) + Tables 54-59
// Rahu: same as Saturn (p.319: "Rahu's behavior is similar to that of Saturn's")
// Ketu: same as Mars (p.319: "Ketu's behavior to Mars's")
// Venus: Table 58 — good: 1,2,3,4,5,9,11 (NOT 8 or 12)
const GOOD_HOUSES_FROM_MOON = {
  Sun:     [3,6,10,11],          // Table 63 confirmed
  Moon:    [1,3,6,7,10,11],      // Table 63 confirmed
  Mars:    [3,6,11],             // Table 63 confirmed
  Mercury: [2,4,6,8,10,11],     // Table 63 confirmed
  Jupiter: [2,5,7,9,11],        // Table 63 confirmed
  Venus:   [1,2,3,4,5,9,11],    // Table 58 (6,7,8,10,12 = bad)
  Saturn:  [3,6,11],             // Table 63 confirmed
  Rahu:    [3,6,11],             // p.319: "same as Saturn"
  Ketu:    [3,6,11],             // p.319: "same as Mars"
};

// Vedha table (house → vedha house)
const VEDHA_TABLE = {
  Sun:     { good:[3,6,10,11],   vedha:[9,12,4,5] },
  Moon:    { good:[1,3,6,7,10,11], vedha:[5,9,12,2,4,8] },
  Mars:    { good:[3,6,11],       vedha:[12,9,5] },
  Mercury: { good:[2,4,6,8,10,11], vedha:[5,3,9,1,8,12] },
  Jupiter: { good:[2,5,7,9,11],   vedha:[12,4,3,10,8] },
  Venus:   { good:[1,2,3,4,5,8,9,11,12], vedha:[8,7,1,10,9,5,11,6,3] },
  Saturn:  { good:[3,6,11],       vedha:[12,9,5] },
  Rahu:    { good:[3,6,11],       vedha:[12,9,5] },
  Ketu:    { good:[3,6,11],       vedha:[12,9,5] },
};

// Moorti
function getMoorti(moonSignIdx, transitSignIdx) {
  const dist = ((transitSignIdx - moonSignIdx + 12) % 12) + 1;
  if ([2,12].includes(dist)) return { name:'Swarna', score:100, meaning:'Excellent — golden results' };
  if ([3,11].includes(dist)) return { name:'Rajata', score:75,  meaning:'Good — silver results' };
  if ([4,10].includes(dist)) return { name:'Tamra',  score:50,  meaning:'Mixed — copper results' };
  if ([5,9].includes(dist))  return { name:'Loha',   score:25,  meaning:'Weak — iron results, obstacles' };
  return { name:'Neutral', score:50, meaning:'Neutral transit' };
}

// Tara
const TARA_NAMES = ['Janma','Sampath','Vipat','Kshema','Pratyak','Sadhana','Naidhana','Mitra','Param Mitra'];
const TARA_SCORE = { Janma:40,Sampath:80,Vipat:10,Kshema:75,Pratyak:15,Sadhana:70,Naidhana:5,Mitra:65,'Param Mitra':90 };
const TARA_MEANING = {
  Janma: 'Birth star — mental stress, avoid important acts',
  Sampath: 'Wealth star — auspicious, financial gains',
  Vipat: 'Danger star — obstacles, avoid travel',
  Kshema: 'Wellbeing star — health, comfort',
  Pratyak: 'Obstacle star — hindrance, delays',
  Sadhana: 'Achievement star — success in work',
  Naidhana: 'Death star — very inauspicious, caution',
  Mitra: 'Friend star — good results, helpful people',
  'Param Mitra': 'Best friend star — excellent results'
};

function getTara(moonNakIdx, transitNakIdx) {
  const count = ((transitNakIdx - moonNakIdx + 27) % 27);
  const name  = TARA_NAMES[count % 9];
  return { name, score: TARA_SCORE[name], count: count+1, meaning: TARA_MEANING[name] };
}

// ── Sign lordships ─────────────────────────────────────────────────────────────
const SIGN_LORDS = {
  Ar:'Mars',Ta:'Venus',Ge:'Mercury',Cn:'Moon',Le:'Sun',Vi:'Mercury',
  Li:'Venus',Sc:'Mars',Sg:'Jupiter',Cp:'Saturn',Aq:'Saturn',Pi:'Jupiter'
};

function getHouseLord(lagnaCode, houseNum) {
  const lagnaIdx  = SIGN_CODES.indexOf(lagnaCode);
  const houseSign = SIGN_CODES[(lagnaIdx + houseNum - 1) % 12];
  return { sign: houseSign, lord: SIGN_LORDS[houseSign] };
}

// ── Sukshma Dasha computation ──────────────────────────────────────────────────
/**
 * Compute sukshma dasha (4th level) from MD/AD/PD.
 * Sukshma = PD proportionally divided by 9 planet sequence.
 * Total PD years × (planet_vimsottari_years / 120) = sukshma duration.
 * Source: Proportional from Vimshottari total (same method as AD from MD, PD from AD)
 */
const VIMSH_YEARS = {
  Ketu:7, Venus:20, Sun:6, Moon:10, Mars:7, Rahu:18, Jupiter:16, Saturn:19, Mercury:17
};
const VIMSH_ORDER = ['Ketu','Venus','Sun','Moon','Mars','Rahu','Jupiter','Saturn','Mercury'];

function computeSukshmaDashas(pd) {
  if (!pd || !pd.lord || !pd.startDate || !pd.endDate) return [];
  const pdYears   = pd.years || ((new Date(pd.endDate) - new Date(pd.startDate)) / (365.25 * 86400000));
  const pdLordIdx = VIMSH_ORDER.indexOf(pd.lord);
  if (pdLordIdx < 0) return [];

  const sukshmas = [];
  let currentDate = pd.startDate;

  for (let i = 0; i < 9; i++) {
    const sLord   = VIMSH_ORDER[(pdLordIdx + i) % 9];
    const sYears  = pdYears * (VIMSH_YEARS[sLord] / 120);
    const endDate = addDays(currentDate, sYears * 365.25636);

    sukshmas.push({
      lord:      sLord,
      startDate: currentDate,
      endDate:   endDate,
      years:     sYears,
    });
    currentDate = endDate;
  }
  return sukshmas;
}

function addDays(dateStr, days) {
  const d = new Date(dateStr);
  d.setTime(d.getTime() + days * 86400000);
  return d.toISOString().split('T')[0];
}

function findPD(vimshottariDashas, dateStr) {
  const arr = Array.isArray(vimshottariDashas) ? vimshottariDashas : Object.values(vimshottariDashas);
  for (const md of arr) {
    if (!md || md.startDate > dateStr || md.endDate <= dateStr) continue;
    for (const ad of (md.antardashas || [])) {
      if (!ad || ad.startDate > dateStr || ad.endDate <= dateStr) continue;
      for (const pd of (ad.pratyantardashas || [])) {
        if (!pd || pd.startDate > dateStr || pd.endDate <= dateStr) continue;
        return { md, ad, pd };
      }
      return { md, ad, pd: null };
    }
    return { md, ad: null, pd: null };
  }
  return { md: null, ad: null, pd: null };
}

// ── Main: analyzeTransitForDate ────────────────────────────────────────────────

/**
 * Complete transit analysis for a given date.
 *
 * @param {object} params
 * @param {string} params.date          - 'YYYY-MM-DD'
 * @param {object} params.chart         - full chart from buildHoroscope
 * @param {object} params.transitPlanets - { Sun:{signCode,longitude,degreeInSign}, Moon:..., ... }
 * @returns {object} complete transit analysis
 */
function analyzeTransitForDate(params) {
  const { date, chart, transitPlanets } = params;

  const lagnaCode    = chart.lagna?.signCode;
  const lagnaIdx     = SIGN_CODES.indexOf(lagnaCode);
  const moonSignCode = chart.bodies?.Moon?.signCode;
  const moonSignIdx  = SIGN_CODES.indexOf(moonSignCode);
  const moonNakIdx   = chart.panchanga?.nakshatra?.index ?? 0;
  const av           = chart.ashtakavarga;

  // ── 1. Sukshma Dasha at date ─────────────────────────────────────────────────
  const { md, ad, pd } = findPD(chart.vimshottariDashas, date);
  const sukshmas = pd ? computeSukshmaDashas(pd) : [];
  const sd = sukshmas.find(s => s.startDate <= date && s.endDate > date) || null;

  const dashaInfo = {
    mahadasha:    md?.lord || null,
    antardasha:   ad?.lord || null,
    pratyantardasha: pd?.lord || null,
    sukshmadasha: sd?.lord || null,
    display: [md?.lord, ad?.lord, pd?.lord, sd?.lord].filter(Boolean).join(' / '),
    // House activation from dasha lords
    dashaActivatedHouses: [],
  };

  // What houses do active dasha lords activate?
  [md?.lord, ad?.lord, pd?.lord, sd?.lord].filter(Boolean).forEach(lord => {
    if (!chart.bodies?.[lord]) return;
    const lordHouse = chart.bodies[lord].house || chart.bodies[lord].rasiHouse;
    const lordSign  = chart.bodies[lord].signCode;
    // House lord rules these houses
    const ruledHouses = [];
    for (let h = 1; h <= 12; h++) {
      const hs = getHouseLord(lagnaCode, h);
      if (hs.lord === lord) ruledHouses.push(h);
    }
    dashaInfo.dashaActivatedHouses.push({
      planet: lord,
      occupiesHouse: lordHouse,
      rulesHouses: ruledHouses,
      signCode: lordSign,
      karakatva: PLANET_KARAKATVA[lord] || '',
    });
  });

  // ── 2. Per-planet transit analysis ───────────────────────────────────────────
  const planetTransits = {};
  const ALL_PLANETS = ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn','Rahu','Ketu'];

  ALL_PLANETS.forEach(planet => {
    const pos = transitPlanets[planet];
    if (!pos) return;

    const tSignCode = pos.signCode;
    const tSignIdx  = SIGN_CODES.indexOf(tSignCode);
    const tDeg      = pos.degreeInSign || (pos.longitude % 30);
    if (tSignIdx < 0) return;

    // House from natal lagna (whole-sign)
    const houseFromLagna = ((tSignIdx - lagnaIdx + 12) % 12) + 1;
    const houseSig       = HOUSE_SIGNIFICATIONS[houseFromLagna];
    const { lord: houseLord } = getHouseLord(lagnaCode, houseFromLagna);

    // House from natal Moon
    const houseFromMoon = ((tSignIdx - moonSignIdx + 12) % 12) + 1;
    const isGoodFromMoon = GOOD_HOUSES_FROM_MOON[planet]?.includes(houseFromMoon) ?? false;

    // Vedha check
    const vedhaData = VEDHA_TABLE[planet];
    let vedhaObstructed = false;
    let vedhaObstructor = null;
    if (vedhaData) {
      const goodIdx  = vedhaData.good.indexOf(houseFromMoon);
      if (goodIdx >= 0 && isGoodFromMoon) {
        const vedhaHouse = vedhaData.vedha[goodIdx];
        // Check if any planet transits in vedha house from moon
        ALL_PLANETS.forEach(other => {
          if (other === planet) return;
          if (planet==='Sun' && other==='Saturn') return;  // exception
          if (planet==='Moon' && other==='Mercury') return; // exception
          if (planet==='Saturn' && other==='Sun') return;
          if (planet==='Mercury' && other==='Moon') return;
          const otherPos = transitPlanets[other];
          if (!otherPos) return;
          const otherHouseFromMoon = ((SIGN_CODES.indexOf(otherPos.signCode) - moonSignIdx + 12) % 12) + 1;
          if (otherHouseFromMoon === vedhaHouse) {
            vedhaObstructed = true;
            vedhaObstructor = other;
          }
        });
      }
    }

    // Moorti
    const moorti = getMoorti(moonSignIdx, tSignIdx);

    // Tara
    const nakIdx = Math.floor(((pos.longitude % 360) + 360) % 360 / (360/27));
    const tara   = getTara(moonNakIdx, nakIdx);

    // Ashtakavarga
    let bav = null, sav = null, kakshya = null;
    if (av?.bav?.[planet]) {
      bav = av.bav[planet][tSignIdx];
      sav = av.sav[tSignIdx];
      // Kakshya
      const kakshyaLords  = ['Saturn','Jupiter','Mars','Sun','Venus','Mercury','Moon','Lagna'];
      const kakshyaIdx    = Math.min(Math.floor(tDeg / 3.75), 7);
      const kakshyaLord   = kakshyaLords[kakshyaIdx];
      const contribIdx    = ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn','Lagna'].indexOf(kakshyaLord);
      const hasRekha      = av.pav?.[planet]?.[tSignIdx]?.[contribIdx] ?? null;
      kakshya = { lord: kakshyaLord, hasRekha, startDeg: kakshyaIdx*3.75, endDeg: (kakshyaIdx+1)*3.75 };
    }

    // Natal planet in this transit sign? (conjunction in transit)
    const natalHere = Object.entries(chart.bodies || {})
      .filter(([p, b]) => b?.signCode === tSignCode && ALL_PLANETS.includes(p))
      .map(([p]) => p);

    // Impact score
    let score = 50; // neutral base
    const impacts = [];

    if (isGoodFromMoon && !vedhaObstructed) { score += 15; impacts.push('Good house from Moon'); }
    else if (isGoodFromMoon && vedhaObstructed) { score -= 10; impacts.push('Good house but Vedha by '+vedhaObstructor); }
    else { score -= 10; impacts.push('Unfavorable house from Moon (H'+houseFromMoon+')'); }

    score += (moorti.score - 50) * 0.3;
    impacts.push(moorti.name+' Moorti: '+moorti.meaning);

    score += (tara.score - 50) * 0.3;
    impacts.push(tara.name+' Tara: '+tara.meaning);

    if (bav !== null) {
      if (bav >= 5)      { score += 15; impacts.push('BAV: '+bav+'/8 — strong'); }
      else if (bav >= 4) { score += 5;  impacts.push('BAV: '+bav+'/8 — moderate'); }
      else               { score -= 10; impacts.push('BAV: '+bav+'/8 — weak'); }
    }
    if (sav !== null) {
      if (sav >= 30)     { score += 10; impacts.push('SAV: '+sav+' — favorable sign'); }
      else if (sav < 25) { score -= 10; impacts.push('SAV: '+sav+' — unfavorable sign'); }
    }
    if (kakshya?.hasRekha === true)  { score += 8; impacts.push('Kakshya lord ('+kakshya.lord+') has rekha — favorable'); }
    if (kakshya?.hasRekha === false) { score -= 5; impacts.push('Kakshya lord ('+kakshya.lord+') no rekha — diminished'); }

    score = Math.max(0, Math.min(100, Math.round(score)));

    planetTransits[planet] = {
      // Position
      signCode:     tSignCode,
      sign:         SIGN_NAMES[tSignIdx] || tSignCode,
      degreeInSign: Number(tDeg.toFixed(4)),
      nakshatra:    NAKSHATRA_NAMES[nakIdx] || '',

      // House activation
      houseFromLagna,
      houseFromMoon,
      houseDomain:   houseSig?.domain || '',
      houseLord:     houseLord,
      houseLordRole: houseSig?.naturalKaraka ? (houseSig.naturalKaraka+' — '+houseSig.karakaRole) : '',
      naturalKaraka: houseSig?.naturalKaraka || '',

      // Planet's own signification
      planetKarakatva: PLANET_KARAKATVA[planet] || '',

      // Transit quality
      isGoodFromMoon,
      vedhaObstructed,
      vedhaObstructor,
      moorti,
      tara,
      bav, sav, kakshya,

      // Natal contacts
      natalPlanetsHere: natalHere,
      conjoinsNatalPlanet: natalHere.length > 0,

      // Score and summary
      score,
      impacts,
      quality: score >= 70 ? 'favorable' : score >= 45 ? 'mixed' : 'unfavorable',
    };
  });

  // ── 3. Overall day summary ────────────────────────────────────────────────────
  const scores = Object.values(planetTransits).map(p => p.score);
  const avgScore = scores.length ? Math.round(scores.reduce((a,b)=>a+b,0)/scores.length) : 50;

  // Most impactful transit (slow planets Jupiter, Saturn most important)
  const slowPlanets = ['Saturn','Jupiter','Rahu','Ketu'].filter(p => planetTransits[p]);
  const keyTransit  = slowPlanets[0] ? planetTransits[slowPlanets[0]] : null;

  // Houses being activated today (from transiting planets)
  const activatedHouses = {};
  Object.entries(planetTransits).forEach(([planet, data]) => {
    const h = data.houseFromLagna;
    if (!activatedHouses[h]) activatedHouses[h] = { house: h, domain: HOUSE_SIGNIFICATIONS[h]?.domain, planets: [], houseLord: data.houseLord };
    activatedHouses[h].planets.push({ planet, score: data.score, quality: data.quality });
  });

  return {
    date,
    // Dasha at this date (up to sukshma)
    dasha: dashaInfo,
    // Per-planet transit detail
    planets: planetTransits,
    // Activated houses summary
    activatedHouses,
    // Overall
    overallScore: avgScore,
    overallQuality: avgScore >= 65 ? 'favorable' : avgScore >= 45 ? 'mixed' : 'challenging',
    keyTransit: keyTransit ? {
      planet: slowPlanets[0],
      house: keyTransit.houseFromLagna,
      domain: keyTransit.houseDomain,
      quality: keyTransit.quality,
      moorti: keyTransit.moorti.name,
      tara: keyTransit.tara.name,
    } : null,
  };
}

module.exports = { analyzeTransitForDate, computeSukshmaDashas, HOUSE_SIGNIFICATIONS, PLANET_KARAKATVA };
