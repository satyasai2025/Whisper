/**
 * Planetary Dignity (Avastha by Sign Placement)
 *
 * Classical tiers (BPHS), from strongest to weakest:
 *   Exalted (Uchcha) > Moolatrikona > Own Sign (Swakshetra) >
 *   Great Friend's Sign > Friend's Sign > Neutral's Sign >
 *   Enemy's Sign > Great Enemy's Sign > Debilitated (Neecha)
 *
 * Exaltation/debilitation/moolatrikona points are fixed degrees within a
 * fixed sign (BPHS Ch. 3). Friend/enemy-sign tiers reuse the Naisargika
 * (natural) relationship between the placed planet and the sign's lord —
 * NOT the five-fold Panchadha (that combination is for inter-planet
 * relationships, not sign dignity; this is the standard classical usage).
 *
 * RAHU/KETU: Exaltation/debilitation signs for the nodes are NOT settled
 * in core BPHS and vary significantly across traditions (commonly cited
 * options include Taurus/Scorpio, Gemini/Sagittarius, or none at all).
 * Left unclassified here rather than asserting one convention as fact.
 */

const { SIGN_LORDS } = require('../parser/utils/constants');
const { getNaturalRelationship } = require('./relationships');

const EXALTATION = {
  Sun:     { sign: 'Ar', degree: 10 },
  Moon:    { sign: 'Ta', degree: 3 },
  Mars:    { sign: 'Cp', degree: 28 },
  Mercury: { sign: 'Vi', degree: 15 },
  Jupiter: { sign: 'Cn', degree: 5 },
  Venus:   { sign: 'Pi', degree: 27 },
  Saturn:  { sign: 'Li', degree: 20 }
};

// Debilitation sign is always the 7th from exaltation sign, at the same degree
const DEBILITATION = {
  Sun: 'Li', Moon: 'Sc', Mars: 'Cn', Mercury: 'Pi',
  Jupiter: 'Cp', Venus: 'Vi', Saturn: 'Ar'
};

const MOOLATRIKONA = {
  Sun:     { sign: 'Le', range: [0, 20] },
  Moon:    { sign: 'Ta', range: [4, 30] },
  Mars:    { sign: 'Ar', range: [0, 12] },
  Mercury: { sign: 'Vi', range: [16, 20] },
  Jupiter: { sign: 'Sg', range: [0, 10] },
  Venus:   { sign: 'Li', range: [0, 15] },
  Saturn:  { sign: 'Aq', range: [0, 20] }
};

function getOwnSigns(planet) {
  return Object.entries(SIGN_LORDS)
    .filter(([sign, lord]) => lord === planet)
    .map(([sign]) => sign);
}

const NATURAL_TO_TIER = {
  friend: "Friend's Sign",
  neutral: "Neutral's Sign",
  enemy: "Enemy's Sign"
};

function classifyDignity(planet, signCode, degreeInSign) {
  const exalt = EXALTATION[planet];
  if (exalt && signCode === exalt.sign) {
    const distance = Math.abs(degreeInSign - exalt.degree);
    return {
      tier: 'Exalted',
      detail: `Exact exaltation point is ${exalt.degree}° ${exalt.sign} — this placement is ${distance.toFixed(2)}° from it.`,
      strength: 'very strong'
    };
  }

  if (DEBILITATION[planet] && signCode === DEBILITATION[planet]) {
    const exactDegree = exalt.degree; // debilitation point = same degree number in debility sign
    const distance = Math.abs(degreeInSign - exactDegree);
    return {
      tier: 'Debilitated',
      detail: `Exact debilitation point is ${exactDegree}° ${signCode} — this placement is ${distance.toFixed(2)}° from it. Check for Neecha Bhanga (debilitation cancellation) conditions before treating this as simply weak.`,
      strength: 'weak (pending cancellation check)'
    };
  }

  const mt = MOOLATRIKONA[planet];
  if (mt && signCode === mt.sign && degreeInSign >= mt.range[0] && degreeInSign <= mt.range[1]) {
    return {
      tier: 'Moolatrikona',
      detail: `Within the Moolatrikona range (${mt.range[0]}°-${mt.range[1]}° ${mt.sign}).`,
      strength: 'strong'
    };
  }

  const ownSigns = getOwnSigns(planet);
  if (ownSigns.includes(signCode)) {
    return {
      tier: 'Own Sign (Swakshetra)',
      detail: `${signCode} is ruled by ${planet} itself.`,
      strength: 'strong'
    };
  }

  // Friend/neutral/enemy sign, via natural relationship to the sign's lord
  const signLord = SIGN_LORDS[signCode];
  const natural = getNaturalRelationship(planet, signLord);
  if (natural && NATURAL_TO_TIER[natural]) {
    return {
      tier: NATURAL_TO_TIER[natural],
      detail: `${signCode} is ruled by ${signLord}, a natural ${natural} of ${planet}.`,
      strength: natural === 'friend' ? 'moderate-favorable' : natural === 'enemy' ? 'moderate-unfavorable' : 'moderate-neutral'
    };
  }

  return {
    tier: 'Unclassified',
    detail: `Could not determine relationship between ${planet} and ${signLord}.`,
    strength: 'unknown'
  };
}

/**
 * Compute dignity for all planets present in `bodies`.
 */
function computeDignity(bodies) {
  const CLASSICAL_PLANETS = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn'];
  const result = {};

  for (const planet of CLASSICAL_PLANETS) {
    if (!bodies[planet]) continue;
    const { signCode, longitudeInSign } = bodies[planet];
    result[planet] = classifyDignity(planet, signCode, longitudeInSign);
  }

  for (const node of ['Rahu', 'Ketu']) {
    if (bodies[node]) {
      result[node] = {
        tier: 'Not classified',
        detail: 'Exaltation/debilitation signs for nodes are not settled in core BPHS and vary significantly by tradition — left unclassified rather than asserting one convention.',
        strength: 'n/a'
      };
    }
  }

  return {
    classifications: result,
    methodology: 'BPHS Ch. 3 — exaltation/debilitation/moolatrikona degrees are classical fixed points. Friend/enemy-sign tiers use Naisargika (natural) relationship to the sign lord, the standard convention for dignity (not the five-fold Panchadha, which is for inter-planet analysis).'
  };
}

module.exports = { computeDignity, classifyDignity, EXALTATION, DEBILITATION, MOOLATRIKONA, getOwnSigns };
