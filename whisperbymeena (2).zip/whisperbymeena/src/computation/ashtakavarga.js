/**
 * Ashtakavarga Computation — BAV, SAV, PAV, Kakshya
 * Source: PVR Narasimha Rao "Vedic Astrology: An Integrated Approach" Ch.12
 *
 * Ch.12.2 Benefic/Malefic Houses — Tables 19-26 (exact from book, p.147-150)
 * Ch.12.3 Bhinna Ashtakavarga (BAV) — count rekhas per rasi per planet
 * Ch.12.4 Samudaaya Ashtakavarga (SAV) — sum of all 7 planet BAVs
 * Ch.12.6 Prastaara Ashtakavarga (PAV) — individual contributor breakdown
 * Ch.25.5.2 Kakshyas — Table 60 (p.334), 8 per sign of 3°45' each
 * Ch.25.6 Sodhya Pinda — Table 29 multipliers for timing (p.160)
 *
 * PVR note (p.161): "Some astrologers use bindu for benefic and rekha for malefic
 * — opposite convention. This book follows Parasara: 1 = rekha = benefic."
 *
 * Tables verified: counting from planet/lagna position
 * "House" in tables means counting from that reference (contributor) zodiacally
 */

'use strict';

// ── BAV Tables (Tables 19-26, p.147-150) ─────────────────────────────────────
// Each table: 12 rows (houses 1-12 from contributor) × 8 columns (Sun,Moon,Mars,Merc,Jup,Ven,Sat,Lag)
// 1 = rekha (benefic), 0 = malefic
// Row index 0 = 1st house from contributor

const BAV_TABLES = {
  // Table 19: Sun's AV (p.147)
  Sun: [
    [1,0,1,0,0,0,1,0], // house 1 from contributor
    [1,0,1,0,0,0,1,0], // house 2
    [0,1,0,1,0,0,0,1], // house 3
    [1,0,1,0,0,0,1,1], // house 4
    [0,0,0,1,1,0,0,0], // house 5
    [0,1,0,1,1,1,0,1], // house 6
    [1,0,1,0,0,1,1,0], // house 7
    [1,0,1,0,0,0,1,0], // house 8
    [1,0,1,1,1,0,1,0], // house 9
    [1,1,1,1,0,0,1,1], // house 10
    [1,1,1,1,1,0,1,1], // house 11
    [0,0,0,1,0,1,0,1], // house 12
  ],
  // Table 20: Moon's AV (p.147)
  Moon: [
    [0,1,0,1,1,0,0,0],
    [0,0,1,0,1,0,0,0],
    [1,1,1,1,0,1,1,1],
    [0,0,0,1,1,1,0,0],
    [0,0,1,1,0,1,1,0],
    [1,1,1,0,0,0,1,1],
    [1,1,0,1,1,1,0,0],
    [1,0,0,1,1,0,0,0],
    [0,1,0,0,0,1,0,0],
    [1,1,1,1,1,1,0,1],
    [1,1,1,1,1,1,1,1],
    [0,0,0,0,0,0,0,0],
  ],
  // Table 21: Mars's AV (p.148)
  Mars: [
    [0,0,1,0,0,0,1,1],
    [0,0,1,0,0,0,0,0],
    [1,1,0,1,0,0,0,1],
    [0,0,1,0,0,0,1,0],
    [1,0,0,1,0,0,0,0],
    [1,1,0,1,1,1,0,1],
    [0,0,1,0,0,0,1,0],
    [0,0,1,0,0,1,1,0],
    [0,0,0,0,0,0,1,0],
    [1,0,1,0,1,0,1,1],
    [1,1,1,1,1,1,1,1],
    [0,0,0,0,1,1,0,0],
  ],
  // Table 22: Mercury's AV (p.148)
  Mercury: [
    [0,0,1,1,0,1,1,1],
    [0,1,1,0,0,1,1,1],
    [0,0,0,1,0,1,0,0],
    [0,1,1,0,0,1,1,1],
    [1,0,0,1,0,1,0,0],
    [1,1,0,1,1,0,0,1],
    [0,0,1,0,0,0,1,0],
    [0,1,1,0,1,1,1,1],
    [1,0,1,1,0,1,1,0],
    [0,1,1,1,0,0,1,1],
    [1,1,1,1,1,1,1,1],
    [1,0,0,1,1,0,0,0],
  ],
  // Table 23: Jupiter's AV (p.148)
  Jupiter: [
    [1,0,1,1,1,0,0,1],
    [1,1,1,1,1,1,0,1],
    [1,0,0,0,1,0,1,0],
    [1,0,1,1,1,0,0,1],
    [0,1,0,1,0,1,1,1],
    [0,0,0,1,0,1,1,1],
    [1,1,1,0,1,0,0,1],
    [1,0,1,0,1,0,0,0],
    [1,1,0,1,0,1,0,1],
    [1,0,1,1,1,1,0,1],
    [1,1,1,1,1,1,0,1],
    [0,0,0,0,0,0,1,0],
  ],
  // Table 24: Venus's AV (p.149)
  Venus: [
    [0,1,0,0,0,1,0,1],
    [0,1,0,0,0,1,0,1],
    [0,1,1,1,0,1,1,1],
    [0,1,1,0,0,1,1,1],
    [0,1,0,1,1,1,1,1],
    [0,0,1,1,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [1,1,0,0,1,1,1,1],
    [0,1,1,1,1,1,1,1],
    [0,0,0,0,1,1,1,0],
    [1,1,1,1,1,1,1,1],
    [1,1,1,0,0,0,0,0],
  ],
  // Table 25: Saturn's AV (p.149)
  Saturn: [
    [1,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0],
    [0,1,1,0,0,0,1,1],
    [1,0,0,0,0,0,0,1],
    [0,0,1,0,1,0,1,0],
    [0,1,1,1,1,1,1,1],
    [1,0,0,0,0,0,0,0],
    [1,0,0,1,0,0,0,0],
    [0,0,0,1,0,0,0,0],
    [1,0,1,1,0,0,0,1],
    [1,1,1,1,1,1,1,1],
    [0,0,1,1,1,1,0,0],
  ],
  // Table 26: Lagna's AV (p.150)
  Lagna: [
    [0,0,1,1,1,1,1,0],
    [0,0,0,1,1,1,0,0],
    [1,1,1,0,0,1,1,1],
    [1,0,0,1,1,1,1,0],
    [0,0,0,0,1,1,0,0],
    [1,1,1,1,1,0,1,1],
    [0,0,0,0,1,0,0,0],
    [0,0,0,1,0,1,0,0],
    [0,0,0,0,1,1,0,0],
    [1,1,1,1,1,0,1,1],
    [1,1,1,1,1,0,1,1],
    [1,1,0,0,0,0,0,0],
  ],
};

// ── Contributor order (for PAV) ───────────────────────────────────────────────
const CONTRIBUTORS = ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn','Lagna'];

// ── Kakshya table (Table 60, p.334) ──────────────────────────────────────────
// Each of 8 kakshyas = 3°45' = 3.75°
const KAKSHYA_LORDS = ['Saturn','Jupiter','Mars','Sun','Venus','Mercury','Moon','Lagna'];
// Start: 0°, 3.75°, 7.5°, 11.25°, 15°, 18.75°, 22.5°, 26.25°

// ── Sodhya Pinda multipliers (Table 29, p.160) ───────────────────────────────
const SODHYA_MULTIPLIERS = {
  Sun:5, Moon:5, Mars:8, Mercury:5, Jupiter:10, Venus:7, Saturn:5
};

// ─────────────────────────────────────────────────────────────────────────────

/**
 * Get house number from reference sign to target sign (zodiacal, 1-indexed)
 * e.g. from Ar(0) to Cn(3) = 4th house
 */
function getHouseFrom(fromSignIdx, toSignIdx) {
  return ((toSignIdx - fromSignIdx + 12) % 12) + 1;
}

/**
 * Compute BAV (Bhinna Ashtakavarga) for one planet.
 * Returns array of 12 rekha counts (index 0 = Aries).
 *
 * Method: For each of the 8 contributors, find contributor's sign,
 * count house from contributor to each target rasi, look up Table.
 * Sum the rekhas from all 8 contributors in each rasi.
 *
 * @param {string} planet       - 'Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn'
 * @param {object} positions    - { Sun:signIdx, Moon:signIdx, ... Lagna:signIdx } (0-11)
 * @returns {number[]}           - 12 rekha counts indexed by sign (Ar=0)
 */
function computeBAV(planet, positions) {
  const table = BAV_TABLES[planet];
  const rekhas = new Array(12).fill(0);
  const pav   = Array.from({length:12}, () => new Array(8).fill(0)); // PAV breakdown

  CONTRIBUTORS.forEach((contributor, cIdx) => {
    const contribSignIdx = positions[contributor];
    if (contribSignIdx === undefined || contribSignIdx === null) return;

    // For each target rasi (0-11)
    for (let targetSignIdx = 0; targetSignIdx < 12; targetSignIdx++) {
      const houseNum = getHouseFrom(contribSignIdx, targetSignIdx); // 1-12
      const hasRekha = table[houseNum - 1][cIdx]; // 1 or 0
      if (hasRekha) {
        rekhas[targetSignIdx]++;
        pav[targetSignIdx][cIdx] = 1;
      }
    }
  });

  return { rekhas, pav };
}

/**
 * Compute all BAVs and SAV.
 *
 * @param {object} signPositions - { Sun:signIdx, Moon:signIdx, ... Lagna:signIdx }
 * @returns {object} { bav: { Sun:[12], Moon:[12]... }, sav:[12], pav:{Sun:[[bool×8]×12]...} }
 */
function computeAshtakavarga(signPositions) {
  const bav = {};
  const pav = {};
  const sav = new Array(12).fill(0);

  const PLANETS_7 = ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn'];

  PLANETS_7.forEach(p => {
    const result = computeBAV(p, signPositions);
    bav[p] = result.rekhas;
    pav[p] = result.pav;
    // SAV = sum of 7 planet BAVs
    for (let i = 0; i < 12; i++) sav[i] += result.rekhas[i];
  });

  // Validate: SAV should total 337 rekhas across all 12 signs
  const savTotal = sav.reduce((a,b) => a+b, 0);

  return { bav, sav, pav, savTotal };
}

/**
 * Get kakshya info for a planet at a given degree in its sign.
 * @param {number} degreeInSign - 0-30
 * @param {string} planet       - the planet being analyzed
 * @param {Array}  bavForSign   - PAV for this sign [bool × 8 contributors]
 * @returns {object} { kakshyaIndex, kakshyaLord, hasRekha, favorable }
 */
function getKakshya(degreeInSign, bavPAVForSign) {
  const kakshyaIndex = Math.min(Math.floor(degreeInSign / 3.75), 7);
  const kakshyaLord  = KAKSHYA_LORDS[kakshyaIndex];
  const contribIdx   = CONTRIBUTORS.indexOf(kakshyaLord);
  const hasRekha     = (bavPAVForSign && contribIdx >= 0) ? bavPAVForSign[contribIdx] : false;

  return {
    kakshyaIndex,
    kakshyaLord,
    hasRekha: Boolean(hasRekha),
    startDeg: kakshyaIndex * 3.75,
    endDeg:   (kakshyaIndex + 1) * 3.75
  };
}

/**
 * Score a transit planet using full Ashtakavarga analysis.
 * Returns comprehensive transit quality for one planet.
 *
 * @param {string} planet        - transiting planet name
 * @param {number} transitSignIdx- sign index (0-11) planet is transiting
 * @param {number} degreeInSign  - degree in sign (0-30)
 * @param {object} av            - result of computeAshtakavarga
 * @returns {object} transit quality metrics
 */
function scoreTransit(planet, transitSignIdx, degreeInSign, av) {
  const bavForSign = av.bav[planet] ? av.bav[planet][transitSignIdx] : null;
  const savForSign = av.sav[transitSignIdx];
  const pavForSign = av.pav[planet] ? av.pav[planet][transitSignIdx] : null;

  const kakshya = getKakshya(degreeInSign, pavForSign);

  // BAV interpretation
  const bavScore = bavForSign !== null ? bavForSign : 4;
  const bavQuality = bavScore >= 5 ? 'strong' : bavScore >= 4 ? 'neutral' : 'weak';

  // SAV interpretation (Ch.12.4 p.153): ≥30 = favorable, <25 = unfavorable
  const savQuality = savForSign >= 30 ? 'favorable' : savForSign >= 25 ? 'average' : 'unfavorable';

  return {
    planet,
    transitSign: transitSignIdx,
    degreeInSign: Number(degreeInSign.toFixed(4)),
    bav: bavScore,
    bavQuality,
    sav: savForSign,
    savQuality,
    kakshya,
    overallFavorable: bavScore >= 5 && savForSign >= 25 && kakshya.hasRekha
  };
}

/**
 * Compute Sodhya Pinda for a planet (for transit timing, Ch.25.6)
 *
 * Method:
 *   Rasi Pinda = sum over all 12 signs of (rekhas_in_sign × sign_number)
 *   Graha Pinda = sum over all planets of (rekhas_in_planet's_sign × planet_multiplier)
 *   Sodhya Pinda = Rasi Pinda + Graha Pinda
 *
 * @param {string} planet        - planet whose SodhyaPinda to find
 * @param {object} av            - ashtakavarga results
 * @param {object} signPositions - planet sign positions (0-indexed)
 */
function computeSodhyaPinda(planet, av, signPositions) {
  const bavRows = av.pav[planet]; // [12 signs][8 contributors]
  if (!bavRows) return null;

  // Sodhya AV (SoAV): for each sign, sum rekhas × sign number (1-indexed from Ar)
  let rasiPinda = 0;
  for (let signIdx = 0; signIdx < 12; signIdx++) {
    const rekhas = av.bav[planet][signIdx];
    rasiPinda += rekhas * (signIdx + 1);
  }

  // Graha Pinda: for each of 7 planets, find their sign's rekhas in SoAV, multiply by multiplier
  let grahaPinda = 0;
  const PLANETS_7 = ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn'];
  PLANETS_7.forEach(p => {
    const mult = SODHYA_MULTIPLIERS[p];
    const pSignIdx = signPositions[p];
    if (pSignIdx !== undefined) {
      grahaPinda += av.bav[planet][pSignIdx] * mult;
    }
  });

  const sodhyaPinda = rasiPinda + grahaPinda;

  // Nakshatra from Sodhya Pinda (Ch.25.6)
  // "divide product with 27, take remainder, count nakshatras from Aswini"
  // Product = sodhyaPinda (or sodhyaPinda × rekhas_in_house)
  const nakshatraIndex = (sodhyaPinda % 27);

  return {
    rasiPinda,
    grahaPinda,
    sodhyaPinda,
    nakshatraIndex,
    note: 'Ch.25.6: Saturn transit in nakshatra index = bad; Jupiter = good'
  };
}

module.exports = {
  computeAshtakavarga,
  computeBAV,
  getKakshya,
  scoreTransit,
  computeSodhyaPinda,
  KAKSHYA_LORDS,
  CONTRIBUTORS,
  BAV_TABLES
};
