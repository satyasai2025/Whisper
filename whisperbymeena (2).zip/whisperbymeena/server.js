/**
 * WhisperByMeena — Local Server
 *
 * Endpoints:
 *   GET  /                       → browser UI
 *   POST /api/parse              → upload JHora PDF, return parsed JSON + analysis
 *   POST /api/parse-text         → submit raw text (for testing without PDF)
 *   GET  /api/events?chartKey=X  → list personal events for a chart
 *   POST /api/events             → add a personal event
 *   DELETE /api/events/:id       → remove a personal event
 *   GET  /api/dasha-context      → MD/AD/PD active on a given date for a saved chart
 *   GET  /api/health             → server status
 *
 * Start: node server.js
 * Access: http://localhost:3000
 */

const express = require('express');
const multer = require('multer');
const cors = require('cors');
const path = require('path');
const fs = require('fs').promises;

const { parseJHoraPDF, parseJHoraText } = require('./src/parser/jhora-parser');
const { findActiveDashaWithPratyantar } = require('./src/parser/extractors/vimshottari');
const { computeMultiDashaContext } = require('./src/parser/extractors/conditional-dashas');
const { computeConvergence } = require('./src/analysis/convergence');
const { generateReport } = require('./src/report/report-generator');
const { generateWorkbook } = require('./src/report/xlsx-generator');
const { predictAll } = require('./src/analysis/predictive-engine');
const { classifyEducationPath, classifyCareerPath, classifyForeignPath } = require('./src/analysis/promise');
const { analyzeTransit, TRANSIT_PLANETS } = require('./src/analysis/transit');
const { computeEphemeris } = require('./src/analysis/ephemeris');

const PORT = process.env.PORT || 3000;
const UPLOAD_DIR = path.join(__dirname, 'data', 'uploads');
const ANALYZED_DIR = path.join(__dirname, 'data', 'analyzed_charts');
const EVENTS_FILE = path.join(__dirname, 'data', 'events.json');

const app = express();

app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

(async () => {
  await fs.mkdir(UPLOAD_DIR, { recursive: true });
  await fs.mkdir(ANALYZED_DIR, { recursive: true });
})();

const storage = multer.diskStorage({
  destination: UPLOAD_DIR,
  filename: (req, file, cb) => {
    const safeName = file.originalname.replace(/[^a-z0-9._-]/gi, '_');
    cb(null, Date.now() + '_' + safeName);
  }
});
const upload = multer({ storage, limits: { fileSize: 10 * 1024 * 1024 } });

// ===== Helpers =====

function sanitizeKey(s) {
  return (s || '').trim().replace(/\s+/g, '_').replace(/[^a-zA-Z0-9_-]/g, '');
}

function deriveChartKey(chart, fallbackFilename) {
  const fromName = sanitizeKey(chart.native?.name);
  if (fromName) return fromName;
  return sanitizeKey(fallbackFilename.replace(/\.[^.]+$/, '')) || 'chart';
}

function computeActiveDashas(chart) {
  const today = new Date().toISOString().split('T')[0];
  const multi = computeMultiDashaContext(chart.dashas || {}, today);
  // Vimshottari gets the Pratyantar-aware version (richer than the generic one)
  if (chart.dashas?.vimshottari?.mahadashas) {
    multi.vimshottari = findActiveDashaWithPratyantar(chart.dashas.vimshottari.mahadashas, today);
  }
  return { asOf: today, ...multi };
}

async function loadEvents() {
  try {
    const raw = await fs.readFile(EVENTS_FILE, 'utf-8');
    const data = JSON.parse(raw);
    return Array.isArray(data.events) ? data.events : [];
  } catch {
    return [];
  }
}

async function saveEvents(events) {
  const payload = {
    _format: 'Each event: { id, chartKey, date: YYYY-MM-DD, category, description, verified, notes? }',
    _categories: ['career', 'marriage', 'education', 'health', 'relocation', 'finance', 'family', 'spiritual', 'other'],
    events
  };
  await fs.writeFile(EVENTS_FILE, JSON.stringify(payload, null, 2));
}

async function loadSavedChart(chartKey) {
  // Try computed chart first (from /api/compute)
  const computedPath = path.join(ANALYZED_DIR, `${chartKey}.json`);
  try {
    const raw = await fs.readFile(computedPath, 'utf-8');
    const computed = JSON.parse(raw);
    // If this is a computed chart, adapt it to the shape parsers expect
    if (computed.planets && computed.lagna) {
      return adaptComputedChart(computed);
    }
    return computed;
  } catch(e) { /* not a computed chart, try parsed */ }

  // Fall back to JHora-parsed chart
  const parsedPath = path.join(ANALYZED_DIR, `${chartKey}_parsed.json`);
  const raw = await fs.readFile(parsedPath, 'utf-8');
  return JSON.parse(raw);
}

// Adapt a computed-horoscope result to the shape expected by analysis modules
function adaptComputedChart(c) {
  // The new buildHoroscope already includes bodies + analysis
  // Just add dashas in JHora parser shape and return
  const native = {
    name: c.native && c.native.name,
    dateOfBirth: c.native && c.native.birthDate,
    timeOfBirth: c.native && c.native.birthTime,
    gmtOffset: c.native && c.native.gmtOffset,
    coordinates: { latitude: c.native && c.native.latitude, longitude: c.native && c.native.longitude },
    placeOfBirth: c.native && (c.native.place || '')
  };
  const dashas = {
    vimshottari: { mahadashas: c.vimshottariDashas || [] },
    ashtottari:  { mahadashas: c.ashtottariDashas  || [] }
  };
  return {
    _computed: c,
    bodies:   c.bodies   || {},
    analysis: c.analysis || {},
    dashas,
    native,
    metadata: { chartKey: c._chartKey || 'computed', isComputed: true }
  };
}

// ===== Routes =====

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Safe JSON serializer that removes circular references
function safeJSON(obj) {
  const seen = new WeakSet();
  return JSON.parse(JSON.stringify(obj, (key, val) => {
    if (typeof val === 'object' && val !== null) {
      if (seen.has(val)) return '[Circular]';
      seen.add(val);
    }
    return val;
  }));
}

app.post('/api/parse', upload.single('pdf'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No PDF uploaded. Use field name "pdf".' });
  }
  try {
    const chart = await parseJHoraPDF(req.file.path);
    chart.metadata.originalFilename = req.file.originalname;
    chart.metadata.activeDashas = computeActiveDashas(chart);

    const chartKey = deriveChartKey(chart, req.file.originalname);
    chart.metadata.chartKey = chartKey;

    // If native has birth coordinates + time, also run buildHoroscope
    // so the UI gets the same rich data as /api/compute
    const n = chart.native;
    if (n && n.latitude && n.longitude && n.birthDate && n.birthTime) {
      try {
        const [byear, bmonth, bday] = (n.birthDate || '').split('-').map(Number);
        const [bhour, bmin] = (n.birthTime || '').split(':').map(Number);
        const gmtOffset = n.timezone || n.gmtOffset || 5.5;

        if (byear && bmonth && bday && !isNaN(bhour)) {
          const { buildHoroscope } = require('./src/analysis/horoscope-engine');
          const computed = buildHoroscope({
            name: n.name || 'Native',
            year: byear, month: bmonth, day: bday,
            hour: bhour, minute: bmin || 0, second: 0,
            gmtOffsetHours: gmtOffset,
            latitude: n.latitude, longitude: n.longitude
          }, { fromYear: new Date().getFullYear() - 2, toYear: new Date().getFullYear() + 10 });

          computed.native.name = n.name || computed.native.name;
          computed.native.place = n.place || n.placeOfBirth || '';
          computed.native.gender = req.body.gender || n.gender || 'unknown';
          computed.native.year = byear; computed.native.month = bmonth; computed.native.day = bday;
          computed.native.hour = bhour; computed.native.minute = bmin || 0;
          computed.native.gmtOffset = gmtOffset; computed.native.gmtOffsetHours = gmtOffset;
          computed.native.latitude = n.latitude; computed.native.longitude = n.longitude;

          // Save and return computed chart (same format as /api/compute)
          const computedKey = chartKey + '_computed';
          const computedPath = path.join(ANALYZED_DIR, `${computedKey}.json`);
          const safe = safeJSON(computed);
          await fs.writeFile(computedPath, JSON.stringify(safe, null, 2));
          safe.chartKey = computedKey;
          safe._parsedAlso = true;
          return res.json(safe);
        }
      } catch(e2) {
        console.warn('buildHoroscope after parse failed:', e2.message);
        // Fall through to return parsed chart
      }
    }

    const outPath = path.join(ANALYZED_DIR, `${chartKey}_parsed.json`);
    await fs.writeFile(outPath, JSON.stringify(chart, null, 2));
    chart.metadata.savedTo = `${chartKey}_parsed.json`;

    res.json(chart);
  } catch (err) {
    console.error('Parse error:', err);
    res.status(500).json({ error: err.message, stack: err.stack });
  }
});

app.post('/api/parse-text', (req, res) => {
  const { text } = req.body;
  if (!text || typeof text !== 'string') {
    return res.status(400).json({ error: 'Provide raw text in "text" field.' });
  }
  try {
    const chart = parseJHoraText(text);
    chart.metadata.activeDashas = computeActiveDashas(chart);
    chart.metadata.chartKey = deriveChartKey(chart, 'pasted_text');
    res.json(chart);
  } catch (err) {
    console.error('Parse error:', err);
    res.status(500).json({ error: err.message });
  }
});

// --- Personal Events ---

app.get('/api/events', async (req, res) => {
  const { chartKey } = req.query;
  const events = await loadEvents();
  const filtered = chartKey ? events.filter(e => e.chartKey === chartKey) : events;
  res.json({ events: filtered });
});

app.post('/api/events', async (req, res) => {
  const { chartKey, date, category, description, verified, notes } = req.body;
  if (!chartKey || !date || !category || !description) {
    return res.status(400).json({ error: 'Required: chartKey, date, category, description.' });
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    return res.status(400).json({ error: 'date must be in YYYY-MM-DD format.' });
  }

  const events = await loadEvents();
  const newEvent = {
    id: Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
    chartKey, date, category, description,
    verified: verified !== false,
    notes: notes || null
  };

  // Compute dasha context BEFORE saving, so it's persisted in the file
  // (not just returned in this response). Multi-system: not just
  // Vimshottari — convergence across systems is the point.
  try {
    const chart = await loadSavedChart(chartKey);
    const multi = computeMultiDashaContext(chart.dashas || {}, date);
    if (chart.dashas?.vimshottari?.mahadashas) {
      multi.vimshottari = findActiveDashaWithPratyantar(chart.dashas.vimshottari.mahadashas, date);
    }
    newEvent.dashaContext = multi;
    newEvent.convergence = computeConvergence(multi, chart);
  } catch {
    newEvent.dashaContext = null; // chart not found/saved yet — non-fatal
    newEvent.convergence = null;
  }

  events.push(newEvent);
  await saveEvents(events);

  res.json({ event: newEvent });
});

app.delete('/api/events/:id', async (req, res) => {
  const events = await loadEvents();
  const filtered = events.filter(e => e.id !== req.params.id);
  if (filtered.length === events.length) {
    return res.status(404).json({ error: 'Event not found.' });
  }
  await saveEvents(filtered);
  res.json({ deleted: true });
});

// --- Dasha context lookup (for any arbitrary date against a saved chart) ---

app.get('/api/dasha-context', async (req, res) => {
  const { chartKey, date } = req.query;
  if (!chartKey || !date) {
    return res.status(400).json({ error: 'Required query params: chartKey, date.' });
  }
  try {
    const chart = await loadSavedChart(chartKey);
    const multi = computeMultiDashaContext(chart.dashas || {}, date);
    if (chart.dashas?.vimshottari?.mahadashas) {
      multi.vimshottari = findActiveDashaWithPratyantar(chart.dashas.vimshottari.mahadashas, date);
    }
    res.json({ context: multi, convergence: computeConvergence(multi, chart) });
  } catch (err) {
    res.status(404).json({ error: `Chart "${chartKey}" not found. Parse it first.` });
  }
});

// --- Predictive Engine (forward event-timing with convergence%) ---

app.get('/api/predict', async (req, res) => {
  const { chartKey, asOf } = req.query;
  if (!chartKey) {
    return res.status(400).json({ error: 'Required query param: chartKey.' });
  }
  try {
    const chart = await loadSavedChart(chartKey);
    const fromDate = asOf || new Date().toISOString().split('T')[0];
    const predictions = predictAll(chart, fromDate, { maxWindows: 5 });
    const educationPath = classifyEducationPath(chart);
    const careerPath = classifyCareerPath(chart);
    const foreignPath = classifyForeignPath(chart);
    res.json(safeJSON({ asOf: fromDate, predictions, educationPath, careerPath, foreignPath }));
  } catch (err) {
    console.error('Predict error:', err);
    res.status(404).json({ error: `Chart "${chartKey}" not found, or prediction failed: ${err.message}` });
  }
});

// --- Report Export ---

app.get('/api/report', async (req, res) => {
  const { chartKey } = req.query;
  if (!chartKey) {
    return res.status(400).json({ error: 'Required query param: chartKey.' });
  }
  try {
    const chart = await loadSavedChart(chartKey);
    const allEvents = await loadEvents();
    const events = allEvents.filter(e => e.chartKey === chartKey);
    const html = generateReport(chart, events);
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="jyotish-report-${chartKey}.html"`);
    res.send(html);
  } catch (err) {
    console.error('Report error:', err);
    res.status(404).json({ error: `Chart "${chartKey}" not found, or report failed: ${err.message}` });
  }
});

app.get('/api/workbook', async (req, res) => {
  const { chartKey } = req.query;
  if (!chartKey) {
    return res.status(400).json({ error: 'Required query param: chartKey.' });
  }
  try {
    const chart = await loadSavedChart(chartKey);
    const allEvents = await loadEvents();
    const events = allEvents.filter(e => e.chartKey === chartKey);
    const buffer = await generateWorkbook(chart, events);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="jyotish-data-${chartKey}.xlsx"`);
    res.send(Buffer.from(buffer));
  } catch (err) {
    console.error('Workbook error:', err);
    res.status(404).json({ error: `Chart "${chartKey}" not found, or workbook failed: ${err.message}` });
  }
});

// --- Gochar (Transit) — manual input ---

app.get('/api/transit/planets', (req, res) => {
  // Lets the frontend know which planets to show input fields for,
  // without hardcoding the list client-side too.
  res.json({ planets: TRANSIT_PLANETS });
});

app.post('/api/transit', async (req, res) => {
  const { chartKey, positions, asOfDate } = req.body;
  if (!chartKey || !positions) {
    return res.status(400).json({ error: 'Required: chartKey, positions (e.g. { "Sun": "Ar", "Moon": "Ta", ... }).' });
  }
  try {
    const chart = await loadSavedChart(chartKey);
    const result = analyzeTransit(chart, positions, asOfDate);
    res.json(result);
  } catch (err) {
    console.error('Transit error:', err);
    res.status(404).json({ error: `Chart "${chartKey}" not found, or transit analysis failed: ${err.message}` });
  }
});

// --- Gochar (Transit) — automatic, validated ephemeris ---
// See src/analysis/ephemeris.js for the full validation record (checked
// against JHora ground truth on two independent charts, sub-2-arcsecond
// accuracy). Offered as an ADDITIONAL option alongside manual input, not
// a replacement.
app.post('/api/transit/auto', async (req, res) => {
  const { chartKey, date, time, gmtOffsetHours } = req.body;
  if (!chartKey || !date) {
    return res.status(400).json({ error: 'Required: chartKey, date (YYYY-MM-DD). Optional: time (HH:MM, default 12:00), gmtOffsetHours (default 5.5).' });
  }
  try {
    const { analyzeTransitForDate } = require('./src/engine/transit-analyzer');
    const chart = await loadSavedChart(chartKey);
    const [year, month, day] = date.split('-').map(Number);
    const [hour, minute] = (time || '12:00').split(':').map(Number);
    const offset = gmtOffsetHours !== undefined ? Number(gmtOffsetHours) : (chart.native?.gmtOffsetHours || 5.5);
    const lat = chart.native?.latitude || 23.596111;
    const lon = chart.native?.longitude || 73.588333;

    // Compute transit positions
    const { computeFullHoroscope } = require('./src/analysis/ephemeris');
    const h = computeFullHoroscope({ year, month, day, hour, minute: minute||0, second:0, gmtOffsetHours: offset }, lat, lon);
    const transitPlanets = {};
    ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn','Rahu','Ketu'].forEach(p => {
      if (h.planets?.[p]) {
        transitPlanets[p] = {
          signCode: h.planets[p].signCode,
          longitude: h.planets[p].siderealLongitude,
          degreeInSign: h.planets[p].degreeInSign
        };
      }
    });

    const result = analyzeTransitForDate({ date, chart, transitPlanets });

    // Normalize to UI-expected format
    result.asOfDate = date;
    result.natalMoonSign = chart.bodies?.Moon?.signCode || '—';
    result.ayanamsaUsed = h.lagna?.ayanamsa?.toFixed(4) || '23.5';
    result.nativeAge = year - (chart.native?.year || 1976);
    result.computedPositions = transitPlanets;

    // Map 'planets' to 'results' with UI-expected fields
    result.results = {};
    Object.entries(result.planets || {}).forEach(([planet, p]) => {
      result.results[planet] = {
        transitSign: p.sign || p.signCode,
        houseFromMoon: p.houseFromMoon || '—',
        snapshot: p.quality === 'favorable' ? 'Good' : p.quality === 'unfavorable' ? 'Unfavorable' : 'Mixed',
        result: p.impacts?.join('; ') || '',
        chartAdjusted: p.score != null ? {
          label: p.quality || 'mixed',
          combinedScore: p.score - 50,
          breakdown: (p.impacts||[]).map(imp => ({ label: imp, value: 0, reason: imp }))
        } : null,
        tara: p.tara,
        moorti: p.moorti,
        bav: p.bav,
        nakshatra: p.nakshatra,
        eventConnections: []
      };
    });

    res.json(safeJSON(result));
  } catch (err) {
    console.error('Auto-transit error:', err);
    res.status(500).json({ error: `Transit computation failed: ${err.message}` });
  }
});

// ── Verify a single past event against stored chart ──────────────────────────
app.post('/api/verify-event', async (req, res) => {
  const { chartKey, eventKey, eventDate, eventLabel, gender } = req.body;
  if (!chartKey || !eventKey || !eventDate) {
    return res.status(400).json({ error: 'Required: chartKey, eventKey, eventDate' });
  }
  try {
    const { verifyPastEvent } = require('./src/engine/event-verifier');
    const chart = await loadSavedChart(chartKey);
    const nativeGender = gender || chart.native?.gender || 'female';

    // Compute transit at event date
    const [y,m,d] = eventDate.split('-').map(Number);
    const eph = computeEphemeris({ year:y, month:m, day:d, hour:12, minute:0, second:0, gmtOffsetHours: chart.native?.gmtOffset || 5.5 });
    const transitData = {};
    for (const [p, pos] of Object.entries(eph.positions)) {
      transitData[p] = { signCode: pos.signCode, longitude: pos.siderealLongitude || pos.longitude, degreeInSign: pos.degreeInSign };
    }

    const result = verifyPastEvent({ eventKey, eventDate, eventLabel: eventLabel || eventKey, chart, transitData, gender: nativeGender });

    // Add to data bank
    try {
      const { addEventToDataBank } = require('./src/utils/data-bank');
      addEventToDataBank(chartKey, chart.native?.name || 'Native', { ...result, eventKey, eventDate, eventLabel });
    } catch(e) { /* non-fatal */ }

    res.json(result);
  } catch(err) {
    console.error('Verify event error:', err);
    res.status(500).json({ error: err.message });
  }
});


app.post('/api/transit/full', async (req, res) => {
  const { chartKey, date, time, gmtOffsetHours, latitude, longitude } = req.body;
  if (!date) return res.status(400).json({ error: 'Required: date. Optional: chartKey OR latitude+longitude, time, gmtOffsetHours' });

  try {
    const { analyzeTransitForDate } = require('./src/engine/transit-analyzer');
    const [year, month, day] = date.split('-').map(Number);
    const [hour, minute] = (time || '12:00').split(':').map(Number);
    const offset = Number(gmtOffsetHours ?? 5.5);
    const lat = Number(latitude ?? 23.596111);
    const lon = Number(longitude ?? 73.588333);

    // Load or use stored chart
    let chart;
    if (chartKey) {
      chart = await loadSavedChart(chartKey);
    } else {
      return res.status(400).json({ error: 'chartKey required' });
    }

    // Compute transit positions at requested time
    const eph = computeEphemeris({ year, month, day, hour, minute: minute||0, second:0, gmtOffsetHours: offset }, lat, lon);
    const transitPlanets = {};
    for (const [p, pos] of Object.entries(eph.positions)) {
      transitPlanets[p] = { signCode: pos.signCode, longitude: pos.siderealLongitude || pos.longitude, degreeInSign: pos.degreeInSign };
    }

    const result = analyzeTransitForDate({ date, chart, transitPlanets });
    result.transitTime = time || '12:00';
    result.gmtOffset = offset;
    res.json(result);
  } catch (err) {
    console.error('Full transit error:', err);
    res.status(500).json({ error: err.message });
  }
});

// ── Transit event check — will transit support a specific event? ──────────────
app.post('/api/transit/event-check', async (req, res) => {
  const { chartKey, date, eventKey } = req.body;
  if (!chartKey || !date || !eventKey) {
    return res.status(400).json({ error: 'Required: chartKey, date, eventKey' });
  }
  try {
    const { analyzeTransitForDate } = require('./src/engine/transit-analyzer');
    const chart = await loadSavedChart(chartKey);
    const [y,m,d] = date.split('-').map(Number);
    const eph = computeEphemeris({ year:y,month:m,day:d,hour:12,minute:0,second:0,gmtOffsetHours:chart.native?.gmtOffset||5.5 });
    const transitPlanets = {};
    for (const [p,pos] of Object.entries(eph.positions)) {
      transitPlanets[p] = { signCode:pos.signCode, longitude:pos.siderealLongitude||pos.longitude, degreeInSign:pos.degreeInSign };
    }
    const analysis = analyzeTransitForDate({ date, chart, transitPlanets });

    const PRIMARY = { marriage:['Venus','Jupiter'], firstJob:['Saturn','Sun','Mercury'],
      jobChange:['Saturn','Mercury'], promotion:['Sun','Jupiter'], children:['Jupiter','Moon'],
      housePurchase:['Mars','Saturn'], foreignTravel:['Rahu','Jupiter'],
      majorIllness:['Saturn','Mars'], deathOfFather:['Sun','Saturn'],
      deathOfMother:['Moon','Saturn'], wealth:['Jupiter','Venus'] };
    const SECONDARY = { marriage:['Mars','Rahu'], firstJob:['Mars','Jupiter'],
      children:['Mars','Sun'], housePurchase:['Moon','Jupiter'],
      foreignTravel:['Saturn','Moon'], majorIllness:['Rahu','Moon'], wealth:['Mercury','Moon'] };
    const LABELS = { marriage:'Marriage/Partnership', firstJob:'Career Start',
      jobChange:'Job Change', promotion:'Promotion', children:'Child Birth',
      housePurchase:'Property Purchase', foreignTravel:'Foreign Travel',
      majorIllness:'Major Illness', deathOfFather:'Death of Father',
      deathOfMother:'Death of Mother', wealth:'Wealth/Financial Gain' };

    const primary   = PRIMARY[eventKey]   || [];
    const secondary = SECONDARY[eventKey] || [];
    let supportScore = 0, primaryPassing = 0;
    const planetResults = [];

    Object.entries(analysis.planets || {}).forEach(([planet, pt]) => {
      const isPrimary   = primary.includes(planet);
      const isSecondary = secondary.includes(planet);
      if (!isPrimary && !isSecondary && !['Saturn','Jupiter','Rahu','Ketu','Mars'].includes(planet)) return;

      const passing = pt.isGoodFromMoon && !pt.vedhaObstructed;
      if (isPrimary   && passing)  { supportScore += 25; primaryPassing++; }
      else if (isSecondary && passing) supportScore += 10;
      else if (isPrimary && !passing)  supportScore -= 5;

      planetResults.push({
        planet, sign:pt.sign, houseFromMoon:pt.houseFromMoon,
        isGoodFromMoon:pt.isGoodFromMoon, vedhaObstructed:pt.vedhaObstructed,
        vedhaObstructor:pt.vedhaObstructor, moorti:pt.moorti?.name,
        taraName:pt.tara?.name, bav:pt.bav,
        eventRelevance: isPrimary?'primary':isSecondary?'secondary':'minor',
      });
    });

    supportScore = Math.max(0, Math.min(100, supportScore));
    res.json({
      date, eventKey, eventLabel: LABELS[eventKey]||eventKey,
      overallSupport: supportScore, primaryPassing, totalPrimary: primary.length,
      verdict: supportScore>=65?'Strong transit support':supportScore>=40?'Partial support':'Weak transit support',
      planets: planetResults.sort((a,b) => ['primary','secondary','minor'].indexOf(a.eventRelevance) - ['primary','secondary','minor'].indexOf(b.eventRelevance)),
    });
  } catch(err) {
    console.error('Transit event-check error:', err);
    res.status(500).json({ error: err.message });
  }
});

const { buildHoroscope } = require('./src/analysis/horoscope-engine');

// --- Compute from birth data (primary path, no JHora needed) ---
app.post('/api/compute', async (req, res) => {
  const { name, year, month, day, hour, minute, second, gmtOffsetHours, latitude, longitude, place, pastEvents, fromYear, toYear } = req.body;
  if (!year || !month || !day || latitude === undefined || longitude === undefined) {
    return res.status(400).json({ error: 'Required: year, month, day, latitude, longitude (and hour, minute, gmtOffsetHours for accurate Lagna).' });
  }
  try {
    const result = buildHoroscope(
      { name: name || '', year: Number(year), month: Number(month), day: Number(day),
        hour: Number(hour || 0), minute: Number(minute || 0), second: Number(second || 0),
        gmtOffsetHours: Number(gmtOffsetHours !== undefined ? gmtOffsetHours : 5.5),
        latitude: Number(latitude), longitude: Number(longitude) },
      { fromYear: fromYear ? Number(fromYear) : undefined,
        toYear: toYear ? Number(toYear) : undefined,
        pastEvents: pastEvents || [] }
    );
    // Add place name and gender to native info
    if (place) result.native.place = place;
    if (req.body.gender) result.native.gender = req.body.gender;
    // Store birth data for Tajaka computation
    result.native.year   = Number(year);
    result.native.month  = Number(month);
    result.native.day    = Number(day);
    result.native.hour   = Number(hour || 0);
    result.native.minute = Number(minute || 0);
    result.native.gmtOffset     = Number(gmtOffsetHours !== undefined ? gmtOffsetHours : 5.5);
    result.native.gmtOffsetHours = Number(gmtOffsetHours !== undefined ? gmtOffsetHours : 5.5);
    result.native.latitude  = Number(latitude);
    result.native.longitude = Number(longitude);
    // Save for use by other endpoints (transit, etc.)
    const chartKey = (name || 'chart').replace(/\s+/g, '_') + '_computed';

    // Remove circular references before serialization
    const safeResult = safeJSON(result);

    await fs.writeFile(
      path.join(ANALYZED_DIR, chartKey + '.json'),
      JSON.stringify({ ...safeResult, _chartKey: chartKey }, null, 2)
    );

    // Auto-add to Excel data bank (non-fatal)
    try {
      const { addChartToDataBank, addPredictionsToDataBank } = require('./src/utils/data-bank');
      const bankResult = addChartToDataBank(result, { chartKey });
      if (bankResult.added) {
        const { predictAll } = require('./src/analysis/predictive-engine');
        const preds = safeJSON(predictAll(result, new Date().toISOString().split('T')[0], { maxWindows: 3 }));
        addPredictionsToDataBank(chartKey, name || 'Native', preds);
      }
      safeResult._bankStatus = bankResult;
    } catch(bankErr) {
      console.warn('DataBank (non-fatal):', bankErr.message);
    }

    res.json({ chartKey, ...safeResult });
  } catch (err) {
    console.error('Compute error:', err);
    res.status(500).json({ error: 'Computation failed: ' + err.message });
  }
});

// ── Jyotish Portrait ─────────────────────────────────────────────────────────
app.post('/api/portrait', async (req, res) => {
  const { chartKey } = req.body;
  if (!chartKey) return res.status(400).json({ error: 'Required: chartKey' });
  try {
    const { generatePortrait } = require('./src/engine/portrait-engine');
    const chart = await loadSavedChart(chartKey);
    const portrait = generatePortrait(chart);
    res.json(safeJSON(portrait));
  } catch(err) {
    console.error('Portrait error:', err);
    res.status(500).json({ error: err.message });
  }
});


app.post('/api/btr/questions', async (req, res) => {
  const { chartKey, fromAge, toAge, maxQ } = req.body;
  if (!chartKey) return res.status(400).json({ error: 'Required: chartKey' });
  try {
    const { generateBTRQuestions } = require('./src/engine/btr-questionnaire');
    const chart = await loadSavedChart(chartKey);
    const questions = generateBTRQuestions(chart, { fromAge:fromAge||18, toAge:toAge||65, maxQ:maxQ||12 });
    res.json({ chartKey, questions, total: questions.length });
  } catch(err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/btr/score', async (req, res) => {
  const { chartKey, answers } = req.body;
  if (!chartKey || !answers) return res.status(400).json({ error: 'Required: chartKey, answers' });
  try {
    const { generateBTRQuestions, scoreBTRAnswers } = require('./src/engine/btr-questionnaire');
    const chart = await loadSavedChart(chartKey);
    const questions = generateBTRQuestions(chart, { fromAge:18, toAge:65, maxQ:15 });
    const answerMap = {};
    answers.forEach(a => { answerMap[a.id] = a.answer; });
    questions.forEach(q => { if (answerMap[q.id] !== undefined) q.answer = answerMap[q.id]; });
    const transitFn = async (dateStr) => {
      const [y,m,d] = dateStr.split('-').map(Number);
      const eph = computeEphemeris({ year:y,month:m,day:d,hour:12,minute:0,second:0,gmtOffsetHours:chart.native?.gmtOffset||5.5 });
      const t = {};
      for (const [p,pos] of Object.entries(eph.positions)) {
        t[p] = { signCode:pos.signCode, longitude:pos.siderealLongitude||pos.longitude, degreeInSign:pos.degreeInSign };
      }
      return t;
    };
    const result = await scoreBTRAnswers(questions, chart, transitFn);
    res.json({ chartKey, ...result });
  } catch(err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Tajaka Annual Chart ───────────────────────────────────────────────────────
app.post('/api/tajaka', async (req, res) => {
  const { chartKey, year, fromYear, toYear } = req.body;
  if (!chartKey) return res.status(400).json({ error: 'Required: chartKey' });
  try {
    const { computeTajakaChart, computeTajakaRange } = require('./src/computation/tajaka');
    const chart = await loadSavedChart(chartKey);
    const native = chart.native || {};
    const nativeData = {
      year: native.year||1976, month: native.month||1, day: native.day||1,
      hour: native.hour||0, minute: native.minute||0, second: 0,
      gmtOffsetHours: native.gmtOffset || native.gmtOffsetHours || 5.5,
      latitude: native.latitude||23.596111, longitude: native.longitude||73.588333,
    };
    if (year) {
      const tajaka = computeTajakaChart(nativeData, Number(year));
      res.json(safeJSON(tajaka));
    } else {
      const currentYear = new Date().getFullYear();
      const start = fromYear ? Number(fromYear) : currentYear - 1;
      const end   = toYear   ? Number(toYear)   : currentYear + 3;
      const charts = computeTajakaRange(nativeData, start, Math.min(end, start+8));
      res.json(safeJSON({ charts, count: charts.length }));
    }
  } catch(err) {
    console.error('Tajaka error:', err);
    res.status(500).json({ error: err.message });
  }
});

// ── Data Bank Download ────────────────────────────────────────────────────────
app.get('/api/databank/download', (req, res) => {
  try {
    const { getBankFilePath } = require('./src/utils/data-bank');
    const filePath = getBankFilePath();
    if (!require('fs').existsSync(filePath)) {
      return res.status(404).json({ error: 'Data bank not yet created. Compute a chart first.' });
    }
    res.download(filePath, 'WhisperByMeena_DataBank.xlsx');
  } catch(e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/databank/status', (req, res) => {
  try {
    const { getBankFilePath } = require('./src/utils/data-bank');
    const XLSX = require('xlsx');
    const filePath = getBankFilePath();
    if (!require('fs').existsSync(filePath)) {
      return res.json({ exists: false, charts: 0, events: 0, predictions: 0 });
    }
    const wb = XLSX.readFile(filePath);
    const chartsWs = wb.Sheets['Charts'];
    const eventsWs = wb.Sheets['Events'];
    const predsWs  = wb.Sheets['Predictions'];
    const countRows = ws => {
      if (!ws || !ws['!ref']) return 0;
      return XLSX.utils.decode_range(ws['!ref']).e.r; // rows - 1 header
    };
    res.json({
      exists: true,
      charts: countRows(chartsWs),
      events: countRows(eventsWs),
      predictions: countRows(predsWs),
      filePath: path.basename(filePath)
    });
  } catch(e) {
    res.status(500).json({ error: e.message });
  }
});


app.listen(PORT, () => {
  console.log(`\n  WhisperByMeena server running`);
  console.log(`  → Open http://localhost:${PORT} in your browser`);
  console.log(`  → Upload a JHora PDF to begin\n`);
});
