/**
 * Yoga Detection
 *
 * SCOPE NOTE: Classical literature documents hundreds of named yogas, many
 * with inconsistent or debated conditions across texts. Rather than
 * attempting exhaustive (and inevitably shaky) coverage, this module
 * detects a focused set of well-defined, broadly-agreed-upon yoga
 * FAMILIES, each with its classical source and connection logic shown.
 * Treat absence of a yoga here as "not detected by these specific
 * conditions," not as "this chart has no yogas."
 *
 * Detected:
 *   - Parivartana Yoga (sign exchange) — foundational, classified by
 *     which house-types are involved
 *   - Gajakesari Yoga — Moon-Jupiter mutual kendra
 *   - Raja Yoga (Kendra-Trikona connection) — BPHS's central
 *     auspiciousness principle: a kendra lord connected to a trikona lord
 *   - Dhana Yoga — 2nd/11th (wealth) lords connected to 1st/5th/9th lords
 *   - Vipreet Raja Yoga — Harsha/Sarala/Vimala (6th/8th/12th lords
 *     placed back in 6th/8th/12th)
 *
 * "Connected" means: conjunction (same house), mutual graha drishti
 * (aspect), or parivartana (sign exchange) — the three classical
 * connection types BPHS uses for yoga formation.
 */

const { SIGN_LORDS } = require('../parser/utils/constants');
const { signAtHouse, getHouseLordships } = require('./functional-nature');

const CLASSICAL_PLANETS = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn'];

function ord(n) {
  if (n === 1 || n === 11) return n + 'st';
  if (n === 2 || n === 12) return n + 'nd';
  if (n === 3) return n + 'rd';
  return n + 'th';
}

function lordOfHouse(lagnaSignCode, house) {
  return SIGN_LORDS[signAtHouse(lagnaSignCode, house)];
}

/**
 * Determine how (if at all) two planets are connected: conjunction,
 * mutual/one-way aspect, or sign exchange.
 */
function getConnection(planetA, planetB, bodies, aspectsData) {
  if (planetA === planetB) return null;
  if (!bodies[planetA] || !bodies[planetB]) return null;

  const houseA = bodies[planetA].house;
  const houseB = bodies[planetB].house;

  if (houseA === houseB) {
    return { type: 'conjunction', detail: `${planetA} and ${planetB} are conjunct in house ${houseA}.` };
  }

  const aspectsAB = aspectsData?.outgoing?.[planetA]?.planetsAspected?.some(p => p.planet === planetB);
  const aspectsBA = aspectsData?.outgoing?.[planetB]?.planetsAspected?.some(p => p.planet === planetA);
  if (aspectsAB || aspectsBA) {
    return {
      type: 'aspect',
      detail: `${aspectsAB ? planetA + ' aspects ' + planetB : ''}${aspectsAB && aspectsBA ? ' and ' : ''}${aspectsBA ? planetB + ' aspects ' + planetA : ''}.`
    };
  }

  return null;
}

/**
 * Classify a pair of houses by type, for describing yoga "quality."
 */
function houseType(house) {
  if ([1, 4, 7, 10].includes(house) && [1, 5, 9].includes(house)) return 'kendra+trikona';
  if ([1, 5, 9].includes(house)) return 'trikona';
  if ([1, 4, 7, 10].includes(house)) return 'kendra';
  if ([6, 8, 12].includes(house)) return 'dusthana';
  return 'upachaya';
}

/**
 * Parivartana Yoga — detect mutual sign exchange between any two of the
 * 7 classical planets.
 */
function detectParivartana(lagnaSignCode, bodies, housesRuledBy) {
  const found = [];
  const seen = new Set();

  for (const planet of CLASSICAL_PLANETS) {
    if (!bodies[planet]) continue;
    const ownHouses = housesRuledBy[planet] || [];
    const currentHouse = bodies[planet].house;
    if (ownHouses.includes(currentHouse)) continue; // already in own sign, no exchange

    const hostLord = lordOfHouse(lagnaSignCode, currentHouse);
    if (!hostLord || hostLord === planet || !bodies[hostLord]) continue;

    const hostLordOwnHouses = housesRuledBy[hostLord] || [];
    const hostLordCurrentHouse = bodies[hostLord].house;

    if (ownHouses.includes(hostLordCurrentHouse)) {
      const pairKey = [planet, hostLord].sort().join('-');
      if (seen.has(pairKey)) continue;
      seen.add(pairKey);

      const typeA = houseType(currentHouse);
      const typeB = houseType(hostLordCurrentHouse);
      let quality;
      if ((typeA.includes('dusthana')) || (typeB.includes('dusthana'))) {
        quality = 'Mixed — involves a Dusthana house, effects are complicated rather than purely auspicious.';
      } else if (typeA.includes('kendra') || typeA.includes('trikona') || typeB.includes('kendra') || typeB.includes('trikona')) {
        quality = 'Favorable — exchange between significant (Kendra/Trikona) houses.';
      } else {
        quality = 'Neutral — exchange between houses of lesser classical significance.';
      }

      found.push({
        planets: [planet, hostLord],
        houses: [currentHouse, hostLordCurrentHouse],
        quality,
        detail: `${planet} (lord of ${ownHouses.join('/')}) sits in house ${currentHouse} while ${hostLord} (lord of ${hostLordOwnHouses.join('/')}) sits in house ${hostLordCurrentHouse} — each occupying the other's house.`
      });
    }
  }

  return found;
}

/**
 * Gajakesari Yoga — Moon and Jupiter in mutual Kendra (1,4,7,10 apart).
 */
function detectGajakesari(bodies) {
  if (!bodies.Moon || !bodies.Jupiter) return null;
  const distance = ((bodies.Jupiter.house - bodies.Moon.house + 12) % 12) + 1;
  const kendraDistances = [1, 4, 7, 10];
  if (!kendraDistances.includes(distance)) return null;

  return {
    present: true,
    moonHouse: bodies.Moon.house,
    jupiterHouse: bodies.Jupiter.house,
    detail: `Moon (house ${bodies.Moon.house}) and Jupiter (house ${bodies.Jupiter.house}) are in mutual Kendra.`,
    caveat: 'Classical texts also require Jupiter not be debilitated, combust, or otherwise weak for the yoga to give full results — check Jupiter\'s dignity separately before weighting this heavily.'
  };
}

/**
 * Kendra-Trikona Raja Yoga — a Kendra lord (1,4,7,10) connected to a
 * Trikona lord (1,5,9), via conjunction, aspect, or exchange.
 */
function detectRajaYogas(lagnaSignCode, bodies, housesRuledBy, aspectsData, parivartanaList) {
  const kendraHouses = [1, 4, 7, 10];
  const trikonaHouses = [1, 5, 9];
  const found = [];
  const seen = new Set();

  for (const kh of kendraHouses) {
    const kLord = lordOfHouse(lagnaSignCode, kh);
    for (const th of trikonaHouses) {
      if (kh === th) continue;
      const tLord = lordOfHouse(lagnaSignCode, th);
      if (!kLord || !tLord || kLord === tLord) continue;

      const pairKey = [kLord, tLord].sort().join('-');
      if (seen.has(pairKey)) continue;

      const connection = getConnection(kLord, tLord, bodies, aspectsData);
      const exchange = parivartanaList.find(p => p.planets.includes(kLord) && p.planets.includes(tLord));

      if (connection || exchange) {
        seen.add(pairKey);
        found.push({
          kendraLord: kLord, kendraHouse: kh,
          trikonaLord: tLord, trikonaHouse: th,
          connectionType: exchange ? 'exchange' : connection.type,
          detail: exchange
            ? `${kLord} (${ord(kh)} lord) and ${tLord} (${ord(th)} lord) are connected via sign exchange (Parivartana).`
            : `${kLord} (${ord(kh)} lord) and ${tLord} (${ord(th)} lord) are connected via ${connection.type}. ${connection.detail}`
        });
      }
    }
  }

  return found;
}

/**
 * Dhana Yoga — wealth-house lords (2nd, 11th) connected to
 * 1st/5th/9th lords.
 */
function detectDhanaYogas(lagnaSignCode, bodies, housesRuledBy, aspectsData, parivartanaList) {
  const wealthHouses = [2, 11];
  const supportHouses = [1, 5, 9];
  const found = [];
  const seen = new Set();

  for (const wh of wealthHouses) {
    const wLord = lordOfHouse(lagnaSignCode, wh);
    for (const sh of supportHouses) {
      if (wh === sh) continue;
      const sLord = lordOfHouse(lagnaSignCode, sh);
      if (!wLord || !sLord || wLord === sLord) continue;

      const pairKey = [wLord, sLord].sort().join('-');
      if (seen.has(pairKey)) continue;

      const connection = getConnection(wLord, sLord, bodies, aspectsData);
      const exchange = parivartanaList.find(p => p.planets.includes(wLord) && p.planets.includes(sLord));

      if (connection || exchange) {
        seen.add(pairKey);
        found.push({
          wealthLord: wLord, wealthHouse: wh,
          supportLord: sLord, supportHouse: sh,
          connectionType: exchange ? 'exchange' : connection.type,
          detail: exchange
            ? `${wLord} (${ord(wh)} lord) and ${sLord} (${ord(sh)} lord) connected via sign exchange (Parivartana).`
            : `${wLord} (${ord(wh)} lord) and ${sLord} (${ord(sh)} lord) connected via ${connection.type}. ${connection.detail}`
        });
      }
    }
  }

  return found;
}

/**
 * Vipreet Raja Yoga — the three classical named types:
 *   Harsha:  6th lord placed in 6th, 8th, or 12th house
 *   Sarala:  8th lord placed in 6th, 8th, or 12th house
 *   Vimala: 12th lord placed in 6th, 8th, or 12th house
 * (A dusthana lord placed in ANOTHER dusthana is considered to "neutralize"
 *  affliction rather than compound it — the classical logic behind this
 *  yoga family.)
 */
function detectVipreetRajaYogas(lagnaSignCode, bodies) {
  const dusthanas = [6, 8, 12];
  const names = { 6: 'Harsha', 8: 'Sarala', 12: 'Vimala' };
  const found = [];

  for (const houseNum of [6, 8, 12]) {
    const lord = lordOfHouse(lagnaSignCode, houseNum);
    if (!bodies[lord]) continue;
    const currentHouse = bodies[lord].house;
    if (dusthanas.includes(currentHouse) && currentHouse !== houseNum) {
      found.push({
        name: `${names[houseNum]} Yoga`,
        lord,
        ownHouse: houseNum,
        placedInHouse: currentHouse,
        detail: `${lord} (lord of ${houseNum}th) is placed in the ${currentHouse}th — another Dusthana. Classically read as a Vipreet (reversed) Raja Yoga: affliction tends to neutralize rather than compound.`
      });
    } else if (currentHouse === houseNum) {
      // Lord in its own dusthana — different classical treatment, noted but not counted as Vipreet
      found.push({
        name: `${names[houseNum]} Yoga (own-house variant)`,
        lord,
        ownHouse: houseNum,
        placedInHouse: currentHouse,
        detail: `${lord} (lord of ${houseNum}th) is placed in its own ${houseNum}th house. Some texts still count this as a (weaker) Vipreet condition; treat with lower confidence than the cross-Dusthana case.`,
        confidence: 'low'
      });
    }
  }

  return found;
}

function computeYogas(lagnaSignCode, bodies, aspectsData) {
  const housesRuledBy = getHouseLordships(lagnaSignCode);
  const parivartana = detectParivartana(lagnaSignCode, bodies, housesRuledBy);
  const gajakesari = detectGajakesari(bodies);
  const rajaYogas = detectRajaYogas(lagnaSignCode, bodies, housesRuledBy, aspectsData, parivartana);
  const dhanaYogas = detectDhanaYogas(lagnaSignCode, bodies, housesRuledBy, aspectsData, parivartana);
  const vipreetRajaYogas = detectVipreetRajaYogas(lagnaSignCode, bodies);

  return {
    parivartana,
    gajakesari,
    rajaYogas,
    dhanaYogas,
    vipreetRajaYogas,
    methodology: 'A focused, classically well-defined subset of yogas — not exhaustive. "Connected" means conjunction, mutual graha drishti, or sign exchange (BPHS\'s three classical connection types). Absence here means "not detected by these specific conditions," not "this chart has no yogas."'
  };
}

module.exports = {
  computeYogas,
  detectParivartana,
  detectGajakesari,
  detectRajaYogas,
  detectDhanaYogas,
  detectVipreetRajaYogas,
  getConnection
};
