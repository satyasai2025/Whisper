/**
 * Functional Nature (Functional Benefic / Malefic) — Lagna-dependent
 *
 * A planet's NATURAL nature (e.g. Jupiter is naturally benefic, Saturn
 * naturally malefic) is fixed. Its FUNCTIONAL nature for a given native
 * depends on which houses it rules FROM THAT NATIVE'S LAGNA — this is
 * what actually matters for predictive analysis, since the same planet
 * can be a strong functional benefic for one Lagna and a functional
 * malefic for another.
 *
 * Methodology (synthesis of BPHS kendra/trikona/dusthana principles as
 * commonly applied in Phaladeepika-era and modern practice, e.g. PVR):
 *
 *   - Lord of a Trikona (1, 5, 9) [not also ruling a dusthana] → Functional Benefic
 *   - Lord of BOTH a Kendra (1,4,7,10) AND a Trikona (1,5,9)   → Yogakaraka
 *     (strongest functional benefic — classical named combinations:
 *      Mars for Cancer/Leo Lagna, Venus for Capricorn/Aquarius Lagna,
 *      Saturn for Taurus/Libra Lagna)
 *   - Lord of a Kendra ONLY (4,7,10 — not also trikona)        → Neutral
 *     (kendra lords are tempered by "Kendradhipatya Dosha" — they lose
 *     pure benefic status even if naturally benefic, but are not malefic)
 *   - Lord of a Dusthana (6, 8, 12) [not also trikona]         → Functional Malefic
 *   - Lord of a Dusthana AND a Trikona (same planet)            → Functional Benefic, tempered
 *     (net effect is debated; trikona dominance generally wins, but the
 *      dusthana association introduces complications — flagged as mixed)
 *   - Lord of ONLY 3rd and/or 11th (Upachaya, non-kendra/trikona)
 *                                                                → Mild Functional Malefic
 *     (this call is less universally settled across traditions — flagged
 *      with lower confidence)
 *
 *   Additional flags (don't change the core classification, but matter
 *   for analysis):
 *     - Maraka: rules 2nd and/or 7th house (classical "death-inflicting"
 *       houses — relevant for timing analysis, not benefic/malefic per se)
 *
 * RAHU/KETU: Nodes don't own signs in mainstream Parashari astrology, so
 * they have no house-lordship and this method does NOT classify them.
 * Their functional nature is handled differently across traditions (sign
 * dispositor substitution, occupied-house quality, nakshatra lordship) —
 * left unclassified here rather than guessing, per data-integrity policy.
 */

const { SIGN_INDEX, SIGN_ORDER, SIGN_LORDS } = require('../parser/utils/constants');

const KENDRA = [1, 4, 7, 10];
const TRIKONA = [1, 5, 9];
const DUSTHANA = [6, 8, 12];
const MARAKA = [2, 7];

// Sign modality groups — determine which house is the Badhaka (obstacle) house
const MOVABLE_SIGNS = ['Ar', 'Cn', 'Li', 'Cp']; // Chara rashis
const FIXED_SIGNS   = ['Ta', 'Le', 'Sc', 'Aq']; // Sthira rashis
const DUAL_SIGNS    = ['Ge', 'Vi', 'Sg', 'Pi']; // Dwiswabhava rashis

/**
 * Sign occupying a given house number, counting from Lagna.
 */
function signAtHouse(lagnaSignCode, houseNumber) {
  const lagnaIdx = SIGN_INDEX[lagnaSignCode];
  const signIdx = (lagnaIdx + houseNumber - 1) % 12;
  return SIGN_ORDER[signIdx];
}

/**
 * Badhaka (obstacle-causing) house and its lord (Badhakesh).
 *
 * Classical rule (BPHS, widely used for obstacle/delay timing analysis):
 *   - Movable (Chara) Lagna  (Ar, Cn, Li, Cp) → 11th house is Badhaka Sthana
 *   - Fixed (Sthira) Lagna   (Ta, Le, Sc, Aq) → 9th house is Badhaka Sthana
 *   - Dual (Dwiswabhava) Lagna (Ge, Vi, Sg, Pi) → 7th house is Badhaka Sthana
 *
 * The lord of that house (Badhakesh) is considered a significator of
 * obstacles, delays, and difficulties — especially relevant during that
 * planet's dasha/antardasha periods.
 */
function getBadhakaHouse(lagnaSignCode) {
  if (MOVABLE_SIGNS.includes(lagnaSignCode)) return 11;
  if (FIXED_SIGNS.includes(lagnaSignCode)) return 9;
  if (DUAL_SIGNS.includes(lagnaSignCode)) return 7;
  return null;
}

function computeBadhakesh(lagnaSignCode) {
  const badhakaHouse = getBadhakaHouse(lagnaSignCode);
  if (!badhakaHouse) return null;
  const badhakaSign = signAtHouse(lagnaSignCode, badhakaHouse);
  const badhakesh = SIGN_LORDS[badhakaSign];
  return { badhakaHouse, badhakaSign, badhakesh };
}

/**
 * For a given Lagna sign, determine which house(s) each of the 7 classical
 * planets rules.
 */
function getHouseLordships(lagnaSignCode) {
  const housesRuledBy = {}; // planet -> [house numbers]
  for (let house = 1; house <= 12; house++) {
    const sign = signAtHouse(lagnaSignCode, house);
    const lord = SIGN_LORDS[sign];
    if (!housesRuledBy[lord]) housesRuledBy[lord] = [];
    housesRuledBy[lord].push(house);
  }
  return housesRuledBy;
}

function classifyPlanet(planet, housesRuled) {
  const kendraNonLagna = housesRuled.filter(h => h === 4 || h === 7 || h === 10);
  const trikonaNonLagna = housesRuled.filter(h => h === 5 || h === 9);
  const rulesLagna = housesRuled.includes(1);
  const dusthana = housesRuled.filter(h => DUSTHANA.includes(h));
  const hasMaraka = housesRuled.some(h => MARAKA.includes(h));
  const onlyUpachaya = housesRuled.every(h => h === 3 || h === 11);

  let classification, reasoning, confidence;

  // Yogakaraka requires a NON-Lagna kendra (4/7/10) AND a NON-Lagna trikona
  // (5/9) — both house1's kendra-ness and trikona-ness are trivial/shared,
  // so simply ruling house1 must NOT by itself trigger this classification.
  if (kendraNonLagna.length > 0 && trikonaNonLagna.length > 0) {
    classification = 'Yogakaraka';
    reasoning = `Rules a Kendra (${kendraNonLagna.join(', ')}) and a Trikona (${trikonaNonLagna.join(', ')}) as separate houses — the classical named functional-benefic combination (e.g. Saturn for Taurus/Libra, Mars for Cancer/Leo, Venus for Capricorn/Aquarius).`;
    confidence = 'high';
  } else if (rulesLagna && dusthana.length > 0) {
    classification = 'Functional Benefic (Lagna lord, mixed with Dusthana)';
    reasoning = `Rules the Lagna (1st house — generally the strongest functional benefic signal) but also a Dusthana (${dusthana.join(', ')}). Lagna lordship typically dominates, but the Dusthana association tempers it — not a clean case.`;
    confidence = 'medium';
  } else if (rulesLagna) {
    const extra = housesRuled.filter(h => h !== 1);
    classification = 'Functional Benefic (Lagna Lord)';
    reasoning = extra.length > 0
      ? `Rules the Lagna (1st house) plus house(s) ${extra.join(', ')}. Lagna lordship is the strongest single auspicious signal for a planet.`
      : `Rules only the Lagna (1st house) — the cleanest functional-benefic signal: the planet governs the self/native directly.`;
    confidence = 'high';
  } else if (trikonaNonLagna.length > 0 && dusthana.length > 0) {
    classification = 'Functional Benefic (mixed)';
    reasoning = `Rules a Trikona (${trikonaNonLagna.join(', ')}) and also a Dusthana (${dusthana.join(', ')}). Trikona lordship generally dominates, but the Dusthana association introduces complications — treat with more caution than a clean Trikona lord.`;
    confidence = 'medium';
  } else if (trikonaNonLagna.length > 0) {
    classification = 'Functional Benefic';
    reasoning = `Rules Trikona house(s): ${trikonaNonLagna.join(', ')}.`;
    confidence = 'high';
  } else if (dusthana.length > 0) {
    classification = 'Functional Malefic';
    reasoning = `Rules Dusthana house(s): ${dusthana.join(', ')}.`;
    confidence = 'high';
  } else if (kendraNonLagna.length > 0) {
    classification = 'Neutral';
    reasoning = `Rules Kendra house(s) only: ${kendraNonLagna.join(', ')}. Tempered by Kendradhipatya Dosha — loses pure benefic status without becoming malefic.`;
    confidence = 'high';
  } else if (onlyUpachaya) {
    classification = 'Mild Functional Malefic';
    reasoning = `Rules only Upachaya house(s) (3rd/11th: ${housesRuled.join(', ')}) without Kendra/Trikona/Dusthana involvement. This classification is less universally settled across traditions.`;
    confidence = 'low';
  } else {
    classification = 'Neutral';
    reasoning = `Rules house(s) ${housesRuled.join(', ')} — no strong functional signal either way.`;
    confidence = 'medium';
  }

  return {
    housesRuled,
    classification,
    reasoning,
    isYogakaraka: classification === 'Yogakaraka',
    isMaraka: hasMaraka,
    marakaNote: hasMaraka
      ? `Also rules Maraka house(s) (${housesRuled.filter(h => MARAKA.includes(h)).join(', ')}) — relevant for death/danger timing analysis, separate from benefic/malefic classification.`
      : null,
    confidence
  };
}

/**
 * Compute functional nature for all 7 classical planets given a Lagna sign.
 * Rahu/Ketu are intentionally left unclassified (see module header).
 */
function computeFunctionalNature(lagnaSignCode) {
  const housesRuledBy = getHouseLordships(lagnaSignCode);
  const result = {};

  for (const [planet, houses] of Object.entries(housesRuledBy)) {
    result[planet] = classifyPlanet(planet, houses);
  }

  // Badhakesh — flag whichever planet rules the Badhaka house
  const badhaka = computeBadhakesh(lagnaSignCode);
  if (badhaka && result[badhaka.badhakesh]) {
    result[badhaka.badhakesh].isBadhakesh = true;
    result[badhaka.badhakesh].badhakaNote =
      `Also the Badhakesh (rules the Badhaka house, ${badhaka.badhakaHouse}${ordinalSuffix(badhaka.badhakaHouse)} — ${badhaka.badhakaSign}). Classically a significator of obstacles and delays, particularly during this planet's dasha/antardasha.`;
  }
  for (const p of Object.values(result)) {
    if (p.isBadhakesh === undefined) p.isBadhakesh = false;
  }

  result.Rahu = {
    classification: 'Not classified',
    reasoning: 'Nodes do not own signs in mainstream Parashari astrology, so house-lordship-based classification does not apply. Traditions differ (dispositor substitution, occupied-house quality, nakshatra lordship) — left unclassified rather than guessing.',
    confidence: 'n/a',
    isBadhakesh: false
  };
  result.Ketu = { ...result.Rahu };

  return {
    lagnaSign: lagnaSignCode,
    badhaka,
    classifications: result,
    methodology: 'Synthesis of BPHS kendra/trikona/dusthana principles, including Yogakaraka, Maraka, and Badhakesh identification, as commonly applied in Phaladeepika-era and modern (PVR-style) practice.'
  };
}

function ordinalSuffix(n) {
  if (n === 1 || n === 11) return 'st';
  if (n === 2 || n === 12) return 'nd';
  if (n === 3) return 'rd';
  return 'th';
}

module.exports = {
  computeFunctionalNature,
  getHouseLordships,
  signAtHouse,
  getBadhakaHouse,
  computeBadhakesh,
  KENDRA, TRIKONA, DUSTHANA, MARAKA,
  MOVABLE_SIGNS, FIXED_SIGNS, DUAL_SIGNS
};
