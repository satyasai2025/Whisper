/**
 * CONVERGENCE LAYER (Layer 3 of the Predictive Engine — final layer)
 *
 * Combines Layer 1 (promise.js — does the chart show this event at all?)
 * and Layer 2 (dasha-activation.js — in which future window?) into the
 * spec's core deliverable: a convergence-percentage PER FUTURE WINDOW,
 * always accompanied by the reasoning that produced it.
 *
 * ============================ SPEC COMPLIANCE ============================
 * From the original build-spec, two rules govern this layer specifically:
 *
 *  RULE — "SCORE KABHI 0% YA 100% NAHI": the score is mathematically
 *  clamped to [5, 95]. Jyotish does not deal in certainties; this range
 *  leaves room for free will and choice, by construction, not as a
 *  cosmetic afterthought.
 *
 *  RULE — "NARRATIVE > RAW SCORE": a percentage is NEVER returned alone.
 *  Every score carries the full, itemized breakdown of what produced it
 *  — each point added or subtracted is traceable to a specific indicator
 *  from Layer 1 or Layer 2, which is itself sourced back to a classical
 *  principle. There is no hidden multiplier anywhere in this file.
 *
 * SCORING FORMULA (fully shown, not a black box):
 *   baseline               = 50   (neutral starting point)
 *   + promise adjustment    = (supportCount - weakenCount) x 8, capped at +/-30
 *   + activation adjustment = min(connectionStrength x 5, 25)
 *   + Ashtottari confirmation = +15 if Ashtottari Dasha (CO-PRIMARY per the
 *                                build-spec, alongside Vimshottari) also
 *                                independently agrees
 *   + Narayana confirmation   = +8 if Narayana Dasha (a tertiary,
 *                                structurally-different rasi-based system)
 *                                also independently agrees
 *   -----------------------------------------------------------
 *   raw total, then clamped to [5, 95]
 *
 * SPEC NOTE: the original build-spec is explicit that this engine runs on
 * "Vimsottari + Ashtottari dasha." An earlier version of this module only
 * used Vimshottari as primary and Narayana as the sole cross-check —
 * that was a real deviation from spec (caught by the Learner), corrected
 * here by making Ashtottari a co-primary, more heavily-weighted
 * confirmation than Narayana.
 *
 * This formula is a DESIGN CHOICE, not a discovered law — it is shown in
 * full so the Learner (or anyone) can recompute it by hand, disagree with
 * the weights, and adjust them. That auditability is the entire point.
 * =========================================================================
 */

const { evaluatePromise, EVENT_DEFINITIONS } = require('./promise');
const { findActivationWindows } = require('./dasha-activation');

const WEIGHTS = {
  baseline: 50,
  perPromiseIndicator: 8,
  promiseCap: 30,
  perActivationConnection: 5,
  activationCap: 25,
  ashtottariConfirmationBonus: 15,
  narayanaConfirmationBonus: 8,
  clampMin: 5,
  clampMax: 95,
};

// ── False positive suppression rules ─────────────────────────────────────────
// Per event type: minimum dasha activation required to show result
// If activation is too low, cap the score regardless of natal promise
const SUPPRESSION_RULES = {
  // Affliction domains — natal chart often shows vulnerability for many people
  // Need STRONG independent dasha confirmation to show as high-score prediction
  // minActivation: minimum connectionStrength required (exclusive — must be > this)
  disease:        { minActivation: 2, maxScoreWithoutActivation: 45, affliction: true },
  majorIllness:   { minActivation: 2, maxScoreWithoutActivation: 45, affliction: true },
  surgery:        { minActivation: 2, maxScoreWithoutActivation: 45, affliction: true },
  accident:       { minActivation: 2, maxScoreWithoutActivation: 45, affliction: true },
  courtCase:      { minActivation: 2, maxScoreWithoutActivation: 45, affliction: true },
  addiction:      { minActivation: 2, maxScoreWithoutActivation: 45, affliction: true },
  deathOfFather:  { minActivation: 3, maxScoreWithoutActivation: 40, affliction: true },
  deathOfMother:  { minActivation: 3, maxScoreWithoutActivation: 40, affliction: true },
  deathOfSpouse:  { minActivation: 3, maxScoreWithoutActivation: 40, affliction: true },
  divorce:        { minActivation: 2, maxScoreWithoutActivation: 45, affliction: true },
  majorFinancialLoss: { minActivation: 2, maxScoreWithoutActivation: 45, affliction: true },
  termination:    { minActivation: 2, maxScoreWithoutActivation: 45, affliction: true },
  // Growth domains — natal promise must have 2+ supporters for high score
  marriage:       { minActivation: 1, maxScoreWithoutNatalPromise: 55 },
  children:       { minActivation: 1, maxScoreWithoutNatalPromise: 55 },
  housePurchase:  { minActivation: 1, maxScoreWithoutNatalPromise: 55 },
  businessStart:  { minActivation: 1, maxScoreWithoutNatalPromise: 55 },
};

function clamp(n, min, max) {
  return Math.max(min, Math.min(max, n));
}

function qualitativeLabel(score, domainType) {
  if (domainType === 'affliction') {
    if (score < 20) return 'Low indication of vulnerability';
    if (score < 40) return 'Mild indication of vulnerability';
    if (score < 60) return 'Unclear / mixed indication';
    if (score < 75) return 'Moderate indication of vulnerability — worth attention';
    if (score < 88) return 'Elevated indication of vulnerability — worth attention';
    return 'Strongly elevated indication of vulnerability — worth attention';
  }
  if (score < 20) return 'Weak indication';
  if (score < 40) return 'Mild indication';
  if (score < 60) return 'Even / unclear indication';
  if (score < 75) return 'Moderate indication';
  if (score < 88) return 'Strong indication';
  return 'Very strong indication';
}

/**
 * Score one (event, window) pair, given the already-computed promise.
 * Includes false-positive suppression for affliction domains.
 */
function scoreWindow(promise, window, eventKey) {
  const breakdown = [];
  const rule = SUPPRESSION_RULES[eventKey] || {};

  breakdown.push({ label: 'Baseline', value: WEIGHTS.baseline, reason: 'Neutral starting point -- no claim either way before evidence.' });

  const promiseRaw = (promise.supportCount - promise.weakenCount) * WEIGHTS.perPromiseIndicator;
  const promiseAdj = clamp(promiseRaw, -WEIGHTS.promiseCap, WEIGHTS.promiseCap);
  breakdown.push({
    label: 'Promise (Layer 1)',
    value: promiseAdj,
    reason: `${promise.supportCount} supporting vs ${promise.weakenCount} weakening classical indicators (capped at +/-${WEIGHTS.promiseCap}).`
  });

  const activationRaw = window.connectionStrength * WEIGHTS.perActivationConnection;
  const activationAdj = Math.min(activationRaw, WEIGHTS.activationCap);
  breakdown.push({
    label: 'Dasha Activation (Layer 2)',
    value: activationAdj,
    reason: `${window.connectionStrength} independent connection(s) between this window's lords and the event's houses/karaka (capped at +${WEIGHTS.activationCap}).`
  });

  const ashtottariBonus = window.ashtottariConfirmation && window.ashtottariConfirmation.agrees ? WEIGHTS.ashtottariConfirmationBonus : 0;
  breakdown.push({
    label: 'Ashtottari confirmation (co-primary)',
    value: ashtottariBonus,
    reason: (window.ashtottariConfirmation && window.ashtottariConfirmation.agrees)
      ? `Ashtottari Dasha independently agrees (${window.ashtottariConfirmation.matchedVia}).`
      : 'Ashtottari Dasha does not independently confirm this window.'
  });

  const narayanaBonus = window.crossConfirmation && window.crossConfirmation.agrees ? WEIGHTS.narayanaConfirmationBonus : 0;
  breakdown.push({
    label: 'Narayana confirmation (tertiary)',
    value: narayanaBonus,
    reason: (window.crossConfirmation && window.crossConfirmation.agrees)
      ? `Narayana Dasha also independently agrees (${window.crossConfirmation.matchedVia}).`
      : 'Narayana Dasha does not independently confirm this window.'
  });

  let rawTotal = breakdown.reduce((sum, b) => sum + b.value, 0);
  let score = clamp(Math.round(rawTotal), WEIGHTS.clampMin, WEIGHTS.clampMax);

  // ── False positive suppression ────────────────────────────────────────────
  let suppressionApplied = null;

  // Affliction domains: Ashtottari must confirm for score > 65%
  if (rule.affliction) {
    // Need strong dasha connection
    if (window.connectionStrength <= rule.minActivation) {
      const cap = rule.maxScoreWithoutActivation;
      if (score > cap) {
        suppressionApplied = `Affliction: needs ${rule.minActivation + 1}+ dasha connections (found ${window.connectionStrength}) — capped at ${cap}%.`;
        score = cap;
      }
    }
    // Ashtottari (co-primary) must confirm for high affliction score
    if (!ashtottariBonus && score > 65) {
      const cap = narayanaBonus ? 70 : 58;
      if (score > cap) {
        suppressionApplied = (suppressionApplied ? suppressionApplied + ' ' : '')
          + `Affliction: Ashtottari not confirming — capped at ${cap}%.`;
        score = cap;
      }
    }
    // Hard cap: affliction domains never exceed 75% — shows tendency, not certainty
    if (score > 75) {
      suppressionApplied = (suppressionApplied ? suppressionApplied + ' ' : '')
        + 'Affliction hard cap 75%: chart shows tendency, not certainty.';
      score = 75;
    }
  }

  if (rule.maxScoreWithoutNatalPromise && promise.supportCount < 2) {
    const cappedScore = Math.min(score, rule.maxScoreWithoutNatalPromise);
    if (cappedScore < score) {
      suppressionApplied = `Growth domain: insufficient natal promise (${promise.supportCount} supporters, need 2+). Score capped at ${rule.maxScoreWithoutNatalPromise}%.`;
      score = cappedScore;
    }
  }

  return {
    score,
    label: qualitativeLabel(score, promise.domainType),
    breakdown,
    rawTotal,
    wasClamped: rawTotal !== score,
    suppressionApplied,
  };
}

/**
 * Build the narrative-bearing prediction for one event category: its
 * promise, plus every relevant future window scored.
 */
function predictEvent(eventKey, chart, fromDate, opts) {
  opts = opts || {};
  const def = EVENT_DEFINITIONS[eventKey];
  if (!def) return { _warning: `Unknown event category: ${eventKey}` };

  const promise = evaluatePromise(eventKey, chart);
  const windows = findActivationWindows(def, chart, fromDate, opts);

  const scoredWindows = windows.map(w => {
    const scored = scoreWindow(promise, w, eventKey);
    return Object.assign({}, w, scored);
  }).sort((a, b) => b.score - a.score || a.startDate.localeCompare(b.startDate));

  return {
    event: eventKey,
    label: def.label,
    domainType: promise.domainType,
    extremeSensitivity: promise.extremeSensitivity || false,
    promise: promise,
    windows: scoredWindows,
    note: promise.domainType === 'affliction'
      ? 'Scores are clamped to 5-95% by design -- this describes a CLASSICAL TENDENCY toward vulnerability in this area, not a diagnosis or a certainty. It is not medical or psychological advice. If this is a live concern, please consult a qualified doctor or counselor -- this tool cannot and does not replace that.'
      : 'Scores are clamped to 5-95% by design -- Jyotish describes tendencies, not certainties, and free will/choice always has room to act. Every score is shown with its full breakdown; never read the percentage without the reasoning beside it.'
  };
}

/**
 * Predict ALL event categories.
 */
function predictAll(chart, fromDate, opts) {
  opts = opts || {};
  const result = {};
  for (const key of Object.keys(EVENT_DEFINITIONS)) {
    result[key] = predictEvent(key, chart, fromDate, opts);
  }
  return result;
}

module.exports = { predictEvent, predictAll, scoreWindow, WEIGHTS, qualitativeLabel };
