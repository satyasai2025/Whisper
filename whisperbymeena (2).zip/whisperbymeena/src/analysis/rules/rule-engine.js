/**
 * Rule Matching Engine
 *
 * Takes the parsed chart (bodies + analysis) and the rule library, and
 * returns every rule whose condition the chart satisfies — each with its
 * source, confidence, caveat, and which specific planet/house triggered
 * it. This is what turns the library into chart-specific output.
 *
 * Design notes:
 *  - The engine is purely a MATCHER. It does not rank, score, or conclude.
 *    It reports which classical statements apply, with full sourcing, so
 *    the Learner (or the convergence layer) can weigh them.
 *  - Every condition `type` maps to one small, auditable matcher function.
 *  - Matchers read ONLY from already-parsed/-analyzed data (functional
 *    nature, dignity, house lordships, body positions) — no new astrology
 *    is computed here, avoiding double-sourcing of logic.
 */

const { buildHouseLordRules } = require('./house-lord-rules');
const { SPECIFIC_RULES } = require('./specific-rules');

const NATURAL_BENEFICS = ['Jupiter', 'Venus', 'Mercury', 'Moon'];
const NATURAL_MALEFICS = ['Saturn', 'Mars', 'Sun', 'Rahu', 'Ketu'];

/**
 * Build a planet→housesRuled map from functional nature (already computed).
 */
function getHouseLordships(analysis) {
  const map = {};
  const fn = analysis?.functionalNature?.classifications;
  if (fn) {
    for (const [planet, c] of Object.entries(fn)) {
      if (c.housesRuled) map[planet] = c.housesRuled;
    }
  }
  return map;
}

/**
 * Each matcher returns an array of "hits" (possibly empty). A hit is
 * { trigger: '...human-readable what matched...' }.
 */
const MATCHERS = {
  houseLordIn(cond, ctx) {
    const { lordOf, placedIn } = cond;
    const lord = lordPlanetOfHouse(ctx, lordOf);
    if (!lord) return [];
    const body = ctx.bodies[lord];
    if (body && body.house === placedIn) {
      return [{ trigger: `${lord} (lord of house ${lordOf}) is placed in house ${placedIn}` }];
    }
    return [];
  },

  naturalBeneficInHouses(cond, ctx) {
    const hits = [];
    for (const planet of cond.planets) {
      const body = ctx.bodies[planet];
      if (body && cond.houses.includes(body.house)) {
        hits.push({ trigger: `${planet} (natural benefic) is in house ${body.house}` });
      }
    }
    return hits;
  },

  naturalMaleficInHouses(cond, ctx) {
    const hits = [];
    for (const planet of cond.planets) {
      const body = ctx.bodies[planet];
      if (body && cond.houses.includes(body.house)) {
        hits.push({ trigger: `${planet} (natural malefic) is in house ${body.house}` });
      }
    }
    return hits;
  },

  planetDignity(cond, ctx) {
    const hits = [];
    const dig = ctx.analysis?.dignity?.classifications || {};
    for (const [planet, d] of Object.entries(dig)) {
      if (d.tier === cond.tier) {
        hits.push({ trigger: `${planet} is ${cond.tier}` });
      }
    }
    return hits;
  },

  isYogakaraka(cond, ctx) {
    const hits = [];
    const fn = ctx.analysis?.functionalNature?.classifications || {};
    for (const [planet, c] of Object.entries(fn)) {
      if (c.isYogakaraka) hits.push({ trigger: `${planet} is the Yogakaraka` });
    }
    return hits;
  },

  isMaraka(cond, ctx) {
    const hits = [];
    const fn = ctx.analysis?.functionalNature?.classifications || {};
    for (const [planet, c] of Object.entries(fn)) {
      if (c.isMaraka) hits.push({ trigger: `${planet} is a Maraka (rules 2nd/7th)` });
    }
    return hits;
  },

  isBadhakesh(cond, ctx) {
    const hits = [];
    const fn = ctx.analysis?.functionalNature?.classifications || {};
    for (const [planet, c] of Object.entries(fn)) {
      if (c.isBadhakesh) hits.push({ trigger: `${planet} is the Badhakesh` });
    }
    return hits;
  },

  lagnaLordInHouses(cond, ctx) {
    const lagnaLord = lordPlanetOfHouse(ctx, 1);
    if (!lagnaLord) return [];
    const body = ctx.bodies[lagnaLord];
    if (body && cond.houses.includes(body.house)) {
      return [{ trigger: `Lagna lord ${lagnaLord} is in house ${body.house}` }];
    }
    return [];
  },

  isAtmakaraka(cond, ctx) {
    const ak = ctx.analysis?.jaimini?.atmakaraka?.planet;
    if (ak) return [{ trigger: `${ak} is the Atmakaraka (soul significator)` }];
    return [];
  }
};

/**
 * Which planet rules a given house (from the Lagna-based lordship map).
 * Returns the first/only classical ruler (ignores co-lordship of nodes).
 */
function lordPlanetOfHouse(ctx, houseNum) {
  for (const [planet, houses] of Object.entries(ctx.houseLordships)) {
    if (houses.includes(houseNum)) return planet;
  }
  return null;
}

/**
 * Match the full library against a chart.
 *
 * @param {object} chart - parsed chart with .bodies and .analysis
 * @param {object} [opts] - { onlyPlanets: [...] } to restrict matches to
 *                          rules triggered by specific planets (used by the
 *                          convergence layer to explain active dasha lords)
 */
function matchRules(chart, opts = {}) {
  const ctx = {
    bodies: chart.bodies,
    analysis: chart.analysis,
    houseLordships: getHouseLordships(chart.analysis)
  };

  const allRules = [...buildHouseLordRules(), ...SPECIFIC_RULES];
  const matched = [];

  for (const rule of allRules) {
    const matcher = MATCHERS[rule.condition.type];
    if (!matcher) continue;
    const hits = matcher(rule.condition, ctx);
    for (const hit of hits) {
      // Optional planet filter (for explaining specific active lords)
      if (opts.onlyPlanets && !opts.onlyPlanets.some(p => hit.trigger.includes(p))) continue;
      matched.push({
        ruleId: rule.id,
        category: rule.category,
        trigger: hit.trigger,
        effect: rule.effect,
        source: rule.source,
        sourceConfidence: rule.sourceConfidence,
        caveat: rule.caveat || null,
        polarity: rule.polarity
      });
    }
  }

  return matched;
}

module.exports = { matchRules, lordPlanetOfHouse, getHouseLordships };
