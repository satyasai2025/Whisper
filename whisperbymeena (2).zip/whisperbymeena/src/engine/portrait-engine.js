/**
 * Jyotish Portrait Engine — "Evidence se Insaan Tak"
 * 
 * Source: PVR Narasimha Rao — Ch.13 (Character Reading Sequence)
 * Sequence: Lagna → Lagna Lord → Moon → Sun → Atmakaraka → Yogas → Functional Nature
 * 
 * Philosophy:
 *   - Vyakti ko describe karo, placements ko nahi
 *   - Jo baar baar repeat ho, usse confidence ke saath likho
 *   - Jo sirf ek jagah se aaye, use "shayad" ke saath
 *   - Strengths aur vulnerabilities dono
 *   - Shadow patterns bhi
 *   - PVR Ch.13: "Read the chart like a story, not a list"
 */

'use strict';

const SIGN_CODES = ['Ar','Ta','Ge','Cn','Le','Vi','Li','Sc','Sg','Cp','Aq','Pi'];

// ── Sign psychological profiles ───────────────────────────────────────────────
const SIGN_PROFILE = {
  Ar: {
    core: 'pioneering, action-oriented, direct, competitive',
    strength: 'courageous, independent, initiates quickly, natural leader',
    shadow: 'impatient, reactive, starts many things without finishing, ego-driven',
    element: 'Fire', quality: 'Movable', lord: 'Mars'
  },
  Ta: {
    core: 'steady, sensual, values-driven, persistent',
    strength: 'reliable, patient, appreciates beauty and comfort, builds lasting things',
    shadow: 'stubborn, resistant to change, can be possessive or overly comfort-seeking',
    element: 'Earth', quality: 'Fixed', lord: 'Venus'
  },
  Ge: {
    core: 'curious, communicative, adaptable, versatile',
    strength: 'quick learner, articulate, connects ideas and people, witty',
    shadow: 'scattered, inconsistent, may lack depth, overthinks',
    element: 'Air', quality: 'Dual', lord: 'Mercury'
  },
  Cn: {
    core: 'nurturing, emotional, intuitive, home-oriented',
    strength: 'deeply caring, protective, strong emotional intelligence, loyal',
    shadow: 'moody, clingy, takes things personally, difficulty with boundaries',
    element: 'Water', quality: 'Movable', lord: 'Moon'
  },
  Le: {
    core: 'confident, generous, creative, needs recognition',
    strength: 'warm-hearted, inspiring, dignified, natural authority',
    shadow: 'pride, need for approval, can dominate or overshadow others',
    element: 'Fire', quality: 'Fixed', lord: 'Sun'
  },
  Vi: {
    core: 'analytical, precise, service-oriented, detail-focused',
    strength: 'systematic, skilled, discriminating, health-conscious',
    shadow: 'overcritical, perfectionist paralysis, excessive self-doubt',
    element: 'Earth', quality: 'Dual', lord: 'Mercury'
  },
  Li: {
    core: 'harmonious, relationship-oriented, fair, aesthetic',
    strength: 'diplomatic, balanced, sense of beauty, good mediator',
    shadow: 'indecisive, people-pleasing, avoids necessary conflict',
    element: 'Air', quality: 'Movable', lord: 'Venus'
  },
  Sc: {
    core: 'intense, perceptive, transformative, secretive',
    strength: 'deep, resilient, sees through surface, powerful focus',
    shadow: 'controlling, jealous, holds grudges, intensity can overwhelm',
    element: 'Water', quality: 'Fixed', lord: 'Mars'
  },
  Sg: {
    core: 'expansive, philosophical, freedom-loving, optimistic',
    strength: 'visionary, honest, adventurous, connects to higher meaning',
    shadow: 'overconfident, restless, can be preachy or tactless',
    element: 'Fire', quality: 'Dual', lord: 'Jupiter'
  },
  Cp: {
    core: 'disciplined, ambitious, practical, responsible',
    strength: 'persistent, organized, long-term planner, earns respect through work',
    shadow: 'overly serious, fear of failure, can suppress emotions',
    element: 'Earth', quality: 'Movable', lord: 'Saturn'
  },
  Aq: {
    core: 'independent, intellectual, humanitarian, unconventional',
    strength: 'original thinker, democratic, ahead of its time, principled',
    shadow: 'detached, emotionally distant, can be rigid in ideals',
    element: 'Air', quality: 'Fixed', lord: 'Saturn'
  },
  Pi: {
    core: 'compassionate, imaginative, spiritual, boundary-dissolving',
    strength: 'empathetic, creative, intuitive, selfless',
    shadow: 'escapist, difficulty with boundaries, idealistic to a fault',
    element: 'Water', quality: 'Dual', lord: 'Jupiter'
  }
};

// ── Planet nature in sign ──────────────────────────────────────────────────────
const PLANET_NATURE = {
  Sun: 'authority, father, soul-purpose, recognition, vitality',
  Moon: 'mind, mother, emotions, public life, habits',
  Mars: 'energy, drive, courage, conflict, property',
  Mercury: 'intelligence, speech, business, skill, adaptability',
  Jupiter: 'wisdom, expansion, luck, children, dharma',
  Venus: 'relationships, beauty, comfort, art, marriage',
  Saturn: 'discipline, karma, delay, structure, longevity',
  Rahu: 'worldly obsession, foreign, unconventional, amplification',
  Ketu: 'spiritual detachment, past karma, research, liberation'
};

// ── House significations ───────────────────────────────────────────────────────
const HOUSE_MEANING = {
  1: 'self and appearance', 2: 'wealth and family', 3: 'courage and communication',
  4: 'mind and home', 5: 'intelligence and creativity', 6: 'health and service',
  7: 'relationships and partnership', 8: 'transformation and secrets',
  9: 'fortune and dharma', 10: 'career and status', 11: 'gains and desires',
  12: 'liberation and loss'
};

// ── Dignity modifications ─────────────────────────────────────────────────────
const DIGNITY_STRENGTH = {
  'Exalted': 'at peak strength — expresses its best qualities',
  'Own Sign': 'comfortable and strong — natural expression',
  "Friend's Sign": 'supportive environment — functions well',
  "Neutral's Sign": 'average strength — mixed results',
  "Enemy's Sign": 'uncomfortable — struggles to express fully',
  'Debilitated': 'at minimum strength — challenged in this area'
};

/**
 * Main: Generate psychological portrait from chart data
 */
function generatePortrait(chart) {
  const bodies    = chart.bodies || {};
  const lagna     = chart.lagna;
  const lagnaCode = lagna?.signCode;
  const analysis  = chart.analysis || {};
  const jaimini   = analysis.jaimini || {};
  const fn        = analysis.functionalNature?.classifications || {};
  const navamsa   = analysis.navamsa?.confirmation || {};
  const yogas     = analysis.yogas || {};
  const arudhas   = analysis.arudhas?.arudhas || {};
  const dignity   = analysis.dignity?.classifications || {};

  // ── Gather evidence ──────────────────────────────────────────────────────────
  const evidence = gatherEvidence(chart, bodies, lagnaCode, fn, jaimini, yogas, navamsa, dignity, arudhas);

  // ── Build portrait sections ──────────────────────────────────────────────────
  const sections = [];

  // Section 1: Who is this person — outer presentation
  sections.push(buildOuterSelf(lagnaCode, bodies, fn, evidence));

  // Section 2: Core tendencies — Moon + Sun
  sections.push(buildCoreTendencies(bodies, lagnaCode, evidence));

  // Section 3: Inner tensions and pulls
  sections.push(buildInnerTensions(bodies, lagnaCode, fn, evidence));

  // Section 4: Career and life path
  sections.push(buildLifePath(bodies, lagnaCode, jaimini, fn, arudhas, yogas, evidence));

  // Section 5: Relationships
  sections.push(buildRelationships(bodies, lagnaCode, jaimini, arudhas, evidence));

  // Section 6: Shadow patterns
  sections.push(buildShadowPatterns(bodies, lagnaCode, fn, evidence));

  // Section 7: Summary
  sections.push(buildSummary(lagnaCode, bodies, jaimini, yogas, evidence));

  return {
    sections: sections.filter(Boolean),
    evidence: evidence.summary,
    chartKey: chart._chartKey || 'unknown'
  };
}

// ── Evidence gathering ────────────────────────────────────────────────────────
function gatherEvidence(chart, bodies, lagnaCode, fn, jaimini, yogas, navamsa, dignity, arudhas) {
  const signals = [];
  const lagnaProfile = SIGN_PROFILE[lagnaCode] || {};

  // Lagna strength
  const lagnaLord = lagnaProfile.lord;
  const lagnaLordBody = bodies[lagnaLord];
  const lagnaLordHouse = lagnaLordBody?.house;
  const lagnaLordSign = lagnaLordBody?.signCode;
  const lagnaLordDig = dignity[lagnaLord]?.d1 || "Neutral's Sign";

  // Moon position
  const moonSign = bodies.Moon?.signCode;
  const moonHouse = bodies.Moon?.house;
  const moonProfile = SIGN_PROFILE[moonSign] || {};

  // Sun position
  const sunSign = bodies.Sun?.signCode;
  const sunHouse = bodies.Sun?.house;

  // AK
  const ak = jaimini?.atmakaraka?.planet;
  const akSign = bodies[ak]?.signCode;
  const akHouse = bodies[ak]?.house;

  // AMK
  const amk = jaimini?.allCharaKarakas?.AMK;
  const amkSign = bodies[amk]?.signCode;
  const amkHouse = bodies[amk]?.house;

  // Saturn as Yogakaraka for Taurus lagna
  const saturnRole = fn['Saturn']?.classification || '';
  const isYogakaraka = saturnRole.includes('Yogakaraka');

  // Yogas present
  const rajaYogas = Array.isArray(yogas.rajaYogas) ? yogas.rajaYogas : [];
  const dhanaYogas = Array.isArray(yogas.dhanaYogas) ? yogas.dhanaYogas : [];
  const hasStrongYogas = rajaYogas.length > 2;

  // Stellium in Cancer (3rd house for Taurus)
  const cnPlanets = Object.entries(bodies)
    .filter(([p,b]) => b?.signCode === 'Cn' && ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn'].includes(p))
    .map(([p]) => p);

  // Multiple planets together
  const houseCounts = {};
  Object.entries(bodies).forEach(([p, b]) => {
    if (!b?.house || !['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn','Rahu','Ketu'].includes(p)) return;
    houseCounts[b.house] = (houseCounts[b.house] || 0) + 1;
  });
  const crowdedHouses = Object.entries(houseCounts).filter(([h,c]) => c >= 3).map(([h,c]) => ({house:+h, count:c}));

  return {
    lagnaCode, lagnaProfile, lagnaLord, lagnaLordBody, lagnaLordHouse,
    lagnaLordSign, lagnaLordDig, moonSign, moonHouse, moonProfile,
    sunSign, sunHouse, ak, akSign, akHouse, amk, amkSign, amkHouse,
    isYogakaraka, saturnRole, rajaYogas, dhanaYogas, hasStrongYogas,
    cnPlanets, crowdedHouses, fn, bodies, dignity,
    summary: {
      lagna: lagnaCode, lagnaLord, lagnaLordHouse, lagnaLordDig,
      moonSign, moonHouse, sunSign, sunHouse,
      ak, akSign, amk, amkSign,
      rajaYogaCount: rajaYogas.length, dhanaYogaCount: dhanaYogas.length,
      crowdedHouses: crowdedHouses.map(h => 'H'+h.house+'('+h.count+' planets)')
    }
  };
}

// ── Section builders ──────────────────────────────────────────────────────────

function buildOuterSelf(lagnaCode, bodies, fn, ev) {
  const prof = ev.lagnaProfile;
  const lord = ev.lagnaLord;
  const lordHouse = ev.lagnaLordHouse;
  const lordDig = ev.lagnaLordDig;
  const lordSign = ev.lagnaLordSign;

  // Confidence level based on lagna lord strength
  const isStrong = ['Exalted', 'Own Sign'].includes(lordDig);
  const isWeak = ['Debilitated', "Enemy's Sign"].includes(lordDig);

  let para = `Yeh vyakti baahri duniya ko **${lagnaCode} Lagna** ke zariye dekhta/dekhti hai — `;
  para += `yaani ${prof.core} ki pravritti bahut naturally saamne aati hai. `;

  if (ev.crowdedHouses.length > 0) {
    const ch = ev.crowdedHouses[0];
    const hm = HOUSE_MEANING[ch.house] || 'ek khaas shetra';
    para += `Lagna mein ya ${ch.count} grahon ka ek jagah hona ek bahut strong focus banata hai — `;
    para += `${hm} ka shetra is vyakti ke jeevan mein baar baar importance lega. `;
  }

  para += `\n\nLagna lord **${lord}** H${lordHouse} (${HOUSE_MEANING[lordHouse]||'—'}) mein hai, `;
  para += `${lordSign} rashi mein — jo ${DIGNITY_STRENGTH[lordDig] || 'average'} hai. `;

  if (isStrong) {
    para += `Yeh ek significant signal hai ki yeh vyakti apni core identity ko clearly express karne mein capable hai. `;
    para += `**Baahri pehchan mein confidence** — ek quality jo baar baar support hoti hai is chart mein.`;
  } else if (isWeak) {
    para += `Yeh suggest karta hai ki apni baahri pehchan ko establish karne mein is vyakti ko **zyada mehnat** lagti hai. `;
    para += `Jo andar se strong hai, woh baahri duniya mein utni aasaani se express nahi hota.`;
  } else {
    para += `Lagna lord ki position ek mixed signal deti hai — kuch areas mein strong, kuch mein support ki zaroorat hai.`;
  }

  return { title: 'Yeh Kaun Hai', content: para };
}

function buildCoreTendencies(bodies, lagnaCode, ev) {
  const moonSign = ev.moonSign;
  const moonHouse = ev.moonHouse;
  const moonProf = ev.moonProfile;
  const sunSign = ev.sunSign;
  const sunHouse = ev.sunHouse;

  // Get Moon nakshatra
  const { getFullLongitude, getNakshatra, NAKSHATRA_PSYCHOLOGY } = require('../computation/nakshatra');
  const moonLon = getFullLongitude(bodies.Moon);
  const moonNak = moonLon != null ? getNakshatra(moonLon) : null;
  const moonNakPsych = moonNak ? NAKSHATRA_PSYCHOLOGY[moonNak.name] : null;

  // Get AK nakshatra
  const ak = ev.ak;
  const akLon = ak ? getFullLongitude(bodies[ak]) : null;
  const akNak = akLon != null ? getNakshatra(akLon) : null;

  let para = `**Moon** (mann aur bhavnaon ka karaka) **${moonSign}** mein H${moonHouse} mein hai. `;
  para += `Moon ka sign mann ke habitual patterns dikhata hai — `;
  para += `andar se yeh vyakti ${moonProf.core} ki taraf naturally jhukta/jhukti hai. `;
  para += `${moonProf.strength} — yeh qualities naturally aate hain.\n\n`;

  // Moon nakshatra psychology
  if (moonNak && moonNakPsych) {
    para += `**Moon nakshatra: ${moonNak.name}** (lord: ${moonNak.lord}) — `;
    para += `*${moonNakPsych.theme}*. `;
    para += `${moonNakPsych.nature}. `;
    para += `\nIska ek shadow bhi hai: *${moonNakPsych.shadow}*. `;
    para += `Nakshatra lord ${moonNak.lord} ka jo ghar aur sign hai — woh bhi mann ke deeper patterns mein ek role play karta hai.\n\n`;
  }

  // Moon and Sun same house
  if (bodies.Moon?.house === bodies.Sun?.house) {
    para += `**Sun aur Moon ek hi house mein hain** — `;
    para += `andar ki emotional reality aur baahri soul-purpose ek direction mein jaate hain. `;
    para += `Alignment acha hai, lekin **dono energies ek jagah hone se overload** bhi ho sakta hai — `;
    para += `perspective lene ke liye distance banana kabhi mushkil lagta hai.`;
  } else {
    para += `**Sun** (aatma aur purpose) **${sunSign}** mein H${sunHouse} mein hai. `;
    para += `Moon aur Sun alag jagah hone se is vyakti ke andar ek **natural tension** hai — `;
    para += `jo andar se feel hota hai (Moon) aur jo baahri duniya mein express karna chahte hain (Sun) — `;
    para += `in dono ke beech mein kabhi kabhi adjustment karna padta hai.`;
  }

  // Cancer concentration
  if (ev.cnPlanets.length >= 3) {
    para += `\n\n**${ev.cnPlanets.join(', ')} — Cancer mein concentration:**\n`;
    para += `Teen ya zyada grahe Cancer mein hain — yeh extraordinary hai. `;
    para += `**Griha, parivar, emotions, aur mann** ek central theme ban jaate hain. `;
    para += `Yeh vyakti deeply connected hai apne inner world se.`;
  }

  return { title: 'Core Pravritti', content: para };
}

function buildInnerTensions(bodies, lagnaCode, fn, ev) {
  const tensionSignals = [];
  const harmonySignals = [];

  // Check for functional malefics in important houses
  const mars = bodies.Mars;
  const jupiter = bodies.Jupiter;
  const saturn = bodies.Saturn;
  const rahu = bodies.Rahu;

  // For Taurus lagna: Jupiter is functional malefic (rules 8 and 11)
  if (fn['Jupiter']?.classification?.includes('Malefic') && jupiter?.house) {
    tensionSignals.push({
      text: `Jupiter (jo is lagna ke liye functional malefic hai — H8 aur H11 ka lord) H${jupiter.house} mein hai`,
      impact: 'expansion aur wisdom ki jagah ek complex energy create kar sakta hai'
    });
  }

  // Saturn yogakaraka for Taurus
  if (ev.isYogakaraka && saturn?.house) {
    harmonySignals.push({
      text: `Saturn Yogakaraka hai Taurus lagna ke liye`,
      impact: `H${saturn.house} mein hote hue yeh discipline, structure, aur long-term success ka strong support deta hai`
    });
  }

  // Rahu in 6th house
  if (rahu?.house === 6) {
    tensionSignals.push({
      text: 'Rahu H6 mein (Libra) hai',
      impact: 'enemy, disease, service — in areas mein unusual yaane conventional se alag patterns'
    });
  }

  let para = '';

  if (harmonySignals.length > 0) {
    para += `Is chart mein kuch **constructive alignments** hain jo support karte hain:\n\n`;
    harmonySignals.forEach(s => {
      para += `• **${s.text}** — ${s.impact}.\n`;
    });
  }

  if (tensionSignals.length > 0) {
    para += `\nSaath hi, kuch **internal tensions** bhi hain jo is vyakti ke andar kaam karte hain:\n\n`;
    tensionSignals.forEach(s => {
      para += `• **${s.text}** — ${s.impact}.\n`;
    });
    para += `\nYeh tensions necessarily nakaratmak nahi hain — ye woh areas hain jahan growth hoti hai, `;
    para += `lekin yeh areas easy nahi hote.`;
  }

  if (!para) {
    para = `Is chart mein koi extreme tension ya dramatic conflict nahi dikh raha — `;
    para += `jo ek sign hai ki is vyakti ka jeevan relatively balanced trajectory rakhta hai.`;
  }

  return { title: 'Andar ke Pulls aur Tensions', content: para };
}

function buildLifePath(bodies, lagnaCode, jaimini, fn, arudhas, yogas, ev) {
  const amk = ev.amk;
  const amkHouse = ev.amkHouse;
  const amkSign = ev.amkSign;
  const gl = arudhas?.GL || arudhas?.A10;
  const al = arudhas?.A1;
  const rajaYogas = ev.rajaYogas;
  const dhanaYogas = ev.dhanaYogas;

  let para = `**Career aur Jeevan Path:**\n\n`;
  para += `AMK (Amatyakaraka — career ka significator) **${amk}** hai, jo H${amkHouse} (${HOUSE_MEANING[amkHouse]||'—'}) `;
  para += `mein ${amkSign} mein hai. `;

  const amkNature = PLANET_NATURE[amk] || '';
  para += `${amk} ka svabhav hai: *${amkNature}* — `;
  para += `isliye yeh vyakti ka career naturally in themes ko involve karta hai ya karta rahega. `;

  if (rajaYogas.length > 0) {
    para += `\n\n**Raja Yogas:** Is chart mein **${rajaYogas.length} Raja Yoga** hain. `;
    if (rajaYogas.length >= 4) {
      para += `Yeh ek significant promise hai — classical texts kehte hain ki Raja Yoga wala vyakti `;
      para += `apne field mein recognition aur authority paata hai. `;
      para += `Lekin ek important caveat: Raja Yoga sirf promise deta hai — delivery dasha aur gochara ke hisaab se hoti hai. `;
      para += `**Is chart mein potential clearly hai — timing is par depend karti hai.**`;
    } else {
      para += `Yeh ek partial support deta hai career mein aage badhne ke liye.`;
    }
  }

  if (dhanaYogas.length > 0) {
    para += `\n\nSaath hi **${dhanaYogas.length} Dhana Yoga** bhi hain — financial growth ka classical indication.`;
  }

  if (ev.isYogakaraka) {
    para += `\n\nSaturn Yogakaraka hone ke naate — **mehnat, discipline, aur structured approach** `;
    para += `is vyakti ke liye success ka sabse reliable path hai. `;
    para += `Saturn ke periods (Vimshottari mein Saturn MD, ya gochar mein Saturn ka activation) `;
    para += `typically this person ke liye productive aur career-advancing hote hain.`;
  }

  return { title: 'Career aur Jeevan Path', content: para };
}

function buildRelationships(bodies, lagnaCode, jaimini, arudhas, ev) {
  const dk = jaimini?.allCharaKarakas?.DK;
  const dkSign = bodies[dk]?.signCode;
  const dkHouse = bodies[dk]?.house;
  const ulHouse = arudhas?.A12?.finalArudhaHouse;
  const venus = bodies.Venus;
  const jupiter = bodies.Jupiter;

  let para = `**Rishte aur Partnership:**\n\n`;
  para += `DK (Darakaraka — spouse ka significator) **${dk}** hai, H${dkHouse} mein ${dkSign} mein. `;

  const dkNature = PLANET_NATURE[dk] || '';
  para += `${dk} jo dikhata hai — *${dkNature}* — yeh themes spouse ya partnerships mein relevant hote hain.\n\n`;

  // Venus position (natural karaka of relationships)
  if (venus) {
    para += `**Venus** (relationships ka natural karaka) H${venus.house} (${HOUSE_MEANING[venus.house]||'—'}) `;
    para += `mein ${venus.signCode} mein hai. `;

    if (venus.house === 3) {
      para += `H3 Venus suggest karta hai ki communication, shared interests, aur intellectual connection `;
      para += `relationships mein bahut important role play karte hain. `;
      para += `*Jab tak baat hoti rahi, rishta chalta raha* — yeh ek pattern ho sakta hai.`;
    } else if (venus.house === 7) {
      para += `Venus apne karaka house mein — relationships naturally important hain aur Venus ke periods mein `;
      para += `significant relationship events aate hain.`;
    }
  }

  if (ulHouse) {
    para += `\n\nUL (Upapada Lagna) H${ulHouse} mein hai — `;
    para += `yeh marriage/commitment ke time aur quality ka ek important indicator hai. `;
  }

  // For Taurus lagna, Jupiter as functional malefic can complicate relationships
  if (ev.fn?.Jupiter?.classification?.includes('Malefic') && jupiter?.house) {
    para += `\n\nEk important nuance: Jupiter jo normally rishton mein wisdom laata hai, `;
    para += `is lagna ke liye functionally complex hai. `;
    para += `Yeh suggest karta hai ki relationships mein *"zyada sochna ya expand karna"* `;
    para += `kabhi kabhi stability se zyada tension create kar sakta hai.`;
  }

  return { title: 'Rishte aur Relationships', content: para };
}

function buildShadowPatterns(bodies, lagnaCode, fn, ev) {
  const shadows = [];

  // Taurus lagna shadow
  if (lagnaCode === 'Ta') {
    shadows.push('Stubborn hona — "mere tarike se hi hoga" attitude in situations where flexibility would serve better');
    shadows.push('Comfort zone se bahar nikalna mushkil lagta hai, especially when it involves financial or material security');
  }

  // Cancer concentration shadow
  if (ev.cnPlanets.length >= 3) {
    shadows.push('Over-emotional responses — feelings ko reality se alag karna kabhi mushkil ho sakta hai');
    shadows.push('Past se attached rehna — "woh time achha tha" trap mein aana');
    shadows.push('Family ya close ones ke liye zyada sacrifice karna, apni zarooraton ko ignore karke');
  }

  // Moon in Leo shadow
  if (ev.moonSign === 'Le') {
    shadows.push('Recognition ki zaroorat — jab appreciation nahi milta to mann bahut affected hota hai');
    shadows.push('Emotional decisions mein pride aane dena — "main kaise maan sakta/sakti hoon" attitude');
  }

  // Rahu in 6th
  if (bodies.Rahu?.house === 6) {
    shadows.push('Dushmani ya competition ko unnecessary create karna, ya phir in se bahut zyada preoccupied rehna');
  }

  // Functional malefic Jupiter
  if (fn?.Jupiter?.classification?.includes('Malefic')) {
    shadows.push('Kabhi kabhi over-expansion ya overconfidence — particularly in financial matters');
  }

  let para = `Har strong quality ki ek cost hoti hai. Is chart ke patterns se jo shadow areas emerge karte hain:\n\n`;
  shadows.forEach(s => {
    para += `• ${s}\n`;
  });

  para += `\n*Yeh "flaws" nahi hain — yeh woh patterns hain jo awareness se transform ho sakte hain. `;
  para += `Chart tendencies dikhaata hai, destiny nahi.*`;

  return { title: 'Shadow Patterns', content: para };
}

function buildSummary(lagnaCode, bodies, jaimini, yogas, ev) {
  const ak = ev.ak;
  const akSign = ev.akSign;
  const lagnaProf = ev.lagnaProfile;
  const moonProf = ev.moonProfile;
  const rajaYogas = ev.rajaYogas;

  let para = `**Saar:**\n\n`;
  para += `Is vyakti ki core prakriti ek interesting mix hai — `;
  para += `baahri taur par **${lagnaProf.core}** (${lagnaCode} Lagna), `;
  para += `andar se **${moonProf.core}** (${ev.moonSign} Moon). `;

  para += `\n\nAK (Atmakaraka) **${ak}** hai — *${PLANET_NATURE[ak]||''}* — `;
  para += `yeh is vyakti ki aatma ka sabse important signification hai. `;
  para += `${ak} ke themes — duniya mein kaafi baar aayenge, aur yeh vyakti in themes ke through apni `;
  para += `sabse badi learning karegi/karega.`;

  if (rajaYogas.length >= 3) {
    para += `\n\nIs chart mein **recognition aur authority ka promise** clearly hai — `;
    para += `${rajaYogas.length} Raja Yogas ek uncommon combination hai. `;
    para += `Yeh vyakti apne chosen field mein naam kama sakta/sakti hai, `;
    para += `lekin yeh tab hoga jab Saturn ka structured discipline (Yogakaraka) `;
    para += `aur Venus ka authentic creative expression (Lagna lord) dono aligned honge.`;
  }

  if (ev.isYogakaraka) {
    para += `\n\n**Sabse important practical insight:** Saturn is chart ka Yogakaraka hai. `;
    para += `Jo log is energy ko dekhne mein fail karte hain, woh Saturn ke periods mein `;
    para += `sirf struggle dekhte hain. Jo log Saturn ko samjhte hain, `;
    para += `woh in periods ko apni life ke **most productive phases** mein convert karte hain. `;
    para += `Discipline, consistency, aur long-term thinking — yeh is vyakti ke success ke actual pillars hain.`;
  }

  return { title: 'Saar — Is Vyakti Ke Baare Mein', content: para };
}

module.exports = { generatePortrait };
