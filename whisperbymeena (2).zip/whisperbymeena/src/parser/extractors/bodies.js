/**
 * Body Positions Extractor (v2)
 *
 * Real JHora PDFs have these complications (via pdf-parse):
 *   - Nakshatra-pada sometimes glued: "Krit4" instead of "Krit 4"
 *   - More body types: Vighati Lagna, Varnada Lagna, Sree Lagna
 *   - Header may be glued: "BodyLongitudeNakshatra"
 *
 * Examples handled:
 *   Lagna 8 Ta 27' 20.18" Krit4 Ta Pi
 *   Sun - PK12 Cn 19' 48.54" Push 3 Cn Li
 *   Mercury - AK 26 Cn 13' 34.90" Asre3 Cn Aq
 *   Bhava Lagna 2 Ta 25' 38.42" Krit2 Ta Cp
 *   Sree Lagna 26 Vi 01' 50.21" Chit1 Vi Le
 */

const {
  computeHouse, normalizePlanetName, normalizeSign, normalizeNakshatra,
  CHARA_KARAKAS
} = require('../utils/constants');

// Recognized body names — longer multi-word names FIRST to avoid prefix collisions
const BODY_NAMES = [
  'Bhava Lagna', 'Hora Lagna', 'Ghati Lagna',
  'Vighati Lagna', 'Varnada Lagna', 'Sree Lagna',
  'Lagna',
  'Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn',
  'Rahu', 'Ketu', 'Uranus', 'Neptune', 'Pluto',
  'Maandi', 'Gulika'
];

// Trailing pattern: deg sign min' sec" nak [optional space] pada rasi navamsa
// Nakshatra is alphabetic-only (no digits), then 0 or more spaces, then single digit pada
const POSITION_PATTERN =
  /(\d+)\s+([A-Z][a-z])\s+(\d+)'\s+([\d.]+)"\s+([A-Z][A-Za-z]{2,5})\s*(\d)\s+([A-Z][a-z])\s+([A-Z][a-z])\s*$/;

function extractBodies(sectionText) {
  const lines = sectionText.split('\n').map(l => l.trim()).filter(Boolean);

  const bodies = {};
  const charaKarakas = {};
  let lagnaSignCode = null;

  for (const line of lines) {
    // Skip the header line "BodyLongitudeNakshatra Pada Rasi Navamsa" etc.
    if (/^Body\s*Longitude/.test(line)) continue;

    const parsed = parseBodyLine(line);
    if (!parsed) continue;

    if (parsed.name === 'Lagna') lagnaSignCode = parsed.signCode;
    bodies[parsed.name] = parsed;

    if (parsed.charaKaraka) {
      for (const code of parsed.charaKaraka.split('/')) {
        if (CHARA_KARAKAS[code]) charaKarakas[code] = parsed.name;
      }
    }
  }

  if (lagnaSignCode) {
    for (const name of Object.keys(bodies)) {
      const body = bodies[name];
      if (name === 'Lagna') body.house = 1;
      else body.house = computeHouse(lagnaSignCode, body.signCode);
    }
  }

  return { bodies, charaKarakas };
}

function parseBodyLine(line) {
  const posMatch = line.match(POSITION_PATTERN);
  if (!posMatch) return null;

  let prefix = line.substring(0, posMatch.index).trim();

  // Detect chara karaka tag at end of prefix
  let charaKaraka = null;
  const ckMatch = prefix.match(/\s+-\s+([A-Za-z\/]+)$/);
  if (ckMatch) {
    charaKaraka = ckMatch[1];
    prefix = prefix.substring(0, ckMatch.index).trim();
  }

  // Retrograde flag
  let retrograde = false;
  if (prefix.endsWith('(R)')) {
    retrograde = true;
    prefix = prefix.substring(0, prefix.length - 3).trim();
  }

  // Match body name
  let bodyName = null;
  for (const known of BODY_NAMES) {
    if (prefix === known) { bodyName = known; break; }
  }
  if (!bodyName) return null;

  return {
    name: bodyName,
    sign: normalizeSign(posMatch[2]),
    signCode: posMatch[2],
    degrees: parseInt(posMatch[1], 10),
    minutes: parseInt(posMatch[3], 10),
    seconds: parseFloat(posMatch[4]),
    longitudeInSign: parseInt(posMatch[1], 10) + parseInt(posMatch[3], 10) / 60 + parseFloat(posMatch[4]) / 3600,
    nakshatra: normalizeNakshatra(posMatch[5]),
    nakshatraCode: posMatch[5],
    pada: parseInt(posMatch[6], 10),
    rasi: normalizeSign(posMatch[7]),
    rasiCode: posMatch[7],
    navamsa: normalizeSign(posMatch[8]),
    navamsaCode: posMatch[8],
    retrograde,
    charaKaraka: charaKaraka || null,
    house: null
  };
}

module.exports = { extractBodies, parseBodyLine, BODY_NAMES };
