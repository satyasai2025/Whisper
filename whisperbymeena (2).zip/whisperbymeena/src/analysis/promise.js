/**
 * PROMISE LAYER (Layer 1 of the Predictive Engine)
 *
 * From the original build-spec: a predictive read should never rest on a
 * single rule. For each life-event category, classical analysis checks
 * MULTIPLE independent angles before concluding the chart "promises" that
 * event at all:
 *
 *   1. RELEVANT HOUSE(S) — the bhava(s) classically tied to this event
 *   2. HOUSE LORD strength/placement — is the lord well-disposed?
 *   3. KARAKA (natural significator) strength/placement — e.g. Jupiter for
 *      children, Venus/7th-lord for marriage
 *   4. OCCUPANTS of the relevant house — benefics/malefics sitting there
 *   5. ASPECTS on the relevant house — who aspects it, benefic or malefic
 *   6. SAHAM (sensitive point), where one is defined for this domain —
 *      its house placement and whether its dispositor is well-disposed
 *
 * This module does NOT decide WHEN (that's the Dasha-Activation layer) or
 * assign a single number (that's the Convergence layer). It only answers:
 * "does this chart show a credible classical promise for this event, and
 * which independent indicators support that?" Each indicator is reported
 * with its own polarity (supports / weakens) so nothing is silently
 * averaged away.
 *
 * DOMAIN TYPE matters for reading polarity correctly:
 *   - 'growth' domains (marriage, career, foreign, children, wealth):
 *     "supports" = supports the event/outcome happening — a GOOD thing.
 *   - 'affliction' domains (disease, addiction): "supports" = supports
 *     VULNERABILITY to the affliction — this is a risk-flag, not a
 *     positive outcome. "weakens" here means PROTECTIVE. This distinction
 *     is surfaced explicitly (domainType field) so it is never read
 *     backwards.
 *
 * ============================ HONESTY NOTE ============================
 * "Promise" here means "the classical indicators a Jyotishi would check
 * before saying an event is promised" — it is a STRUCTURED CHECKLIST,
 * not a verdict. A chart can show weak promise on every indicator; that
 * is itself useful information, reported plainly, not hidden.
 *
 * SOURCING CAVEAT for newer domains: "Addiction" specifically is not a
 * single named classical category the way "marriage" or "career" are.
 * Classical texts address vyasana (vice/addiction) in scattered
 * references tied to 6th/8th/12th-house affliction and malefic
 * combinations (notably Saturn-Rahu, a modern-practice convention more
 * than a core-BPHS-named yoga). This is flagged at 'interpretive' or
 * 'synthesized' confidence rather than 'direct' throughout.
 * =========================================================================
 */

const { SOURCES } = require('./rules/schema');

const REAL_PLANETS = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn', 'Rahu', 'Ketu'];

/**
 * Each event category lists:
 *   houses     — primary bhava(s) to check (first is primary, rest secondary)
 *   karakas    — natural significator planet(s) for this event
 *   label      — human label
 *   domainType — 'growth' (supports = good outcome) or 'affliction'
 *                (supports = vulnerability flag, NOT a good outcome)
 *   sahamKey   — key into sahams.js output, if a relevant Saham exists
 *   source     — classical grounding for why these houses/karakas matter
 */
const EVENT_DEFINITIONS = {
  // ===== Relationships =====
  marriage: {
    label: 'Marriage',
    domainType: 'growth',
    houses: [7],
    secondaryHouses: [2, 11],
    karakas: ['Venus'],
    source: { text: SOURCES.BPHS, area: '7th house & Kalatra-karaka (Venus) principles' }
  },
  engagement: {
    label: 'Engagement',
    domainType: 'growth',
    houses: [7],
    secondaryHouses: [11],
    karakas: ['Venus'],
    source: { text: SOURCES.BPHS, area: '7th house (commitment/promise phase, preceding marriage itself)' }
  },
  divorce: {
    label: 'Divorce / Marital Separation',
    domainType: 'affliction',
    houses: [7],
    secondaryHouses: [6, 8],
    karakas: ['Saturn'],
    source: { text: SOURCES.PVR, area: '7th-house affliction + Saturn (separation/distance) + 6th (disputes) + 8th (ending of bond) -- a synthesis of classical affliction principles, not a single named yoga' },
    note: 'Affliction here is a TENDENCY, not a certainty -- many charts show some 7th-house affliction and the relationship endures. This flags a stress-pattern worth weighing, not a forecast.'
  },

  // ===== Career & Work (granular lifecycle) =====
  career: {
    label: 'Career (general)',
    domainType: 'growth',
    houses: [10],
    secondaryHouses: [6, 2, 11],
    karakas: ['Saturn', 'Sun', 'Mercury'],
    sahamKey: 'karma',
    source: { text: SOURCES.BPHS, area: '10th house (karma) principles -- general/umbrella career assessment' }
  },
  firstJob: {
    label: 'First Job',
    domainType: 'growth',
    houses: [10],
    secondaryHouses: [6, 2],
    karakas: ['Saturn', 'Mercury'],
    sahamKey: 'karma',
    source: { text: SOURCES.BPHS, area: '10th house (career) + 6th house (service/employment specifically, as distinct from business)' }
  },
  jobChange: {
    label: 'Job Change',
    domainType: 'growth',
    houses: [10],
    secondaryHouses: [6, 12],
    karakas: ['Saturn', 'Rahu'],
    sahamKey: 'karma',
    source: { text: SOURCES.PVR, area: '10th house + 12th (ending of the old position) -- the 12th-as-release/transition principle applied to career; Rahu as modern change-signifier' }
  },
  promotion: {
    label: 'Promotion',
    domainType: 'growth',
    houses: [10],
    secondaryHouses: [1, 11],
    karakas: ['Sun', 'Saturn'],
    sahamKey: 'karma',
    source: { text: SOURCES.BPHS, area: '10th house + Sun (status/authority increase) + 11th (gains/recognition)' }
  },
  termination: {
    label: 'Job Termination / Loss of Position',
    domainType: 'affliction',
    houses: [10],
    secondaryHouses: [6, 12],
    karakas: ['Saturn'],
    sahamKey: 'karma',
    source: { text: SOURCES.BPHS, area: '10th house affliction + 12th (loss) + 6th (service disruption)' }
  },
  businessStart: {
    label: 'Business / Entrepreneurship Start',
    domainType: 'growth',
    houses: [7],
    secondaryHouses: [10, 3, 11],
    karakas: ['Mercury', 'Mars'],
    sahamKey: 'vyapara',
    source: { text: SOURCES.PVR, area: '9th-lord-in-Lagna independence pattern; Mercury-Mars business combination (same documented pattern used in Career Path classification)' }
  },
  retirement: {
    label: 'Retirement',
    domainType: 'growth',
    houses: [10],
    secondaryHouses: [4, 12],
    karakas: ['Saturn'],
    source: { text: SOURCES.BPHS, area: '12th-from-10th (release from active career engagement) + Saturn (natural significator of completion) + 4th (home/rest gaining prominence)' },
    note: 'This is a NEUTRAL life-stage transition, not unambiguously positive or negative the way other growth domains are framed -- treated as growth-polarity by default (since it is usually a chosen/earned transition), but read it that way loosely.'
  },

  // ===== Property =====
  housePurchase: {
    label: 'House / Property Purchase',
    domainType: 'growth',
    houses: [4],
    secondaryHouses: [2, 11],
    karakas: ['Mars'],
    source: { text: SOURCES.BPHS, area: '4th house (property/land) + Mars (classical karaka for land/immovable property)' }
  },
  vehiclePurchase: {
    label: 'Vehicle Purchase',
    domainType: 'growth',
    houses: [4],
    secondaryHouses: [2, 11],
    karakas: ['Venus'],
    source: { text: SOURCES.BPHS, area: '4th house (classically also covers vehicles/conveyances) + Venus (comfort/luxury significations)' }
  },

  // ===== Foreign =====
  foreignTravel: {
    label: 'Foreign Travel / Relocation (general)',
    domainType: 'growth',
    houses: [12],
    secondaryHouses: [9, 3],
    karakas: ['Rahu'],
    sahamKey: 'paradesa',
    source: { text: SOURCES.PVR, area: '12th house (foreign residence) + Rahu as foreign-signifier (modern/PVR convention, not core BPHS) -- general/umbrella assessment' }
  },
  foreignSettlement: {
    label: 'Long-Term Foreign Settlement',
    domainType: 'growth',
    houses: [12],
    secondaryHouses: [9, 4],
    karakas: ['Rahu'],
    sahamKey: 'paradesa',
    source: { text: SOURCES.PVR, area: '12th-lord placement + weak 4th-lord (reduced motherland attachment) pattern -- the same documented combination used in Foreign Path classification, applied here as a specific settlement EVENT rather than a general leaning' }
  },

  // ===== Health (affliction domains) =====
  disease: {
    label: 'Disease / Health Vulnerability (general)',
    domainType: 'affliction',
    houses: [6],
    secondaryHouses: [1, 8],
    karakas: ['Saturn', 'Mars'],
    sahamKey: 'roga',
    source: { text: SOURCES.BPHS, area: '6th house (disease) principles -- general/umbrella health assessment' }
  },
  majorIllness: {
    label: 'Major Illness',
    domainType: 'affliction',
    houses: [6],
    secondaryHouses: [1, 8],
    karakas: ['Saturn', 'Mars'],
    sahamKey: 'roga',
    source: { text: SOURCES.BPHS, area: '6th house (disease) + 1st (vitality) + 8th (chronic/serious matters) -- same core indicators as the general Disease domain, read for a specific acute episode' }
  },
  surgery: {
    label: 'Surgery / Invasive Procedure',
    domainType: 'affliction',
    houses: [6],
    secondaryHouses: [8, 1],
    karakas: ['Mars'],
    sahamKey: 'jadya',
    source: { text: SOURCES.PVR, area: 'Mars (cutting/blood/invasive procedures, classical karaka) + 6th-lord connection (the same Mars+6th-lord pattern also appears in surgeon-profession charts -- the signature can indicate either performing or undergoing surgery depending on context)' }
  },
  accident: {
    label: 'Accident / Sudden Injury',
    domainType: 'affliction',
    houses: [8],
    secondaryHouses: [3, 6],
    karakas: ['Mars'],
    source: { text: SOURCES.BPHS, area: '8th house (sudden/unexpected events) + Mars (injury, classical karaka for accidents)' }
  },

  // ===== Death of close relations — EXTREME SENSITIVITY =====
  // See SENSITIVITY_NOTE below and the dedicated note on each entry. These
  // reflect classical SIGNIFICATOR-house affliction patterns in the
  // broadest sense -- NOT literal death-timing predictions. Classical
  // Jyotish itself treats literal mortality timing with great caution
  // (requiring multiple confirming techniques and very precise birth data
  // even then); this tool is not the right context for that kind of claim,
  // and these domains should never be read or presented as one.
  deathOfFather: {
    label: 'Significant Affliction Concerning Father',
    domainType: 'affliction',
    houses: [9],
    secondaryHouses: [8, 12],
    karakas: ['Sun'],
    source: { text: SOURCES.BPHS, area: '9th house (father) + Sun (karaka) affliction principles' },
    extremeSensitivity: true,
    note: 'This reflects classical 9th-house/Sun AFFLICTION patterns in the broadest sense -- NOT a literal death-timing prediction. Affliction to a relation\'s significator classically corresponds to MANY possible difficulties (health strain, distance, financial trouble, relationship friction) involving that person, not only death. Jyotish treats literal mortality timing with extreme caution even in dedicated longevity analysis; this tool should never be used or read as a death prediction.'
  },
  deathOfMother: {
    label: 'Significant Affliction Concerning Mother',
    domainType: 'affliction',
    houses: [4],
    secondaryHouses: [8, 12],
    karakas: ['Moon'],
    source: { text: SOURCES.BPHS, area: '4th house (mother) + Moon (karaka) affliction principles' },
    extremeSensitivity: true,
    note: 'This reflects classical 4th-house/Moon AFFLICTION patterns in the broadest sense -- NOT a literal death-timing prediction. Affliction to a relation\'s significator classically corresponds to MANY possible difficulties (health strain, distance, financial trouble, relationship friction) involving that person, not only death. Jyotish treats literal mortality timing with extreme caution even in dedicated longevity analysis; this tool should never be used or read as a death prediction.'
  },
  deathOfSpouse: {
    label: 'Significant Affliction Concerning Spouse',
    domainType: 'affliction',
    houses: [7],
    secondaryHouses: [8, 12],
    karakas: ['Venus'],
    source: { text: SOURCES.BPHS, area: '7th house (spouse) + Venus (karaka) affliction principles' },
    extremeSensitivity: true,
    note: 'This reflects classical 7th-house/Venus AFFLICTION patterns in the broadest sense -- NOT a literal death-timing prediction. Affliction to a relation\'s significator classically corresponds to MANY possible difficulties (health strain, distance, financial trouble, relationship friction) involving that person, not only death. Jyotish treats literal mortality timing with extreme caution even in dedicated longevity analysis; this tool should never be used or read as a death prediction.'
  },

  // ===== Legal =====
  courtCase: {
    label: 'Court Case / Legal Dispute',
    domainType: 'affliction',
    houses: [6],
    secondaryHouses: [7, 12],
    karakas: ['Saturn', 'Mars'],
    source: { text: SOURCES.BPHS, area: '6th house (disputes/litigation, the primary classical house for legal conflict) + Saturn/Mars' },
    note: 'This reflects likelihood of being INVOLVED in a legal dispute, not the outcome -- winning or losing a case is a separate question this domain does not address.'
  },

  // ===== Education =====
  education: {
    label: 'Education (general)',
    domainType: 'growth',
    houses: [4],
    secondaryHouses: [9, 2],
    karakas: ['Mercury', 'Jupiter'],
    sahamKey: 'vidya',
    source: { text: SOURCES.BPHS, area: '4th house (primary education) + house-from-house chain (9th=bachelors, 2nd=masters) + Vidya Saham -- general/umbrella assessment' }
  },
  graduation: {
    label: 'Graduation / Degree Completion',
    domainType: 'growth',
    houses: [4],
    secondaryHouses: [9, 2],
    karakas: ['Mercury', 'Jupiter'],
    sahamKey: 'vidya',
    source: { text: SOURCES.BPHS, area: 'Same education-chain indicators as the general Education domain, read for the completion event specifically' }
  },
  scholarship: {
    label: 'Scholarship / Educational Financial Award',
    domainType: 'growth',
    houses: [4],
    secondaryHouses: [9, 11, 2],
    karakas: ['Jupiter', 'Mercury'],
    sahamKey: 'vidya',
    source: { text: SOURCES.PVR, area: 'Education-chain (4th/9th) combined with 11th house (gains) -- a hybrid of education and wealth indicators' }
  },

  // ===== Wealth =====
  wealth: {
    label: 'Wealth (general)',
    domainType: 'growth',
    houses: [2],
    secondaryHouses: [11, 9],
    karakas: ['Jupiter'],
    sahamKey: 'artha',
    source: { text: SOURCES.BPHS, area: '2nd house (Dhana) & Jupiter as Dhana-karaka principles -- general/umbrella wealth assessment' }
  },
  majorFinancialGain: {
    label: 'Major Financial Gain',
    domainType: 'growth',
    houses: [11],
    secondaryHouses: [2, 9],
    karakas: ['Jupiter'],
    sahamKey: 'labha',
    source: { text: SOURCES.BPHS, area: '11th house (gains, the primary classical house for sudden/significant income) + Jupiter (Dhana-karaka)' }
  },
  majorFinancialLoss: {
    label: 'Major Financial Loss',
    domainType: 'affliction',
    houses: [12],
    secondaryHouses: [8, 6],
    karakas: ['Saturn'],
    sahamKey: 'artha',
    source: { text: SOURCES.BPHS, area: '12th house (expenditure/loss) + 8th (sudden loss) + Saturn affliction principles' }
  },

  // ===== Addiction (kept beyond the requested 25 -- already built, validated) =====
  addiction: {
    label: 'Addiction / Loss of Control',
    domainType: 'affliction',
    houses: [12],
    secondaryHouses: [6],
    karakas: ['Rahu', 'Moon'],
    source: { text: SOURCES.PVR, area: 'Vyasana (vice/addiction) via 12th/6th-house affliction + Saturn-Rahu pattern -- a modern-practice convention, not a single named core-BPHS yoga' }
  },

  // ===== Children =====
  children: {
    label: 'Children / Childbirth',
    domainType: 'growth',
    houses: [5],
    secondaryHouses: [9, 11],
    karakas: ['Jupiter'],
    source: { text: SOURCES.BPHS, area: '5th house & Putra-karaka (Jupiter) principles' }
  }
};

const SENSITIVITY_NOTE = 'Domains flagged extremeSensitivity (death-related) reflect classical signficator-affliction patterns in the BROADEST sense, never a literal death-timing prediction. Classical Jyotish treats literal mortality timing with extreme caution even in dedicated longevity analysis; this tool does not and should not be used to make confident claims about anyone\'s death.';

/**
 * Determine functional nature label for a planet, if available, used to
 * weight whether its placement is "favorable" context.
 */
function functionalTone(planet, functionalNature) {
  const c = functionalNature?.classifications?.[planet];
  if (!c) return null;
  if (c.isYogakaraka || c.classification === 'Functional Benefic') return 'favorable';
  if (c.classification === 'Functional Malefic' || c.classification === 'Mild Functional Malefic') return 'unfavorable';
  return 'neutral';
}

/**
 * Evaluate ONE event category's promise for this chart.
 */
function evaluatePromise(eventKey, chart) {
  const def = EVENT_DEFINITIONS[eventKey];
  if (!def) return { _warning: `Unknown event category: ${eventKey}` };

  const { bodies, analysis } = chart;
  const indicators = [];

  // --- Indicator 1: house lord placement ---
  // NOTE on polarity for 'affliction' domains (disease, addiction): a
  // STRONG, well-placed lord of the 6th/12th house is classically read as
  // the native's capacity to OVERCOME that house's struggles (disease,
  // debt, loss) — i.e. PROTECTIVE — not as "more affliction." This is the
  // opposite direction from 'growth' domains, where a strong house-lord
  // directly supports the event. Polarity is flipped accordingly below.
  const primaryHouse = def.houses[0];
  const lordEntry = Object.entries(analysis.functionalNature?.classifications || {})
    .find(([, c]) => c.housesRuled?.includes(primaryHouse));
  if (lordEntry) {
    const [lordPlanet, lordClass] = lordEntry;
    const lordBody = bodies[lordPlanet];
    const dignity = analysis.dignity?.classifications?.[lordPlanet]?.tier;
    const strong = ['Exalted', 'Moolatrikona', 'Own Sign (Swakshetra)'].includes(dignity)
      || [1, 4, 5, 7, 9, 10, 11].includes(lordBody?.house);
    const isAffliction = def.domainType === 'affliction';
    const polarity = isAffliction
      ? (strong ? 'weakens' : 'supports') // strong lord = protective = weakens the affliction-promise
      : (strong ? 'supports' : 'weakens');
    indicators.push({
      type: 'houseLord',
      planet: lordPlanet,
      detail: `${ordinal(primaryHouse)} lord ${lordPlanet} is ${dignity || 'placed'} in house ${lordBody?.house} (functional nature: ${lordClass.classification})${isAffliction ? ' — a strong lord here is read as protective capacity, not increased affliction' : ''}`,
      polarity,
      source: { text: SOURCES.BPHS, area: `${ordinal(primaryHouse)} lord placement principle` }
    });
  }

  // --- Indicator 2: karaka(s) strength/placement ---
  // Karaka dignity measures how strongly that planet expresses ITS OWN
  // significations — for affliction domains the chosen karakas (e.g.
  // Saturn/Mars for disease) ARE the afflicting agent, so a strong,
  // well-dignified karaka still reads as "supports" (it expresses its
  // nature, including difficult significations, more forcefully) — same
  // direction as growth domains, unlike the house-lord case above.
  const isAfflictionDomain = def.domainType === 'affliction';
  for (const karaka of def.karakas) {
    const kBody = bodies[karaka];
    if (!kBody) continue;
    const dignity = analysis.dignity?.classifications?.[karaka]?.tier;
    const favorable = ['Exalted', 'Moolatrikona', 'Own Sign (Swakshetra)', "Friend's Sign"].includes(dignity);
    indicators.push({
      type: 'karaka',
      planet: karaka,
      detail: `Karaka ${karaka} is ${dignity || 'placed'} in house ${kBody.house}${isAfflictionDomain ? ' — strength here means this karaka expresses its (difficult) significations more forcefully' : ''}`,
      polarity: favorable ? 'supports' : (dignity === 'Debilitated' || dignity === "Enemy's Sign" ? 'weakens' : 'neutral'),
      source: def.source
    });
  }

  // --- Indicator 3: occupants of primary house (real grahas only — excludes
  // special points like Hora Lagna, Varnada Lagna, upagrahas) ---
  // For 'affliction' domains, malefic occupants SUPPORT the affliction-
  // promise (vulnerability) and benefics are protective — the reverse of
  // 'growth' domains, where benefics support the (positive) event.
  const occupants = REAL_PLANETS.filter(p => bodies[p]?.house === primaryHouse);
  if (occupants.length > 0) {
    const benefics = occupants.filter(p => ['Jupiter', 'Venus', 'Mercury', 'Moon'].includes(p));
    const malefics = occupants.filter(p => ['Saturn', 'Mars', 'Sun', 'Rahu', 'Ketu'].includes(p));
    indicators.push({
      type: 'occupancy',
      detail: `House ${primaryHouse} is occupied by: ${occupants.join(', ')}`,
      polarity: beneficMalefiPolarity(benefics.length, malefics.length, isAfflictionDomain),
      source: { text: SOURCES.BPHS, area: 'Benefic/malefic occupancy principle' }
    });
  }

  // --- Indicator 4: aspects on primary house ---
  const aspectingPlanets = [];
  for (const [planet, data] of Object.entries(analysis.aspects?.outgoing || {})) {
    if (data.housesAspected?.includes(primaryHouse)) aspectingPlanets.push(planet);
  }
  if (aspectingPlanets.length > 0) {
    const benefics = aspectingPlanets.filter(p => ['Jupiter', 'Venus', 'Mercury', 'Moon'].includes(p));
    const malefics = aspectingPlanets.filter(p => ['Saturn', 'Mars', 'Sun', 'Rahu', 'Ketu'].includes(p));
    indicators.push({
      type: 'aspect',
      detail: `House ${primaryHouse} is aspected by: ${aspectingPlanets.join(', ')}`,
      polarity: beneficMalefiPolarity(benefics.length, malefics.length, isAfflictionDomain),
      source: { text: SOURCES.BPHS, area: 'Graha Drishti on bhava principle' }
    });
  }

  // --- Indicator 5b: Saham, where one is defined for this domain ---
  if (def.sahamKey && analysis.sahams?.sahams?.[def.sahamKey]) {
    const saham = analysis.sahams.sahams[def.sahamKey];
    if (!saham._warning) {
      const sahamLordEntry = Object.entries(analysis.functionalNature?.classifications || {})
        .find(([, c]) => c.housesRuled?.includes(saham.house));
      const inTargetHouse = [...def.houses, ...(def.secondaryHouses || [])].includes(saham.house);
      indicators.push({
        type: 'saham',
        detail: `${saham.name} falls in house ${saham.house} (${saham.sign})${inTargetHouse ? ' — directly in this event\'s house group' : ''}`,
        polarity: inTargetHouse ? 'supports' : 'neutral',
        source: saham.source
      });
    }
  }

  // --- Indicator 5: secondary houses' lords connection (lighter weight) ---
  for (const secHouse of def.secondaryHouses || []) {
    const secLordEntry = Object.entries(analysis.functionalNature?.classifications || {})
      .find(([, c]) => c.housesRuled?.includes(secHouse));
    if (!secLordEntry) continue;
    const [secLord] = secLordEntry;
    const secLordBody = bodies[secLord];
    if (secLordBody?.house === primaryHouse || def.houses.includes(secLordBody?.house)) {
      indicators.push({
        type: 'secondaryConnection',
        planet: secLord,
        detail: `${ordinal(secHouse)} lord ${secLord} connects into house ${secLordBody.house}, linking ${ordinal(secHouse)}-house themes to this event`,
        polarity: 'supports',
        source: { text: SOURCES.BPHS, area: 'Secondary house-lord connection principle' }
      });
    }
  }

  const supports = indicators.filter(i => i.polarity === 'supports').length;
  const weakens = indicators.filter(i => i.polarity === 'weakens').length;

  const genericNote = def.domainType === 'affliction'
    ? 'This is a structured checklist of classical indicators, not a verdict. For this domain, "supports" means supports VULNERABILITY (a risk-flag), and "weakens" means PROTECTIVE — read polarity carefully, it is reversed from growth domains like career or marriage.'
    : 'This is a structured checklist of classical indicators, not a verdict. See indicators for what supports vs. weakens the promise, each independently sourced.';

  return {
    event: eventKey,
    label: def.label,
    domainType: def.domainType || 'growth',
    extremeSensitivity: def.extremeSensitivity || false,
    primaryHouse,
    indicators,
    supportCount: supports,
    weakenCount: weakens,
    neutralCount: indicators.length - supports - weakens,
    note: def.note ? genericNote + ' ' + def.note : genericNote
  };
}

/**
 * For 'growth' domains, more benefics than malefics = supports (the event
 * is helped). For 'affliction' domains, this is REVERSED: more malefics
 * supports the affliction-promise (vulnerability), more benefics weakens
 * it (protective).
 */
function beneficMalefiPolarity(beneficCount, maleficCount, isAfflictionDomain) {
  if (beneficCount === maleficCount) return 'neutral';
  const beneficsWin = beneficCount > maleficCount;
  if (isAfflictionDomain) {
    return beneficsWin ? 'weakens' : 'supports';
  }
  return beneficsWin ? 'supports' : 'weakens';
}

/**
 * EDUCATION PATH CLASSIFICATION
 *
 * Goes beyond the basic "is education promised" checklist (evaluatePromise
 * with 'education') to suggest WHICH BROAD PATH the chart leans toward:
 * Academic/Higher-Education, Skill-Based/Vocational (e.g. trades like
 * carpentry, farming, plumbing), Commerce/Trade, or a Disruption/Break
 * tendency.
 *
 * ============================ HONESTY CAVEAT ============================
 * This is MORE INTERPRETIVE than the standard promise checklist. Classical
 * BPHS does not enumerate "carpentry" or "plumbing" as named categories —
 * those are PVR-style modern synthesis from broader house/planet
 * significations (4th=land/property and Mars' rulership of land/tools;
 * 6th=service/labor; Saturn=discipline/manual labor; Mercury=trade/
 * commerce). Every leaning here is shown as a TENDENCY with its
 * supporting indicators, at 'interpretive' or 'synthesized' confidence —
 * NEVER as "this person should become a carpenter." The chart can show
 * multiple leanings at once, or none clearly — both are reported plainly.
 * =========================================================================
 */
function classifyEducationPath(chart) {
  const { bodies, analysis } = chart;
  const fn = analysis.functionalNature?.classifications || {};
  const dig = analysis.dignity?.classifications || {};

  function lordOfHouse(houseNum) {
    const entry = Object.entries(fn).find(([, c]) => c.housesRuled?.includes(houseNum));
    return entry ? entry[0] : null;
  }
  function isStrong(planet) {
    const tier = dig[planet]?.tier;
    if (['Exalted', 'Moolatrikona', 'Own Sign (Swakshetra)'].includes(tier)) return true;
    const house = bodies[planet]?.house;
    return [1, 4, 5, 7, 9, 10, 11].includes(house);
  }
  function weaknessReason(planet) {
    const tier = dig[planet]?.tier;
    if (['Debilitated', "Enemy's Sign"].includes(tier)) return `${tier} (dignity)`;
    const house = bodies[planet]?.house;
    if ([6, 8, 12].includes(house)) return `placed in Dusthana house ${house}`;
    return null;
  }
  function isWeak(planet) {
    return weaknessReason(planet) !== null;
  }

  const ninthLord = lordOfHouse(9);
  const sixthLord = lordOfHouse(6);
  const fourthLord = lordOfHouse(4);
  const jupiter = 'Jupiter', mercury = 'Mercury', mars = 'Mars', saturn = 'Saturn';

  const leanings = [];

  // --- Academic / Higher Education leaning ---
  {
    const indicators = [];
    if (isStrong(jupiter)) indicators.push(`Jupiter (wisdom/scholarship significator) is well-placed (house ${bodies.Jupiter?.house})`);
    if (ninthLord && isStrong(ninthLord)) indicators.push(`9th lord ${ninthLord} (higher-education house) is well-placed`);
    if (isStrong(mercury) && !isWeak(mercury)) indicators.push(`Mercury (intellect) is well-placed and unafflicted`);
    if (indicators.length >= 2) {
      leanings.push({
        path: 'Academic / Higher Education',
        indicators,
        confidence: 'interpretive',
        source: { text: SOURCES.BPHS, area: '9th house + Jupiter (scholarship) principles' }
      });
    }
  }

  // --- Skill-Based / Vocational leaning (trades: farming, carpentry, plumbing, manual/technical work) ---
  {
    const indicators = [];
    const sixthStrong = sixthLord && isStrong(sixthLord);
    const ninthLordWeakness = ninthLord ? weaknessReason(ninthLord) : null;
    const mercuryWeakness = weaknessReason(mercury);
    if (sixthStrong) indicators.push(`6th lord ${sixthLord} (service/skill/labor house) is well-placed — favors hands-on, skill-based work`);
    if (ninthLordWeakness) indicators.push(`9th lord ${ninthLord} (higher education) is ${ninthLordWeakness} — leans away from prolonged formal academics`);
    if (mercuryWeakness) indicators.push(`Mercury (formal intellect/study) is ${mercuryWeakness} — leans away from prolonged formal academics`);
    if (isStrong(mars)) indicators.push(`Mars (land, tools, physical work, construction) is well-placed — consistent with trades like construction, farming, or technical/manual work`);
    if (isStrong(saturn)) indicators.push(`Saturn (discipline, systematic labor, structure) is well-placed — consistent with disciplined trade work (e.g. skilled labor, plumbing-type structured technical trades)`);
    if (indicators.length >= 2) {
      leanings.push({
        path: 'Skill-Based / Vocational (e.g. trades, technical, hands-on work)',
        indicators,
        confidence: 'synthesized',
        source: { text: SOURCES.PVR, area: '6th house (service/skill) + Mars/Saturn significations — modern synthesis, not a single named classical yoga' }
      });
    }
  }

  // --- Commerce / Trade leaning ---
  {
    const indicators = [];
    if (isStrong(mercury) && [2, 3, 10, 11].includes(bodies.Mercury?.house)) {
      indicators.push(`Mercury (trade/commerce) is well-placed in house ${bodies.Mercury.house} — favors business/trade-oriented learning over pure academics`);
    }
    if (fourthLord && [2, 10, 11].includes(bodies[fourthLord]?.house)) {
      indicators.push(`4th lord ${fourthLord} connects into a wealth/career house — education may be commercially/practically oriented`);
    }
    if (indicators.length >= 1) {
      leanings.push({
        path: 'Commerce / Trade-Oriented',
        indicators,
        confidence: 'synthesized',
        source: { text: SOURCES.PVR, area: 'Mercury (commerce) house-placement synthesis' }
      });
    }
  }

  // --- Disruption / Break tendency ---
  {
    const indicators = [];
    if (fourthLord) {
      const reason = weaknessReason(fourthLord);
      if (reason) indicators.push(`4th lord ${fourthLord} (basic education) is ${reason} — suggests possible interruption`);
    }
    if (ninthLord) {
      const reason = weaknessReason(ninthLord);
      if (reason) indicators.push(`9th lord ${ninthLord} (higher education) is ${reason} — suggests possible interruption at the higher-education stage`);
    }
    const eighthLord = lordOfHouse(8);
    if (eighthLord && bodies[eighthLord]?.house === 4) indicators.push(`8th lord ${eighthLord} (disruption) is placed in the 4th house — a classical break/disruption signature for education`);
    if (indicators.length >= 1) {
      leanings.push({
        path: 'Possible Disruption / Break Tendency',
        indicators,
        confidence: 'interpretive',
        source: { text: SOURCES.BPHS, area: 'Weak/afflicted education-house-lord disruption principle' }
      });
    }
  }

  return {
    leanings,
    note: 'These are TENDENCIES suggested by broad house/planet significations, not predictions of a specific job or trade. Classical texts do not name "carpentry" or "plumbing" specifically — the Skill-Based/Vocational and Commerce leanings are modern synthesis (PVR-style) from house significations, flagged at lower confidence than core BPHS promise indicators. A chart may show several leanings at once, reflecting real complexity rather than a single clean answer; timing of WHICH path is active in which life period is a separate (dasha-based) question.'
  };
}

/**
 * CAREER PATH CLASSIFICATION
 *
 * Goes beyond the basic "is career success promised" checklist to suggest
 * WHICH BROAD CAREER ORIENTATION the chart leans toward: Government/
 * Authority, Business/Entrepreneurship, Technical/Engineering, Creative/
 * Arts, Service/Healing, or Defense/Discipline-Based.
 *
 * ============================ HONESTY CAVEAT ============================
 * This is interpretive synthesis from house/planet significations and
 * documented case patterns (e.g. Moon connected to 10th house appearing
 * in pediatrician charts, Mars+6th-lord in surgeon charts) — it is NOT a
 * lookup table claiming "Mars = surgeon." These are broad orientations,
 * not specific job titles, and a chart can show several at once. A full
 * classical reading would also examine D10 (Dasamsa, the career-specific
 * divisional chart) in detail — this module works from D1 only, which
 * this tool's predictive engine is built on throughout; D10-based
 * refinement is a known scope limitation, not a hidden claim of D10
 * analysis.
 * =========================================================================
 */
function classifyCareerPath(chart) {
  const { bodies, analysis } = chart;
  const fn = analysis.functionalNature?.classifications || {};
  const dig = analysis.dignity?.classifications || {};

  function lordOfHouse(houseNum) {
    const entry = Object.entries(fn).find(([, c]) => c.housesRuled?.includes(houseNum));
    return entry ? entry[0] : null;
  }
  function isStrong(planet) {
    const tier = dig[planet]?.tier;
    if (['Exalted', 'Moolatrikona', 'Own Sign (Swakshetra)'].includes(tier)) return true;
    return [1, 4, 5, 7, 9, 10, 11].includes(bodies[planet]?.house);
  }
  function conjunct(p1, p2) {
    return bodies[p1]?.house && bodies[p1].house === bodies[p2]?.house;
  }

  const tenthLord = lordOfHouse(10);
  const ninthLord = lordOfHouse(9);
  const sixthLord = lordOfHouse(6);
  const seventhLord = lordOfHouse(7);
  const leanings = [];

  // --- Government / Authority / Leadership ---
  {
    const indicators = [];
    if (isStrong('Sun')) indicators.push(`Sun (authority, government, leadership) is well-placed`);
    if (tenthLord === 'Sun' || conjunct('Sun', tenthLord)) indicators.push(`Sun is connected to the 10th house (career) directly`);
    if (indicators.length >= 1) {
      leanings.push({ path: 'Government / Authority / Leadership Roles', indicators, confidence: 'interpretive',
        source: { text: SOURCES.BPHS, area: 'Sun as karaka for authority/government, 10th house principles' } });
    }
  }

  // --- Business / Entrepreneurship (vs. service/employment) ---
  {
    const indicators = [];
    if (ninthLord && bodies[ninthLord]?.house === 1) indicators.push(`9th lord ${ninthLord} is in the Lagna — classically associated with an independent, "own boss" orientation rather than working under others`);
    if (seventhLord && (bodies[seventhLord]?.house === 10 || conjunct(seventhLord, 'Mars'))) indicators.push(`7th lord (partnerships/business) connects to career matters or Mars (enterprise) — favors business/partnership over pure service`);
    if (isStrong('Mercury') && isStrong('Mars') && conjunct('Mercury', 'Mars')) indicators.push(`Mercury (trade) and Mars (enterprise) are conjunct and well-placed — a documented pattern for business orientation`);
    if (indicators.length >= 1) {
      leanings.push({ path: 'Business / Entrepreneurship', indicators, confidence: 'interpretive',
        source: { text: SOURCES.PVR, area: '9th-lord-in-Lagna independence pattern; Mercury-Mars business combination' } });
    }
  }

  // --- Service / Employment orientation (the complement to business) ---
  {
    const indicators = [];
    if (sixthLord && isStrong(sixthLord)) indicators.push(`6th lord ${sixthLord} (service) is well-placed — favors structured employment over independent business`);
    if (isStrong('Saturn') && (tenthLord === 'Saturn' || conjunct('Saturn', tenthLord))) indicators.push(`Saturn (discipline, structured work) is well-placed and connected to career — favors stable, long-term employment`);
    if (indicators.length >= 1) {
      leanings.push({ path: 'Structured Service / Employment', indicators, confidence: 'interpretive',
        source: { text: SOURCES.BPHS, area: '6th house (service) + Saturn as karaka for structured labor' } });
    }
  }

  // --- Technical / Engineering / Hands-on-skill ---
  {
    const indicators = [];
    if (conjunct('Mercury', 'Mars') || conjunct('Mercury', 'Saturn')) indicators.push(`Mercury (intellect/precision) is conjunct Mars or Saturn — a combination consistent with technical/engineering work`);
    if (isStrong('Rahu') && [10, 6, 3].includes(bodies.Rahu?.house)) indicators.push(`Rahu (modern technology, unconventional skill) is placed in house ${bodies.Rahu.house} — consistent with technical/modern-field orientation`);
    if (indicators.length >= 1) {
      leanings.push({ path: 'Technical / Engineering', indicators, confidence: 'synthesized',
        source: { text: SOURCES.PVR, area: 'Mercury-Mars/Saturn precision combination; Rahu as modern-technology signifier (modern convention)' } });
    }
  }

  // --- Creative / Arts ---
  {
    const indicators = [];
    if (isStrong('Venus') && [5, 10].includes(bodies.Venus?.house)) indicators.push(`Venus (arts, aesthetics) is well-placed in house ${bodies.Venus.house} — favors creative/artistic fields`);
    const fifthLord = lordOfHouse(5);
    if (fifthLord && bodies[fifthLord]?.house === 10) indicators.push(`5th lord ${fifthLord} (creativity) connects into the 10th house (career)`);
    if (indicators.length >= 1) {
      leanings.push({ path: 'Creative / Arts-Oriented', indicators, confidence: 'interpretive',
        source: { text: SOURCES.BPHS, area: 'Venus as karaka for arts; 5th-10th house connection' } });
    }
  }

  // --- Service / Healing (medicine, counseling) ---
  {
    const indicators = [];
    if (sixthLord && conjunct(sixthLord, 'Mars')) indicators.push(`6th lord ${sixthLord} is conjunct Mars — a documented pattern in surgeon/medical-field charts (precision + service combination)`);
    if (bodies.Moon?.house === 10) indicators.push(`Moon is in the 10th house — a documented pattern in charts involving care for others (e.g. pediatric/nurturing professions)`);
    if (isStrong('Jupiter') && sixthLord === 'Jupiter') indicators.push(`Jupiter (healing wisdom) rules the 6th house (service) and is well-placed`);
    if (indicators.length >= 1) {
      leanings.push({ path: 'Healing / Counseling / Caregiving Professions', indicators, confidence: 'synthesized',
        source: { text: SOURCES.PVR, area: 'Documented case patterns (Mars+6th-lord for surgeons; Moon-in-10th for child-focused care professions) — not a single named classical yoga' } });
    }
  }

  // --- Defense / Discipline-Based / High-Stakes Competitive Fields ---
  {
    const indicators = [];
    if (bodies.Mars?.house === 10 && isStrong('Mars')) indicators.push(`Mars is strong in the 10th house — classically associated with command/leadership in disciplined, high-stakes fields (defense, sports, surgery)`);
    if (bodies.Ketu?.house === 10) indicators.push(`Ketu is in the 10th house — in documented chart patterns this combination has appeared with disciplined/regimented career structures`);
    if (indicators.length >= 1) {
      leanings.push({ path: 'Defense / Discipline-Based / High-Stakes Competitive Fields', indicators, confidence: 'synthesized',
        source: { text: SOURCES.PVR, area: 'Mars/Ketu-in-10th documented case patterns — modern synthesis, not a core-BPHS-named yoga' } });
    }
  }

  return {
    leanings,
    note: 'These are BROAD CAREER ORIENTATIONS suggested by D1 house/planet patterns, not specific job titles. A complete classical reading would also examine D10 (Dasamsa) in detail, which this module does not do (the predictive engine throughout this tool works from D1). Several leanings can apply at once.'
  };
}

/**
 * FOREIGN TRAVEL / RELOCATION PATH CLASSIFICATION
 *
 * Distinguishes intensity/type: short business/study travel, long-term
 * settlement abroad, or foreign-linked career/education (without
 * necessarily physical relocation) — versus the basic Foreign Travel
 * promise checklist, which only asks "is foreign connection indicated
 * at all."
 *
 * Classical basis (from this tool's reference material, PVR's case
 * notes): "9th and 12th houses are the important houses to see foreign
 * travel. Even Badhakesha can show foreign travel." This module builds
 * directly on that documented principle.
 * =========================================================================
 */
function classifyForeignPath(chart) {
  const { bodies, analysis } = chart;
  const fn = analysis.functionalNature?.classifications || {};

  function lordOfHouse(houseNum) {
    const entry = Object.entries(fn).find(([, c]) => c.housesRuled?.includes(houseNum));
    return entry ? entry[0] : null;
  }

  const ninthLord = lordOfHouse(9);
  const twelfthLord = lordOfHouse(12);
  const badhakesh = Object.entries(fn).find(([, c]) => c.isBadhakesh)?.[0];
  const leanings = [];

  // --- Short-term travel (business/study trips, not relocation) ---
  {
    const indicators = [];
    const thirdLord = lordOfHouse(3);
    if (thirdLord && bodies[thirdLord]?.house === 9) indicators.push(`3rd lord ${thirdLord} (short travel) connects into the 9th house (long journeys) — favors trips rather than permanent relocation`);
    if (bodies.Mercury?.house === 9 || bodies.Mercury?.house === 3) indicators.push(`Mercury (short-distance movement, communication) is placed in a travel-related house`);
    if (indicators.length >= 1) {
      leanings.push({ path: 'Short-Term Foreign Travel (business/study trips)', indicators, confidence: 'interpretive',
        source: { text: SOURCES.BPHS, area: '3rd house (short travel) + 9th house (long journeys) connection' } });
    }
  }

  // --- Long-term settlement / relocation ---
  {
    const indicators = [];
    if (twelfthLord && [9, 12].includes(bodies[twelfthLord]?.house)) indicators.push(`12th lord ${twelfthLord} (foreign residence) is itself placed in a foreign-linked house — supports longer-term residence abroad, not just travel`);
    const fourthLord = lordOfHouse(4);
    if (fourthLord) {
      const tier = analysis.dignity?.classifications?.[fourthLord]?.tier;
      if (['Debilitated', "Enemy's Sign"].includes(tier) || [6, 8, 12].includes(bodies[fourthLord]?.house)) {
        indicators.push(`4th lord ${fourthLord} (motherland, roots) is weak or in a Dusthana — classically read as reduced attachment to the native land, supporting relocation`);
      }
    }
    if (bodies.Rahu?.house === 12 || bodies.Rahu?.house === 9) indicators.push(`Rahu (modern foreign-connection signifier) is in house ${bodies.Rahu.house}`);
    if (indicators.length >= 1) {
      leanings.push({ path: 'Long-Term Settlement / Relocation Abroad', indicators, confidence: 'interpretive',
        source: { text: SOURCES.PVR, area: '12th-lord-in-foreign-house + weak 4th-lord (reduced motherland attachment) pattern' } });
    }
  }

  // --- Foreign-linked career/education (without necessarily relocating) ---
  {
    const indicators = [];
    if (ninthLord && twelfthLord && bodies[ninthLord]?.house === bodies[twelfthLord]?.house) {
      indicators.push(`9th lord ${ninthLord} and 12th lord ${twelfthLord} are conjunct — both foreign-connection houses linked together, a documented pattern for foreign-flavored career/education`);
    }
    if (ninthLord === 'Jupiter' || twelfthLord === 'Jupiter') indicators.push(`Jupiter (higher learning, prosperity abroad) rules a foreign-connection house`);
    if (indicators.length >= 1) {
      leanings.push({ path: 'Foreign-Linked Career or Education', indicators, confidence: 'interpretive',
        source: { text: SOURCES.PVR, area: '9th-12th lord connection pattern (documented in case analysis: "Jupiter owns 9th and 12th... can certainly take him abroad")' } });
    }
  }

  // --- Badhakesh involvement (documented as a foreign-travel indicator) ---
  if (badhakesh) {
    leanings.push({
      path: 'Badhakesh-Linked Foreign Connection',
      indicators: [`${badhakesh} is the Badhakesh (obstacle-house lord) — documented as a contributing foreign-travel indicator independent of the 9th/12th houses`],
      confidence: 'interpretive',
      source: { text: SOURCES.PVR, area: '"Even Badhakesha can show foreign travel" — documented case principle' }
    });
  }

  return {
    leanings,
    note: 'These distinguish the TYPE/INTENSITY of foreign connection (short trip vs. long-term settlement vs. foreign-linked career/education) beyond the basic promise checklist. Several can apply together — e.g. a chart might show both early short-term travel and a later long-term settlement tendency, which the Dasha-Activation layer (not this static classification) would help separate by timing.'
  };
}

function ordinal(n) {
  return { 1: '1st', 2: '2nd', 3: '3rd', 4: '4th', 5: '5th', 6: '6th', 7: '7th', 8: '8th', 9: '9th', 10: '10th', 11: '11th', 12: '12th' }[n] || `${n}th`;
}

/**
 * Evaluate ALL defined event categories for this chart.
 */
function evaluateAllPromises(chart) {
  const result = {};
  for (const key of Object.keys(EVENT_DEFINITIONS)) {
    result[key] = evaluatePromise(key, chart);
  }
  return result;
}

module.exports = { evaluatePromise, evaluateAllPromises, EVENT_DEFINITIONS, classifyEducationPath, classifyCareerPath, classifyForeignPath };
