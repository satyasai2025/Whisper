/**
 * Chart Diagram Extractor (v3 — backward line-scan + glued-token splitting)
 *
 * TWO KEY FIXES over v1:
 *
 * 1. BOUNDARY DETECTION: Chart diagrams are NOT simply "the text between
 *    two consecutive 'Natal Chart X' anchors" — that span can swallow
 *    entire dasha tables sitting between two charts in the PDF (e.g. D9's
 *    diagram is on page 1, but D10's anchor is on page 9, with 7 pages of
 *    dasha tables in between). FIX: scan BACKWARD from each anchor,
 *    collecting only lines that are diagram-valid, stopping at the first
 *    line that isn't (a date, a word, a quoted minute/second, etc.).
 *
 * 2. GLUED TOKENS: pdf-parse sometimes drops the space between adjacent
 *    arudha/special-point codes — e.g. "A10A11" instead of "A10 A11",
 *    "A8UL" instead of "A8 UL", "VeRa" instead of "Ve Ra". A naive
 *    whitespace split treats these as one invalid token, which (combined
 *    with fix #1) prematurely truncates the backward scan. FIX: any
 *    whitespace-delimited token that doesn't directly match a known code
 *    is run through a greedy sub-tokenizer that tries to decompose it into
 *    a sequence of valid codes before declaring the line invalid.
 */

const { SIGN_INDEX } = require('../utils/constants');

// A single valid diagram content code
const CODE_UNIT = '(?:A(?:1[0-2]|[1-9])|AL|UL|GL|HL|BB|SL|PP|Md|Gk|As|Su|Mo|Ma|Me|Ju|Ve|Sa|Ra|Ke|Ur|Ne|Pl)';
const CONTENT_TOKEN = new RegExp(`^${CODE_UNIT}$`);
const CODE_UNIT_RE = new RegExp(`^${CODE_UNIT}`);

function isHouseMarker(token) {
  const num = parseInt(token, 10);
  return Number.isInteger(num) && num >= 1 && num <= 12 && String(num) === token;
}

/**
 * Try to decompose a glued token (e.g. "A10A11", "VeRa") into a sequence
 * of valid diagram codes. Returns an array of codes, or null if the
 * token can't be fully consumed (meaning it's not actually diagram content).
 */
function splitGluedToken(token) {
  const result = [];
  let rest = token;
  while (rest.length > 0) {
    const m = CODE_UNIT_RE.exec(rest);
    if (!m) return null;
    result.push(m[0]);
    rest = rest.slice(m[0].length);
  }
  return result.length > 0 ? result : null;
}

/**
 * Tokenize one line into diagram tokens. Returns an array of
 * { type: 'marker'|'content', value } or null if the line is NOT
 * a valid diagram line (i.e. contains something that isn't a house
 * marker or a (possibly glued) content code).
 */
function tokenizeDiagramLine(line) {
  const rawTokens = line.split(/\s+/).filter(Boolean);
  if (rawTokens.length === 0) return [];

  const out = [];
  for (const raw of rawTokens) {
    if (isHouseMarker(raw)) {
      out.push({ type: 'marker', value: parseInt(raw, 10) });
      continue;
    }
    if (CONTENT_TOKEN.test(raw)) {
      out.push({ type: 'content', value: raw });
      continue;
    }
    // Try glued-token decomposition
    const split = splitGluedToken(raw);
    if (split) {
      for (const code of split) out.push({ type: 'content', value: code });
      continue;
    }
    // Token doesn't resolve — line is not a diagram line
    return null;
  }
  return out;
}

const CHART_ANCHOR_DEFS = [
  { key: 'd1',  pattern: /Natal Chart\s*Rasi/ },
  { key: 'd2',  pattern: /Natal Chart\s*D-2\b/ },
  { key: 'd3',  pattern: /Natal Chart\s*D-3\b/ },
  { key: 'd4',  pattern: /Natal Chart\s*D-4\b/ },
  { key: 'd5',  pattern: /Natal Chart\s*D-5\b/ },
  { key: 'd6',  pattern: /Natal Chart\s*D-6\b/ },
  { key: 'd7',  pattern: /Natal Chart\s*D-7\b/ },
  { key: 'd8',  pattern: /Natal Chart\s*D-8\b/ },
  { key: 'd9',  pattern: /Natal Chart\s*D-9\b/ },
  { key: 'd10', pattern: /Natal Chart\s*D-10\b/ },
  { key: 'd11', pattern: /Natal Chart\s*D-11\b/ },
  { key: 'd12', pattern: /Natal Chart\s*D-12\b/ },
  { key: 'd16', pattern: /Natal Chart\s*D-16\b/ },
  { key: 'd20', pattern: /Natal Chart\s*D-20\b/ },
  { key: 'd24', pattern: /Natal Chart\s*D-24\b/ },
  { key: 'd27', pattern: /Natal Chart\s*D-27\b/ },
  { key: 'd30', pattern: /Natal Chart\s*D-30\b/ },
  { key: 'd40', pattern: /Natal Chart\s*D-40\b/ },
  { key: 'd45', pattern: /Natal Chart\s*D-45\b/ },
  { key: 'd60', pattern: /Natal Chart\s*D-60\b/ }
];

function extractAllChartsFromText(rawText) {
  const lines = rawText.split('\n');

  const lineStartOffsets = [];
  let offset = 0;
  for (const line of lines) {
    lineStartOffsets.push(offset);
    offset += line.length + 1;
  }

  function lineIndexForOffset(charPos) {
    let lo = 0, hi = lineStartOffsets.length - 1, ans = 0;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      if (lineStartOffsets[mid] <= charPos) { ans = mid; lo = mid + 1; }
      else hi = mid - 1;
    }
    return ans;
  }

  const found = [];
  for (const { key, pattern } of CHART_ANCHOR_DEFS) {
    const m = pattern.exec(rawText);
    if (m) found.push({ key, lineIndex: lineIndexForOffset(m.index) });
  }
  found.sort((a, b) => a.lineIndex - b.lineIndex);

  const charts = {};
  for (const { key, lineIndex } of found) {
    const tokenLines = [];
    let i = lineIndex - 1;
    while (i >= 0) {
      const trimmed = lines[i].trim();
      if (trimmed === '') { i--; continue; }
      const tokens = tokenizeDiagramLine(trimmed);
      if (tokens === null) break;
      tokenLines.unshift(tokens);
      i--;
    }
    charts[key] = parseTokenLines(tokenLines);
  }

  return charts;
}

function parseTokenLines(tokenLines) {
  const signSlots = {};
  for (let i = 1; i <= 12; i++) signSlots[i] = [];

  let currentSlot = null;
  for (const tokens of tokenLines) {
    for (const tok of tokens) {
      if (tok.type === 'marker') {
        currentSlot = tok.value;
      } else if (currentSlot !== null) {
        signSlots[currentSlot].push(tok.value);
      }
    }
  }
  return { signSlots };
}

function signSlotsToHouses(signSlots, lagnaSignIndex) {
  const houses = {};
  for (let i = 1; i <= 12; i++) houses[i] = [];

  for (let slot = 1; slot <= 12; slot++) {
    const signIndex = slot - 1;
    const house = ((signIndex - lagnaSignIndex + 12) % 12) + 1;
    for (const occupant of signSlots[slot]) {
      houses[house].push(occupant);
    }
  }
  return { houses, lagnaSignIndex };
}

function findLagnaInSlots(signSlots) {
  for (let slot = 1; slot <= 12; slot++) {
    if (signSlots[slot].includes('As')) return slot - 1;
  }
  return null;
}

module.exports = {
  extractAllChartsFromText,
  parseTokenLines,
  signSlotsToHouses,
  findLagnaInSlots,
  splitGluedToken,
  tokenizeDiagramLine
};
