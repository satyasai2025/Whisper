/**
 * Nakshatra Integration Module
 * 
 * Source: PVR Narasimha Rao "Vedic Astrology: An Integrated Approach"
 * Ch.1.3.5 — Nakshatras and their lords
 * Ch.4.1 — Nakshatra lord as secondary dasha significator
 * Ch.25 — Transit nakshatra analysis
 * 
 * Key principle (PVR p.67):
 *   "The nakshatra lord of a planet acts as a secondary significator
 *   during that planet's dasha period. If Sun is in Rohini (Moon's nakshatra),
 *   Moon also gets activated during Sun's dasha."
 */

'use strict';

// Sign codes for longitude computation
const SIGN_CODES_NK = ['Ar','Ta','Ge','Cn','Le','Vi','Li','Sc','Sg','Cp','Aq','Pi'];

/**
 * Get full sidereal longitude from body object.
 * bodies store longitudeInSign + signCode, not full sidereal longitude.
 */
function getFullLongitude(body) {
  if (!body) return null;
  if (body.siderealLongitude != null) return body.siderealLongitude;
  if (body.longitude != null && body.longitude > 0) return body.longitude;
  if (body.signCode && body.longitudeInSign != null) {
    const sigIdx = SIGN_CODES_NK.indexOf(body.signCode);
    if (sigIdx >= 0) return sigIdx * 30 + body.longitudeInSign;
  }
  return null;
}


const NAKSHATRAS = [
  { name:'Aswini',       lord:'Ketu',    startLon:0     },
  { name:'Bharani',      lord:'Venus',   startLon:13.33 },
  { name:'Krittika',     lord:'Sun',     startLon:26.67 },
  { name:'Rohini',       lord:'Moon',    startLon:40    },
  { name:'Mrigasira',    lord:'Mars',    startLon:53.33 },
  { name:'Aardra',       lord:'Rahu',    startLon:66.67 },
  { name:'Punarvasu',    lord:'Jupiter', startLon:80    },
  { name:'Pushyami',     lord:'Saturn',  startLon:93.33 },
  { name:'Asresha',      lord:'Mercury', startLon:106.67},
  { name:'Makha',        lord:'Ketu',    startLon:120   },
  { name:'Poorva Phalguni', lord:'Venus',startLon:133.33},
  { name:'Uttara Phalguni', lord:'Sun',  startLon:146.67},
  { name:'Hasta',        lord:'Moon',    startLon:160   },
  { name:'Chitra',       lord:'Mars',    startLon:173.33},
  { name:'Swaati',       lord:'Rahu',    startLon:186.67},
  { name:'Visaakha',     lord:'Jupiter', startLon:200   },
  { name:'Anooraadha',   lord:'Saturn',  startLon:213.33},
  { name:'Jyeshtha',     lord:'Mercury', startLon:226.67},
  { name:'Moola',        lord:'Ketu',    startLon:240   },
  { name:'Poorvaashaadha',lord:'Venus',  startLon:253.33},
  { name:'Uttaraashaadha',lord:'Sun',    startLon:266.67},
  { name:'Sravanam',     lord:'Moon',    startLon:280   },
  { name:'Dhanishtha',   lord:'Mars',    startLon:293.33},
  { name:'Satabhishak',  lord:'Rahu',    startLon:306.67},
  { name:'Poorvaabhaadra',lord:'Jupiter',startLon:320   },
  { name:'Uttaraabhaadra',lord:'Saturn', startLon:333.33},
  { name:'Revati',       lord:'Mercury', startLon:346.67},
];

const NAK_SPAN = 360 / 27; // 13.333°
const PADA_SPAN = NAK_SPAN / 4; // 3.333°

/**
 * Get nakshatra info from sidereal longitude
 */
function getNakshatra(lon) {
  const l = ((lon % 360) + 360) % 360;
  const idx = Math.min(Math.floor(l / NAK_SPAN), 26);
  const degInNak = l % NAK_SPAN;
  const pada = Math.floor(degInNak / PADA_SPAN) + 1;
  const nak = NAKSHATRAS[idx];
  return {
    index: idx,
    name: nak.name,
    lord: nak.lord,
    pada,
    degreeInNakshatra: degInNak,
    longitude: l
  };
}

/**
 * Get Nav Tara from natal Moon nakshatra to transit nakshatra
 * Source: PVR p.319, traditional Gochar text
 * 
 * Taras (9 cycle from natal Moon):
 * 1=Janma, 2=Sampath, 3=Vipat, 4=Kshema, 5=Pratyak,
 * 6=Sadhana, 7=Naidhana, 8=Mitra, 9=Param Mitra
 */
const TARA_NAMES    = ['Janma','Sampath','Vipat','Kshema','Pratyak','Sadhana','Naidhana','Mitra','Param Mitra'];
const TARA_QUALITY  = { Janma:'mixed', Sampath:'good', Vipat:'bad', Kshema:'good', Pratyak:'bad', Sadhana:'good', Naidhana:'bad', Mitra:'good', 'Param Mitra':'excellent' };
const TARA_SCORE    = { Janma:40, Sampath:80, Vipat:10, Kshema:75, Pratyak:15, Sadhana:70, Naidhana:5, Mitra:65, 'Param Mitra':90 };
const TARA_MEANING  = {
  Janma:       'Birth star — mental stress, avoid important decisions',
  Sampath:     'Wealth star — auspicious, financial gains possible',
  Vipat:       'Danger star — obstacles, avoid risky activities',
  Kshema:      'Wellbeing star — health and comfort favored',
  Pratyak:     'Obstacle star — hindrance, delays likely',
  Sadhana:     'Achievement star — success in efforts',
  Naidhana:    'Death star — very inauspicious, be cautious',
  Mitra:       'Friend star — positive results, helpful people',
  'Param Mitra': 'Best friend star — excellent results overall'
};

function getNavTara(moonNakIdx, transitNakIdx) {
  const count = ((transitNakIdx - moonNakIdx + 27) % 27);
  const name  = TARA_NAMES[count % 9];
  return {
    name,
    count: count + 1,
    quality:  TARA_QUALITY[name],
    score:    TARA_SCORE[name],
    meaning:  TARA_MEANING[name],
    isFavorable: ['Sampath','Kshema','Sadhana','Mitra','Param Mitra'].includes(name)
  };
}

// ── Nakshatra psychological profiles (for portrait) ───────────────────────────
const NAKSHATRA_PSYCHOLOGY = {
  Aswini:    { theme: 'speed, initiation, healing', nature: 'eager to begin, natural healer, can be hasty', shadow: 'impatience, starting without completing' },
  Bharani:   { theme: 'carrying burdens, transformation, birth-death', nature: 'responsible, creative, intense', shadow: 'overburdened, moralistic' },
  Krittika:  { theme: 'sharp discernment, purification, cutting', nature: 'focused, critical, goal-oriented', shadow: 'harsh criticism, cutting others' },
  Rohini:    { theme: 'growth, beauty, sensuality, abundance', nature: 'creative, charming, loves comfort', shadow: 'possessive, materialistic, stubborn' },
  Mrigasira: { theme: 'seeking, curious, restless', nature: 'always searching for something better, curious mind', shadow: 'never satisfied, scattered' },
  Aardra:    { theme: 'storm, destruction to rebuild, research', nature: 'penetrating intellect, goes to the root', shadow: 'turbulent emotions, destructive phases' },
  Punarvasu: { theme: 'return, restoration, hope renewed', nature: 'resilient, philosophical, returns from adversity', shadow: 'repeating same patterns, nostalgia' },
  Pushyami:  { theme: 'nourishment, care, spiritual sustenance', nature: 'nurturing, responsible, protective', shadow: 'over-controlling, self-neglect' },
  Asresha:   { theme: 'embrace, kundalini, mysterious knowledge', nature: 'shrewd, perceptive, strategic', shadow: 'manipulative, secretive, toxic' },
  Makha:     { theme: 'ancestors, throne, magnificence', nature: 'proud, leadership-oriented, respect for tradition', shadow: 'arrogance, entitlement' },
  'Poorva Phalguni': { theme: 'relaxation, enjoyment, creativity', nature: 'artistic, playful, magnetic', shadow: 'laziness, self-indulgence' },
  'Uttara Phalguni': { theme: 'partnership, social contracts, service', nature: 'helping nature, builds lasting relationships', shadow: 'dependence on others, overly giving' },
  Hasta:     { theme: 'skilled hands, craftsmanship, manifestation', nature: 'dexterous, witty, manifests ideas into reality', shadow: 'cunning, restless hands' },
  Chitra:    { theme: 'brilliant, architect, visual', nature: 'aesthetic intelligence, perfectionist, creative', shadow: 'vain, restless, never satisfied with creation' },
  Swaati:    { theme: 'independence, flexibility, wind', nature: 'independent, adaptable, diplomatic', shadow: 'scattered, difficulty committing' },
  Visaakha:  { theme: 'purpose, ambition, two paths', nature: 'goal-oriented, persistent, can wait for the right time', shadow: 'jealousy, extremism, either-or thinking' },
  Anooraadha: { theme: 'devotion, friendship, organization', nature: 'loyal, deep friendships, organized', shadow: 'repressed emotions, inability to forgive' },
  Jyeshtha:  { theme: 'eldest, authority, protection of others', nature: 'protective, ambitious, strong will', shadow: 'domineering, loneliness at the top' },
  Moola:     { theme: 'root, destruction, going to the source', nature: 'investigative, unafraid to uproot false structures', shadow: 'destructive tendencies, isolation' },
  'Poorvaashaadha': { theme: 'invincible, water, purification', nature: 'confident, independent, persevering', shadow: 'arrogance, invincibility complex' },
  'Uttaraashaadha': { theme: 'final victory, universal principles', nature: 'righteous, disciplined, long-term focus', shadow: 'inflexibility, delayed gratification issues' },
  Sravanam:  { theme: 'listening, learning, connection', nature: 'excellent listener, learns from all sources', shadow: 'gossip, information overload' },
  Dhanishtha: { theme: 'wealth, music, mars energy', nature: 'ambitious, musical ability, charitable', shadow: 'restless, relationship challenges' },
  Satabhishak: { theme: 'hundred healers, research, mystical', nature: 'scientific mind, healing ability, secretive', shadow: 'isolation, unconventional to extreme' },
  'Poorvaabhaadra': { theme: 'two-faced, transformation, fire serpent', nature: 'passionate, idealistic, otherworldly intelligence', shadow: 'extremism, burning bridges' },
  'Uttaraabhaadra': { theme: 'rain serpent, depth, responsibility', nature: 'wise, patient, deep spiritual understanding', shadow: 'too slow to act, overly introspective' },
  Revati:    { theme: 'journey\'s end, nourishment, completion', nature: 'compassionate, protective, helps others complete journeys', shadow: 'self-sacrifice to detriment, impractical idealism' }
};

/**
 * Get nakshatra description for a planet in a chart
 * Used in portrait generation
 */
function getNakshatraDescription(planet, lonOrBody, context) {
  // Accept either a longitude number or a body object
  const lon = (typeof lonOrBody === 'number') ? lonOrBody : getFullLongitude(lonOrBody);
  if (lon === null) return null;
  const nak = getNakshatra(lon);
  const psych = NAKSHATRA_PSYCHOLOGY[nak.name] || {};

  return {
    nakshatra: nak.name,
    pada: nak.pada,
    lord: nak.lord,
    theme: psych.theme || '',
    nature: psych.nature || '',
    shadow: psych.shadow || '',
    // Secondary activation: nakshatra lord is also activated
    secondaryActivation: nak.lord !== planet ? nak.lord : null,
    // Pada D9 sign (useful for marriage/relationship context)
    d9Sign: getPadaD9Sign(nak.index, nak.pada)
  };
}

/**
 * Get D9 sign from nakshatra pada
 * Fire nakshatras: Ar start; Earth: Cp; Air: Li; Water: Cn
 */
function getPadaD9Sign(nakIdx, pada) {
  const SIGNS = ['Ar','Ta','Ge','Cn','Le','Vi','Li','Sc','Sg','Cp','Aq','Pi'];
  const IS_FIRE  = [0,4,8,12,16,20,24]; // Aswini, Makha, Moola... (every 9th starting from 0)
  const IS_EARTH = [1,5,9,13,17,21,25];
  const IS_AIR   = [2,6,10,14,18,22,26];
  // Water = rest
  let startIdx;
  if (IS_FIRE.includes(nakIdx))  startIdx = 0;  // Ar
  else if (IS_EARTH.includes(nakIdx)) startIdx = 9;  // Cp
  else if (IS_AIR.includes(nakIdx))   startIdx = 6;  // Li
  else startIdx = 3; // Cn
  return SIGNS[(startIdx + pada - 1) % 12];
}

/**
 * Get secondary activated planets in a dasha period
 * based on nakshatra lords of active planets
 * 
 * PVR principle: During Planet X's dasha, if X is in nakshatra of Planet Y,
 * then Y also gets secondary activation.
 * 
 * @param {string} dashaPlanet - the active dasha lord
 * @param {object} bodies      - natal planet positions with siderealLongitude
 * @returns {object|null}      - secondary activation info
 */
function getSecondaryActivation(dashaPlanet, bodies) {
  const body = bodies[dashaPlanet];
  if (!body) return null;

  const lon = getFullLongitude(body);
  if (lon === null) return null;

  const nak = getNakshatra(lon);

  // Secondary planet = nakshatra lord (if different from dasha planet)
  if (nak.lord === dashaPlanet) return null; // own nakshatra, no secondary

  const secondaryBody = bodies[nak.lord];
  if (!secondaryBody) return null;

  const secondaryLon = secondaryBody.siderealLongitude ?? secondaryBody.longitude;
  const secondaryNak = secondaryLon != null ? getNakshatra(secondaryLon) : null;

  return {
    dashaPlanet,
    dashaPlantNakshatra: nak.name,
    secondaryPlanet: nak.lord,
    secondaryHouse: secondaryBody.house || secondaryBody.rasiHouse,
    secondarySign: secondaryBody.signCode,
    secondaryNakshatra: secondaryNak?.name,
    meaning: `${dashaPlanet} is in ${nak.name} (${nak.lord}'s nakshatra) — ${nak.lord} also gets secondary activation during ${dashaPlanet} dasha`
  };
}

/**
 * Compute secondary activations for all 9 planets
 * Returns map: { Sun: {secondary: 'Saturn', ...}, Moon: {...}, ... }
 */
function computeAllSecondaryActivations(bodies) {
  const result = {};
  const PLANETS = ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn','Rahu','Ketu'];
  PLANETS.forEach(p => {
    const sa = getSecondaryActivation(p, bodies);
    if (sa) result[p] = sa;
  });
  return result;
}

/**
 * Get Karma Nakshatra (nakshatra of 10th house cusp)
 * Used in career event verification
 * 
 * @param {number} lagnaLon - sidereal longitude of lagna
 * @returns {object} karma nakshatra info
 */
function getKarmaNakshatra(lagnaLon) {
  // 10th house cusp = lagna + 270° (in whole-sign, it's 10th sign's first degree)
  const tenthLon = (lagnaLon + 270) % 360;
  return getNakshatra(tenthLon);
}

/**
 * Get Vainasika nakshatra (88th from Moon = very inauspicious)
 * PVR p.319: "When a planet transits this nakshatra, avoid important activities"
 */
function getVainasika(moonNakIdx) {
  // 88th nakshatra = (moonNakIdx + 87) % 27
  const vainasika = (moonNakIdx + 87) % 27;
  return { index: vainasika, name: NAKSHATRAS[vainasika].name };
}

module.exports = {
  getNakshatra,
  getNavTara,
  getNakshatraDescription,
  getSecondaryActivation,
  computeAllSecondaryActivations,
  getKarmaNakshatra,
  getVainasika,
  getFullLongitude,
  NAKSHATRAS,
  NAKSHATRA_PSYCHOLOGY,
  TARA_NAMES,
  TARA_SCORE,
  TARA_QUALITY,
  TARA_MEANING,
  getPadaD9Sign
};
