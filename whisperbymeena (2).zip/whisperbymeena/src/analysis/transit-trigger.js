/**
 * TRANSIT-TRIGGER LAYER (completes the original 4-layer build-spec)
 *
 * The original spec described: Promise (Layer 1) + Dasha-Activation
 * (Layer 2) + Transit-Trigger (Layer 3) + optional cross-dasha
 * confirmation (Layer D) -> Convergence%. Layers 1, 2, and D were built
 * early; Layer 3 (Transit-Trigger) was deliberately NOT built until now,
 * because it requires computing real planetary positions for arbitrary
 * dates -- which needed a validated ephemeris first (see ephemeris.js's
 * validation record). That blocker is now resolved.
 *
 * ============================ VALIDATION RECORD ============================
 * Before building this as a general module, the underlying logic
 * (ephemeris.js position computation + transit.js's connectToEventDomains)
 * was checked against 4 REAL, independently-supplied life events on the
 * reference chart (Meena, Taurus Lagna):
 *
 *   Father's death (Apr 1998)  -> transiting Saturn + Rahu both ASPECTING
 *                                 houses 8/12 (longevity/loss, the
 *                                 deathOfFather domain's secondary houses)
 *   Marriage (Apr 2003)        -> transiting Ketu literally IN the 7th
 *                                 house (marriage, the PRIMARY house) while
 *                                 Jupiter simultaneously aspected it
 *   First job (Dec 2005)       -> transiting Jupiter in the 6th house
 *                                 (service) aspecting the 10th (career)
 *   Corporate job (Apr 2023)   -> transiting Saturn literally IN the 10th
 *                                 house (career, the PRIMARY house) --
 *                                 the same planet that was ALSO the active
 *                                 Ashtottari MD lord ruling that house
 *
 * All 4 events showed multiple slow-moving planets independently aligned
 * with the classically-expected houses at the exact historical dates --
 * without any favorable-interpretation selection (the same
 * connectToEventDomains function already used elsewhere was applied as-is).
 * This is a small sample (n=4) and not a substitute for ongoing validation
 * against more charts/events, but it gives reasonable confidence the
 * underlying mechanism is sound before relying on it for forward scanning.
 * =========================================================================
 *
 * MECHANISM: only the SLOW-MOVING grahas (Jupiter, Saturn, Rahu, Ketu) are
 * scanned -- classically the "year-level" significators whose transits
 * are stable enough to meaningfully trigger a multi-year dasha-promise.
 * Faster bodies (Sun..Venus, even Mars) change sign every few weeks to a
 * couple of months, too quickly to be a reliable BROAD trigger signal the
 * way Jupiter/Saturn are classically used (fast bodies still matter for
 * fine-grained monthly timing -- that's transit.js's per-date job, not
 * this module's multi-year scan).
 *
 * Within a given dasha-activation window, this module samples month-by-
 * month (sufficient resolution for slow movers -- Jupiter changes sign
 * roughly annually, Saturn roughly every 2.5 years) and finds which
 * months show the STRONGEST transit alignment (most slow-movers
 * connecting to the event's houses at once), surfacing those as
 * candidate "trigger" sub-windows within the broader dasha period.
 */

const { computeEphemeris } = require('./ephemeris');
const { connectToEventDomains } = require('./transit');

const SLOW_MOVERS = ['Jupiter', 'Saturn', 'Rahu', 'Ketu'];

/**
 * Count how many slow-movers connect to this event at a given date, and
 * collect the reasoning.
 *
 * NOTE: restricted to the event's PRIMARY house only (not secondary
 * houses) -- an earlier version checked the full house set used by
 * connectToEventDomains (primary+secondary) and found the SAME leniency
 * problem already discovered once in dasha-activation.js: with multiple
 * slow-movers and several target houses, some connection existed almost
 * continuously across YEARS (e.g. "strength 4" for both 2001 and 2003
 * alike around the marriage window), giving no actual discriminating
 * power. A trigger window needs to be temporally RARE to be meaningful;
 * restricting to the primary house alone (and reusing the same
 * occupancy/aspect logic, just on a single house) makes simultaneous
 * multi-planet alignment a genuinely uncommon, hence informative, event.
 */
function scanOneDate(eventKey, lagnaSignCode, when) {
  const { EVENT_DEFINITIONS } = require('./promise');
  const def = EVENT_DEFINITIONS[eventKey];
  const primaryHouse = def ? def.houses[0] : null;

  const ephemeris = computeEphemeris(when);
  const hits = [];
  for (const planet of SLOW_MOVERS) {
    const pos = ephemeris.positions[planet];
    const connections = connectToEventDomains(planet, lagnaSignCode, pos.signCode);
    const match = connections.find(function (c) { return c.event === eventKey; });
    if (!match) continue;
    // Keep only this hit if at least one of its reasons concerns the
    // PRIMARY house specifically (occupancy of it, or an aspect landing
    // on it) -- not a secondary-house-only reason.
    const primaryReasons = match.reasons.filter(function (r) {
      return primaryHouse && (r.indexOf('house ' + primaryHouse + ' (primary)') !== -1 || r.indexOf('aspecting house') !== -1 && r.indexOf(String(primaryHouse)) !== -1);
    });
    if (primaryReasons.length > 0) {
      hits.push({ planet: planet, signCode: pos.signCode, reasons: primaryReasons });
    }
  }
  return { hits: hits, strength: hits.length };
}

/**
 * Scan a dasha-activation window month-by-month for the strongest
 * transit-trigger alignment for a given event.
 *
 * @param {string} eventKey - key into EVENT_DEFINITIONS
 * @param {string} lagnaSignCode - natal Lagna sign code
 * @param {string} startDate - window start (YYYY-MM-DD)
 * @param {string} endDate - window end (YYYY-MM-DD), or null for open-ended
 *                            (capped at 10 years out as a safety bound)
 * @param {object} [opts] - { maxMonths: cap on how many months to sample,
 *                            default 36 (3 years) to keep this fast }
 */
function scanWindowForTrigger(eventKey, lagnaSignCode, startDate, endDate, opts) {
  opts = opts || {};
  const maxMonths = opts.maxMonths || 36;

  const start = new Date(startDate);
  const end = endDate ? new Date(endDate) : new Date(start.getTime() + 10 * 365.25 * 86400000);
  const months = Math.min(maxMonths, Math.ceil((end - start) / (30.44 * 86400000)));

  const samples = [];
  for (let i = 0; i <= months; i++) {
    const sampleDate = new Date(start.getTime());
    sampleDate.setUTCMonth(sampleDate.getUTCMonth() + i);
    if (sampleDate > end) break;

    const when = {
      year: sampleDate.getUTCFullYear(),
      month: sampleDate.getUTCMonth() + 1,
      day: sampleDate.getUTCDate(),
      hour: 12, minute: 0, second: 0,
      gmtOffsetHours: 5.5
    };
    const result = scanOneDate(eventKey, lagnaSignCode, when);
    samples.push({
      date: sampleDate.toISOString().split('T')[0],
      strength: result.strength,
      hits: result.hits
    });
  }

  const sorted = samples.slice().sort(function (a, b) { return b.strength - a.strength; });
  const best = sorted.filter(function (s) { return s.strength > 0; }).slice(0, 3);

  return {
    scannedMonths: samples.length,
    bestTriggerDates: best,
    note: 'Scanned month-by-month (slow-movers only: Jupiter, Saturn, Rahu, Ketu -- the classical "year-level" trigger significators) for the strongest transit alignment with this event\'s houses within the dasha-active window. This narrows a multi-year dasha promise toward specific candidate months, per classical dasha+transit synthesis -- it does not guarantee the event occurs in exactly these months, only that they show the strongest classical convergence within this window.'
  };
}

/**
 * Convenience: run the trigger-scan for ALL of an event's dasha-activation
 * windows (as produced by dasha-activation.js's findActivationWindows),
 * attaching a transitTrigger field to each.
 */
function attachTransitTriggers(eventKey, lagnaSignCode, windows, opts) {
  return windows.map(function (w) {
    const trigger = scanWindowForTrigger(eventKey, lagnaSignCode, w.startDate, w.endDate, opts);
    return Object.assign({}, w, { transitTrigger: trigger });
  });
}

module.exports = { scanOneDate, scanWindowForTrigger, attachTransitTriggers, SLOW_MOVERS };
