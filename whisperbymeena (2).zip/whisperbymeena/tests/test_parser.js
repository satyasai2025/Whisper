/**
 * Parser Test Script
 * Tests the JHora parser against the sample text input.
 *
 * Run: node tests/test_parser.js
 */

const fs = require('fs');
const path = require('path');
const { parseJHoraText } = require('../src/parser/jhora-parser');
const { findActiveDasha } = require('../src/parser/extractors/vimshottari');
const { findActiveNarayana } = require('../src/parser/extractors/narayana');

const TEST_INPUT = path.join(__dirname, '../data/test_input/jatin_sample.txt');
const OUTPUT_FILE = path.join(__dirname, '../data/test_input/jatin_parsed.json');

function pass(msg) { console.log(`  ✓ ${msg}`); }
function fail(msg) { console.log(`  ✗ ${msg}`); process.exitCode = 1; }

function run() {
  console.log('Loading test input:', TEST_INPUT);
  const rawText = fs.readFileSync(TEST_INPUT, 'utf-8');
  console.log(`  ${rawText.length} characters, ${rawText.split('\n').length} lines\n`);

  const chart = parseJHoraText(rawText, { sourceFile: 'jatin_sample.txt' });

  console.log('=== Section Detection ===');
  console.log('  Sections found:', chart.metadata.sectionsFound.join(', '));
  console.log();

  console.log('=== Native ===');
  console.log('  Name:', chart.native.name);
  console.log('  DOB:', chart.native.dateOfBirth);
  console.log('  TOB:', chart.native.timeOfBirth);
  console.log('  GMT Offset:', chart.native.gmtOffset);
  console.log('  Place:', chart.native.placeOfBirth);
  console.log('  Coordinates:', chart.native.coordinates);
  console.log();

  // Assertions on native
  if (chart.native.name && chart.native.name.includes('Jatin')) pass('Name extracted');
  else fail(`Name extraction failed: got "${chart.native.name}"`);

  if (chart.native.dateOfBirth === '1998-11-25') pass('Date extracted correctly');
  else fail(`Date wrong: got "${chart.native.dateOfBirth}"`);

  if (chart.native.timeOfBirth === '09:00:00') pass('Time extracted correctly');
  else fail(`Time wrong: got "${chart.native.timeOfBirth}"`);

  if (chart.native.gmtOffset === '+05:30') pass('GMT offset correct');
  else fail(`GMT offset wrong: got "${chart.native.gmtOffset}"`);

  if (chart.native.placeOfBirth && chart.native.placeOfBirth.includes('Ahmedabad')) pass('Place extracted');
  else fail(`Place extraction failed: got "${chart.native.placeOfBirth}"`);

  console.log('\n=== Panchanga ===');
  console.log('  Tithi:', chart.panchanga.tithi);
  console.log('  Nakshatra:', chart.panchanga.janmaNakshatra);
  console.log('  Vaar/Yoga/Karana/Hora:', chart.panchanga.vaar, '/', chart.panchanga.yoga, '/', chart.panchanga.karana, '/', chart.panchanga.hora);

  if (chart.panchanga.vaar === 'Wednesday') pass('Vaar extracted');
  else fail(`Vaar wrong: got "${chart.panchanga.vaar}"`);

  if (chart.panchanga.janmaNakshatra === 'Sravanam') pass('Janma nakshatra extracted');
  else fail(`Nakshatra wrong: got "${chart.panchanga.janmaNakshatra}"`);

  console.log('\n=== Lagna ===');
  if (chart.bodies.Lagna) {
    console.log('  Sign:', chart.bodies.Lagna.sign, `(${chart.bodies.Lagna.signCode})`);
    console.log('  Degrees:', chart.bodies.Lagna.degrees + '°' + chart.bodies.Lagna.minutes + '\'' + chart.bodies.Lagna.seconds + '"');
    console.log('  Nakshatra:', chart.bodies.Lagna.nakshatra, 'pada', chart.bodies.Lagna.pada);
    console.log('  Navamsa:', chart.bodies.Lagna.navamsa);

    if (chart.bodies.Lagna.signCode === 'Sg') pass('Lagna in Sagittarius');
    else fail(`Lagna wrong: got ${chart.bodies.Lagna.signCode}`);
  } else {
    fail('Lagna not extracted');
  }

  console.log('\n=== All Bodies ===');
  const expectedBodies = ['Lagna', 'Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn', 'Rahu', 'Ketu'];
  for (const name of expectedBodies) {
    const b = chart.bodies[name];
    if (b) {
      const flags = [];
      if (b.retrograde) flags.push('R');
      if (b.charaKaraka) flags.push(b.charaKaraka);
      const flagStr = flags.length ? ` [${flags.join(', ')}]` : '';
      console.log(`  ${name.padEnd(8)} ${b.sign.padEnd(12)} ${b.degrees}°${b.minutes}'  ${b.nakshatra}-${b.pada}  navamsa: ${b.navamsa}  house: ${b.house}${flagStr}`);
    } else {
      console.log(`  ${name}: NOT FOUND`);
      fail(`Body ${name} not extracted`);
    }
  }

  console.log('\n=== Chara Karakas ===');
  const expectedKarakas = { AK: 'Jupiter', AmK: 'Mercury', BK: 'Moon', PiK: 'Sun', GK: 'Mars', DK: 'Saturn' };
  for (const [code, name] of Object.entries(chart.charaKarakas)) {
    console.log(`  ${code} (${require('../src/parser/utils/constants').CHARA_KARAKAS[code]}): ${name}`);
  }
  for (const [code, expectedName] of Object.entries(expectedKarakas)) {
    if (chart.charaKarakas[code] === expectedName) {
      pass(`${code} = ${expectedName}`);
    } else {
      fail(`${code} expected ${expectedName}, got ${chart.charaKarakas[code]}`);
    }
  }

  console.log('\n=== Functional Nature (Lagna-based) ===');
  for (const [planet, c] of Object.entries(chart.analysis.functionalNature.classifications)) {
    if (c.classification === 'Not classified') continue;
    console.log(`  ${planet}: ${c.classification} (rules: ${c.housesRuled})`);
  }

  console.log('\n=== Vimshottari Dasha ===');
  const v = chart.dashas.vimshottari;
  console.log(`  ${v.mahadashas.length} mahadashas found`);
  if (v.mahadashas.length >= 9) pass(`Vimshottari has ${v.mahadashas.length} MDs (expected 9+)`);
  else fail(`Vimshottari has only ${v.mahadashas.length} MDs`);

  for (const md of v.mahadashas.slice(0, 3)) {
    console.log(`  MD ${md.lord}: ${md.startDate} → ${md.endDate} (${md.antardashas.length} ADs)`);
    if (md.antardashas.length !== 9) fail(`MD ${md.lord} has ${md.antardashas.length} ADs (expected 9)`);
  }

  // Find current dasha
  const today = new Date().toISOString().split('T')[0];
  const active = findActiveDasha(v.mahadashas, today);
  if (active) {
    console.log(`  Active on ${today}: ${active.mahadasha} MD / ${active.antardasha} AD`);
  } else {
    console.log(`  No active dasha found for ${today}`);
  }

  console.log('\n=== Narayana Dasha ===');
  const n = chart.dashas.narayana;
  console.log(`  ${n.periods.length} major periods found`);
  for (const p of n.periods.slice(0, 3)) {
    console.log(`  ${p.rasi}: ${p.startDate} → ${p.endDate} (${p.subPeriods.length} sub-periods)`);
  }

  const activeN = findActiveNarayana(n.periods, today);
  if (activeN) {
    console.log(`  Active on ${today}: ${activeN.major} major / ${activeN.sub} sub`);
  }

  // Save full output
  fs.writeFileSync(OUTPUT_FILE, JSON.stringify(chart, null, 2));
  console.log(`\n=== Full output saved to: ${OUTPUT_FILE} ===`);
  console.log(`  Size: ${(fs.statSync(OUTPUT_FILE).size / 1024).toFixed(1)} KB`);
}

try {
  run();
  console.log('\nTest run complete.');
} catch (err) {
  console.error('TEST FAILED:', err);
  console.error(err.stack);
  process.exit(1);
}
