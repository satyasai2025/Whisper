/**
 * Past Event Verification Engine — Sprint 1
 * 
 * Purpose: Verify a past event against chart using multi-layer analysis.
 * Returns scored verification with specific reasons — not just pass/fail.
 * 
 * Architecture:
 *   Layer 1 (Dasha): Karaka + house lord check (Vimshottari + Narayana)
 *   Layer 2 (D-chart): Primary divisional chart for event type
 *   Layer 3 (Transit): Vedha, Moorti, Tara, BAV at event date
 *   
 * Score 0-100:
 *   75+: Strong confirmation — birth time reliable
 *   50-74: Moderate — some factors confirm
 *   30-49: Weak — only partial match
 *   <30: Poor — birth time suspect OR event not chart-driven
 */

'use strict';

// ── Event Definitions ──────────────────────────────────────────────────────────
// For each event: natural karakas, chara karakas, primary D-chart, relevant houses
const EVENT_DEFINITIONS = {
  marriage: {
    label: 'Marriage / Partnership',
    // Naisargika karaka: Venus for marriage timing (BOTH genders — PVR p.83 Table 15)
    // "7th from Venus should be used for predicting marriage, both in male and female charts"
    naturalKarakas: ['Venus'],
    // Chara karaka: DK (Darakaraka) = spouse significator for BOTH genders
    charaKaraka: 'DK',
    // Sthira karaka for DEATH of spouse (NOT for marriage prediction):
    //   Female chart: Jupiter = husband (PVR p.82: "Jupiter: Husband")
    //   Male chart: Venus = wife
    //   This is determined at runtime based on native's gender
    primaryDchart: 'd9',
    primaryHouses: [7, 2, 11],
    secondaryHouses: [1],
    dchartHouses: [7, 1, 2],
    specialPoints: ['UL'],
    transitPrimary: ['Jupiter', 'Venus'],
    // Gender-specific additional karaka (set at runtime)
    genderKaraka: { female: 'Jupiter', male: 'Venus' },
  },
  children: {
    label: 'Child Birth',
    naturalKarakas: ['Jupiter'],
    charaKaraka: 'PK',                  // Putrakaraka
    primaryDchart: 'd7',
    primaryHouses: [5, 9, 11],
    secondaryHouses: [1, 7],
    dchartHouses: [5, 1, 9],
    specialPoints: [],
    transitPrimary: ['Jupiter'],
  },
  firstJob: {
    label: 'Career Start',
    naturalKarakas: ['Saturn', 'Sun'],
    charaKaraka: 'AMK',                 // Amatyakaraka
    primaryDchart: 'd10',
    primaryHouses: [10, 6, 2],
    secondaryHouses: [11, 1],
    dchartHouses: [10, 1, 6],
    specialPoints: ['GL'],              // Ghati Lagna
    transitPrimary: ['Saturn', 'Jupiter'],
  },
  jobChange: {
    label: 'Job Change',
    naturalKarakas: ['Saturn', 'Sun'],
    charaKaraka: 'AMK',
    primaryDchart: 'd10',
    primaryHouses: [10, 6, 12],
    secondaryHouses: [2, 11],
    dchartHouses: [10, 6, 1],
    specialPoints: ['GL'],
    transitPrimary: ['Saturn'],
  },
  promotion: {
    label: 'Promotion / Success',
    naturalKarakas: ['Sun', 'Jupiter'],
    charaKaraka: 'AMK',
    primaryDchart: 'd10',
    primaryHouses: [10, 1, 11],
    secondaryHouses: [2, 9],
    dchartHouses: [1, 10, 9],
    specialPoints: ['GL'],
    transitPrimary: ['Jupiter', 'Sun'],
  },
  housePurchase: {
    label: 'Property Purchase',
    naturalKarakas: ['Mars'],
    charaKaraka: 'BK',
    primaryDchart: 'd4',
    primaryHouses: [4, 2, 11],
    secondaryHouses: [12],
    dchartHouses: [4, 1, 2],
    specialPoints: [],
    transitPrimary: ['Jupiter', 'Mars'],
  },
  deathOfFather: {
    label: 'Death of Father',
    naturalKarakas: ['Sun', 'Saturn'],
    charaKaraka: 'PK',
    primaryDchart: 'd12',
    primaryHouses: [9, 4, 8],
    secondaryHouses: [12],
    dchartHouses: [9, 1, 8],
    specialPoints: [],
    transitPrimary: ['Saturn'],
  },
  deathOfMother: {
    label: 'Death of Mother',
    naturalKarakas: ['Moon', 'Saturn'],
    charaKaraka: 'MK',
    primaryDchart: 'd12',
    primaryHouses: [4, 8, 12],
    secondaryHouses: [9],
    dchartHouses: [4, 1, 8],
    specialPoints: [],
    transitPrimary: ['Saturn'],
  },
  foreignTravel: {
    label: 'Foreign Travel / Settlement',
    naturalKarakas: ['Rahu'],
    charaKaraka: 'GK',
    primaryDchart: 'd9',
    primaryHouses: [12, 9, 3],
    secondaryHouses: [7],
    dchartHouses: [12, 9, 1],
    specialPoints: [],
    transitPrimary: ['Rahu', 'Jupiter'],
  },
  majorIllness: {
    label: 'Major Illness',
    naturalKarakas: ['Saturn', 'Mars'],
    charaKaraka: 'GK',
    primaryDchart: 'd1',
    primaryHouses: [6, 8, 12],
    secondaryHouses: [1],
    dchartHouses: [6, 1, 8],
    specialPoints: [],
    transitPrimary: ['Saturn', 'Mars'],
  },
  surgery: {
    label: 'Surgery / Medical Procedure',
    naturalKarakas: ['Mars', 'Ketu'],
    charaKaraka: 'GK',
    primaryDchart: 'd1',
    primaryHouses: [6, 8, 1],
    secondaryHouses: [12],
    dchartHouses: [6, 8, 1],
    specialPoints: [],
    transitPrimary: ['Mars', 'Saturn'],
  },
  accident: {
    label: 'Accident / Injury',
    naturalKarakas: ['Mars'],
    charaKaraka: 'GK',
    primaryDchart: 'd1',
    primaryHouses: [6, 8, 3],
    secondaryHouses: [12, 1],
    dchartHouses: [6, 8, 1],
    specialPoints: [],
    transitPrimary: ['Mars', 'Rahu'],
  },
  businessStart: {
    label: 'Business Start',
    naturalKarakas: ['Mercury', 'Jupiter'],
    charaKaraka: 'AMK',
    primaryDchart: 'd10',
    primaryHouses: [10, 7, 3],
    secondaryHouses: [11, 2],
    dchartHouses: [10, 1, 7],
    specialPoints: ['GL'],
    transitPrimary: ['Jupiter', 'Saturn'],
  },
  wealth: {
    label: 'Wealth / Financial Gain',
    naturalKarakas: ['Jupiter', 'Venus'],
    charaKaraka: 'AMK',
    primaryDchart: 'd1',
    primaryHouses: [2, 11, 9],
    secondaryHouses: [5, 1],
    dchartHouses: [2, 11, 1],
    specialPoints: [],
    transitPrimary: ['Jupiter'],
  },
  education: {
    label: 'Education / Degree',
    naturalKarakas: ['Mercury', 'Jupiter'],
    charaKaraka: 'AMK',
    primaryDchart: 'd1',
    primaryHouses: [5, 9, 4],
    secondaryHouses: [1, 11],
    dchartHouses: [5, 9, 1],
    specialPoints: [],
    transitPrimary: ['Jupiter', 'Mercury'],
  },
};

// ── Karaka mapping ─────────────────────────────────────────────────────────────
const KARAKA_NAMES = {
  AK: 'Atmakaraka', AMK: 'Amatyakaraka', BK: 'Bhratrikaraka',
  MK: 'Matrikaraka', PK: 'Putrakaraka', GK: 'Gnatikaraka', DK: 'Darakaraka'
};

// ── Transit quality helpers ────────────────────────────────────────────────────
// Good houses for each planet from natal Moon (standard Gochar table)
const GOOD_HOUSES_FROM_MOON = {
  Sun:     [3,6,10,11],
  Moon:    [1,3,6,7,10,11],
  Mars:    [3,6,11],
  Mercury: [2,4,6,8,10,11],
  Jupiter: [2,5,7,9,11],
  Venus:   [1,2,3,4,5,9,11],    // Table 58: NOT 6,7,8,10,12
  Saturn:  [3,6,11],
  Rahu:    [3,6,11],
  Ketu:    [3,6,11],
};

// Moorti from natal Moon distance
function getMoorti(moonSignIdx, transitSignIdx) {
  const dist = ((transitSignIdx - moonSignIdx + 12) % 12) + 1;
  if ([2,12].includes(dist)) return { name:'Swarna', quality:'excellent', score:100 };
  if ([3,11].includes(dist)) return { name:'Rajata', quality:'good',      score:75  };
  if ([4,10].includes(dist)) return { name:'Tamra',  quality:'mixed',     score:50  };
  if ([5,9].includes(dist))  return { name:'Loha',   quality:'weak',      score:25  };
  if ([1,7].includes(dist))  return { name:'Neutral',quality:'neutral',   score:50  };
  return { name:'Neutral', quality:'neutral', score:50 };
}

// Tara from natal Moon nakshatra
const TARA_NAMES = ['Janma','Sampath','Vipat','Kshema','Pratyak','Sadhana','Naidhana','Mitra','Param Mitra'];
const TARA_QUALITY = {
  Janma:'mixed', Sampath:'good', Vipat:'bad', Kshema:'good',
  Pratyak:'bad', Sadhana:'good', Naidhana:'bad', Mitra:'good', 'Param Mitra':'excellent'
};
const TARA_SCORE = {
  Janma:40, Sampath:80, Vipat:10, Kshema:75,
  Pratyak:15, Sadhana:70, Naidhana:5, Mitra:65, 'Param Mitra':90
};

function getTara(moonNakIdx, transitNakIdx) {
  const count = ((transitNakIdx - moonNakIdx + 27) % 27);
  const taraIdx = count % 9;
  const name = TARA_NAMES[taraIdx];
  return { name, quality: TARA_QUALITY[name], score: TARA_SCORE[name], count: count+1 };
}

const SIGN_CODES = ['Ar','Ta','Ge','Cn','Le','Vi','Li','Sc','Sg','Cp','Aq','Pi'];

function houseFromLagna(lagnaSignCode, planetSignCode) {
  const lagnaIdx  = SIGN_CODES.indexOf(lagnaSignCode);
  const planetIdx = SIGN_CODES.indexOf(planetSignCode);
  return ((planetIdx - lagnaIdx + 12) % 12) + 1;
}

// ── Main verification function ──────────────────────────────────────────────────

/**
 * Verify a past event with full multi-layer analysis.
 * 
 * @param {object} params
 * @param {string} params.eventKey
 * @param {string} params.eventDate     - 'YYYY-MM-DD'
 * @param {string} params.eventLabel    - user-provided label
 * @param {object} params.chart         - full chart from buildHoroscope
 * @param {object} params.transitData   - planets at event date from ephemeris
 * @returns {object} verification result with score and reasons
 */
function verifyPastEvent(params) {
  const { eventKey, eventDate, eventLabel, chart, transitData, gender } = params;
  const def = EVENT_DEFINITIONS[eventKey];
  if (!def) return { error: 'Unknown event type: ' + eventKey };

  // Determine native's gender (default female for Meena chart)
  // 'female' | 'male' | null (unknown)
  const nativeGender = gender || chart.native?.gender || null;

  const birthYear = chart.lagna ? new Date(chart.native?.dateOfBirth || '1976-01-01').getFullYear() : 1976;
  const eventYear = new Date(eventDate).getFullYear();
  const age = eventYear - birthYear;

  const reasons = [];     // what supports this event
  const concerns = [];    // what contradicts or weakens
  const signals = [];     // all signals with weights

  // ── Get active dashas at event date ─────────────────────────────────────────
  const vimsh = findDashaAtDate(chart.vimshottariDashas, eventDate);
  const nar   = findNarayanaAtDate(chart.narayanaD1?.dasas, eventDate);

  const activeMD  = vimsh?.mahadasha;
  const activeAD  = vimsh?.antardasha;
  const activePD  = vimsh?.pratyantardasha;
  const activeNar = nar?.mahadasha;
  const activeNarAD = nar?.antardasha;

  // ── Get chart data ───────────────────────────────────────────────────────────
  const bodies        = chart.bodies;
  const lagnaCode     = chart.lagna?.signCode;
  const charaKarakas  = chart.analysis?.jaimini?.allCharaKarakas || {};
  const arudhas       = chart.analysis?.arudhas?.arudhas || {};
  const fn            = chart.analysis?.functionalNature?.classifications || {};
  const dchartKey     = def.primaryDchart; // 'd7', 'd9', 'd10' etc.
  const dchart        = chart[dchartKey];

  // ── LAYER 1: DASHA ANALYSIS ─────────────────────────────────────────────────
  let l1Score = 0;
  const l1Details = [];
  const allActiveLords = [activeMD, activeAD, activePD].filter(Boolean);

  // Nakshatra secondary activations — who gets activated during each dasha lord's period
  // PVR principle: if MD lord is in nakshatra of planet Y, Y also gets secondary activation
  const { computeAllSecondaryActivations } = require('../computation/nakshatra');
  const nakshatraActivations = computeAllSecondaryActivations(bodies);

  // Secondary activated planets in current dasha
  const secondaryActivated = new Set();
  allActiveLords.forEach(lord => {
    const sa = nakshatraActivations[lord];
    if (sa) secondaryActivated.add(sa.secondaryPlanet);
  });

  // Check 1a: Natural karaka in MD, AD, or PD — OR secondary activated via nakshatra
  def.naturalKarakas.forEach(karaka => {
    if (activeMD === karaka) {
      const pts = 25; l1Score += pts;
      reasons.push(`${karaka} MD — natural karaka for ${def.label}`);
      signals.push({ signal:`${karaka}_MD`, weight:pts, layer:1, type:'karaka' });
    } else if (activeAD === karaka) {
      const pts = 20; l1Score += pts;
      reasons.push(`${karaka} AD — natural karaka for ${def.label}`);
      signals.push({ signal:`${karaka}_AD`, weight:pts, layer:1, type:'karaka' });
    } else if (activePD === karaka) {
      const pts = 15; l1Score += pts;
      reasons.push(`${karaka} PD — natural karaka triggered at micro-period level`);
      signals.push({ signal:`${karaka}_PD`, weight:pts, layer:1, type:'karaka' });
    } else if (secondaryActivated.has(karaka)) {
      // Nakshatra secondary activation — smaller weight
      const pts = 8; l1Score += pts;
      const sa = allActiveLords.map(l => nakshatraActivations[l]).find(sa => sa?.secondaryPlanet === karaka);
      reasons.push(`${karaka} — nakshatra secondary activation (${sa?.dashaPlantNakshatra} nakshatra of active dasha lord)`);
      signals.push({ signal:`${karaka}_nakshatra_secondary`, weight:pts, layer:1, type:'nakshatra' });
    }
  });

  // Check 1b: Chara karaka in MD, AD, or PD
  const charaKarakaName   = def.charaKaraka;
  const charaKarakaPlanet = charaKarakas[charaKarakaName];
  if (charaKarakaPlanet) {
    if (activeMD === charaKarakaPlanet) {
      const pts = 22; l1Score += pts;
      reasons.push(`${charaKarakaPlanet} MD — ${KARAKA_NAMES[charaKarakaName]} (${charaKarakaName})`);
      signals.push({ signal:`${charaKarakaName}_MD`, weight:pts, layer:1, type:'chara_karaka' });
    } else if (activeAD === charaKarakaPlanet) {
      const pts = 18; l1Score += pts;
      reasons.push(`${charaKarakaPlanet} AD — ${KARAKA_NAMES[charaKarakaName]} (${charaKarakaName})`);
      signals.push({ signal:`${charaKarakaName}_AD`, weight:pts, layer:1, type:'chara_karaka' });
    } else if (activePD === charaKarakaPlanet) {
      const pts = 14; l1Score += pts;
      reasons.push(`${charaKarakaPlanet} PD — ${KARAKA_NAMES[charaKarakaName]} (${charaKarakaName}) triggers at PD level`);
      signals.push({ signal:`${charaKarakaName}_PD`, weight:pts, layer:1, type:'chara_karaka' });
    }
  }

  // Check 1b-extra: Gender-specific karaka
  // Source: PVR Ch.8.3 p.82
  // Female: Jupiter = sthira karaka of husband (physical body, Shiva's domain)
  // Male: Venus = sthira karaka of wife
  // NOTE: Sthira karakas are for death timing, but we check them here as
  //       SECONDARY signals for marriage — if active, they add weight.
  //       They are NOT the primary karaka for marriage timing.
  if (eventKey === 'marriage' && def.genderKaraka && nativeGender) {
    const gKaraka = def.genderKaraka[nativeGender]; // Jupiter for female, Venus for male
    if (gKaraka && gKaraka !== charaKarakaPlanet) { // avoid double counting
      if (activeMD === gKaraka) {
        const pts = 15; l1Score += pts;
        reasons.push(`${gKaraka} MD — sthira karaka of ${nativeGender==='female'?'husband':'wife'} (Ch.8.3, secondary signal)`);
        signals.push({ signal:`sthira_${gKaraka}_MD`, weight:pts, layer:1, type:'sthira_karaka' });
      } else if (activeAD === gKaraka) {
        const pts = 12; l1Score += pts;
        reasons.push(`${gKaraka} AD — sthira karaka of ${nativeGender==='female'?'husband':'wife'} (secondary)`);
        signals.push({ signal:`sthira_${gKaraka}_AD`, weight:pts, layer:1, type:'sthira_karaka' });
      } else if (activePD === gKaraka) {
        const pts = 8; l1Score += pts;
        reasons.push(`${gKaraka} PD — sthira karaka of ${nativeGender==='female'?'husband':'wife'} triggered`);
        signals.push({ signal:`sthira_${gKaraka}_PD`, weight:pts, layer:1, type:'sthira_karaka' });
      }
    }
    // Manglik check — note if Mars in H1,4,7,8,12 (classical dosha check)
    const marsHouse = bodies?.Mars?.house || bodies?.Mars?.rasiHouse;
    const manglikHouses = [1,4,7,8,12];
    if (marsHouse && manglikHouses.includes(marsHouse)) {
      concerns.push(`Mars in H${marsHouse} — Manglik consideration: check for relationship obstacles`);
    }
  }
  const houseRulerships = buildHouseRulerships(lagnaCode, bodies);
  def.primaryHouses.forEach(h => {
    const lord = houseRulerships[h];
    if (!lord) return;
    if (activeMD === lord) {
      const pts = 18; l1Score += pts;
      reasons.push(`${lord} MD — rules H${h} (${def.label} house from lagna)`);
      signals.push({ signal:`H${h}_lord_MD`, weight:pts, layer:1, type:'house_lord' });
    } else if (activeAD === lord) {
      const pts = 14; l1Score += pts;
      reasons.push(`${lord} AD — rules H${h}`);
      signals.push({ signal:`H${h}_lord_AD`, weight:pts, layer:1, type:'house_lord' });
    } else if (activePD === lord) {
      const pts = 10; l1Score += pts;
      reasons.push(`${lord} PD — rules H${h} (micro-period trigger)`);
      signals.push({ signal:`H${h}_lord_PD`, weight:pts, layer:1, type:'house_lord' });
    }
  });

  // Check 1d: Active lord occupies primary event house natally
  allActiveLords.forEach(lord => {
    if (!bodies[lord]) return;
    const occ = bodies[lord].house || bodies[lord].rasiHouse;
    if (occ && def.primaryHouses.includes(occ)) {
      if (!signals.find(s => s.signal === `${lord}_occ_H${occ}`)) {
        const pts = 12; l1Score += pts;
        reasons.push(`${lord} (active) occupies H${occ} natally`);
        signals.push({ signal:`${lord}_occ_H${occ}`, weight:pts, layer:1, type:'occupies' });
      }
    }
  });

  // Check 1e: Narayana D1
  if (activeNar) {
    const narHouse = houseFromLagna(lagnaCode, activeNar);
    if (def.primaryHouses.includes(narHouse)) {
      const pts = 15; l1Score += pts;
      reasons.push(`Narayana D1 ${activeNar} (H${narHouse}) — direct house`);
      signals.push({ signal:'Narayana_D1_house', weight:pts, layer:1, type:'narayana' });
    }
    const narAsp   = getRasiAspects(activeNar);
    const aspH     = narAsp.map(s => houseFromLagna(lagnaCode, s));
    const aspMatch = aspH.filter(h => def.primaryHouses.includes(h));
    if (aspMatch.length > 0 && l1Score < 40) {
      const pts = 10; l1Score += pts;
      reasons.push(`Narayana D1 ${activeNar} aspects H${aspMatch[0]}`);
      signals.push({ signal:'Narayana_D1_aspect', weight:pts, layer:1, type:'narayana' });
    }
  }

  // Check 1f: Saham activation — natal Vivaha/Karma/Putra Saham in transit dasha houses
  // Saham = a sensitive calculated point; if transit dasha lord's rasi = saham's sign → activated
  const sahamMap = { marriage:'vivaha', children:'putra', career:'karma', firstJob:'karma',
    promotion:'karma', housePurchase:'artha', foreignTravel:'paradesa', wealth:'artha' };
  const sahamKey = sahamMap[eventKey];
  if (sahamKey) {
    const saham = chart.analysis?.sahams?.sahams?.[sahamKey];
    if (saham?.sign && !saham._warning) {
      const sahamHouse = saham.house;
      // Is any active dasha lord in saham's sign? Or does active Narayana dasa activate it?
      const allActive = [activeMD, activeAD, activePD].filter(Boolean);
      allActive.forEach(lord => {
        const lordSign = bodies[lord]?.signCode;
        if (lordSign === saham.sign) {
          const pts = 12; l1Score += pts;
          reasons.push(`${lord} in ${sahamKey} Saham sign (${saham.sign}) — ${saham.name} activated (H${sahamHouse})`);
          signals.push({ signal:`saham_${sahamKey}_${lord}`, weight:pts, layer:1, type:'saham' });
        }
      });
      // Also: if transit Narayana dasa = saham sign
      if (activeNar === saham.sign) {
        const pts = 15; l1Score += pts;
        reasons.push(`Narayana D1 dasa of ${saham.name} sign (${saham.sign}, H${sahamHouse}) — activated`);
        signals.push({ signal:`narayana_saham_${sahamKey}`, weight:pts, layer:1, type:'saham_narayana' });
      }
    }
  }

  l1Score = Math.min(l1Score, 100);

  // ── LAYER 2: D-CHART + VARGA NARAYANA ───────────────────────────────────────
  let l2Score = 0;
  // dchartKey and dchart already declared above

  // Select correct Narayana dasha for this event type
  const vargaNarayanaMap = {
    d9: chart.narayanaD9, d10: chart.narayanaD10,
    d7: chart.narayanaD7, d12: chart.narayanaD12, d4: null, d1: chart.narayanaD1
  };
  const vargaNarayana = vargaNarayanaMap[dchartKey];
  let vargaActive = null, vargaAD = null;

  if (vargaNarayana?.dasas) {
    vargaActive = vargaNarayana.dasas.find(d => d.startDate <= eventDate && d.endDate > eventDate);
    vargaAD = vargaActive?.antardasas?.find(a => a.startDate <= eventDate && a.endDate > eventDate);
  }

  if (dchart && dchart.lagna) {
    const dLagnaCode = dchart.lagna;
    const dLagnaIdx  = SIGN_CODES.indexOf(dLagnaCode);

    // Check 2a: Primary karaka's position in D-chart
    const primaryKaraka = def.naturalKarakas[0];
    if (primaryKaraka && dchart.houses) {
      const karakaHouseInDchart = dchart.houses[primaryKaraka];
      if (karakaHouseInDchart && def.dchartHouses.includes(karakaHouseInDchart)) {
        const pts = 20;
        l2Score += pts;
        reasons.push(`${primaryKaraka} in H${karakaHouseInDchart} of ${dchartKey.toUpperCase()} — strong for ${def.label}`);
        signals.push({ signal: `${primaryKaraka}_${dchartKey}_house`, weight: pts, layer: 2, type: 'dchart_karaka' });
      }
    }

    // Check 2b: Varga Narayana active dasa connects to primary D-chart houses
    if (vargaActive) {
      const narHouseInDchart = ((SIGN_CODES.indexOf(vargaActive.rasi) - dLagnaIdx + 12) % 12) + 1;
      if (def.dchartHouses.includes(narHouseInDchart)) {
        const pts = 30;
        l2Score += pts;
        reasons.push(`Narayana ${dchartKey.toUpperCase()} dasa of ${vargaActive.rasi} (H${narHouseInDchart}) — primary event house activated`);
        signals.push({ signal: `Narayana_${dchartKey}_primary`, weight: pts, layer: 2, type: 'varga_narayana' });
      }
      // Check rasi aspect from dasa rasi on primary houses
      const narAspected = getRasiAspects(vargaActive.rasi);
      const narAspHouses = narAspected.map(s => ((SIGN_CODES.indexOf(s) - dLagnaIdx + 12) % 12) + 1);
      const narAspMatch = narAspHouses.filter(h => def.dchartHouses.includes(h));
      if (narAspMatch.length > 0 && l2Score < 30) {
        const pts = 15;
        l2Score += pts;
        reasons.push(`Narayana ${dchartKey.toUpperCase()} ${vargaActive.rasi} aspects H${narAspMatch[0]} — event connection`);
        signals.push({ signal: `Narayana_${dchartKey}_aspect`, weight: pts, layer: 2, type: 'varga_narayana' });
      }
    }

    // Check 2c: Varga Narayana antardasha
    if (vargaAD) {
      const adHouseInDchart = ((SIGN_CODES.indexOf(vargaAD.rasi) - dLagnaIdx + 12) % 12) + 1;
      if (def.dchartHouses.includes(adHouseInDchart)) {
        const pts = 15;
        l2Score += pts;
        reasons.push(`Narayana ${dchartKey.toUpperCase()} AD of ${vargaAD.rasi} (H${adHouseInDchart}) — antardasha confirms`);
        signals.push({ signal: `Narayana_${dchartKey}_AD`, weight: pts, layer: 2, type: 'varga_narayana_ad' });
      }
    }

    // Check 2d: Active Vimshottari lord in primary D-chart houses
    [activeMD, activeAD].filter(Boolean).forEach((lord, i) => {
      if (!dchart.houses) return;
      const houseInDchart = dchart.houses[lord];
      if (houseInDchart && def.dchartHouses.includes(houseInDchart)) {
        const pts = i === 0 ? 15 : 10;
        l2Score += pts;
        reasons.push(`${lord} (Vimsh ${i===0?'MD':'AD'}) in H${houseInDchart} of ${dchartKey.toUpperCase()}`);
        signals.push({ signal: `${lord}_${dchartKey}_vimsh`, weight: pts, layer: 2, type: 'dchart_vimsh' });
      }
    });

    // Check 2e: Special points (UL for marriage, GL for career)
    if (def.specialPoints.includes('UL') && arudhas.A12) {
      const ulHouse = arudhas.A12.finalArudhaHouse;
      if (ulHouse && vargaActive) {
        const ulSign = getSignFromHouse(lagnaCode, ulHouse);
        if (vargaActive.rasi === ulSign) {
          const pts = 25;
          l2Score += pts;
          reasons.push(`Narayana D9 dasa of UL sign (${ulSign}) — Upapada Lagna activated for marriage`);
          signals.push({ signal: 'UL_narayana_d9', weight: pts, layer: 2, type: 'special_point' });
        }
        // 3rd from UL = dasha of separation/marriage ending
        const thirdFromUL = getSignFromHouse(ulSign, 3);
        if (vargaActive.rasi === thirdFromUL) {
          concerns.push(`Narayana D9 running 3rd from UL (${thirdFromUL}) — potential separation indicator`);
        }
      }
    }

    if (def.specialPoints.includes('GL') && chart.specialLagnas?.GL) {
      const glSign = chart.specialLagnas.GL.signCode;
      if (vargaActive && vargaActive.rasi === glSign) {
        const pts = 20;
        l2Score += pts;
        reasons.push(`Narayana D10 dasa of GL (${glSign}) — Ghati Lagna activated for career`);
        signals.push({ signal: 'GL_narayana_d10', weight: pts, layer: 2, type: 'special_point' });
      }
    }

    l2Score = Math.min(l2Score, 100);
  }

  // Expose varga Narayana info in result
  const vargaNarayanaInfo = vargaActive ? {
    system: dchartKey.toUpperCase()+' Narayana',
    mahadasha: vargaActive.rasi,
    antardasha: vargaAD?.rasi || null,
    seed: vargaNarayana?.dseed,
    display: [vargaActive.rasi, vargaAD?.rasi].filter(Boolean).join(' / ')
  } : null;

  // ── LAYER 3: TRANSIT ANALYSIS ────────────────────────────────────────────────
  let l3Score = 0;

  if (transitData && chart.panchanga) {
    const moonSignCode = bodies?.Moon?.signCode;
    const moonNakIdx   = chart.panchanga?.nakshatra?.index ?? 0;
    const moonSignIdx  = SIGN_CODES.indexOf(moonSignCode);
    const lagnaSignIdx = SIGN_CODES.indexOf(lagnaCode);

    def.transitPrimary.forEach(planet => {
      const pos = transitData[planet];
      if (!pos) return;
      const transitSignCode = pos.signCode;
      const transitSignIdx  = SIGN_CODES.indexOf(transitSignCode);
      if (transitSignIdx < 0) return;

      // Good house from Moon?
      const houseFromMoon = ((transitSignIdx - moonSignIdx + 12) % 12) + 1;
      const isGoodFromMoon = GOOD_HOUSES_FROM_MOON[planet]?.includes(houseFromMoon);

      // Moorti
      const moorti = getMoorti(moonSignIdx, transitSignIdx);

      // Tara
      const nakIdx = Math.floor(((pos.longitude % 360) + 360) % 360 / (360/27));
      const tara = getTara(moonNakIdx, nakIdx);

      // Ashtakavarga
      let bavScore = null;
      let savScore = null;
      if (chart.ashtakavarga?.bav?.[planet]) {
        bavScore = chart.ashtakavarga.bav[planet][transitSignIdx];
        savScore = chart.ashtakavarga.sav[transitSignIdx];
      }

      // House from D1 lagna
      const houseFromLagnaNum = ((transitSignIdx - lagnaSignIdx + 12) % 12) + 1;
      const isRelevantHouse = def.primaryHouses.includes(houseFromLagnaNum);

      // Score this transit
      let planetTransitScore = 0;
      const planetReasons = [];

      if (isGoodFromMoon) {
        planetTransitScore += 20;
        planetReasons.push(`good house from Moon (H${houseFromMoon})`);
      }
      if (moorti.quality === 'excellent') { planetTransitScore += 20; planetReasons.push(`Swarna Moorti`); }
      else if (moorti.quality === 'good') { planetTransitScore += 12; planetReasons.push(`Rajata Moorti`); }
      else if (moorti.quality === 'weak') { planetTransitScore -= 10; concerns.push(`${planet} in Loha Moorti — weak transit`); }

      if (tara.quality === 'excellent') { planetTransitScore += 20; planetReasons.push(`Param Mitra Tara`); }
      else if (tara.quality === 'good')  { planetTransitScore += 15; planetReasons.push(`${tara.name} Tara (favorable)`); }
      else if (tara.quality === 'bad')   { planetTransitScore -= 15; concerns.push(`${planet} in ${tara.name} Tara — inauspicious`); }

      if (bavScore !== null) {
        if (bavScore >= 5) { planetTransitScore += 20; planetReasons.push(`BAV ${bavScore}/8 (strong)`); }
        else if (bavScore >= 4) { planetTransitScore += 10; planetReasons.push(`BAV ${bavScore}/8 (moderate)`); }
        else { planetTransitScore -= 5; concerns.push(`${planet} BAV only ${bavScore}/8`); }
      }
      if (savScore !== null) {
        if (savScore >= 30) { planetTransitScore += 10; planetReasons.push(`SAV ${savScore} (favorable sign)`); }
        else if (savScore < 25) { concerns.push(`SAV ${savScore} in transit sign — unfavorable`); }
      }

      if (isRelevantHouse) {
        planetTransitScore += 15;
        planetReasons.push(`in H${houseFromLagnaNum} (${def.label} house)`);
      }

      if (planetTransitScore > 0 && planetReasons.length > 0) {
        reasons.push(`${planet} transit: ${planetReasons.join(', ')}`);
      }

      l3Score += Math.max(0, planetTransitScore);

      signals.push({
        signal: `${planet}_transit`,
        weight: Math.max(0, planetTransitScore),
        layer: 3,
        type: 'transit',
        details: {
          sign: transitSignCode,
          houseFromMoon,
          houseFromLagna: houseFromLagnaNum,
          moorti: moorti.name,
          tara: tara.name,
          bav: bavScore,
          sav: savScore
        }
      });
    });

    l3Score = Math.min(l3Score, 100);
  }

  // ── LAYER 4: PHASE 7+10 — Degree Trigger + Karma Nakshatra ──────────────────
  let l4Score = 0;
  let l4Info  = null;
  try {
    const { analyzePhase7And10 } = require('./degree-trigger');
    const phase = analyzePhase7And10(chart, transitData, eventKey, eventDate);
    l4Score = Math.min(phase.combinedScore, 50);
    l4Info  = phase;

    // Add reasons from degree triggers
    phase.degreeTriggers.triggers.slice(0, 3).forEach(t => {
      reasons.push(`${t.orbLabel} degree trigger (${t.orb.toFixed(1)}°): ${t.transitPlanet} → natal ${t.natalLabel}`);
      signals.push({ signal:`degree_${t.transitPlanet}_${t.natalPoint}`, weight: t.score, layer:4, type:'degree_trigger' });
    });

    // Add karma nakshatra activations
    phase.karmaNakshatra.activations.forEach(a => {
      reasons.push(`Karma Nakshatra: ${a.description.slice(0, 80)}`);
      signals.push({ signal:`karma_nak_${a.planet}`, weight: a.score, layer:4, type:'karma_nakshatra' });
    });

    if (phase.highlights.length > 0) {
      signals.push({ signal:'phase7_10_summary', weight: l4Score, layer:4, type:'phase7_10', summary: phase.summary });
    }
  } catch(e) {
    // Phase 7+10 optional — don't fail if unavailable
  }
  // ── FINAL SCORE ──────────────────────────────────────────────────────────────
  // L1=30% + L2=30% + L3=25% + L4(degree+karma)=15%
  let l1Weight = 0.30, l2Weight = 0.30, l3Weight = 0.25, l4Weight = 0.15;

  // If L1 low but L2+L3 confirm — reduce L1 penalty
  if (l1Score < 30 && l2Score >= 25 && l3Score >= 60) {
    l1Weight = 0.20; l2Weight = 0.35; l3Weight = 0.30; l4Weight = 0.15;
  }

  const rawScore = Math.round(
    l1Score * l1Weight + l2Score * l2Weight +
    l3Score * l3Weight + l4Score * l4Weight
  );

  // ── CONVERGENCE ENGINE ───────────────────────────────────────────────────────
  // Check if multiple signals come from truly independent sources
  // Same planet driving L1 + L2 = NOT independent
  const { applyConvergence } = require('./convergence-engine');
  const l2Active = l2Score > 15;
  const l3Active = l3Score > 30;
  const l4Active = l4Score > 10;

  const { adjusted: finalScore, convergence } = applyConvergence(rawScore, signals, eventKey);

  // Add convergence warning if relevant
  if (convergence.warning) {
    concerns.push(`Convergence: ${convergence.warning}`);
  }
  if (convergence.level === 'none' || convergence.level === 'low') {
    concerns.push(`Convergence: ${convergence.summary}`);
  }

  // Tier
  let tier, tierLabel;
  if (finalScore >= 70) { tier = 'strong';   tierLabel = 'Strong confirmation — birth time reliable'; }
  else if (finalScore >= 50) { tier = 'moderate'; tierLabel = 'Moderate confirmation'; }
  else if (finalScore >= 30) { tier = 'weak';    tierLabel = 'Weak match — verify birth time'; }
  else                   { tier = 'poor';     tierLabel = 'Poor match — birth time suspect or event not chart-driven'; }

  return {
    eventKey,
    eventLabel,
    eventDate,
    age,
    // Dasha at event
    vimshottari: {
      mahadasha: activeMD,
      antardasha: activeAD,
      pratyantardasha: activePD,
      display: [activeMD, activeAD, activePD].filter(Boolean).join(' / ')
    },
    narayana: {
      mahadasha: activeNar,
      antardasha: activeNarAD,
      display: [activeNar, activeNarAD].filter(Boolean).join(' / ')
    },
    // Karakas active
    karakaActive: {
      naturalKaraka: def.naturalKarakas[0],
      isNaturalKarakaInMDAD: def.naturalKarakas.some(k => k === activeMD || k === activeAD),
      charaKaraka: charaKarakaName,
      charaKarakaPlanet,
      isCharaKarakaActive: charaKarakaPlanet === activeMD || charaKarakaPlanet === activeAD || charaKarakaPlanet === activePD,
      genderKaraka: def.genderKaraka && nativeGender ? {
        planet: def.genderKaraka[nativeGender],
        gender: nativeGender,
        role: nativeGender==='female' ? 'Jupiter — sthira karaka of husband (PVR Ch.8.3)' : 'Venus — sthira karaka of wife (PVR Ch.8.3)',
        note: 'Primarily for death timing; secondary signal for marriage'
      } : null,
    },
    // Varga Narayana (D9/D10/D7)
    vargaNarayana: vargaNarayanaInfo,
    // Scores
    l1Score: Math.min(100, l1Score),
    l2Score: Math.min(100, l2Score),
    l3Score: Math.min(100, l3Score),
    l4Score: Math.min(50, l4Score),
    phase7_10: l4Info,
    convergence,
    finalScore,
    tier,
    tierLabel,
    // Evidence
    reasons: reasons.slice(0, 8),     // top 8 supporting reasons
    concerns: concerns.slice(0, 4),   // top 4 concerns
    signals,
    // Transit at event date
    transitPositions: transitData,
    // BTR signal
    btrSignal: finalScore < 35 ? 'Consider birth time adjustment' :
               finalScore < 50 ? 'Partial chart match — review' : null,
  };
}

// ── Helper functions ──────────────────────────────────────────────────────────

function findDashaAtDate(vimshottariDashas, dateStr) {
  if (!vimshottariDashas) return null;
  const dashaArr = Array.isArray(vimshottariDashas) ? vimshottariDashas : Object.values(vimshottariDashas);

  for (const md of dashaArr) {
    if (!md || md.startDate > dateStr || md.endDate <= dateStr) continue;
    const adArr = md.antardashas || md.antardasha || [];
    let foundMD = md.lord || md.mahadasha;
    for (const ad of adArr) {
      if (!ad || ad.startDate > dateStr || ad.endDate <= dateStr) continue;
      const pdArr = ad.pratyantardashas || ad.pratyantardasha || [];
      let foundAD = ad.lord || ad.antardasha;
      for (const pd of pdArr) {
        if (!pd || pd.startDate > dateStr || pd.endDate <= dateStr) continue;
        return { mahadasha: foundMD, antardasha: foundAD, pratyantardasha: pd.lord || pd.pratyantardasha };
      }
      return { mahadasha: foundMD, antardasha: foundAD, pratyantardasha: null };
    }
    return { mahadasha: foundMD, antardasha: null, pratyantardasha: null };
  }
  return null;
}

function findNarayanaAtDate(dasas, dateStr) {
  if (!dasas) return null;
  for (const md of dasas) {
    if (md.startDate <= dateStr && md.endDate > dateStr) {
      const ad = (md.antardasas || []).find(a => a.startDate <= dateStr && a.endDate > dateStr);
      return { mahadasha: md.rasi, antardasha: ad?.rasi || null };
    }
  }
  return null;
}

function buildHouseRulerships(lagnaCode, bodies) {
  // Standard sign lordships
  const SIGN_LORDS = {
    Ar:'Mars', Ta:'Venus', Ge:'Mercury', Cn:'Moon', Le:'Sun', Vi:'Mercury',
    Li:'Venus', Sc:'Mars', Sg:'Jupiter', Cp:'Saturn', Aq:'Saturn', Pi:'Jupiter'
  };
  const lagnaIdx = SIGN_CODES.indexOf(lagnaCode);
  const rulerships = {};
  for (let h = 1; h <= 12; h++) {
    const signCode = SIGN_CODES[(lagnaIdx + h - 1) % 12];
    rulerships[h] = SIGN_LORDS[signCode];
  }
  return rulerships;
}

function getRasiAspects(signCode) {
  const idx = SIGN_CODES.indexOf(signCode);
  if (idx < 0) return [];
  const IS_MOVABLE = [1,0,0,1,0,0,1,0,0,1,0,0];
  const IS_FIXED   = [0,1,0,0,1,0,0,1,0,0,1,0];
  const IS_DUAL    = [0,0,1,0,0,1,0,0,1,0,0,1];
  if (IS_MOVABLE[idx]) return ['Ta','Le','Sc','Aq'].filter(s=>s!==signCode);
  if (IS_FIXED[idx])   return ['Ge','Vi','Sg','Pi'].filter(s=>s!==signCode);
  if (IS_DUAL[idx])    return ['Ar','Cn','Li','Cp'].filter(s=>s!==signCode);
  return [];
}

function getSignFromHouse(lagnaCode, houseNum) {
  const lagnaIdx = SIGN_CODES.indexOf(lagnaCode);
  return SIGN_CODES[(lagnaIdx + houseNum - 1) % 12];
}

module.exports = { verifyPastEvent, EVENT_DEFINITIONS, findDashaAtDate };
