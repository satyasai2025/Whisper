/**
 * Section Router (v2)
 *
 * Splits raw JHora text into named sections using FLEXIBLE regex anchors.
 * pdf-parse output may collapse or insert whitespace inconsistently
 * (e.g. "BodyLongitudeNakshatra", "Natal Chart\nRasi"), so we match
 * with `\s*` allowing zero or more whitespace between key tokens.
 */

const SECTION_ANCHORS = [
  // Body table — pdf-parse may collapse spaces between header words
  { key: 'bodyTable',           pattern: /Body\s*Longitude\s*Nakshatra/ },

  // Vimshottari and variations — check Tribhagi BEFORE generic Vimsottari Dasa
  { key: 'vimshottariTribhagi', pattern: /Vimsottari Dasa - Tribhagi/ },
  { key: 'vimshottari',         pattern: /Vimsottari Dasa\s*\(\)/ },

  // Strengths and qualities
  { key: 'ashtakavarga',        pattern: /Ashtakavarga of Rasi Chart:/ },
  { key: 'pinda',               pattern: /Planet\s*Sodhya\s*Pinda/ },
  { key: 'bhavaBala',           pattern: /House\s*Bhava\s*Bala/ },
  { key: 'shadbala',            pattern: /Planet\s*Shadbala/ },
  { key: 'avastha',             pattern: /Planet\s*Age\s*Alertness/ },
  { key: 'activity',            pattern: /Planet\s*Activity\b/ },
  { key: 'vaiseshikamsas',      pattern: /Vaiseshikamsas\b/ },
  { key: 'vimsopaka',           pattern: /Vimsopaka\b/ },

  // Conditional dashas — set A
  { key: 'ashtottari',          pattern: /Ashtottari Dasa/ },
  { key: 'kalachakra',          pattern: /Kalachakra Dasa/ },
  { key: 'moola',               pattern: /Moola Dasa/ },

  // Phalita rasi dashas — set A
  { key: 'narayana',            pattern: /Narayana Dasa of D-1/ },
  { key: 'sudasa',              pattern: /Sudasa\b/ },

  // Phalita rasi dashas — set B
  { key: 'lagnaKendradi',       pattern: /Lagna Kendradi Rasi Dasa/ },
  { key: 'drigdasa',            pattern: /Drigdasa of D-1/ },

  // Death / trouble
  { key: 'shoola',              pattern: /Shoola dasa/ },
  { key: 'niryanaShoola',       pattern: /Niryana Shoola Dasa/ },

  // Yogini
  { key: 'yogini',              pattern: /Yogini Dasa/ },

  // Divisional charts — CHECK SPECIFIC NUMBERS BEFORE GENERIC (D-10 before D-1, etc.)
  { key: 'd60Chart',  pattern: /Natal Chart\s*D-60/ },
  { key: 'd45Chart',  pattern: /Natal Chart\s*D-45/ },
  { key: 'd40Chart',  pattern: /Natal Chart\s*D-40/ },
  { key: 'd30Chart',  pattern: /Natal Chart\s*D-30/ },
  { key: 'd27Chart',  pattern: /Natal Chart\s*D-27/ },
  { key: 'd24Chart',  pattern: /Natal Chart\s*D-24/ },
  { key: 'd20Chart',  pattern: /Natal Chart\s*D-20/ },
  { key: 'd16Chart',  pattern: /Natal Chart\s*D-16/ },
  { key: 'd12Chart',  pattern: /Natal Chart\s*D-12/ },
  { key: 'd11Chart',  pattern: /Natal Chart\s*D-11/ },
  { key: 'd10Chart',  pattern: /Natal Chart\s*D-10/ },
  { key: 'd9Chart',   pattern: /Natal Chart\s*D-9/ },
  { key: 'd8Chart',   pattern: /Natal Chart\s*D-8/ },
  { key: 'd7Chart',   pattern: /Natal Chart\s*D-7/ },
  { key: 'd6Chart',   pattern: /Natal Chart\s*D-6/ },
  { key: 'd5Chart',   pattern: /Natal Chart\s*D-5/ },
  { key: 'd4Chart',   pattern: /Natal Chart\s*D-4/ },
  { key: 'd3Chart',   pattern: /Natal Chart\s*D-3/ },
  { key: 'd2Chart',   pattern: /Natal Chart\s*D-2/ },
  { key: 'd1Chart',   pattern: /Natal Chart\s*Rasi/ }
];

function splitSections(rawText) {
  const found = [];

  for (const { key, pattern } of SECTION_ANCHORS) {
    const m = pattern.exec(rawText);
    if (m) {
      found.push({ key, position: m.index, matchLength: m[0].length });
    }
  }

  found.sort((a, b) => a.position - b.position);

  const sections = {};
  if (found.length === 0) {
    sections.header = rawText.trim();
    return sections;
  }

  sections.header = rawText.substring(0, found[0].position).trim();

  for (let i = 0; i < found.length; i++) {
    const current = found[i];
    const next = found[i + 1];
    const start = current.position;
    const end = next ? next.position : rawText.length;
    sections[current.key] = rawText.substring(start, end).trim();
  }

  return sections;
}

module.exports = { splitSections, SECTION_ANCHORS };
