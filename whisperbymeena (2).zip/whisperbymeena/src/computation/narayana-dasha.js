/**
 * Narayana Dasha Computation
 * Source: PVR Narasimha Rao "Vedic Astrology: An Integrated Approach" Ch.18
 *
 * Ch.18.1 Introduction: "most important rasi dasa, phalita dasa, shows general results"
 * Ch.18.2.1 Dasa Progression: Table 40 (all 12 seeds, 3 cases each)
 * Ch.18.2.2 Dasa Length: lord counting, exaltation/debilitation exception
 * Ch.18.3 Antardasas: 12 equal parts, antardasa seed, direction rules
 * Ch.18.4 Interpretation: dasa lagna, paaka rasi rules
 * Ch.15.5.2 Stronger Rasi: 6-rule comparison
 * Ch.15.5.1 Stronger Co-Lord: rules for Sc and Aq
 *
 * Also covers from same chapter/session:
 * Ch.19 Lagna Kendradi Rasi Dasha (material success)
 * Ch.20 Sudasa (wealth, power — seed = Sree Lagna)
 * Ch.21 Drigdasha (spiritual only — seed = 9th house)
 */

'use strict';

// Sign indices 0-11 (Ar=0 ... Pi=11)
const SIGN_CODES  = ['Ar','Ta','Ge','Cn','Le','Vi','Li','Sc','Sg','Cp','Aq','Pi'];
const SIGN_NAMES  = ['Aries','Taurus','Gemini','Cancer','Leo','Virgo',
                     'Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'];

// Sign properties (Ch.2)
const IS_ODD       = [1,0,1,0,1,0,1,0,1,0,1,0]; // Ar,Ge,Le,Li,Sg,Aq = odd
const IS_ODD_FOOTED= [1,1,1,0,0,0,1,1,1,0,0,0]; // Ar,Ta,Ge,Li,Sc,Sg = odd-footed
const IS_MOVABLE   = [1,0,0,1,0,0,1,0,0,1,0,0]; // Ar,Cn,Li,Cp
const IS_FIXED     = [0,1,0,0,1,0,0,1,0,0,1,0]; // Ta,Le,Sc,Aq
const IS_DUAL      = [0,0,1,0,0,1,0,0,1,0,0,1]; // Ge,Vi,Sg,Pi

// Sign lords (primary lord for single-lord signs; for Sc=Mars primary, Aq=Saturn primary by default)
// Co-lords: Sc → Mars/Ketu; Aq → Saturn/Rahu
const SIGN_LORDS   = ['Mars','Venus','Mercury','Moon','Sun','Mercury',
                      'Venus','Mars','Jupiter','Saturn','Saturn','Jupiter'];
const CO_LORDS     = { Sc: ['Mars','Ketu'], Aq: ['Saturn','Rahu'] };

// Exaltation/debilitation signs for dasa length correction
const EXALTED_IN   = { Sun:'Ar', Moon:'Ta', Mars:'Cp', Mercury:'Vi',
                       Jupiter:'Cn', Venus:'Pi', Saturn:'Li' };
const DEBILITATED_IN = { Sun:'Li', Moon:'Sc', Mars:'Cn', Mercury:'Pi',
                         Jupiter:'Cp', Venus:'Vi', Saturn:'Ar' };
// Rahu/Ketu exaltation: Rahu in Ta/Ge (controversial — PVR uses Ge), Ketu in Sg
const RAHU_EXALTED = 'Ge'; const KETU_EXALTED = 'Sg';
const RAHU_DEBI    = 'Sg'; const KETU_DEBI    = 'Ge';

// Table 40 (Ch.18, p.234-235) — complete dasa progression for each seed
const NARAYANA_TABLE_40 = {
  Ar: { normal:'Ar,Ta,Ge,Cn,Le,Vi,Li,Sc,Sg,Cp,Aq,Pi', saturn:'Ar,Ta,Ge,Cn,Le,Vi,Li,Sc,Sg,Cp,Aq,Pi', ketu:'Ar,Pi,Aq,Cp,Sg,Sc,Li,Vi,Le,Cn,Ge,Ta' },
  Ta: { normal:'Ta,Sg,Cn,Aq,Vi,Ar,Sc,Ge,Cp,Le,Pi,Li', saturn:'Ta,Ge,Cn,Le,Vi,Li,Sc,Sg,Cp,Aq,Pi,Ar', ketu:'Ta,Li,Pi,Le,Cp,Ge,Sc,Ar,Vi,Aq,Cn,Sg' },
  Ge: { normal:'Ge,Aq,Li,Vi,Ta,Cp,Sg,Le,Ar,Pi,Sc,Cn', saturn:'Ge,Cn,Le,Vi,Li,Sc,Sg,Cp,Aq,Pi,Ar,Ta', ketu:'Ge,Li,Aq,Pi,Cn,Sc,Sg,Ar,Le,Vi,Cp,Ta' },
  Cn: { normal:'Cn,Ge,Ta,Ar,Pi,Aq,Cp,Sg,Sc,Li,Vi,Le', saturn:'Cn,Le,Vi,Li,Sc,Sg,Cp,Aq,Pi,Ar,Ta,Ge', ketu:'Cn,Le,Vi,Li,Sc,Sg,Cp,Aq,Pi,Ar,Ta,Ge' },
  Le: { normal:'Le,Cp,Ge,Sc,Ar,Vi,Aq,Cn,Sg,Ta,Li,Pi', saturn:'Le,Vi,Li,Sc,Sg,Cp,Aq,Pi,Ar,Ta,Ge,Cn', ketu:'Le,Pi,Li,Ta,Sg,Cn,Aq,Vi,Ar,Sc,Ge,Cp' },
  Vi: { normal:'Vi,Cp,Ta,Ge,Li,Aq,Pi,Cn,Sc,Sg,Ar,Le', saturn:'Vi,Li,Sc,Sg,Cp,Aq,Pi,Ar,Ta,Ge,Cn,Le', ketu:'Vi,Ta,Cp,Sg,Le,Ar,Pi,Sc,Cn,Ge,Aq,Li' },
  Li: { normal:'Li,Sc,Sg,Cp,Aq,Pi,Ar,Ta,Ge,Cn,Le,Vi', saturn:'Li,Sc,Sg,Cp,Aq,Pi,Ar,Ta,Ge,Cn,Le,Vi', ketu:'Li,Vi,Le,Cn,Ge,Ta,Ar,Pi,Aq,Cp,Sg,Sc' },
  Sc: { normal:'Sc,Ge,Cp,Le,Pi,Li,Ta,Sg,Cn,Aq,Vi,Ar', saturn:'Sc,Sg,Cp,Aq,Pi,Ar,Ta,Ge,Cn,Le,Vi,Li', ketu:'Sc,Ar,Vi,Aq,Cn,Sg,Ta,Li,Pi,Le,Cp,Ge' },
  Sg: { normal:'Sg,Le,Ar,Pi,Sc,Cn,Ge,Aq,Li,Vi,Ta,Cp', saturn:'Sg,Cp,Aq,Pi,Ar,Ta,Ge,Cn,Le,Vi,Li,Sc', ketu:'Sg,Ar,Le,Vi,Cp,Ta,Ge,Li,Aq,Pi,Cn,Sc' },
  Cp: { normal:'Cp,Sg,Sc,Li,Vi,Le,Cn,Ge,Ta,Ar,Pi,Aq', saturn:'Cp,Aq,Pi,Ar,Ta,Ge,Cn,Le,Vi,Li,Sc,Sg', ketu:'Cp,Aq,Pi,Ar,Ta,Ge,Cn,Le,Vi,Li,Sc,Sg' },
  Aq: { normal:'Aq,Cn,Sg,Ta,Li,Pi,Le,Cp,Ge,Sc,Ar,Vi', saturn:'Aq,Pi,Ar,Ta,Ge,Cn,Le,Vi,Li,Sc,Sg,Cp', ketu:'Aq,Vi,Ar,Sc,Ge,Cp,Le,Pi,Li,Ta,Sg,Cn' },
  Pi: { normal:'Pi,Cn,Sc,Sg,Ar,Le,Vi,Cp,Ta,Ge,Li,Aq', saturn:'Pi,Ar,Ta,Ge,Cn,Le,Vi,Li,Sc,Sg,Cp,Aq', ketu:'Pi,Sc,Cn,Ge,Aq,Li,Vi,Ta,Cp,Sg,Le,Ar' },
};

// ─────────────────────────────────────────────────────────────────────────────

/** Convert sign code to 0-based index */
function signIdx(code) { return SIGN_CODES.indexOf(code); }

/** Count houses from sign A to sign B (forward=zodiacal, backward=anti-zodiacal) */
function countHouses(fromCode, toCode, forward) {
  const f = signIdx(fromCode), t = signIdx(toCode);
  if (forward) return ((t - f + 12) % 12) + 1;
  else         return ((f - t + 12) % 12) + 1;
}

/** Compute houses forward/backward from a sign (returns 1-12 array) */
function houseSequence(fromCode, forward) {
  const f = signIdx(fromCode);
  return Array.from({length:12}, (_,i) => SIGN_CODES[forward ? (f+i)%12 : ((f-i+12*100)%12)]);
}

/** Get sign n houses away from fromCode (1-based, forward=zodiacal) */
function nthHouse(fromCode, n, forward) {
  const f = signIdx(fromCode);
  if (forward) return SIGN_CODES[(f + n - 1) % 12];
  else         return SIGN_CODES[((f - n + 1) % 12 + 12*100) % 12];
}

/**
 * Stronger Rasi — Ch.15.5.2 (6 rules)
 * Returns 'a' or 'b' (whichever is stronger)
 */
function strongerRasi(codeA, codeB, bodies) {
  const a = codeA, b = codeB;
  if (a === b) return a;

  // Rule 1: more planets
  const countPlanets = (s) => Object.values(bodies).filter(p => p.signCode === s).length;
  const ca = countPlanets(a), cb = countPlanets(b);
  if (ca !== cb) return ca > cb ? a : b;

  // Rule 2: occupied/aspected by Jupiter, Mercury, or rasi lord (using rasi aspect)
  // For simplicity: count how many of {Jupiter, Mercury, lord} occupy OR have rasi aspect on the sign
  const getRasiAspects = (signCode) => {
    // A sign aspects signs of a different mode:
    // Movable aspects Fixed (not adjacent); Fixed aspects Dual; Dual aspects Movable
    const idx = signIdx(signCode);
    if (IS_MOVABLE[idx]) return ['Ta','Le','Sc','Aq'].filter(s => s !== signCode);
    if (IS_FIXED[idx])   return ['Ge','Vi','Sg','Pi'].filter(s => s !== signCode);
    if (IS_DUAL[idx])    return ['Ar','Cn','Li','Cp'].filter(s => s !== signCode);
    return [];
  };

  const aspectsFrom = (fromCode) => {
    const aspected = getRasiAspects(fromCode);
    return aspected;
  };

  const influenceCount = (s) => {
    let count = 0;
    const LORD = SIGN_LORDS[signIdx(s)]; // simplified: single lord
    for (const p of ['Jupiter','Mercury',LORD]) {
      const body = bodies[p];
      if (!body) continue;
      if (body.signCode === s) { count++; continue; }
      // Does p aspect s?
      const pAspects = aspectsFrom(body.signCode);
      if (pAspects.includes(s)) count++;
    }
    return count;
  };

  const ia = influenceCount(a), ib = influenceCount(b);
  if (ia !== ib) return ia > ib ? a : b;

  // Rule 3: contains exalted planet
  const hasExalted = (s) => Object.entries(EXALTED_IN).some(([p, es]) => es === s && bodies[p]?.signCode === s);
  const ea = hasExalted(a), eb = hasExalted(b);
  if (ea !== eb) return ea ? a : b;

  // Rule 4: lord in rasi of different oddity
  const lordInDiffOddity = (s) => {
    const lord = SIGN_LORDS[signIdx(s)];
    const body = bodies[lord];
    if (!body) return false;
    return IS_ODD[signIdx(s)] !== IS_ODD[signIdx(body.signCode)];
  };
  const da = lordInDiffOddity(a), db = lordInDiffOddity(b);
  if (da !== db) return da ? a : b;

  // Rule 5: natural strength Dual > Fixed > Movable (not useful for 7th-house pairs, same type)
  const naturalStr = (s) => IS_DUAL[signIdx(s)] ? 3 : IS_FIXED[signIdx(s)] ? 2 : 1;
  const na = naturalStr(a), nb = naturalStr(b);
  if (na !== nb) return na > nb ? a : b;

  // Rule 6: lord more advanced in its rasi
  const lordAdvancement = (s) => {
    const lord = SIGN_LORDS[signIdx(s)];
    const body = bodies[lord];
    if (!body) return 0;
    if (lord === 'Rahu' || lord === 'Ketu') return 30 - (body.longitudeInSign || 0); // from end
    return body.longitudeInSign || 0;
  };
  const la = lordAdvancement(a), lb = lordAdvancement(b);
  return la >= lb ? a : b;
}

/**
 * Stronger Co-Lord — Ch.15.5.1
 * For Sc (Mars/Ketu) and Aq (Saturn/Rahu)
 */
function strongerCoLord(signCode, bodies) {
  const coLords = CO_LORDS[signCode];
  if (!coLords) return SIGN_LORDS[signIdx(signCode)];

  const [p1, p2] = coLords;
  const b1 = bodies[p1], b2 = bodies[p2];

  // Basic rule: if one co-lord IS in the sign, take the other
  if (b1?.signCode === signCode && b2?.signCode !== signCode) return p2;
  if (b2?.signCode === signCode && b1?.signCode !== signCode) return p1;

  // Rule 1: joined by more planets
  const companions = (p) => Object.entries(bodies).filter(([k,v]) => k!==p && v.signCode===bodies[p]?.signCode).length;
  const c1 = companions(p1), c2 = companions(p2);
  if (c1 !== c2) return c1 > c2 ? p1 : p2;

  // Rule 2: Jupiter, Mercury, dispositor aspect/conjoin
  // Simplified: check if exalted
  const isExalted = (p) => {
    const b = bodies[p]; if (!b) return false;
    if (p==='Rahu') return b.signCode === RAHU_EXALTED;
    if (p==='Ketu') return b.signCode === KETU_EXALTED;
    return EXALTED_IN[p] === b.signCode;
  };
  if (isExalted(p1) && !isExalted(p2)) return p1;
  if (isExalted(p2) && !isExalted(p1)) return p2;

  // Rule 4: planet in stronger rasi type
  const rasistr = (p) => {
    const b = bodies[p]; if (!b) return 0;
    return IS_DUAL[signIdx(b.signCode)] ? 3 : IS_FIXED[signIdx(b.signCode)] ? 2 : 1;
  };
  const r1 = rasistr(p1), r2 = rasistr(p2);
  if (r1 !== r2) return r1 > r2 ? p1 : p2;

  // Rule 5(a) for dasa: take planet giving larger dasa length
  // (fallback — both equal, return first)
  return p1;
}

/**
 * Compute dasa length for a rasi — Ch.18.2.2
 * Count from dasa rasi to its lord (forward if odd-footed, backward if even-footed)
 * Subtract 1. Exalted lord: +1. Debilitated lord: -1. If count=1, dasa=12.
 */
function dasaLength(dasaCode, bodies) {
  const idx = signIdx(dasaCode);
  const forward = IS_ODD_FOOTED[idx] === 1;

  // Get lord (handle co-lords for Sc and Aq)
  let lord;
  if (dasaCode === 'Sc' || dasaCode === 'Aq') {
    lord = strongerCoLord(dasaCode, bodies);
  } else {
    lord = SIGN_LORDS[idx];
  }

  const lordBody = bodies[lord];
  if (!lordBody) return 12; // fallback

  const lordSign = lordBody.signCode;
  const count = countHouses(dasaCode, lordSign, forward);

  let years = count === 1 ? 12 : count - 1;

  // Exaltation / debilitation correction
  const isExalted = (lord === 'Rahu') ? lordSign === RAHU_EXALTED
                  : (lord === 'Ketu') ? lordSign === KETU_EXALTED
                  : EXALTED_IN[lord] === lordSign;
  const isDebi    = (lord === 'Rahu') ? lordSign === RAHU_DEBI
                  : (lord === 'Ketu') ? lordSign === KETU_DEBI
                  : DEBILITATED_IN[lord] === lordSign;

  if (isExalted) years += 1;
  if (isDebi)    years -= 1;
  if (years < 0) years = 0;
  if (years > 12) years = 12;

  return years;
}

/**
 * Add years to a date string (YYYY-MM-DD) using Sun's arc measurement.
 * Ch.18.6: "1 year = Sun moves 30°. Time is measured by Sun's arc."
 * Simplified: add fractional years to date via Julian day arithmetic.
 * (Full sun-arc tracking would require ephemeris calls — use calendar approximation here,
 *  refine later with actual sun position tracking)
 */
function addYearsToDate(dateStr, years) {
  const d = new Date(dateStr);
  const totalDays = years * 365.25636; // tropical year
  d.setTime(d.getTime() + totalDays * 86400000);
  return d.toISOString().split('T')[0];
}

/**
 * Find dasa seed — stronger of lagna and 7th house
 */
function findDasaSeed(lagnaCode, bodies) {
  const seventh = SIGN_CODES[(signIdx(lagnaCode) + 6) % 12];
  return strongerRasi(lagnaCode, seventh, bodies);
}

/**
 * Get progression key based on Saturn/Ketu in seed
 */
function progressionKey(seedCode, bodies) {
  const hasSaturn = bodies['Saturn']?.signCode === seedCode;
  const hasKetu   = bodies['Ketu']?.signCode === seedCode;
  if (hasSaturn) return 'saturn';
  if (hasKetu)   return 'ketu';
  return 'normal';
}

/**
 * Compute first-cycle remainder fraction for first dasa at birth.
 * "Only a fraction of first dasa is left at birth."
 * Uses lagna advancement in its sign (standard Narayana start fraction).
 * For Sudasa: uses SL advancement.
 */
function firstDasaRemainder(seedCode, bodies, lagnaLon) {
  // Fraction remaining in first dasa = (30 - lagna_deg_in_sign) / 30
  const lagnaAdvancement = lagnaLon % 30; // degrees in sign (0-30)
  return (30 - lagnaAdvancement) / 30;
}

/**
 * Compute antardasa seed (stronger of dasa rasi and 7th from it).
 */
function antardasaSeed(dasaCode, bodies) {
  const seventh = SIGN_CODES[(signIdx(dasaCode) + 6) % 12];
  return strongerRasi(dasaCode, seventh, bodies);
}

/**
 * Compute antardasa direction.
 * Ch.18.3: "forward or backward based on whether the rasi from which antardasas
 *   start is an odd rasi or even rasi" (odd/even, not odd-footed/even-footed)
 * Exception: Saturn in antardasa seed → forward; Ketu in antardasa seed → reversed.
 */
function antardasaDirection(startCode, bodies) {
  const hasSaturn = bodies['Saturn']?.signCode === startCode;
  const hasKetu   = bodies['Ketu']?.signCode === startCode;
  let forward = IS_ODD[signIdx(startCode)] === 1;
  if (hasSaturn) forward = true;   // Saturn exception: forward
  if (hasKetu)   forward = !forward; // Ketu exception: reverse
  return forward;
}

/**
 * Find where antardasa sequence starts (rasi containing lord of antardasa seed).
 */
function antardasaStart(dasaCode, bodies) {
  const seed = antardasaSeed(dasaCode, bodies);
  let lord;
  if (seed === 'Sc' || seed === 'Aq') lord = strongerCoLord(seed, bodies);
  else lord = SIGN_LORDS[signIdx(seed)];
  return bodies[lord]?.signCode || seed;
}

/**
 * Compute full Narayana Dasha sequence for a given seed.
 * Returns array of { rasi, rasiName, years, cycle } — does not include dates yet.
 */
function computeNarayanaSequence(seedCode, bodies, maxYears) {
  const key = progressionKey(seedCode, bodies);
  const progression = NARAYANA_TABLE_40[seedCode][key].split(',');

  // First cycle lengths
  const firstCycle = progression.map(r => ({ rasi: r, rasiName: SIGN_NAMES[signIdx(r)], years: dasaLength(r, bodies), cycle: 1 }));

  // Second cycle: each dasa length = 12 - first_cycle_length
  const secondCycle = progression.map((r, i) => ({ rasi: r, rasiName: SIGN_NAMES[signIdx(r)], years: 12 - firstCycle[i].years, cycle: 2 }));

  return [...firstCycle, ...secondCycle];
}

/**
 * Main: Compute Narayana Dasha with dates.
 *
 * @param {string} lagnaCode     - Lagna sign code (e.g. 'Ta')
 * @param {object} bodies        - planets object from bodies-builder
 * @param {number} lagnaLon      - Lagna sidereal longitude (for first dasa fraction)
 * @param {string} birthDate     - 'YYYY-MM-DD'
 * @param {number} maxYears      - how many years to compute (default 120)
 * @returns {object} { seed, progression, dasas: [{rasi, rasiName, years, startDate, endDate, antardasas}] }
 */
function computeNarayanaDasha(lagnaCode, bodies, lagnaLon, birthDate, maxYears) {
  maxYears = maxYears || 120;

  const seed = findDasaSeed(lagnaCode, bodies);
  const key  = progressionKey(seed, bodies);
  const sequence = computeNarayanaSequence(seed, bodies, maxYears);

  // First dasa remainder
  const firstFraction = firstDasaRemainder(seed, bodies, lagnaLon);

  const dasas = [];
  let currentDate = birthDate;
  let totalYears = 0;

  for (let i = 0; i < sequence.length; i++) {
    const { rasi, rasiName, years, cycle } = sequence[i];
    let effectiveYears = (i === 0) ? years * firstFraction : years;

    if (totalYears + effectiveYears > maxYears) {
      effectiveYears = maxYears - totalYears;
    }

    const startDate = currentDate;
    const endDate   = addYearsToDate(currentDate, effectiveYears);

    // Compute antardasas
    const antardasas = [];
    if (effectiveYears > 0 && years > 0) {
      const adStartCode = antardasaStart(rasi, bodies);
      const adForward   = antardasaDirection(adStartCode, bodies);
      const adSequence  = houseSequence(adStartCode, adForward);
      // Each antardasa = total_dasa_months / 12 months = effectiveYears * 12 / 12 months each
      const adDurationYears = effectiveYears / 12;
      let adCurrent = startDate;

      for (let j = 0; j < 12; j++) {
        const adRasi = adSequence[j];
        const adStart = adCurrent;
        const adEnd   = addYearsToDate(adCurrent, adDurationYears);
        antardasas.push({ rasi: adRasi, rasiName: SIGN_NAMES[signIdx(adRasi)], startDate: adStart, endDate: adEnd });
        adCurrent = adEnd;
      }
    }

    dasas.push({ rasi, rasiName, years: effectiveYears, cycle, startDate, endDate, antardasas });
    currentDate = endDate;
    totalYears += effectiveYears;
    if (totalYears >= maxYears) break;
  }

  return {
    system: 'Narayana',
    seed,
    progressionKey: key,
    lagnaCode,
    dasas
  };
}

/**
 * Compute Lagna Kendradi Rasi Dasha — Ch.19
 * Seed = stronger of lagna and 7th.
 * Direction: forward if lagna is odd sign, backward if even sign.
 * Saturn in seed → forward; Ketu in seed → reversed.
 * Sequence: kendras (1,4,7,10), panapharas (2,5,8,11), apoklimas (3,6,9,12) from seed.
 * Dasa lengths: same as Narayana dasa rules.
 */
function computeLagnaKendradiDasha(lagnaCode, bodies, lagnaLon, birthDate, maxYears) {
  maxYears = maxYears || 120;

  const seed = findDasaSeed(lagnaCode, bodies);

  // Direction based on LAGNA (not seed) sign — Ch.19: "forward or backward based on lagna"
  let forward = IS_ODD[signIdx(lagnaCode)] === 1;
  if (bodies['Saturn']?.signCode === seed) forward = true;
  if (bodies['Ketu']?.signCode   === seed) forward = !forward;

  // Sequence: kendras, panapharas, apoklimas
  const kendra    = [1,4,7,10].map(n => nthHouse(seed, n, forward));
  const panaphara = [2,5,8,11].map(n => nthHouse(seed, n, forward));
  const apoklima  = [3,6,9,12].map(n => nthHouse(seed, n, forward));
  const sequence  = [...kendra, ...panaphara, ...apoklima];

  // First dasa remainder (same rule as Narayana)
  const firstFraction = firstDasaRemainder(seed, bodies, lagnaLon);

  const dasas = [];
  let currentDate = birthDate;
  let totalYears = 0;

  // Two cycles
  for (let cycle = 1; cycle <= 2; cycle++) {
    for (let i = 0; i < sequence.length; i++) {
      const rasi = sequence[i];
      let years = dasaLength(rasi, bodies);
      if (cycle === 2) years = 12 - dasaLength(rasi, bodies);
      let effectiveYears = (cycle === 1 && i === 0) ? years * firstFraction : years;
      if (totalYears + effectiveYears > maxYears) effectiveYears = maxYears - totalYears;

      const startDate = currentDate;
      const endDate   = addYearsToDate(currentDate, effectiveYears);
      dasas.push({ rasi, rasiName: SIGN_NAMES[signIdx(rasi)], years: effectiveYears, cycle, startDate, endDate });
      currentDate = endDate;
      totalYears += effectiveYears;
      if (totalYears >= maxYears) break;
    }
    if (totalYears >= maxYears) break;
  }

  return { system: 'LagnaKendradi', seed, dasas };
}

/**
 * Compute Sudasa — Ch.20
 * Seed = sign containing Sree Lagna (SL).
 * Direction: forward if SL in odd sign, backward if even sign.
 * Sequence: kendras, panapharas, apoklimas from SL sign.
 * First dasa fraction: (30 - SL_advancement) / 30
 * Dasa lengths: same as Narayana.
 */
function computeSudasa(slCode, slDegreeInSign, bodies, birthDate, maxYears) {
  maxYears = maxYears || 120;
  if (!slCode) return null;

  const forward = IS_ODD[signIdx(slCode)] === 1;

  const kendra    = [1,4,7,10].map(n => nthHouse(slCode, n, forward));
  const panaphara = [2,5,8,11].map(n => nthHouse(slCode, n, forward));
  const apoklima  = [3,6,9,12].map(n => nthHouse(slCode, n, forward));
  const sequence  = [...kendra, ...panaphara, ...apoklima];

  // First dasa fraction — Ch.20.2(7): "(30 - SL's advancement) / 30"
  const firstFraction = (30 - (slDegreeInSign || 0)) / 30;

  const dasas = [];
  let currentDate = birthDate;
  let totalYears = 0;

  for (let cycle = 1; cycle <= 2; cycle++) {
    for (let i = 0; i < sequence.length; i++) {
      const rasi = sequence[i];
      let years = dasaLength(rasi, bodies);
      if (cycle === 2) years = 12 - dasaLength(rasi, bodies);
      let effectiveYears = (cycle === 1 && i === 0) ? years * firstFraction : years;
      if (totalYears + effectiveYears > maxYears) effectiveYears = maxYears - totalYears;

      const startDate = currentDate;
      const endDate   = addYearsToDate(currentDate, effectiveYears);
      dasas.push({ rasi, rasiName: SIGN_NAMES[signIdx(rasi)], years: effectiveYears, cycle, startDate, endDate });
      currentDate = endDate;
      totalYears += effectiveYears;
      if (totalYears >= maxYears) break;
    }
    if (totalYears >= maxYears) break;
  }

  return { system: 'Sudasa', seed: slCode, slDegreeInSign, dasas };
}

/**
 * Compute Drigdasha — Ch.21
 * Seed: 9th house from lagna.
 * First 4 dasas: 9th house + 3 signs aspecting it (direction based on odd/even-footed)
 * Next 4: 10th house + 3 signs aspecting it
 * Last 4: 11th house + 3 signs aspecting it
 * Dasa lengths: same Narayana rules.
 * Use: spiritual progress ONLY (Ch.21.1)
 */
function computeDrigdasha(lagnaCode, bodies, lagnaLon, birthDate, maxYears) {
  maxYears = maxYears || 120;

  const lagnaIdx_ = signIdx(lagnaCode);
  const ninthCode  = SIGN_CODES[(lagnaIdx_ + 8) % 12];
  const tenthCode  = SIGN_CODES[(lagnaIdx_ + 9) % 12];
  const eleventhCode = SIGN_CODES[(lagnaIdx_ + 10) % 12];

  // For each of 9th/10th/11th: find signs aspecting it (rasi drishti)
  // Movable aspects Fixed (not adjacent); Fixed aspects Dual; Dual aspects Movable
  // Each sign has 3 signs aspecting it
  function signsAspecting(code) {
    const idx = signIdx(code);
    if (IS_MOVABLE[idx]) return ['Ta','Le','Sc','Aq'].filter(s=>s!==code);
    if (IS_FIXED[idx])   return ['Ge','Vi','Sg','Pi'].filter(s=>s!==code);
    if (IS_DUAL[idx])    return ['Ar','Cn','Li','Cp'].filter(s=>s!==code);
    return [];
  }

  // Direction for each house: based on odd-footed or even-footed
  function getGroupSequence(startCode) {
    const forward = IS_ODD_FOOTED[signIdx(startCode)] === 1;
    const aspectors = signsAspecting(startCode);
    if (forward) return [startCode, ...aspectors.sort((a,b) => signIdx(a) - signIdx(b))];
    else return [startCode, ...aspectors.sort((a,b) => signIdx(b) - signIdx(a))];
  }

  const sequence = [
    ...getGroupSequence(ninthCode),
    ...getGroupSequence(tenthCode),
    ...getGroupSequence(eleventhCode)
  ];

  const firstFraction = firstDasaRemainder(ninthCode, bodies, lagnaLon);
  const dasas = [];
  let currentDate = birthDate;
  let totalYears = 0;

  for (let cycle = 1; cycle <= 2; cycle++) {
    for (let i = 0; i < sequence.length; i++) {
      const rasi = sequence[i];
      let years = dasaLength(rasi, bodies);
      if (cycle === 2) years = 12 - years;
      let effectiveYears = (cycle === 1 && i === 0) ? years * firstFraction : years;
      if (totalYears + effectiveYears > maxYears) effectiveYears = maxYears - totalYears;

      const startDate = currentDate;
      const endDate   = addYearsToDate(currentDate, effectiveYears);
      dasas.push({ rasi, rasiName: SIGN_NAMES[signIdx(rasi)], years: effectiveYears, cycle, startDate, endDate });
      currentDate = endDate;
      totalYears += effectiveYears;
      if (totalYears >= maxYears) break;
    }
    if (totalYears >= maxYears) break;
  }

  return { system: 'Drigdasha', seed: ninthCode, note: 'Spiritual progress only (Ch.21.1)', dasas };
}

/**
 * Find active Narayana dasha period for a given date
 */
function findActiveNarayana(dasas, dateStr) {
  for (const md of dasas) {
    if (md.startDate <= dateStr && md.endDate > dateStr) {
      for (const ad of (md.antardasas || [])) {
        if (ad.startDate <= dateStr && ad.endDate > dateStr) {
          return { mahadasha: md.rasi, mahadashaName: md.rasiName, antardasha: ad.rasi, antardashaName: ad.rasiName,
                   mdPeriod: { startDate: md.startDate, endDate: md.endDate },
                   adPeriod: { startDate: ad.startDate, endDate: ad.endDate } };
        }
      }
      return { mahadasha: md.rasi, mahadashaName: md.rasiName, antardasha: null,
               mdPeriod: { startDate: md.startDate, endDate: md.endDate } };
    }
  }
  return null;
}

/**
 * Compute Narayana Dasha for a Divisional Chart (Varga).
 * Source: PVR textbook Ch.18.5 — Narayana dasa of vargas
 *
 * Steps (from book):
 *   (1) Find seed house = n-th house in rasi chart
 *   (2) Take that house. Find its lord.
 *   (3) Take rasi occupied by lord in the D-chart
 *   (4) Find stronger of that rasi vs 7th from it (in D-chart)
 *   (5) Compute Narayana dasa of D-chart as if it were rasi chart
 *
 * @param {number} n            - divisional number (9 for D9, 10 for D10, 7 for D7, etc.)
 * @param {string} lagnaCode    - rasi chart lagna sign code
 * @param {object} rasiBodies   - rasi chart bodies (for seed lord position)
 * @param {object} dchartSigns  - D-chart planet sign positions { Sun:'Li', Moon:'Ta', ... }
 * @param {string} birthDate    - 'YYYY-MM-DD'
 * @param {number} maxYears     - how many years to compute
 * @returns {object} Narayana dasha result with seed info
 */
function computeVargaNarayana(n, lagnaCode, rasiBodies, dchartSigns, birthDate, maxYears) {
  maxYears = maxYears || 120;

  // Step 1: Seed house = n-th house (subtract 12 if n>12)
  const seedN = ((n - 1) % 12) + 1;
  const lagnaIdx_r = signIdx(lagnaCode);
  const seedHouseIdx = (lagnaIdx_r + seedN - 1) % 12;
  const seedHouseCode = SIGN_CODES[seedHouseIdx];

  // Step 2: Lord of seed house in RASI chart
  const RASI_LORDS_LOCAL = {
    Ar:'Mars',Ta:'Venus',Ge:'Mercury',Cn:'Moon',Le:'Sun',Vi:'Mercury',
    Li:'Venus',Sc:'Mars',Sg:'Jupiter',Cp:'Saturn',Aq:'Saturn',Pi:'Jupiter'
  };

  let seedLord;
  if (seedHouseCode === 'Sc' || seedHouseCode === 'Aq') {
    seedLord = strongerCoLord(seedHouseCode, rasiBodies);
  } else {
    seedLord = RASI_LORDS_LOCAL[seedHouseCode];
  }

  // Step 3: Position of seed lord in D-chart
  const lordInDchart = dchartSigns[seedLord];
  if (!lordInDchart) {
    return { error: 'Seed lord '+seedLord+' not found in D-chart signs', seedHouseCode, seedLord };
  }

  // Step 4: Build D-chart bodies for strength comparison
  const dBodies = {};
  Object.entries(dchartSigns).forEach(([p, s]) => {
    dBodies[p] = { signCode: s, longitudeInSign: rasiBodies[p]?.longitudeInSign || 0 };
  });

  // Stronger of lordInDchart vs 7th from it
  const lordDIdx = signIdx(lordInDchart);
  const seventhFromLord = SIGN_CODES[(lordDIdx + 6) % 12];
  const dseed = strongerRasi(lordInDchart, seventhFromLord, dBodies);

  // Step 5: Compute Narayana dasha from dseed using D-chart bodies
  const result = computeNarayanaDasha(dseed, dBodies, 0, birthDate, maxYears);

  return {
    ...result,
    system: 'Narayana_D' + n,
    n,
    seedHouse: seedHouseCode,
    seedLord,
    lordInDchart,
    dseed,
    note: 'Ch.18.5: Narayana dasa of D-'+n+' — seed from '+n+'th house lord in D'+n+' chart'
  };
}

module.exports = {
  computeNarayanaDasha,
  computeVargaNarayana,
  computeLagnaKendradiDasha,
  computeSudasa,
  computeDrigdasha,
  findActiveNarayana,
  strongerRasi,
  dasaLength,
  SIGN_CODES,
  SIGN_NAMES
};
