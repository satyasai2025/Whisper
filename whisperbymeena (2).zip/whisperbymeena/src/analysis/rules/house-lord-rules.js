/**
 * House-Lord Placement Rules (Bhavesh in Bhava)
 *
 * BPHS devotes a chapter to each house describing the effects of that
 * house's LORD being placed in each of the 12 houses (e.g. "Effects of
 * the 1st Lord in Different Houses"). This is among the most systematic
 * and widely-translated portions of classical literature, so these rules
 * are encoded at 'direct' or 'interpretive' confidence accordingly.
 *
 * RATHER THAN hardcoding 144 individually-fabricated sentences (which
 * would invite subtle errors and false precision), this module builds
 * each rule from two well-documented classical PRINCIPLES that BPHS's
 * house-lord chapters repeatedly apply:
 *
 *   PRINCIPLE 1 — The nature of the DESTINATION house colors the result:
 *     - Lord going to a Kendra (1,4,7,10) or Trikona (5,9) → generally
 *       supports / stabilizes the source house's matters.
 *     - Lord going to a Dusthana (6,8,12) → generally stresses / scatters
 *       the source house's matters (the "loss of the bhava" principle).
 *     - Lord going to 3rd/11th (upachaya) → growth through effort over time.
 *     - Lord going to 2nd → supports, with a wealth/family flavor.
 *
 *   PRINCIPLE 2 — The SOURCE house's significations are what get helped or
 *     stressed, and the DESTINATION house is where those significations
 *     "play out" / get linked.
 *
 * The combination (source meaning + destination quality + destination
 * meaning) reproduces the substance of the classical house-lord verses
 * without pretending to quote any single sloka verbatim — hence
 * 'interpretive' confidence by default, with a standing caveat that
 * specific BPHS verses add conditions (lord's dignity, aspects, etc.)
 * that refine these baselines.
 */

const { SOURCES } = require('./schema');

const HOUSE_SIGNIFICATION = {
  1: 'self, health, and overall life-direction',
  2: 'wealth, family, and speech',
  3: 'courage, siblings, and self-effort',
  4: 'home, mother, property, and inner peace',
  5: 'children, intelligence, and past merit',
  6: 'service, health-routine, debts, and competition',
  7: 'spouse, partnerships, and public dealings',
  8: 'longevity, transformations, and sudden events',
  9: 'fortune, dharma, father, and higher learning',
  10: 'career, status, and public action',
  11: 'gains, income, and fulfillment of desires',
  12: 'expenses, foreign matters, loss, and liberation'
};

const KENDRA = [1, 4, 7, 10];
const TRIKONA = [5, 9]; // 1 already counted as kendra
const DUSTHANA = [6, 8, 12];
const UPACHAYA_GROWTH = [3, 11];

function destinationQuality(destHouse) {
  if (destHouse === 1) return { tag: 'kendra/self', polarity: 'favorable', phrase: 'directs them strongly toward the self and personal identity' };
  if (KENDRA.includes(destHouse)) return { tag: 'kendra', polarity: 'favorable', phrase: 'gives them a stable, supported, action-oriented expression' };
  if (TRIKONA.includes(destHouse)) return { tag: 'trikona', polarity: 'favorable', phrase: 'blesses them with fortune and supportive momentum' };
  if (DUSTHANA.includes(destHouse)) return { tag: 'dusthana', polarity: 'challenging', phrase: 'tends to stress, scatter, or delay them' };
  if (UPACHAYA_GROWTH.includes(destHouse)) return { tag: 'upachaya', polarity: 'mixed', phrase: 'grows them gradually through sustained effort' };
  if (destHouse === 2) return { tag: 'wealth', polarity: 'favorable', phrase: 'links them to family and financial matters' };
  return { tag: 'neutral', polarity: 'neutral', phrase: 'links them to that area of life' };
}

function articleFor(tag) {
  return /^[aeiou]/i.test(tag) ? 'an' : 'a';
}

function buildHouseLordRules() {
  const rules = [];

  for (let lordOf = 1; lordOf <= 12; lordOf++) {
    for (let placedIn = 1; placedIn <= 12; placedIn++) {
      const dq = destinationQuality(placedIn);
      const sourceMeaning = HOUSE_SIGNIFICATION[lordOf];
      const destMeaning = HOUSE_SIGNIFICATION[placedIn];

      const effect =
        `The matters of the ${ordinal(lordOf)} house (${sourceMeaning}) become linked to the ${ordinal(placedIn)} house (${destMeaning}); ` +
        `placement in ${articleFor(dq.tag)} ${dq.tag} house ${dq.phrase}.`;

      rules.push({
        id: `houselord-${lordOf}-in-${placedIn}`,
        category: 'house-lord-placement',
        condition: { type: 'houseLordIn', lordOf, placedIn },
        effect,
        source: { text: SOURCES.BPHS, area: `Effects of the ${ordinal(lordOf)} Lord in Different Houses` },
        sourceConfidence: 'interpretive',
        caveat: 'Baseline from the classical house-lord principle (destination-house quality + source-house significations). The specific BPHS verse for this combination adds refining conditions — the lord\'s dignity, aspects on it, and conjunctions — that can strengthen or reverse this baseline. Treat as a starting hypothesis, not a verdict.',
        polarity: dq.polarity
      });
    }
  }

  return rules;
}

function ordinal(n) {
  const map = { 1: '1st', 2: '2nd', 3: '3rd', 4: '4th', 5: '5th', 6: '6th', 7: '7th', 8: '8th', 9: '9th', 10: '10th', 11: '11th', 12: '12th' };
  return map[n] || `${n}th`;
}

module.exports = { buildHouseLordRules, HOUSE_SIGNIFICATION, ordinal };
