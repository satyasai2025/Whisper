/**
 * CHARACTER ANALYSIS
 *
 * Per the Learner's own framing: character is a BUILDING, not a single
 * floor. This module converges the independent layers that classically
 * contribute to character, rather than reading any one of them alone:
 *
 *   1. LAGNA ARCHETYPE -- the structural template for this ascendant sign
 *      (lagna-archetypes.js): what is true for EVERYONE with this Lagna,
 *      before looking at the individual chart at all.
 *   2. LAGNA LORD'S ACTUAL PLACEMENT -- where THIS person's Lagna lord
 *      specifically sits, refining the generic archetype into something
 *      individual (dignity + house + functional nature, already computed
 *      elsewhere in this tool).
 *   3. MOON (Rashi + Nakshatra + House) -- classically the deepest
 *      individual character layer; the Janma Nakshatra is taken from the
 *      Moon specifically, not the Lagna, because the Moon represents the
 *      mind (manas) -- how the person actually experiences themselves
 *      internally, as opposed to the Lagna's outward presentation.
 *   4. SUN (Rashi + Nakshatra + House) -- the soul/ego/willpower layer,
 *      classically distinct from both the outward Lagna and the inward
 *      Moon.
 *   5. DASHA TIMING -- character is not static. Which layer is most
 *      "active"/expressed changes across life, tracked here via which
 *      dasha lord (Lagna lord, Moon, Sun, or another planet) is currently
 *      running.
 *
 * ============================ HONESTY NOTE ============================
 * For Moon's and Sun's specific NAKSHATRA, this module surfaces the
 * reliable STRUCTURAL facts already parsed elsewhere in this tool (sign,
 * nakshatra name + pada, nakshatra lord) rather than inlining a full
 * psychological deep-dive -- the Learner's own nakshatra reference
 * material (the 27-nakshatra deep-dive series) is the right place for
 * that level of detail, and fabricating a condensed paraphrase here
 * risks drifting from that source. This module POINTS to the relevant
 * nakshatra rather than re-describing it from memory.
 * =========================================================================
 */

const { LAGNA_ARCHETYPES, NAKSHATRA_ESSENCE, MOON_RASHI_NATURE } = require('./lagna-archetypes');
const { NAKSHATRA_LORDS, normalizeNakshatra, SIGN_INDEX } = require('../parser/utils/constants');
const { findActiveDashaWithPratyantar } = require('../parser/extractors/vimshottari');

function describePlacement(bodies, dignity, functionalNature, planet) {
  const body = bodies[planet];
  if (!body) return null;
  const nakshatraName = normalizeNakshatra(body.nakshatraCode);
  return {
    planet: planet,
    sign: body.sign,
    signCode: body.signCode,
    house: body.house,
    nakshatra: nakshatraName,
    nakshatraEssence: NAKSHATRA_ESSENCE[nakshatraName] || null,
    nakshatraPada: body.pada,
    nakshatraLord: NAKSHATRA_LORDS[nakshatraName] || null,
    dignity: dignity && dignity.classifications && dignity.classifications[planet] ? dignity.classifications[planet].tier : null,
    functionalNature: functionalNature && functionalNature.classifications && functionalNature.classifications[planet] ? functionalNature.classifications[planet].classification : null
  };
}

/**
 * Find who is the current Vimshottari MD/AD lord, and map that to which
 * "character layer" (Lagna-lord-driven, Moon-driven, Sun-driven, or
 * other) is most actively expressing right now.
 */
function describeActiveLayer(lagnaLord, mdLord, adLord) {
  const roles = [];
  if (mdLord === lagnaLord) roles.push('Lagna-lord period -- the outward/Lagna-archetype layer is strongly active right now.');
  if (mdLord === 'Moon') roles.push('Moon Mahadasha -- the inner emotional/mind layer is strongly active right now.');
  if (mdLord === 'Sun') roles.push('Sun Mahadasha -- the soul/ego/willpower layer is strongly active right now.');
  if (adLord === lagnaLord && mdLord !== lagnaLord) roles.push('Lagna-lord Antardasha (within ' + mdLord + ' Mahadasha) -- the outward layer gets secondary emphasis.');
  if (adLord === 'Moon' && mdLord !== 'Moon') roles.push('Moon Antardasha (within ' + mdLord + ' Mahadasha) -- the inner/mind layer gets secondary emphasis.');
  if (adLord === 'Sun' && mdLord !== 'Sun') roles.push('Sun Antardasha (within ' + mdLord + ' Mahadasha) -- the soul/ego layer gets secondary emphasis.');
  if (roles.length === 0) roles.push('Currently running ' + mdLord + ' Mahadasha / ' + adLord + ' Antardasha -- a layer outside the core Lagna/Moon/Sun triad is most active; read this period\'s themes via its own house-rulership and karakatva (see Indicator Convergence for events).');
  return roles;
}

/**
 * Weave the Lagna archetype, Lagna-lord refinement, Moon (rashi+nakshatra),
 * and Sun into one flowing reading — the way a Jyotishi would actually
 * narrate it, not a bullet-point data dump.
 */
function buildNarrative(archetype, lagnaLordPlacement, moonPlacement, sunPlacement) {
  const paras = [];

  if (archetype) {
    paras.push('At the outward level (Lagna in ' + archetype.name + '), this is a person who tends to show up in the world as: ' + archetype.coreNature);
  }

  if (lagnaLordPlacement) {
    const llDignityNote = lagnaLordPlacement.dignity
      ? ' — currently ' + lagnaLordPlacement.dignity.toLowerCase() + ' in House ' + lagnaLordPlacement.house
      : ' — in House ' + lagnaLordPlacement.house;
    paras.push('That generic baseline is refined by where their Lagna lord (' + lagnaLordPlacement.planet + ') actually sits' + llDignityNote + ', which colors how that outward archetype actually plays out for this specific person rather than the textbook version of it.');
  }

  if (moonPlacement) {
    const moonRashiNote = MOON_RASHI_NATURE[moonPlacement.signCode];
    let moonPara = 'Underneath that outward presentation, the Moon (the seat of the inner mind, Manas) sits in ' + moonPlacement.sign + ', House ' + moonPlacement.house + '.';
    if (moonRashiNote) moonPara += ' ' + moonRashiNote;
    if (moonPlacement.nakshatraEssence) {
      moonPara += ' More specifically, the Moon\'s Nakshatra is ' + moonPlacement.nakshatra + ' (pada ' + moonPlacement.nakshatraPada + '): ' + moonPlacement.nakshatraEssence;
    } else {
      moonPara += ' The Moon\'s Nakshatra is ' + moonPlacement.nakshatra + ' (pada ' + moonPlacement.nakshatraPada + ', lord ' + (moonPlacement.nakshatraLord || '—') + ') — for the full character profile of this specific nakshatra, the dedicated nakshatra reference material goes deeper than this tool does.';
    }
    paras.push(moonPara);
  }

  if (sunPlacement) {
    paras.push('The Sun (soul-purpose and willpower, distinct from both the outward Lagna and the inward Moon) is in ' + sunPlacement.sign + ', House ' + sunPlacement.house + ', Nakshatra ' + sunPlacement.nakshatra + ' — this is the layer that drives underlying motivation and self-respect, separate from how the person presents (Lagna) or what they feel (Moon).');
  }

  return paras;
}

function computeCharacterAnalysis(chart) {
  const bodies = chart.bodies;
  const analysis = chart.analysis;
  const dashas = chart.dashas;

  if (!bodies || !bodies.Lagna) {
    return { _warning: 'Lagna not found -- cannot compute character analysis.' };
  }

  const lagnaSign = bodies.Lagna.signCode;
  const archetype = LAGNA_ARCHETYPES[lagnaSign];

  const lagnaLordEntry = Object.entries((analysis && analysis.functionalNature && analysis.functionalNature.classifications) || {})
    .find(function (entry) { return entry[1].housesRuled && entry[1].housesRuled.includes(1); });
  const lagnaLord = lagnaLordEntry ? lagnaLordEntry[0] : null;

  const lagnaLordPlacement = lagnaLord ? describePlacement(bodies, analysis.dignity, analysis.functionalNature, lagnaLord) : null;
  const moonPlacement = describePlacement(bodies, analysis.dignity, analysis.functionalNature, 'Moon');
  const sunPlacement = describePlacement(bodies, analysis.dignity, analysis.functionalNature, 'Sun');

  // Current dasha for the timing layer
  let activeLayer = null;
  let currentMD = null, currentAD = null;
  if (dashas && dashas.vimshottari && dashas.vimshottari.mahadashas) {
    const today = new Date().toISOString().split('T')[0];
    const active = findActiveDashaWithPratyantar(dashas.vimshottari.mahadashas, today);
    if (active) {
      currentMD = active.mahadasha;
      currentAD = active.antardasha;
      activeLayer = describeActiveLayer(lagnaLord, currentMD, currentAD);
    }
  }

  const narrative = buildNarrative(archetype, lagnaLordPlacement, moonPlacement, sunPlacement);

  return {
    lagnaSign: bodies.Lagna.sign,
    narrative: narrative,
    lagnaArchetype: archetype,
    lagnaLord: lagnaLordPlacement,
    moon: moonPlacement,
    sun: sunPlacement,
    timing: {
      currentMD: currentMD,
      currentAD: currentAD,
      activeLayer: activeLayer
    },
    note: 'This reading converges independent layers rather than reading any single one alone -- the Lagna archetype, the Lagna lord\'s actual placement, the Moon (the deepest classical character layer -- this is why Janma Nakshatra is taken from the Moon, not the Lagna), the Sun, and current dasha timing. Treat this as a starting sketch to weigh against lived experience, not a fixed verdict.'
  };
}

module.exports = { computeCharacterAnalysis };
