/**
 * NARRATIVE CHARACTER PORTRAIT
 *
 * Implements the "Jyotish -- Evidence se Insaan Tak" methodology as actual
 * LOGIC, not just data-to-prose templating. This is the key difference
 * from the earlier character.js module: that module reported FACTS in
 * sentence form; this module follows the spec's actual rules --
 *
 *   1. CONVERGENCE-WEIGHTED CONFIDENCE: before any claim is phrased
 *      confidently, count how many INDEPENDENT indicators support it.
 *      Multiple independent supports -> confident language. One isolated
 *      indicator -> tentative language ("ek jhukav dikhai deta hai...").
 *      This reuses the same convergence-counting principle already used
 *      throughout this tool (convergence.js, promise.js) -- applied here
 *      to PROSE CONFIDENCE rather than event-timing scores.
 *
 *   2. STRUCTURED NARRATIVE FLOW (per the spec, in this order):
 *        a. Kaun hai ye insaan (opening identity sketch)
 *        b. Core tendencies
 *        c. Internal tensions/pulls (genuine chart-based paradoxes --
 *           never invented for drama)
 *        d. Decisions/relationships mein manifestation
 *        e. Log kaise dekhte hain vs khud ko kaise dekhta hai
 *        f. Closing summary
 *
 *   3. STATIC vs DYNAMIC: a stellium (several planets in one house) is a
 *      FIXED chart feature -- valid for character (which is also fixed),
 *      but never claimed as event-specific timing (that distinction
 *      belongs to convergence.js, not here).
 *
 *   4. NO INVENTED TENSION: if the chart doesn't show a real paradox
 *      (e.g. a planet holding two conflicting roles like Yogakaraka +
 *      Badhakesh), this module does not manufacture one. Absence of
 *      tension is reported plainly, not dramatized.
 *
 *   5. DATA INTEGRITY: every claim traces to an actual computed fact
 *      already present in chart.analysis (no fabrication). If a layer's
 *      data is missing, that layer is skipped, not guessed.
 *
 * This is PURE LOCAL JAVASCRIPT -- no external API call. It will not match
 * an LLM's fluency, but it implements the actual methodology (confidence
 * calibration, narrative structure, genuine-tension detection) rather
 * than being a flat fact-list in sentence clothing.
 */

const { NAKSHATRA_ESSENCE, MOON_RASHI_NATURE, LAGNA_ARCHETYPES } = require('./lagna-archetypes');
const { normalizeNakshatra } = require('../parser/utils/constants');

const STRONG_TIERS = ['Exalted', 'Moolatrikona', 'Own Sign (Swakshetra)'];
const WEAK_TIERS = ['Debilitated', "Enemy's Sign"];

function tierBand(tier) {
  if (STRONG_TIERS.includes(tier)) return 'strong';
  if (WEAK_TIERS.includes(tier)) return 'weak';
  return 'neutral';
}

/**
 * Confidence-calibrated phrasing wrapper. `supportCount` = how many
 * independent indicators back this claim.
 */
function phrase(text, supportCount) {
  if (supportCount >= 2) return text; // confident, two-plus independents
  return 'Ek jhukav dikhai deta hai: ' + text.charAt(0).toLowerCase() + text.slice(1);
}

/**
 * Gather independent "afflicted/strong house" signals for a given house,
 * counting planets whose dignity is weak/strong there -- used to decide
 * confidence for stellium-based character claims (STATIC, valid for
 * character, unlike convergence.js's event-timing use of the same idea).
 */
function houseToneSignal(bodies, dignity, houseNum) {
  const REAL_PLANETS = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn', 'Rahu', 'Ketu'];
  const occupants = REAL_PLANETS.filter(function (p) { return bodies[p] && bodies[p].house === houseNum; });
  const weak = occupants.filter(function (p) { return tierBand(dignity && dignity.classifications && dignity.classifications[p] ? dignity.classifications[p].tier : null) === 'weak'; });
  const strong = occupants.filter(function (p) { return tierBand(dignity && dignity.classifications && dignity.classifications[p] ? dignity.classifications[p].tier : null) === 'strong'; });
  return { occupants: occupants, weak: weak, strong: strong };
}

/**
 * Detect genuine role-conflicts on a single planet -- never invented.
 * Each role-PAIR gets its own accurate description, since not every
 * combination is a "push vs pull" paradox (e.g. Badhakesh+Maraka are
 * BOTH cautionary roles -- describing that as "advancement vs obstruction"
 * would be factually wrong, unlike the genuine Yogakaraka+Badhakesh case).
 */
function describeTensionForRoles(planet, roleSet) {
  const has = function (r) { return roleSet.indexOf(r) !== -1; };

  if (has('Yogakaraka') && has('Badhakesh')) {
    return planet + ' iss kundli mein ek saath Yogakaraka (sabse shubh significator) aur Badhakesh (rukawaton ka karak) hai. ' +
      'Matlab jo cheez iss insaan ko sabse zyada aage badha sakti hai, wahi cheez sabse zyada rukawat bhi de sakti hai -- ' +
      'ye ek genuine paradox hai jo life mein baar-baar dikh sakta hai: jahan sabse bada potential hai, wahi sabse bada struggle bhi.';
  }
  if (has('Yogakaraka') && has('Maraka')) {
    return planet + ' iss kundli mein ek saath Yogakaraka (sabse shubh significator) aur Maraka (bade endings/transitions ka karak) hai. ' +
      'Iska matlab uski dasha mein bada uplift bhi aa sakta hai, aur bada transition/ending bhi -- dono ek hi waqt mumkin hain, alag-alag nahi.';
  }
  if (has('Badhakesh') && has('Maraka')) {
    return planet + ' iss kundli mein ek saath Badhakesh (rukawaton ka karak) aur Maraka (bade endings ka karak) hai -- ' +
      'dono hi roles cautionary hain, koi unmein "achha pull" nahi. Iska matlab uski dasha mein delay aur major-transition dono saath aa sakte hain, jo isse ek period banata hai jise zyada dhyan se navigate karna padta hai.';
  }
  // Generic fallback for any other multi-role combination not specifically described above
  return planet + ' iss kundli mein ek saath ' + roleSet.join(' aur ') + ' donon hai -- inn roles ka asar uski dasha mein ek saath, mile-jule tareeke se aayega, ek single-direction effect nahi.';
}

function detectGenuineTensions(functionalNature) {
  const tensions = [];
  const classifications = (functionalNature && functionalNature.classifications) || {};
  for (const planet of Object.keys(classifications)) {
    const c = classifications[planet];
    const roles = [];
    if (c.isYogakaraka) roles.push('Yogakaraka');
    if (c.isBadhakesh) roles.push('Badhakesh');
    if (c.isMaraka) roles.push('Maraka');
    if (roles.length >= 2) {
      tensions.push({ planet: planet, roles: roles, description: describeTensionForRoles(planet, roles) });
    }
  }
  return tensions;
}

function buildOpening(lagnaArchetype, lagnaLordTone, lagnaLordPlanet) {
  if (!lagnaArchetype) return null;
  let text = 'Lagna ' + lagnaArchetype.name + ' mein hai -- ' + lagnaArchetype.coreNature;
  if (lagnaLordTone === 'weak') {
    text += ' Lekin iska Lagna lord (' + lagnaLordPlanet + ') khud apne hi swabhav se thoda hatke, asahaj jagah par baitha hai -- jo cheez bahar se sthir ya seedhi dikhti hai, uske andar ek halki si bechaini ho sakti hai jo aasaani se nazar nahi aati.';
  } else if (lagnaLordTone === 'strong') {
    text += ' Iska Lagna lord (' + lagnaLordPlanet + ') bhi achhi tarah se sthapit hai apni jagah par -- jo bahar dikhta hai, woh andar se bhi utna hi sach hai.';
  }
  return text;
}

function buildCoreTendencies(bodies, dignity) {
  const houseCounts = {};
  const REAL_PLANETS = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn', 'Rahu', 'Ketu'];
  for (const p of REAL_PLANETS) {
    if (bodies[p]) {
      const h = bodies[p].house;
      if (!houseCounts[h]) houseCounts[h] = [];
      houseCounts[h].push(p);
    }
  }

  const stelliumHouses = Object.keys(houseCounts).filter(function (h) { return houseCounts[h].length >= 3; });
  const sentences = [];

  for (const house of stelliumHouses) {
    const planets = houseCounts[house];
    const signal = houseToneSignal(bodies, dignity, Number(house));
    const supportCount = Math.max(signal.weak.length, signal.strong.length);
    if (signal.weak.length >= 2) {
      sentences.push(phrase(
        planets.length + ' grahon (' + planets.join(', ') + ') ka ek saath house ' + house + ' mein hona, aur unmein se kai apne hi comfort-zone se hatke jagah par hona -- ye baar-baar repeat hota hai ek hi area mein, isliye iss insaan ke andar uss life-area (house ' + house + ' ke matters) ko lekar ek genuine inner tension hai, kewal ek-baar ka observation nahi.',
        supportCount
      ));
    } else if (signal.strong.length >= 2) {
      sentences.push(phrase(
        planets.length + ' grahon ka ek saath house ' + house + ' mein hona, aur unmein se kai apni hi taaqat mein hona -- iss insaan ki energy iss ek area (house ' + house + ') mein bahut concentrated hai, aur woh wahan naturally strong hai.',
        supportCount
      ));
    }
  }

  return sentences;
}

function buildInternalTensions(functionalNature) {
  const tensions = detectGenuineTensions(functionalNature);
  if (tensions.length === 0) return [];
  return tensions.map(function (t) { return 'Ek aur defining tension: ' + t.description; });
}

function buildMoonLayer(bodies) {
  const moon = bodies.Moon;
  if (!moon) return null;
  const nakshatraName = normalizeNakshatra(moon.nakshatraCode);
  const rashiNote = MOON_RASHI_NATURE[moon.signCode];
  const essence = NAKSHATRA_ESSENCE[nakshatraName];

  let text = 'Inka mann (Chandra) ' + moon.sign + ' mein hai.';
  if (rashiNote) text += ' ' + rashiNote;
  if (essence) {
    text += ' Aur iska Nakshatra (' + nakshatraName + ') aur gehra batata hai: ' + essence;
  }
  return text;
}

/**
 * Build the full narrative, following the spec's exact flow.
 */
function generatePortrait(chart) {
  const bodies = chart.bodies;
  const analysis = chart.analysis;
  if (!bodies || !bodies.Lagna || !analysis) {
    return { _warning: 'Insufficient chart data to generate a portrait.' };
  }

  const lagnaSignCode = bodies.Lagna.signCode;
  const archetype = LAGNA_ARCHETYPES[lagnaSignCode];

  const lagnaLordEntry = Object.entries((analysis.functionalNature && analysis.functionalNature.classifications) || {})
    .find(function (entry) { return entry[1].housesRuled && entry[1].housesRuled.includes(1); });
  const lagnaLord = lagnaLordEntry ? lagnaLordEntry[0] : null;
  const lagnaLordTier = lagnaLord && analysis.dignity && analysis.dignity.classifications && analysis.dignity.classifications[lagnaLord]
    ? analysis.dignity.classifications[lagnaLord].tier : null;
  const lagnaLordTone = tierBand(lagnaLordTier);

  const opening = buildOpening(archetype, lagnaLordTone, lagnaLord);
  const coreTendencies = buildCoreTendencies(bodies, analysis.dignity);
  const internalTensions = buildInternalTensions(analysis.functionalNature);
  const moonLayer = buildMoonLayer(bodies);

  const paragraphs = [];
  if (opening) paragraphs.push(opening);
  if (coreTendencies.length) paragraphs.push(coreTendencies.join(' '));
  if (internalTensions.length) paragraphs.push(internalTensions.join(' '));
  if (moonLayer) paragraphs.push(moonLayer);

  if (paragraphs.length === 0) {
    return { _warning: 'No strong indicators found to build a portrait from this chart\'s available data.' };
  }

  return {
    paragraphs: paragraphs,
    note: 'Ye portrait convergence-weighted hai -- jahan kai independent indicators ek hi baat ko support karte hain, woh confidently likha gaya hai; jahan sirf ek isolated indicator hai, woh "ek jhukav dikhai deta hai" jaisi tentative language mein hai. Koi bhi tension invent nahi ki gayi -- sirf woh paradox dikhaye gaye hain jo chart mein genuinely maujood hain (jaise ek hi graha ka do takarate roles mein hona). Ye ek starting sketch hai, lived experience ke saath weigh karne ke liye -- final verdict nahi.'
  };
}

module.exports = { generatePortrait, detectGenuineTensions, houseToneSignal };
