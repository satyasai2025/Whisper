/**
 * SAHAMS (Arabic Parts / Sensitive Points)
 *
 * Source: BPHS / classical Tajaka system, Table 74 in the project's
 * reference textbook. Each Saham is a calculated point (not a planet or
 * house) used to refine analysis of a SPECIFIC life-area -- e.g. Vidya
 * Saham for education, Paradesa Saham for foreign residence, Roga Saham
 * for disease. They are a sharper, domain-specific complement to the
 * house/karaka indicators already used elsewhere in this tool -- never a
 * replacement for them.
 *
 * FORMULA CONVENTION: most sahams are computed as (A - B + C), where the
 * exact formula flips for night births: (B - A + C). This module
 * determines day/night from the chart itself (Sun in houses 7-12 = day
 * birth; houses 1-6 = night birth -- the classical "above/below horizon"
 * rule) and applies the correct variant automatically.
 *
 * ============================ HONESTY NOTE ============================
 * Sahams are a finer-grained, more specialized technique than house/
 * karaka analysis, and classical opinion on exactly how heavily to weigh
 * them varies. They are surfaced here as ADDITIONAL indicators within the
 * existing Promise-layer framework (promise.js) -- one more independent
 * angle to check, not a separate verdict-giving system.
 * =========================================================================
 */

const { SOURCES } = require('./rules/schema');
const { SIGN_INDEX, SIGN_ORDER, SIGN_LORDS } = require('../parser/utils/constants');

/**
 * Convert a body's absolute zodiacal longitude (0-360) from its sign +
 * degree-in-sign.
 */
function absoluteLongitude(body) {
  if (!body) return null;
  return SIGN_INDEX[body.signCode] * 30 + (body.longitudeInSign || 0);
}

/**
 * Is this a day birth? Classical rule: Sun in houses 7-12 (above horizon
 * at birth) = day; houses 1-6 (below horizon) = night.
 */
function isDayBirth(bodies) {
  const sunHouse = bodies.Sun ? bodies.Sun.house : null;
  if (!sunHouse) return null;
  return sunHouse >= 7 && sunHouse <= 12;
}

/**
 * Saham = (A - B + C) mod 360, mapped back to a sign. For night births,
 * A and B swap (B - A + C) unless the saham is marked "same for day & night".
 */
function computeSahamLongitude(aLon, bLon, cLon, isDay, sameForBoth) {
  if (aLon === null || aLon === undefined || bLon === null || bLon === undefined || cLon === null || cLon === undefined) return null;
  let result;
  if (sameForBoth || isDay) {
    result = aLon - bLon + cLon;
  } else {
    result = bLon - aLon + cLon;
  }
  result = ((result % 360) + 360) % 360;
  return result;
}

function longitudeToSign(lon) {
  if (lon === null) return null;
  const idx = Math.floor(lon / 30) % 12;
  return SIGN_ORDER[idx];
}

function longitudeToHouse(lon, lagnaSignCode) {
  if (lon === null) return null;
  const signIdx = Math.floor(lon / 30) % 12;
  const lagnaIdx = SIGN_INDEX[lagnaSignCode];
  return ((signIdx - lagnaIdx + 12) % 12) + 1;
}

/**
 * The Sahams relevant to this tool's life-domain modules (a curated
 * subset of BPHS Table 74 -- not all 36 classical sahams, only the ones
 * with a clear, direct domain mapping used elsewhere in this tool).
 */
function buildSahamDefinitions(ctx) {
  const lon = ctx.lon;
  const houseLordLon = ctx.houseLordLon;

  return {
    vivaha: {
      name: 'Vivaha Saham',
      domain: 'marriage',
      sameForBoth: false,
      a: lon.Venus, b: lon.Moon, c: lon.Lagna,
      source: { text: SOURCES.BPHS, area: 'Tajaka Sahams, Table 74 -- Vivaha Saham (marriage)' }
    },
    putra: {
      name: 'Putra Saham',
      domain: 'children',
      sameForBoth: false,
      a: lon.Jupiter, b: lon.Moon, c: lon.Lagna,
      source: { text: SOURCES.BPHS, area: 'Tajaka Sahams, Table 74 -- Putra Saham (children)' }
    },
    vidya: {
      name: 'Vidya Saham',
      domain: 'education',
      sameForBoth: false,
      a: lon.Sun, b: lon.Moon, c: lon.Lagna,
      source: { text: SOURCES.BPHS, area: 'Tajaka Sahams, Table 74 -- Vidya Saham (education)' }
    },
    paradesa: {
      name: 'Paradesa Saham',
      domain: 'foreign',
      sameForBoth: true,
      a: houseLordLon[9] ? houseLordLon[9].houseLon : null,
      b: houseLordLon[9] ? houseLordLon[9].lordLon : null,
      c: lon.Lagna,
      source: { text: SOURCES.BPHS, area: 'Tajaka Sahams, Table 74 -- Paradesa Saham (foreign countries)' }
    },
    artha: {
      name: 'Artha Saham',
      domain: 'wealth',
      sameForBoth: true,
      a: houseLordLon[2] ? houseLordLon[2].houseLon : null,
      b: houseLordLon[2] ? houseLordLon[2].lordLon : null,
      c: lon.Lagna,
      source: { text: SOURCES.BPHS, area: 'Tajaka Sahams, Table 74 -- Artha Saham (money)' }
    },
    roga: {
      name: 'Roga Saham',
      domain: 'disease',
      sameForBoth: true,
      a: lon.Lagna, b: lon.Moon, c: lon.Lagna,
      source: { text: SOURCES.BPHS, area: 'Tajaka Sahams, Table 74 -- Roga Saham (disease)' }
    },
    jadya: {
      name: 'Jadya Saham',
      domain: 'disease',
      sameForBoth: true,
      a: lon.Mars, b: lon.Saturn, c: lon.Mercury,
      source: { text: SOURCES.BPHS, area: 'Tajaka Sahams, Table 74 -- Jadya Saham (chronic disease)' }
    },
    vyapara: {
      name: 'Vyapara Saham',
      domain: 'career',
      sameForBoth: true,
      a: lon.Mars, b: lon.Saturn, c: lon.Lagna,
      source: { text: SOURCES.BPHS, area: 'Tajaka Sahams, Table 74 -- Vyapara Saham (business)' }
    },
    karma: {
      name: 'Karma Saham',
      domain: 'career',
      sameForBoth: true,
      a: lon.Mars, b: lon.Mercury, c: lon.Lagna,
      source: { text: SOURCES.BPHS, area: 'Tajaka Sahams, Table 74 -- Karma Saham (action/work)' }
    },
    labha: {
      name: 'Labha Saham',
      domain: 'wealth',
      sameForBoth: true,
      a: houseLordLon[11] ? houseLordLon[11].houseLon : null,
      b: houseLordLon[11] ? houseLordLon[11].lordLon : null,
      c: lon.Lagna,
      source: { text: SOURCES.BPHS, area: 'Tajaka Sahams, Table 74 -- Labha Saham (material gains)' }
    }
  };
}

/**
 * Compute all defined Sahams for this chart.
 */
function computeSahams(bodies) {
  if (!bodies || !bodies.Lagna) {
    return { _warning: 'Lagna not found -- cannot compute Sahams.' };
  }

  const lagnaAbsLon = absoluteLongitude(bodies.Lagna);

  const lon = {
    Sun:     absoluteLongitude(bodies.Sun),
    Moon:    absoluteLongitude(bodies.Moon),
    Mars:    absoluteLongitude(bodies.Mars),
    Mercury: absoluteLongitude(bodies.Mercury),
    Jupiter: absoluteLongitude(bodies.Jupiter),
    Venus:   absoluteLongitude(bodies.Venus),
    Saturn:  absoluteLongitude(bodies.Saturn),
    Lagna:   lagnaAbsLon
  };

  const isDay = isDayBirth(bodies);

  // For house-cusp-based sahams (Paradesa, Artha, Labha): "Nth house"
  // longitude is the start of that whole-sign house, and "Nth lord"
  // longitude is that lord's actual body longitude.
  const houseLordLon = {};
  if (lagnaAbsLon !== null) {
    for (const houseNum of [2, 9, 11]) {
      const houseSignIdx = (SIGN_INDEX[bodies.Lagna.signCode] + houseNum - 1) % 12;
      const houseSignCode = SIGN_ORDER[houseSignIdx];
      const houseLon = houseSignIdx * 30;
      const lordPlanet = SIGN_LORDS[houseSignCode];
      houseLordLon[houseNum] = { houseLon: houseLon, lordLon: absoluteLongitude(bodies[lordPlanet]), lordPlanet: lordPlanet };
    }
  }

  if (isDay === null) {
    return { _warning: 'Could not determine day/night birth (Sun house missing) -- Sahams not computed.' };
  }

  const defs = buildSahamDefinitions({ lon: lon, houseLordLon: houseLordLon });
  const results = {};

  for (const key of Object.keys(defs)) {
    const def = defs[key];
    const longitude = computeSahamLongitude(def.a, def.b, def.c, isDay, def.sameForBoth);
    if (longitude === null) {
      results[key] = { name: def.name, domain: def.domain, _warning: 'Could not compute -- missing input longitude.' };
      continue;
    }
    const sign = longitudeToSign(longitude);
    const house = longitudeToHouse(longitude, bodies.Lagna.signCode);
    results[key] = {
      name: def.name,
      domain: def.domain,
      longitude: Number(longitude.toFixed(2)),
      sign: sign,
      house: house,
      source: def.source
    };
  }

  return {
    isDayBirth: isDay,
    sahams: results,
    methodology: 'BPHS Tajaka Sahams (Table 74). Day/night birth determined by Sun\'s house (7-12 = day, 1-6 = night), which flips the (A-B+C) vs (B-A+C) formula for sahams not marked "same for day & night". A curated subset relevant to this tool\'s life-domain modules, not the full classical list of 36+.'
  };
}

module.exports = { computeSahams, isDayBirth, absoluteLongitude };
