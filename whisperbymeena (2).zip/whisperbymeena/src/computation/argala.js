/**
 * Argala & Virodhargala Computation
 * Source: PVR Narasimha Rao "Vedic Astrology: An Integrated Approach" Ch.10.5-10.7
 *
 * Ch.10.5 Argala (Intervention, p.104-106):
 *   Primary argala: planets in 2nd, 4th, 11th from a house/planet
 *   Secondary argala: planets in 5th from a house/planet
 *   Subhargala (benefic intervention): benefic planet causing argala
 *   Papargala (malefic intervention): malefic planet causing argala
 *
 * Ch.10.6 Virodhargala (Obstruction, p.106-107):
 *   12th obstructs 2nd argala
 *   10th obstructs 4th argala
 *   3rd obstructs 11th argala (EXCEPTION: many malefics in 3rd = argala not virodhargala)
 *   9th obstructs 5th argala
 *
 * Ketu exception (p.106):
 *   "If a sign contains Ketu, argalas and virodhargalas on it are counted anti-zodiacally"
 *
 * Validated: Exercise 16 solution (p.110-111) — the argala table in book
 */

'use strict';

const SIGN_CODES = ['Ar','Ta','Ge','Cn','Le','Vi','Li','Sc','Sg','Cp','Aq','Pi'];

// Natural benefics (Ch.3): Jupiter, Venus, Mercury, waxing Moon
// Natural malefics: Sun, Mars, Saturn, Rahu, Ketu, waning Moon
const NATURAL_MALEFICS = new Set(['Sun','Mars','Saturn','Rahu','Ketu']);

function isMalefic(planet) {
  return NATURAL_MALEFICS.has(planet);
}

/**
 * Get sign n houses away from fromSignIdx.
 * @param {number} fromSignIdx - 0-11
 * @param {number} n           - 1-12 (1 = same sign)
 * @param {boolean} forward    - zodiacal (true) or anti-zodiacal (false)
 */
function nthSign(fromSignIdx, n, forward = true) {
  if (forward) return (fromSignIdx + n - 1) % 12;
  else         return ((fromSignIdx - n + 1 + 12 * 100) % 12);
}

/**
 * Get sign index of house h from a reference sign.
 * @param {number} refSignIdx - reference sign (0-11)
 * @param {number} h          - house number (1-12)
 * @param {boolean} forward   - direction
 */
function houseSign(refSignIdx, h, forward = true) {
  return nthSign(refSignIdx, h, forward);
}

/**
 * Compute argalas on a target sign/planet.
 *
 * @param {number} targetSignIdx  - 0-11 (sign to analyze argalas on)
 * @param {object} occupants      - { signIdx: [planet_names] } — who occupies each sign
 * @param {boolean} hasKetu       - whether Ketu is in the target sign
 * @returns {object} { primary: [...], secondary: [...], virodhargala: [...], net: 'subha'|'papa'|'neutral' }
 */
function computeArgalaOnSign(targetSignIdx, occupants, hasKetu) {
  const forward = !hasKetu; // Ketu exception: count anti-zodiacally

  // Argala houses (positions relative to target)
  const argalaHouses = {
    2:  houseSign(targetSignIdx, 2,  forward), // primary
    4:  houseSign(targetSignIdx, 4,  forward), // primary
    11: houseSign(targetSignIdx, 11, forward), // primary
    5:  houseSign(targetSignIdx, 5,  forward), // secondary
  };

  // Virodhargala houses (obstruct corresponding argala)
  const virodhHouses = {
    12: houseSign(targetSignIdx, 12, forward), // obstructs 2nd argala
    10: houseSign(targetSignIdx, 10, forward), // obstructs 4th argala
    3:  houseSign(targetSignIdx, 3,  forward), // obstructs 11th argala (with exception)
    9:  houseSign(targetSignIdx, 9,  forward), // obstructs 5th argala
  };

  // Gather planets at each argala house
  const primaryArgala = [];
  const secondaryArgala = [];
  const virodhargala = [];

  // Primary argala (2nd, 4th, 11th)
  [2, 4, 11].forEach(h => {
    const sIdx = argalaHouses[h];
    const planetsHere = occupants[sIdx] || [];
    planetsHere.forEach(p => {
      primaryArgala.push({
        planet: p, house: h, signIdx: sIdx,
        type: isMalefic(p) ? 'papargala' : 'subhargala'
      });
    });
  });

  // Secondary argala (5th)
  (occupants[argalaHouses[5]] || []).forEach(p => {
    secondaryArgala.push({
      planet: p, house: 5, signIdx: argalaHouses[5],
      type: isMalefic(p) ? 'papargala' : 'subhargala'
    });
  });

  // Virodhargala
  const virodh12 = occupants[virodhHouses[12]] || [];
  const virodh10 = occupants[virodhHouses[10]] || [];
  const virodh3  = occupants[virodhHouses[3]]  || [];
  const virodh9  = occupants[virodhHouses[9]]  || [];

  // 3rd house exception (p.107): "If there are several malefics in the 3rd house,
  // they cause argala instead of virodhargala"
  const maleficsIn3rd = virodh3.filter(p => isMalefic(p));
  const use3rdAsVirodh = maleficsIn3rd.length <= 1; // several = 2+

  virodh12.forEach(p => virodhargala.push({ planet:p, house:12, signIdx:virodhHouses[12], obstructs:2  }));
  virodh10.forEach(p => virodhargala.push({ planet:p, house:10, signIdx:virodhHouses[10], obstructs:4  }));
  if (use3rdAsVirodh) {
    virodh3.forEach(p => virodhargala.push({ planet:p, house:3,  signIdx:virodhHouses[3],  obstructs:11 }));
  } else {
    // Many malefics in 3rd = they become argala instead
    virodh3.forEach(p => {
      if (isMalefic(p)) {
        primaryArgala.push({ planet:p, house:11, signIdx:virodhHouses[3], type:'papargala', note:'3rd malefics become argala' });
      }
    });
  }
  virodh9.forEach(p => virodhargala.push({ planet:p, house:9,  signIdx:virodhHouses[9],  obstructs:5  }));

  // Determine net effect
  const subhaPrimary = primaryArgala.filter(a => a.type === 'subhargala').length;
  const papaPrimary  = primaryArgala.filter(a => a.type === 'papargala').length;
  const subhaVirodh  = virodhargala.filter(a => !isMalefic(a.planet)).length;
  const papaVirodh   = virodhargala.filter(a => isMalefic(a.planet)).length;

  // Net subhargala count (unobstructed benefic argala)
  const netSubha = Math.max(0, subhaPrimary - papaVirodh);
  const netPapa  = Math.max(0, papaPrimary  - subhaVirodh);

  let net;
  if (netSubha > netPapa) net = 'subha';
  else if (netPapa > netSubha) net = 'papa';
  else net = 'neutral';

  return {
    targetSignIdx,
    hasKetu,
    forward,
    primaryArgala,
    secondaryArgala,
    virodhargala,
    netSubha, netPapa, net,
    unobstructedSubha: netSubha
  };
}

/**
 * Compute argalas on all 12 signs.
 *
 * @param {object} bodies  - bodies object from bodies-builder
 * @returns {object}       - argala for each sign (key = sign index 0-11)
 */
function computeAllArgalas(bodies) {
  // Build occupants map: signIdx → [planet_names]
  const occupants = {};
  for (let i = 0; i < 12; i++) occupants[i] = [];

  const PLANETS = ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn','Rahu','Ketu'];
  PLANETS.forEach(p => {
    const body = bodies[p];
    if (!body) return;
    const sIdx = body.signCode ? SIGN_CODES.indexOf(body.signCode) : -1;
    if (sIdx >= 0) occupants[sIdx].push(p);
  });

  // Lagna
  if (bodies.Lagna) {
    const lagnaIdx = SIGN_CODES.indexOf(bodies.Lagna.signCode);
    if (lagnaIdx >= 0) occupants[lagnaIdx].push('Lagna');
  }

  const result = {};
  const ketuIdx = bodies.Ketu ? SIGN_CODES.indexOf(bodies.Ketu.signCode) : -1;

  for (let signIdx = 0; signIdx < 12; signIdx++) {
    const hasKetu = (signIdx === ketuIdx);
    result[SIGN_CODES[signIdx]] = computeArgalaOnSign(signIdx, occupants, hasKetu);
  }

  return result;
}

/**
 * Compute argalas on a specific planet.
 * Same as house argala but targeted at the planet's sign.
 */
function computeArgalaOnPlanet(planetName, bodies) {
  const body = bodies[planetName];
  if (!body) return null;
  const signIdx = SIGN_CODES.indexOf(body.signCode);
  if (signIdx < 0) return null;

  const occupants = {};
  for (let i = 0; i < 12; i++) occupants[i] = [];
  const PLANETS = ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn','Rahu','Ketu'];
  PLANETS.forEach(p => {
    const b = bodies[p];
    if (!b || p === planetName) return; // exclude the planet itself from its own argala
    const sIdx = SIGN_CODES.indexOf(b.signCode);
    if (sIdx >= 0) occupants[sIdx].push(p);
  });

  const ketuIdx = bodies.Ketu ? SIGN_CODES.indexOf(bodies.Ketu.signCode) : -1;
  const hasKetu = (signIdx === ketuIdx);
  return computeArgalaOnSign(signIdx, occupants, hasKetu);
}

/**
 * Find planets that have UNOBSTRUCTED subhargala on a given sign.
 * Used in Narayana dasa interpretation: "dasa of rasi with unobstructed argala from GL = power"
 */
function getUnobstructedArgala(signIdx, bodies) {
  const argala = computeArgalaOnSign(signIdx, buildOccupants(bodies), false);
  return {
    unobstructedSubha: argala.primaryArgala.filter(a => a.type === 'subhargala'),
    obstructed: argala.virodhargala
  };
}

function buildOccupants(bodies) {
  const occ = {};
  for (let i=0; i<12; i++) occ[i]=[];
  const PLANETS = ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn','Rahu','Ketu'];
  PLANETS.forEach(p => {
    const b = bodies[p];
    if (!b) return;
    const sIdx = SIGN_CODES.indexOf(b.signCode);
    if (sIdx>=0) occ[sIdx].push(p);
  });
  return occ;
}

module.exports = { computeAllArgalas, computeArgalaOnSign, computeArgalaOnPlanet, getUnobstructedArgala };
