/**
 * PDF Text Extractor
 * Wraps pdf-parse to extract raw text from a JHora PDF.
 * Parser modules consume this text — they never touch the PDF directly.
 */

const fs = require('fs').promises;

async function extractTextFromPDF(pdfPath) {
  const pdfParse = require('pdf-parse');
  const dataBuffer = await fs.readFile(pdfPath);
  const data = await pdfParse(dataBuffer);
  return normalizeText(data.text);
}

/**
 * Normalize text — pdf-parse and JHora text exports can differ slightly
 * in whitespace and line endings. Make the parser input deterministic.
 */
function normalizeText(text) {
  return text
    .replace(/\r\n/g, '\n')   // Windows line endings
    .replace(/\r/g, '\n')     // Mac line endings
    .replace(/\u00a0/g, ' ')  // Non-breaking space
    .replace(/[ \t]+/g, ' ')  // Collapse whitespace within lines
    .replace(/ \n/g, '\n')    // Trim trailing spaces
    .replace(/\n /g, '\n');   // Trim leading spaces
}

module.exports = { extractTextFromPDF, normalizeText };
