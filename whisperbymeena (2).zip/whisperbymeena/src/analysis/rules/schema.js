/**
 * Classical Rule Library — Schema & Sourcing Standard
 *
 * ============================ HONESTY CONTRACT ============================
 * This library encodes classical astrological rules so the tool can say
 * not just "there is a signal here" (convergence) but "classical text X
 * says this signal means Y." That power comes with strict obligations:
 *
 * 1. EVERY rule cites a source (text + chapter/area). No uncited rules.
 *
 * 2. Each rule carries a `sourceConfidence`:
 *      - 'direct'      : the rule corresponds to a specific, well-known
 *                        classical statement whose substance is widely
 *                        agreed across translations.
 *      - 'interpretive': the rule is a reasonable paraphrase of classical
 *                        principle but the exact wording / attribution
 *                        should be verified against an original text before
 *                        being treated as definitive. The DEFAULT when in
 *                        any doubt.
 *      - 'synthesized' : the rule combines multiple classical principles or
 *                        reflects common modern (e.g. PVR-style) practice
 *                        rather than a single quotable sloka.
 *
 * 3. Rules are NOT predictions. Each `effect` is what the cited tradition
 *    ASSOCIATES with the placement — a hypothesis to test against real
 *    charts/events, never a guaranteed outcome. Phrasing stays tendency-
 *    based ("inclines toward", "classically associated with"), never
 *    deterministic.
 *
 * 4. Conflicting classical positions are BOTH shown when they exist, via
 *    the `caveat` field — the tool never silently picks a winner.
 *
 * 5. This is a CURATED SUBSET, explicitly not the whole of any text. BPHS
 *    alone contains thousands of statements; presenting any selection as
 *    "the rules" would misrepresent. The library is a starting set of
 *    testable classical hypotheses, meant to be expanded and validated
 *    against the Learner's own research database.
 * =========================================================================
 *
 * RULE OBJECT SHAPE:
 * {
 *   id:            unique string
 *   category:      'house-lord-placement' | 'planet-in-house' |
 *                  'conjunction' | 'aspect' | 'special'
 *   condition:     { ... } structured, machine-matchable (see matchers)
 *   effect:        string — the classically-associated tendency
 *   source:        { text, area }   e.g. { text: 'BPHS', area: 'Ch. on 10th house' }
 *   sourceConfidence: 'direct' | 'interpretive' | 'synthesized'
 *   caveat:        optional string — conflicts, conditions, cautions
 *   polarity:      'favorable' | 'challenging' | 'mixed' | 'neutral'
 * }
 */

// Source shorthand used throughout the rule files
const SOURCES = {
  BPHS:        'Brihat Parashara Hora Shastra',
  PHALADEEPIKA:'Phaladeepika (Mantreswara)',
  JAIMINI:     'Jaimini Sutras',
  PVR:         'PVR Narasimha Rao (systematic modern methodology)'
};

module.exports = { SOURCES };
