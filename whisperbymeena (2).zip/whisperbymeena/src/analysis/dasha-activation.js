/**
 * DASHA ACTIVATION LAYER (Layer 2 of the Predictive Engine)
 *
 * Layer 1 (promise.js) answers "does this chart show a credible promise
 * for this event, and on what evidence?" This layer answers the spec's
 * core predictive question: "in WHICH FUTURE dasha-window does that
 * promise become active?"
 *
 * ============================ SPEC CORRECTION ============================
 * The original build-spec's one-line summary is explicit: "Vimsottari +
 * Ashtottari dasha se predictive event-timing deta hai." An earlier version
 * of this module used ONLY Vimshottari as the primary timeline and treated
 * Narayana Dasha as the (optional) cross-check — that was a real deviation
 * from spec, caught by the Learner. This version corrects it: Vimshottari
 * and Ashtottari are now CO-PRIMARY timing systems. The base timeline is
 * still walked via Vimshottari's Antardasha sequence (it gives the
 * AD-level granularity this tool is built around), but at EVERY window,
 * Ashtottari's own MD/AD lords (active at that window's midpoint) are
 * independently checked for relevance using the SAME connection logic
 * used for Vimshottari's own lords — not a weaker/restricted check.
 * Agreement between the two systems is a first-class convergence signal,
 * not an afterthought.
 *
 * Narayana Dasha remains as an ADDITIONAL (tertiary) cross-check, kept at
 * its previously-validated strict rule (primary-house rulership only —
 * see the note on that function) since it was tested and found
 * meaningfully selective at that strictness, unlike a looser check.
 * =========================================================================
 *
 * Classical principle: a house's matters tend to manifest during the
 * dasha/antardasha of a planet CONNECTED to that house — its lord, its
 * karaka, an occupant, or an aspecting planet.
 *
 * ============================ DESIGN NOTES ============================
 * - FUTURE-ONLY, CHRONOLOGICAL: only windows starting today or later are
 *   returned, in chronological order.
 * - RELEVANCE, NOT CERTAINTY: a window is "relevant" if the MD or AD lord
 *   connects to the event via rulership, karakatva, occupancy, or aspect.
 *   More connections = stronger relevance — but this module reports the
 *   connections, not a single number (that's Layer 3's job).
 * =========================================================================
 */

const { analyzePlanetConnections } = require('./convergence');
const { findActiveDasha } = require('../parser/extractors/vimshottari');
const { findActiveNarayana: findActiveNarayanaOld } = require('../parser/extractors/narayana');
const { findActiveNarayana: findActiveNarayanaNew } = require('../computation/narayana-dasha');
const { SIGN_LORDS } = require('../parser/utils/constants');

// Wrapper that handles both old parser structure {periods with subPeriods}
// and new computation structure {dasas with antardasas}
function findActiveNarayana(periodsOrDasas, targetDate) {
  if (!periodsOrDasas || periodsOrDasas.length === 0) return null;
  const first = periodsOrDasas[0];
  // New structure has 'rasi' field; old has 'rasiCode' or different fields
  if (first && first.rasi !== undefined) {
    // New structure from narayana-dasha.js
    const result = findActiveNarayanaNew(periodsOrDasas, targetDate);
    if (!result) return null;
    return {
      major: result.mahadasha,
      sub: result.antardasha,
      majorPeriod: { rasiCode: result.mahadasha, rasi: result.mahadasha },
      subPeriod: result.antardasha ? { rasiCode: result.antardasha, rasi: result.antardasha } : null,
    };
  }
  // Old parser structure
  return findActiveNarayanaOld(periodsOrDasas, targetDate);
}

/**
 * Flatten a Vimshottari mahadashas array into a chronological list of
 * Antardasha windows, each tagged with its parent MD lord.
 */
function flattenAntardashas(mahadashas) {
  const windows = [];
  for (const md of mahadashas) {
    for (const ad of md.antardashas) {
      windows.push({
        mdLord: md.lord,
        adLord: ad.lord,
        startDate: ad.startDate,
        endDate: ad.endDate
      });
    }
  }
  return windows;
}

/**
 * Does `planet` connect to any of `targetHouses`, or is it one of
 * `karakaPlanets`? Returns the connection reasons if so, else null.
 */
function getRelevance(planet, targetHouses, karakaPlanets, bodies, functionalNature, aspects, housesRuledByLagna) {
  const conn = analyzePlanetConnections(planet, bodies, functionalNature, aspects, housesRuledByLagna);
  const reasons = [];

  const ruledMatch = conn.rules.filter(h => targetHouses.includes(h));
  if (ruledMatch.length) reasons.push(`rules house ${ruledMatch.join(',')}`);

  if (conn.occupies && targetHouses.includes(conn.occupies)) {
    reasons.push(`occupies house ${conn.occupies}`);
  }

  const aspectMatch = conn.aspectsHouses.filter(h => targetHouses.includes(h));
  if (aspectMatch.length) reasons.push(`aspects house ${aspectMatch.join(',')}`);

  if (karakaPlanets.includes(planet)) reasons.push('is the karaka');

  return reasons.length > 0 ? reasons : null;
}

/**
 * For one event category, walk forward through Vimshottari AD windows
 * from `fromDate` and report which future windows are relevant.
 */
function findActivationWindows(eventDef, chart, fromDate, opts = {}) {
  const { bodies, analysis } = chart;
  
  // Support both old structure (chart.dashas.vimshottari.mahadashas)
  // and new structure (chart.vimshottariDashas as array)
  const vimshottariDashas = chart.dashas?.vimshottari?.mahadashas
    || (Array.isArray(chart.vimshottariDashas) ? chart.vimshottariDashas : Object.values(chart.vimshottariDashas || {}))
    || [];

  const housesRuledByLagna = {};
  for (const [planet, c] of Object.entries(analysis.functionalNature?.classifications || {})) {
    if (c.housesRuled) housesRuledByLagna[planet] = c.housesRuled;
  }

  // Layer 2 deliberately targets the PRIMARY house only (not the broader
  // primary+secondary set Layer 1/Promise uses). Promise-checking wants
  // broad evidence-gathering; window-discrimination wants precision --
  // testing showed that including secondary houses here made nearly every
  // future window "relevant" for multi-house event categories (36/36),
  // giving this layer no actual power to separate one window from
  // another. Karakas stay in scope (karakatva is a specific, non-lenient
  // signal, unlike a broad multi-house aspect/occupancy net).
  const targetHouses = eventDef.houses;
  const karakaPlanets = eventDef.karakas;

  const allWindows = flattenAntardashas(vimshottariDashas);
  const from = new Date(fromDate).getTime();
  const maxWindows = opts.maxWindows || 8;

  const relevant = [];
  for (const w of allWindows) {
    const endMs = w.endDate ? new Date(w.endDate).getTime() : Infinity;
    if (endMs <= from) continue; // strictly future/ongoing only — never a past window

    const mdReasons = getRelevance(w.mdLord, targetHouses, karakaPlanets, bodies, analysis.functionalNature, analysis.aspects, housesRuledByLagna);
    const adReasons = getRelevance(w.adLord, targetHouses, karakaPlanets, bodies, analysis.functionalNature, analysis.aspects, housesRuledByLagna);

    // Require at least 1 connection reason (MD or AD)
    // Scoring engine will discriminate between weak and strong windows
    const totalReasons = (mdReasons ? mdReasons.length : 0) + (adReasons ? adReasons.length : 0);
    if (totalReasons < 1) continue;

    // Midpoint for cross-system checks — guarded against an undefined
    // endDate (the very last window in the sequence has no defined end).
    // In that case, cross-checks are skipped for this window rather than
    // computing an Infinity-based midpoint (which previously crashed).
    const hasDefinedEnd = Number.isFinite(endMs);
    const midDate = hasDefinedEnd
      ? new Date((new Date(w.startDate).getTime() + endMs) / 2).toISOString().split('T')[0]
      : null;

    // --- Ashtottari (CO-PRIMARY per spec) — checked against rulership of
    // the PRIMARY house ONLY, matching the same restrictive standard
    // already validated for Narayana below. NOTE: an earlier version of
    // this check used the FULL relevance test (rulership+occupancy+
    // aspect+karaka) for Ashtottari's 2 active lords, assuming that
    // checking only 2 specific planets (not "any planet in the chart")
    // would stay selective. Testing showed this was WRONG: with a
    // 3-4-house target set, high-aspect-count planets (Jupiter aspects 3
    // houses; so do Mars and Saturn) matched almost every window (30/32
    // in one test) — the same false-confirmation problem found earlier
    // with Narayana, just rediscovered in a new spot. Restricted to
    // primary-house rulership only, which is rare (one planet per chart)
    // and so stays meaningfully informative.
    let ashtottariConfirmation = null;
    // Support old (chart.dashas.ashtottari.mahadashas) and new (chart.ashtottariDashas) structures
    const ashtottariDashas = chart.dashas?.ashtottari?.mahadashas
      || (Array.isArray(chart.ashtottariDashas) ? chart.ashtottariDashas : Object.values(chart.ashtottariDashas || {}))
      || [];
    if (midDate && ashtottariDashas.length > 0) {
      const asht = findActiveDasha(ashtottariDashas, midDate);
      if (asht) {
        const primaryHouseOnly = eventDef.houses;
        const asMdRules = asht.mahadasha && housesRuledByLagna[asht.mahadasha]?.some(h => primaryHouseOnly.includes(h));
        const asAdRules = asht.antardasha && housesRuledByLagna[asht.antardasha]?.some(h => primaryHouseOnly.includes(h));
        const agrees = !!(asMdRules || asAdRules);
        ashtottariConfirmation = {
          agrees,
          ashtottariMD: asht.mahadasha, ashtottariAD: asht.antardasha,
          matchedVia: asMdRules ? `${asht.mahadasha} (MD lord) rules the primary house` : asAdRules ? `${asht.antardasha} (AD lord) rules the primary house` : null,
          detail: agrees
            ? `Ashtottari Dasha (${asht.mahadasha} -> ${asht.antardasha}) independently confirms: its lord also rules the primary house for this event.`
            : `Ashtottari Dasha (${asht.mahadasha} -> ${asht.antardasha}) does not independently confirm this window (its lord does not rule the primary house).`
        };
      }
    }

    // --- Narayana (tertiary cross-check) — kept at its previously-
    // validated strict rule (primary-house rulership only). NOTE:
    // deliberately checked against rulership of the PRIMARY house ONLY
    // (not secondary houses, not aspects/occupancy) — a broader check was
    // tested and found to be satisfied by nearly every planet in the
    // chart (aspect-matching across 3-4 target houses is too lenient to
    // discriminate when testing all 9 planets), which would have made
    // "confirmation" almost always true and therefore meaningless.
    // Primary-house rulership is rare (one specific planet per chart) and
    // so is an actually informative independent check.
    let crossConfirmation = null;
    // Support old (chart.dashas.narayana.periods) and new (chart.narayanaD1.dasas) structures
    const narayanaDasas = chart.dashas?.narayana?.periods || chart.narayanaD1?.dasas || [];
    if (midDate && narayanaDasas.length > 0) {
      const nar = findActiveNarayana(narayanaDasas, midDate);
      if (nar) {
        const narMajorLord = nar.majorPeriod?.rasiCode ? SIGN_LORDS[nar.majorPeriod.rasiCode] : null;
        const narSubLord = nar.subPeriod?.rasiCode ? SIGN_LORDS[nar.subPeriod.rasiCode] : null;
        const primaryHouseOnly = eventDef.houses; // primary house(s) only — see note above
        const narMajorRules = narMajorLord && housesRuledByLagna[narMajorLord]?.some(h => primaryHouseOnly.includes(h));
        const narSubRules = narSubLord && housesRuledByLagna[narSubLord]?.some(h => primaryHouseOnly.includes(h));
        const agrees = !!(narMajorRules || narSubRules);
        crossConfirmation = {
          agrees,
          narayanaMajor: nar.major, narayanaSub: nar.sub,
          matchedVia: narMajorRules ? `${narMajorLord} (major lord) rules the primary house` : narSubRules ? `${narSubLord} (sub lord) rules the primary house` : null,
          detail: agrees
            ? `Narayana Dasha (${nar.major} -> ${nar.sub}) independently confirms: its lord also rules the primary house for this event.`
            : `Narayana Dasha (${nar.major} -> ${nar.sub}) does not independently confirm this window (its lord does not rule the primary house).`
        };
      }
    }

    relevant.push({
      mdLord: w.mdLord,
      adLord: w.adLord,
      startDate: w.startDate,
      endDate: w.endDate,
      mdReasons: mdReasons || [],
      adReasons: adReasons || [],
      connectionStrength: (mdReasons ? mdReasons.length : 0) + (adReasons ? adReasons.length : 0),
      ashtottariConfirmation,
      crossConfirmation
    });

    if (relevant.length >= maxWindows) break;
  }

  return relevant;
}

/**
 * Run activation-window detection for ALL event categories.
 */
function findAllActivationWindows(chart, fromDate, opts = {}) {
  const { EVENT_DEFINITIONS } = require('./promise');
  const result = {};
  for (const key of Object.keys(EVENT_DEFINITIONS)) {
    result[key] = findActivationWindows(EVENT_DEFINITIONS[key], chart, fromDate, opts);
  }
  return result;
}

module.exports = { findActivationWindows, findAllActivationWindows, flattenAntardashas, getRelevance };
