/**
 * HOROSCOPE ENGINE
 * 
 * Single entry point: birth data in -> complete horoscope out.
 * No JHora PDF needed. Replaces the parser-dependent pipeline.
 * 
 * Outputs:
 *   - Planets (sidereal, Lahiri)
 *   - Lagna + Bhavachalit 
 *   - D9 Navamsa
 *   - Vimshottari + Ashtottari dashas (full MD+AD+PD)
 *   - Functional nature (from Lagna sign)
 *   - Age-aware event windows
 *   - Past + future event timeline
 */

const { computeFullHoroscope, computeEphemeris } = require('./ephemeris');
const { computeVimshottariFromMoon, computeAshtottariFromMoon, findActivePeriod, findActiveAshtottariPeriod } = require('./vimshottari-computer');
const { aspectedHouse, ASPECT_OFFSETS } = require('./aspects');
const { computeLagna, computeBhavachalit } = require('./lagna-computer');
const { computeAnalysis } = require('./index');
const { computeCharacterAnalysis } = require('./character');
const { generatePortrait } = require('./narrative-portrait');
const { buildBodies } = require('./bodies-builder');
const { computePanchanga, getNakshatra, getNavTara } = require('../computation/panchanga');
const { computeNarayanaDasha, computeVargaNarayana, computeLagnaKendradiDasha, computeSudasa, computeDrigdasha, findActiveNarayana } = require('../computation/narayana-dasha');
const { computeSpecialLagnas } = require('../computation/special-lagnas');
const { computeGroupA, computeGroupB } = require('../computation/upagrahas');
const { computeDivisionalChart } = require('../computation/divisional-charts');
const { computeAshtakavarga, scoreTransit, computeSodhyaPinda } = require('../computation/ashtakavarga');
const { computeAllArgalas } = require('../computation/argala');
const { computeNiryanaShoola, computeShoola, computeRudraAndTrishoola, computeLongevityCategory } = require('../computation/shoola-dasha');
const { computeKalachakra } = require('../computation/kalachakra-dasha');
const { computeSunrise, computeSunset } = require('../computation/sunrise');
const { computeAllSecondaryActivations, getFullLongitude, getNakshatraDescription, NAKSHATRA_PSYCHOLOGY } = require('../computation/nakshatra');

const SIGN_INDEX  = {Ar:0,Ta:1,Ge:2,Cn:3,Le:4,Vi:5,Li:6,Sc:7,Sg:8,Cp:9,Aq:10,Pi:11};
const SIGN_NAMES  = ['Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'];
const SIGN_CODES  = ['Ar','Ta','Ge','Cn','Le','Vi','Li','Sc','Sg','Cp','Aq','Pi'];

// ── Lagna-based house rulerships ──────────────────────────────────────────────
// Each sign's natural lord (for computing functional rulerships from Lagna)
const SIGN_LORDS = {
  Ar:'Mars', Ta:'Venus', Ge:'Mercury', Cn:'Moon', Le:'Sun',
  Vi:'Mercury', Li:'Venus', Sc:'Mars', Sg:'Jupiter', Cp:'Saturn',
  Aq:'Saturn', Pi:'Jupiter'
};

function computeRulerships(lagnaSignCode) {
  const lagnaIdx = SIGN_INDEX[lagnaSignCode];
  const rulerships = {};
  for (let h = 1; h <= 12; h++) {
    const signCode = SIGN_CODES[(lagnaIdx + h - 1) % 12];
    const lord = SIGN_LORDS[signCode];
    if (!rulerships[lord]) rulerships[lord] = [];
    rulerships[lord].push(h);
  }
  return rulerships;
}

// ── Dignities ─────────────────────────────────────────────────────────────────
const DIGNITIES = {
  Sun:     { exalted:'Ar', debilitated:'Li', own:['Le'], moolatrikona:'Le' },
  Moon:    { exalted:'Ta', debilitated:'Sc', own:['Cn'], moolatrikona:'Ta' },
  Mars:    { exalted:'Cp', debilitated:'Cn', own:['Ar','Sc'], moolatrikona:'Ar' },
  Mercury: { exalted:'Vi', debilitated:'Pi', own:['Ge','Vi'], moolatrikona:'Vi' },
  Jupiter: { exalted:'Cn', debilitated:'Cp', own:['Sg','Pi'], moolatrikona:'Sg' },
  Venus:   { exalted:'Pi', debilitated:'Vi', own:['Ta','Li'], moolatrikona:'Li' },
  Saturn:  { exalted:'Li', debilitated:'Ar', own:['Cp','Aq'], moolatrikona:'Aq' },
};

function getDignity(planet, signCode) {
  const d = DIGNITIES[planet];
  if (!d) return 'N/A';
  if (signCode === d.exalted)       return 'Exalted';
  if (signCode === d.debilitated)   return 'Debilitated';
  if (signCode === d.moolatrikona)  return 'Moolatrikona';
  if (d.own.includes(signCode))     return 'Own Sign';
  return 'Neutral';
}

// ── Age-aware event windows ────────────────────────────────────────────────────
// Defines the realistic age range for each event type.
// Events outside this range get filtered from predictions (but shown in past verification).
const EVENT_AGE_WINDOWS = {
  firstJob:           { earliest:18, latest:36,  note:'' },
  jobChange:          { earliest:20, latest:70,  note:'' },
  promotion:          { earliest:22, latest:65,  note:'' },
  termination:        { earliest:18, latest:70,  note:'' },
  businessStart:      { earliest:20, latest:65,  note:'' },
  retirement:         { earliest:45, latest:90,  note:'' },
  career:             { earliest:18, latest:70,  note:'' },
  marriage:           { earliest:18, latest:70,  note:'' },
  engagement:         { earliest:18, latest:70,  note:'' },
  divorce:            { earliest:18, latest:80,  note:'' },
  children:           { earliest:18, latest:50,  note:'' },
  education:          { earliest:5,  latest:38,  note:'' },
  graduation:         { earliest:16, latest:40,  note:'' },
  scholarship:        { earliest:14, latest:36,  note:'' },
  housePurchase:      { earliest:22, latest:85,  note:'' },
  vehiclePurchase:    { earliest:18, latest:80,  note:'' },
  foreignTravel:      { earliest:18, latest:85,  note:'' },
  foreignSettlement:  { earliest:20, latest:65,  note:'' },
  majorIllness:       { earliest:0,  latest:100, note:'' },
  surgery:            { earliest:0,  latest:100, note:'' },
  accident:           { earliest:5,  latest:90,  note:'' },
  disease:            { earliest:0,  latest:100, note:'' },
  deathOfFather:      { earliest:0,  latest:100, note:'' },
  deathOfMother:      { earliest:0,  latest:100, note:'' },
  deathOfSpouse:      { earliest:20, latest:100, note:'' },
  majorFinancialGain: { earliest:18, latest:90,  note:'' },
  majorFinancialLoss: { earliest:18, latest:90,  note:'' },
  wealth:             { earliest:18, latest:90,  note:'' },
  courtCase:          { earliest:18, latest:90,  note:'' },
  addiction:          { earliest:12, latest:80,  note:'' },
};

// Life stage themes -- used as additional weight signal
const LIFE_STAGES = [
  { label:'Student / Early',  ageMin:0,  ageMax:22, emphasis:['education','graduation','scholarship'] },
  { label:'Career Start',     ageMin:18, ageMax:32, emphasis:['firstJob','jobChange','marriage','children'] },
  { label:'Growth Phase',     ageMin:28, ageMax:50, emphasis:['promotion','businessStart','housePurchase','children','foreignSettlement'] },
  { label:'Peak / Stability', ageMin:45, ageMax:65, emphasis:['retirement','deathOfFather','deathOfMother','majorFinancialGain'] },
  { label:'Senior',           ageMin:60, ageMax:100,emphasis:['majorIllness','surgery','deathOfSpouse','retirement'] },
];

function getLifeStage(age) {
  return LIFE_STAGES.filter(s => age >= s.ageMin && age <= s.ageMax).map(s => s.label).join(' / ') || 'Unknown';
}

function isEventAgeAppropriate(eventKey, age) {
  const w = EVENT_AGE_WINDOWS[eventKey];
  if (!w) return true; // unknown event = no filter
  return age >= w.earliest && age <= w.latest;
}

// ── 3-Layer event verification ────────────────────────────────────────────────
// Primary D-chart for each event type
const EVENT_DCHART = {
  marriage:'D9', engagement:'D9', divorce:'D9',
  children:'D9',  // D7 ideal but D7 formula not yet verified
  firstJob:'D9', jobChange:'D9', promotion:'D9', termination:'D9',
  businessStart:'D9', retirement:'D9', career:'D9',
  housePurchase:'D9', vehiclePurchase:'D9',
  foreignTravel:'D9', foreignSettlement:'D9',
  majorIllness:'D9', surgery:'D9', accident:'D9', disease:'D9',
  deathOfFather:'D9', deathOfMother:'D9', deathOfSpouse:'D9',
  majorFinancialGain:'D9', majorFinancialLoss:'D9', wealth:'D9',
  courtCase:'D9', addiction:'D9',
};

// Primary + secondary houses for each event
const EVENT_HOUSES = {
  firstJob:          { primary:[10,6],      secondary:[2] },
  jobChange:         { primary:[10,6],      secondary:[12] },
  promotion:         { primary:[10,1],      secondary:[11] },
  termination:       { primary:[10,6],      secondary:[12] },
  businessStart:     { primary:[7,10],      secondary:[3,11] },
  retirement:        { primary:[10,12],     secondary:[4] },
  career:            { primary:[10,6],      secondary:[2,11] },
  marriage:          { primary:[7,2,11],    secondary:[1] },
  engagement:        { primary:[7,11],      secondary:[1] },
  divorce:           { primary:[7,6],       secondary:[8,12] },
  children:          { primary:[5,9],       secondary:[11] },
  education:         { primary:[4,9],       secondary:[2] },
  graduation:        { primary:[4,9],       secondary:[2] },
  scholarship:       { primary:[4,9,11],    secondary:[2] },
  housePurchase:     { primary:[4,2],       secondary:[11] },
  vehiclePurchase:   { primary:[4,2],       secondary:[11] },
  foreignTravel:     { primary:[12,9],      secondary:[3] },
  foreignSettlement: { primary:[12,9],      secondary:[4] },
  majorIllness:      { primary:[6,8],       secondary:[1] },
  surgery:           { primary:[6,8],       secondary:[1] },
  accident:          { primary:[8,3],       secondary:[6] },
  disease:           { primary:[6,1],       secondary:[8] },
  deathOfFather:     { primary:[9,4],       secondary:[8,12] },
  deathOfMother:     { primary:[4,8],       secondary:[12] },
  deathOfSpouse:     { primary:[7,8],       secondary:[12] },
  majorFinancialGain:{ primary:[11,2],      secondary:[9] },
  majorFinancialLoss:{ primary:[12,8],      secondary:[6] },
  wealth:            { primary:[2,11],      secondary:[9] },
  courtCase:         { primary:[6,7],       secondary:[12] },
  addiction:         { primary:[12,6],      secondary:[8] },
};

// Natural karakas for each event
const EVENT_KARAKAS = {
  marriage:'Venus', engagement:'Venus', divorce:'Venus',
  children:'Jupiter', education:'Mercury', graduation:'Mercury',
  scholarship:'Jupiter', firstJob:'Saturn', jobChange:'Saturn',
  promotion:'Sun', termination:'Saturn', businessStart:'Mercury',
  retirement:'Saturn', career:'Saturn', housePurchase:'Mars',
  vehiclePurchase:'Venus', foreignTravel:'Rahu', foreignSettlement:'Rahu',
  majorIllness:'Saturn', surgery:'Mars', accident:'Mars', disease:'Saturn',
  deathOfFather:'Sun', deathOfMother:'Moon', deathOfSpouse:'Venus',
  majorFinancialGain:'Jupiter', majorFinancialLoss:'Saturn',
  wealth:'Jupiter', courtCase:'Mars', addiction:'Rahu',
};

/**
 * Check if a planet connects to target houses using RASI (whole-sign) houses.
 * Source: PVR textbook p.78 — "Each rasi is a house. This author recommends
 * neither [equal house nor Sripathi]. Readers are advised to ignore all discussions
 * on bhaava chakra and chalit chakra."
 * Bhavachalit is NOT used for analysis — only Rasi (whole-sign).
 */
function checkD1Connection(planet, targetHouses, bhavachalit, rulerships) {
  // Use rasiHouse (whole-sign) — NOT bhavaHouse
  const rH = bhavachalit[planet] && bhavachalit[planet].rasiHouse;
  if (!rH) return [];
  const ruled = rulerships[planet] || [];
  const aspected = (ASPECT_OFFSETS[planet] || []).map(o => aspectedHouse(rH, o));
  const hits = [];
  ruled.filter(h => targetHouses.includes(h)).forEach(h => hits.push({ planet, via:'rules', house:h }));
  if (targetHouses.includes(rH)) hits.push({ planet, via:'occupies', house:rH });
  aspected.filter(h => targetHouses.includes(h)).forEach(h => hits.push({ planet, via:'aspects', house:h }));
  return hits;
}

/**
 * Check if a planet connects to target houses in D9.
 */
function checkD9Connection(planet, targetHouses, d9houses, d9rulerships) {
  const d9H = d9houses[planet];
  if (!d9H) return [];
  const ruled = d9rulerships[planet] || [];
  const aspected = (ASPECT_OFFSETS[planet] || []).map(o => aspectedHouse(d9H, o));
  const hits = [];
  ruled.filter(h => targetHouses.includes(h)).forEach(h => hits.push({ planet, via:'rules-D9', house:h }));
  if (targetHouses.includes(d9H)) hits.push({ planet, via:'occupies-D9', house:d9H });
  aspected.filter(h => targetHouses.includes(h)).forEach(h => hits.push({ planet, via:'aspects-D9', house:h }));
  return hits;
}

/**
 * Check Jupiter + Saturn transit connections.
 */
function checkTransit(date, targetHouses, lagnaIdx) {
  const [y,m,d] = date.split('-').map(Number);
  const eph = computeEphemeris({ year:y, month:m, day:d, hour:12, minute:0, second:0, gmtOffsetHours:5.5 });
  const hits = [];
  ['Jupiter','Saturn'].forEach(tp => {
    const tH = ((SIGN_INDEX[eph.positions[tp].signCode] - lagnaIdx + 12) % 12) + 1;
    const aspected = (ASPECT_OFFSETS[tp] || []).map(o => aspectedHouse(tH, o));
    [tH, ...aspected].filter(h => targetHouses.includes(h)).forEach(h => {
      hits.push({ planet:tp, via:'transit', house:h, fromHouse:tH });
    });
  });
  return hits;
}

/**
 * Run 3-layer verification for a specific event on a specific date.
 * Returns: { l1hits, l2hits, l3hits, l1pass, l2pass, l3pass, allPass, score }
 * Now includes Narayana Dasha in L1 — per PVR: "Vimshottari + Narayana must agree"
 */
function verify3Layers(eventKey, date, birthYear, horoscope, d9houses, d9rulerships, rulerships, vimshDashas, ashDashas, narayanaD1) {
  const age = new Date(date).getFullYear() - birthYear;
  const ageAppropriate = isEventAgeAppropriate(eventKey, age);
  const houses = EVENT_HOUSES[eventKey] || { primary:[], secondary:[] };
  const karaka = EVENT_KARAKAS[eventKey];
  const lagnaIdx = SIGN_INDEX[horoscope.lagna.signCode];

  // Active Vimshottari lords
  const vP = findActivePeriod(vimshDashas, date);
  const aP = findActiveAshtottariPeriod(ashDashas, date);
  const vimshLords = [...new Set([
    vP && vP.mahadasha, vP && vP.antardasha, vP && vP.pratyantardasha,
    aP && aP.mahadasha, aP && aP.antardasha
  ].filter(Boolean))];

  const allTargets = [...houses.primary, ...houses.secondary];

  // Active Narayana D1 rasi dasha (added per PVR framework)
  let narayanaActive = null;
  let narayanaConfirms = false;
  if (narayanaD1 && narayanaD1.dasas) {
    const { findActiveNarayana: fan } = require('../computation/narayana-dasha');
    narayanaActive = fan(narayanaD1.dasas, date);
    if (narayanaActive) {
      // Narayana confirms if the active dasa rasi or antardasa rasi
      // occupies or aspects the primary target houses
      const narRasis = [narayanaActive.mahadasha, narayanaActive.antardasha].filter(Boolean);
      // Check if dasa rasi IS a target house from lagna
      narRasis.forEach(r => {
        const houseNum = ((SIGN_INDEX[r] - lagnaIdx + 12) % 12) + 1;
        if (houses.primary.includes(houseNum)) narayanaConfirms = true;
        // Also check aspects from Narayana dasa rasi (rasi aspects)
        // Movable aspects Fixed, Fixed aspects Dual, Dual aspects Movable
        const rIdx = SIGN_INDEX[r];
        let aspectedSignIdxs = [];
        if ([0,3,6,9].includes(rIdx))    aspectedSignIdxs = [1,4,7,10]; // movable→fixed
        else if ([1,4,7,10].includes(rIdx)) aspectedSignIdxs = [2,5,8,11]; // fixed→dual
        else                              aspectedSignIdxs = [0,3,6,9];   // dual→movable
        aspectedSignIdxs.forEach(ai => {
          const aspH = ((ai - lagnaIdx + 12) % 12) + 1;
          if (houses.primary.includes(aspH)) narayanaConfirms = true;
        });
      });
    }
  }

  // L1: Vimshottari lords connecting to target houses (Rasi/whole-sign)
  const l1hits = vimshLords.flatMap(lord => checkD1Connection(lord, allTargets, horoscope.bhavachalit, rulerships));
  const l1primaryHits = l1hits.filter(h => houses.primary.includes(h.house));
  // L1 pass: either Vimshottari connects OR Narayana confirms
  const l1pass = l1primaryHits.length >= 1 || narayanaConfirms;

  // L2: D9 check using Vimshottari lords
  const l2hits = vimshLords.flatMap(lord => checkD9Connection(lord, allTargets, d9houses, d9rulerships));
  const karakaD9H = d9houses[karaka];
  const karakaD9Dig = karaka && DIGNITIES[karaka] ? getDignity(karaka, horoscope.d9.signs[karaka]) : 'N/A';
  const karakaConnected = karaka && karaka !== 'Rahu' && karaka !== 'Ketu' &&
    (allTargets.includes(karakaD9H) || checkD9Connection(karaka, allTargets, d9houses, d9rulerships).length > 0);
  const l2pass = l2hits.filter(h => allTargets.includes(h.house)).length >= 1 || karakaConnected;

  // L3: Gochar
  const l3hits = checkTransit(date, allTargets, lagnaIdx);
  const l3primaryHits = l3hits.filter(h => houses.primary.includes(h.house));
  const l3pass = l3primaryHits.length >= 1;

  const layersPassed = [l1pass, l2pass, l3pass].filter(Boolean).length;
  const allPass = layersPassed === 3;

  // Confidence score — based on PRIMARY house hits, not total hits
  // Primary house hits matter more than secondary
  const l1primaryCount = l1hits.filter(h => houses.primary.includes(h.house)).length;
  const l2primaryCount = l2hits.filter(h => houses.primary.includes(h.house)).length;
  const l3primaryCount = l3hits.filter(h => houses.primary.includes(h.house)).length;
  
  // Independent sources: how many DIFFERENT lords connect to primary houses
  const l1uniqueLords = new Set(l1hits.filter(h=>houses.primary.includes(h.house)).map(h=>h.planet)).size;

  let score = 0;
  // Each layer pass: 30 points max
  if (l1pass && l1primaryCount >= 1) score += 25 + Math.min(5, l1uniqueLords * 2);
  if (l2pass) {
    score += 20;
    if (l2primaryCount >= 1) score += 10;
  }
  if (l3pass && l3primaryCount >= 1) score += 20 + Math.min(5, l3primaryCount * 2);

  // Karaka dignity bonus
  if (['Exalted','Moolatrikona'].includes(karakaD9Dig)) score += 8;
  else if (karakaD9Dig === 'Own Sign') score += 5;
  else if (karakaD9Dig === 'Debilitated') score -= 5;

  // Multiple independent lords hitting same house = genuine convergence
  if (l1uniqueLords >= 3) score += 7;

  // Age appropriateness
  if (!ageAppropriate) score = Math.min(score, 20);

  // Hard cap
  score = Math.min(score, 95);

  return {
    eventKey, date, age, ageAppropriate,
    lords: vimshLords, vimshottari: vP, ashtottari: aP,
    narayanaActive, narayanaConfirms,
    l1hits, l1pass,
    l2hits, l2pass, karakaD9H, karakaD9Dig, karakaConnected,
    l3hits, l3pass,
    layersPassed, allPass, score,
    lifeStage: getLifeStage(age),
    ageNote: !ageAppropriate ? (EVENT_AGE_WINDOWS[eventKey] ? 
      'Age '+age+' is outside typical range ('+EVENT_AGE_WINDOWS[eventKey].earliest+'-'+EVENT_AGE_WINDOWS[eventKey].latest+') for this event.' : '') : ''
  };
}

/**
 * Main entry point.
 * 
 * @param {object} birthData - { year, month, day, hour, minute, second, gmtOffsetHours, latitude, longitude, name }
 * @param {object} options   - { fromYear, toYear, pastEvents: [{date, eventKey, label}] }
 * @returns {object} Complete horoscope + timeline
 */
function buildHoroscope(birthData, options) {
  const opts = options || {};
  const fromYear = opts.fromYear || birthData.year;
  const toYear   = opts.toYear   || (birthData.year + 90);

  // 1. Full astronomical computation
  const horoscope = computeFullHoroscope(
    { year:birthData.year, month:birthData.month, day:birthData.day,
      hour:birthData.hour, minute:birthData.minute, second:birthData.second || 0,
      gmtOffsetHours:birthData.gmtOffsetHours },
    birthData.latitude, birthData.longitude
  );

  // 2. Dashas
  const moonLon = horoscope.planets.Moon.siderealLongitude;
  const birthDateStr = birthData.year + '-' + String(birthData.month).padStart(2,'0') + '-' + String(birthData.day).padStart(2,'0');
  const vimshDashas = computeVimshottariFromMoon(birthDateStr, moonLon, true);
  const ashDashas   = computeAshtottariFromMoon(birthDateStr, moonLon);

  // 3. Rulerships from Lagna
  const rulerships  = computeRulerships(horoscope.lagna.signCode);
  const d9rulerships = computeRulerships(horoscope.d9.lagna); // D9 has its own Lagna
  const d9houses = horoscope.d9.houses;

  // 4. Planet dignities (D1 and D9)
  const dignities = {};
  ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn'].forEach(p => {
    dignities[p] = {
      d1: getDignity(p, horoscope.planets[p].signCode),
      d9: getDignity(p, horoscope.d9.signs[p])
    };
  });

  // 5. Scan ALL dasha windows from fromYear to toYear
  //    For each MD/AD window, check all age-appropriate events
  const timeline = [];
  const birthYear = birthData.year;

  vimshDashas.forEach(md => {
    md.antardashas.forEach(ad => {
      // Check start of each AD window
      const windowDate = ad.startDate;
      const windowYear = parseInt(windowDate.split('-')[0]);
      if (windowYear < fromYear || windowYear > toYear) return;

      const age = windowYear - birthYear;
      const vP = findActivePeriod(vimshDashas, windowDate);
      const aP = findActiveAshtottariPeriod(ashDashas, windowDate);

      // For each event type, check if this period is relevant
      Object.keys(EVENT_HOUSES).forEach(eventKey => {
        if (!isEventAgeAppropriate(eventKey, age)) return; // Age filter

        const result = verify3Layers(
          eventKey, windowDate, birthYear,
          horoscope, d9houses, d9rulerships, rulerships,
          vimshDashas, ashDashas, null // narayanaD1 added after it's computed
        );

        // Only include in timeline if at least 2 layers pass
        if (result.layersPassed >= 2) {
          timeline.push({
            period: md.lord + '/' + ad.lord,
            windowStart: ad.startDate,
            windowEnd: ad.endDate,
            eventKey,
            score: result.score,
            layersPassed: result.layersPassed,
            allPass: result.allPass,
            age,
            lifeStage: result.lifeStage,
            l1pass: result.l1pass,
            l2pass: result.l2pass,
            l3pass: result.l3pass,
            ageAppropriate: result.ageAppropriate,
            ageNote: result.ageNote,
            karakaD9Dig: result.karakaD9Dig
          });
        }
      });
    });
  });

  // Sort by score desc
  timeline.sort((a,b) => b.score - a.score || a.windowStart.localeCompare(b.windowStart));

  // 6. Past event verification — done AFTER Narayana is computed (see step 8 below)
  const pastVerification = [];

  // 6b. Full analysis
  const bodies = buildBodies(horoscope);
  const analysis = computeAnalysis(bodies, {});

  // 6c. Argala (Ch.10) — decisive influences on each sign
  const argalas = computeAllArgalas(bodies);
  try { analysis.character = computeCharacterAnalysis({ bodies, analysis, dashas: { vimshottari: { mahadashas: vimshDashas }, ashtottari: { mahadashas: ashDashas } } }); } catch(e) { analysis.character = null; }
  try { analysis.portrait = generatePortrait({ bodies, analysis }); } catch(e) { analysis.portrait = null; }

  // 7d. Ashtakavarga (Ch.12) — BAV + SAV + PAV
  const SIGN_CODES_AV = ['Ar','Ta','Ge','Cn','Le','Vi','Li','Sc','Sg','Cp','Aq','Pi'];
  const avPositions = {};
  ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn'].forEach(p => {
    avPositions[p] = SIGN_CODES_AV.indexOf(horoscope.planets[p].signCode);
  });
  avPositions.Lagna = SIGN_CODES_AV.indexOf(horoscope.lagna.signCode);
  const ashtakavarga = computeAshtakavarga(avPositions);
  const upagrahasA = computeGroupA(horoscope.planets.Sun.siderealLongitude);
  // Add house numbers to Group A (lagna needed)
  const lagnaSignIdx = SIGN_INDEX[horoscope.lagna.signCode] ?? 0;
  Object.values(upagrahasA).forEach(u => {
    if (u?.signIndex !== undefined) {
      u.house = ((u.signIndex - lagnaSignIdx + 12) % 12) + 1;
    }
  });
  let upagrahasB = {};  // will be computed after sunriseHour

  // 7c. Divisional Charts D4, D7, D10, D12 (Ch.6.2)
  const planetLons = {};
  ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn','Rahu','Ketu'].forEach(p => {
    planetLons[p] = horoscope.planets[p].siderealLongitude;
  });
  const d4  = computeDivisionalChart(4,  planetLons, horoscope.lagna.longitude);
  const d7  = computeDivisionalChart(7,  planetLons, horoscope.lagna.longitude);
  const d10 = computeDivisionalChart(10, planetLons, horoscope.lagna.longitude);
  const d12 = computeDivisionalChart(12, planetLons, horoscope.lagna.longitude);

  // 7. Panchanga + Special Lagnas (Ch.1.3.8-1.3.12, Ch.5)
  const birthDateObj = new Date(Date.UTC(birthData.year, birthData.month - 1, birthData.day));

  // Sunrise: if birth before sunrise, use previous day's sunrise
  let sunriseHour = computeSunrise(birthData.year, birthData.month, birthData.day,
                                    birthData.latitude, birthData.longitude, birthData.gmtOffsetHours);
  const birthDecimalHour = birthData.hour + birthData.minute / 60 + (birthData.second || 0) / 3600;

  if (birthDecimalHour < sunriseHour) {
    // Born before sunrise — use previous day's sunrise
    const prevDate = new Date(Date.UTC(birthData.year, birthData.month - 1, birthData.day - 1));
    sunriseHour = computeSunrise(prevDate.getUTCFullYear(), prevDate.getUTCMonth() + 1, prevDate.getUTCDate(),
                                  birthData.latitude, birthData.longitude, birthData.gmtOffsetHours);
  }

  const elapsedMinutes = (birthDecimalHour - sunriseHour) * 60;

  // Sun longitude at sunrise (approximate — use birth Sun as close enough for same day)
  // For precision, we'd compute ephemeris at sunrise time; birth Sun is within ~0.04° for same day
  const sunAtSunrise = horoscope.planets.Sun.siderealLongitude;

  // Group B Upagrahas (Gulika, Maandi etc.) — sunrise now available
  try {
    const birthHourDecimal = birthData.hour + birthData.minute / 60 + (birthData.second || 0) / 3600;
    
    // For post-midnight births (hour < 12): use PREVIOUS day's sunset
    // This is a night birth from the PREVIOUS evening's perspective
    const isPostMidnight = birthHourDecimal < 12;
    const sunsetDate = isPostMidnight
      ? new Date(Date.UTC(birthData.year, birthData.month - 1, birthData.day - 1))
      : new Date(Date.UTC(birthData.year, birthData.month - 1, birthData.day));
    
    const sunsetHour = computeSunset(
      sunsetDate.getUTCFullYear(), sunsetDate.getUTCMonth() + 1, sunsetDate.getUTCDate(),
      birthData.latitude, birthData.longitude, birthData.gmtOffsetHours
    );
    
    // Weekday of the SUNSET date (not birth date) for night births
    const WEEKDAY_ORDER = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
    const birthDateWD   = new Date(Date.UTC(birthData.year, birthData.month - 1, birthData.day));
    const weekdayDate   = isPostMidnight ? sunsetDate : birthDateWD;

    upagrahasB = computeGroupB({
      weekday:    WEEKDAY_ORDER[weekdayDate.getUTCDay()],
      sunriseHour, sunsetHour,
      birthHour:  birthHourDecimal, // keep original, Group B handles night detection
      isNightBirth: birthHourDecimal < 12, // explicit night birth flag for post-midnight
      birthYear:  birthData.year, birthMonth: birthData.month, birthDay: birthData.day,
      lat:        birthData.latitude, lon: birthData.longitude, gmtOffset: birthData.gmtOffsetHours,
      computeLagnaFn: (y, mo, d, h, mi, s) => {
        const eph = computeFullHoroscope(
          { year:y, month:mo, day:d, hour:h, minute:mi, second:s||0, gmtOffsetHours: birthData.gmtOffsetHours },
          birthData.latitude, birthData.longitude
        );
        return eph.lagna.longitude;
      }
    });
    
    // Add house numbers to Group B
    Object.values(upagrahasB).forEach(u => {
      if (u?.signIndex !== undefined) {
        u.house = ((u.signIndex - lagnaSignIdx + 12) % 12) + 1;
      }
    });
  } catch(e) {
    upagrahasB = { _error: e.message };
  }

  const specialLagnas = computeSpecialLagnas({
    sunAtSunrise,
    elapsedMinutes,
    moonLon: horoscope.planets.Moon.siderealLongitude,
    lagnaLon: horoscope.lagna.longitude
  });

  // Narayana Dasha (D1) — Ch.18
  const narayanaD1 = computeNarayanaDasha(
    horoscope.lagna.signCode, bodies, horoscope.lagna.longitude, birthDateStr, 120
  );

  // Sudasa — Ch.20 (requires SL)
  const sl = specialLagnas.SL;
  const sudasa = computeSudasa(sl.signCode, sl.degreeInSign, bodies, birthDateStr, 120);

  // Lagna Kendradi — Ch.19 (material success)
  const lagnaKendradi = computeLagnaKendradiDasha(
    horoscope.lagna.signCode, bodies, horoscope.lagna.longitude, birthDateStr, 120
  );

  // Narayana D9 (marriage), D10 (career), D7 (children), D12 (parents) — Ch.18.5
  const narayanaD9  = computeVargaNarayana(9,  horoscope.lagna.signCode, bodies, horoscope.d9?.signs  || {}, birthDateStr, 120);
  const narayanaD10 = computeVargaNarayana(10, horoscope.lagna.signCode, bodies, d10?.signs || {}, birthDateStr, 120);
  const narayanaD7  = computeVargaNarayana(7,  horoscope.lagna.signCode, bodies, d7?.signs  || {}, birthDateStr, 120);
  const narayanaD12 = computeVargaNarayana(12, horoscope.lagna.signCode, bodies, d12?.signs || {}, birthDateStr, 120);
  const { strongerRasi } = require('../computation/narayana-dasha');
  const hlCode = specialLagnas.HL ? specialLagnas.HL.signCode : null;
  const longevityCategory = computeLongevityCategory(horoscope.lagna.signCode, bodies, hlCode);
  const niryanaShoola = computeNiryanaShoola(horoscope.lagna.signCode, bodies, birthDateStr, strongerRasi);
  const shoolaDasha   = computeShoola(horoscope.lagna.signCode, bodies, birthDateStr, strongerRasi, null);
  const rudraInfo     = computeRudraAndTrishoola(horoscope.lagna.signCode, bodies,
    analysis.jaimini?.atmakaraka?.planet || null);

  // Kalachakra Dasha (Ch.24) — inner experience, karmic shifts
  const kalachakra = computeKalachakra(horoscope.planets.Moon.siderealLongitude, birthDateStr, 120);

  const panchanga = computePanchanga(
    horoscope.planets.Moon.siderealLongitude,
    horoscope.planets.Sun.siderealLongitude,
    { birthDate: birthDateObj, sunriseHour, birthHour: birthDecimalHour }
  );

  // Nav Tara for each planet (from natal Moon's nakshatra)
  const moonNakIdx = panchanga.nakshatra.index;
  const navTaras = {};
  ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn','Rahu','Ketu'].forEach(p => {
    const pos = horoscope.planets[p];
    if (pos) {
      const nak = getNakshatra(pos.siderealLongitude);
      navTaras[p] = { nakshatra: nak.name, ...getNavTara(moonNakIdx, nak.index) };
    }
  });
  // 8. Past event verification (now with Narayana Dasha)
  if (opts.pastEvents && opts.pastEvents.length) {
    opts.pastEvents.forEach(ev => {
      const result = verify3Layers(
        ev.eventKey, ev.date, birthYear,
        horoscope, d9houses, d9rulerships, rulerships,
        vimshDashas, ashDashas, narayanaD1
      );
      pastVerification.push({ ...result, userLabel: ev.label });
    });
  }

  panchanga.navTaras = navTaras;

  return {
    native: {
      name: birthData.name || '',
      birthDate: birthDateStr,
      birthTime: String(birthData.hour).padStart(2,'0') + ':' + String(birthData.minute).padStart(2,'0'),
      gmtOffset: (birthData.gmtOffsetHours >= 0 ? '+' : '') + birthData.gmtOffsetHours,
      latitude: birthData.latitude,
      longitude: birthData.longitude
    },
    lagna: horoscope.lagna,
    planets: horoscope.planets,
    bhavachalit: horoscope.bhavachalit,
    d9: horoscope.d9,
    houseCusps: horoscope.houseCusps,
    dignities,
    rulerships,
    d9rulerships,
    bodies,
    analysis,
    panchanga,
    specialLagnas,
    upagrahas: { ...upagrahasA, ...upagrahasB },
    upagrahasA,
    upagrahasB,
    ashtakavarga,
    argalas,
    d4, d7, d10, d12,
    narayanaD1,
    narayanaD9,
    narayanaD10,
    narayanaD7,
    narayanaD12,
    sudasa,
    lagnaKendradi,
    niryanaShoola,
    shoolaDasha,
    rudraInfo,
    longevityCategory,
    kalachakra,
    vimshottariDashas: vimshDashas,
    ashtottariDashas: ashDashas,
    timeline,
    pastVerification,
    // Nakshatra secondary activations — per planet, who gets activated during its dasha
    nakshatraActivations: computeAllSecondaryActivations(bodies),
    methodology: 'Full computation from birth data: VSOP87 planets, GMST-based Lagna, whole-sign Rasi houses (PVR textbook p.78), classical D9, Vimshottari+Ashtottari dashas, Panchanga (Ch.1.3.8-1.3.12). 3-layer event verification: D1 Rasi (dasha lords) + D9 (divisional) + Jupiter/Saturn transit. Age-aware filtering.'
  };
}

module.exports = {
  buildHoroscope,
  verify3Layers,
  isEventAgeAppropriate,
  getLifeStage,
  EVENT_AGE_WINDOWS,
  EVENT_HOUSES,
  EVENT_KARAKAS,
  LIFE_STAGES
};
