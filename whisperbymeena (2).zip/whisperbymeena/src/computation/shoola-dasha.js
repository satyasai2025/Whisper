/**
 * Shoola Dasha Systems — Niryaana Shoola + Shoola + Variants
 * Source: PVR Narasimha Rao "Vedic Astrology: An Integrated Approach"
 *   Ch.14 Longevity, Marakas, Rudra, Trishoola, Maheswara (p.180-186)
 *   Ch.22 Niryaana Shoola Dasa (p.273-279)
 *   Ch.23 Shoola Dasa (p.281-288)
 *
 * CRITICAL: These dasas are for LONGEVITY/DEATH TIMING ONLY.
 * Do NOT use for general event prediction.
 * PVR (Ch.22.3): "Niryaana Shoola dasa is dedicated to timing one's death"
 *
 * Validated examples:
 *   Example 84 (p.274): Sg stronger, odd→forward: Sg(9),Cp(7),Aq(8)... Ge dasa brought death
 *   Example 87 (p.276): Sc stronger, even, Saturn in Sc → Saturn exception → Sc,Sg,Cp... Cp dasa
 *   Example 89-92 (Shoola): lagna/7th seed, always forward, 9yr each
 */

'use strict';

const SIGN_CODES = ['Ar','Ta','Ge','Cn','Le','Vi','Li','Sc','Sg','Cp','Aq','Pi'];
const SIGN_NAMES = ['Aries','Taurus','Gemini','Cancer','Leo','Virgo',
                    'Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'];
const IS_ODD     = [1,0,1,0,1,0,1,0,1,0,1,0];
const IS_MOVABLE = [1,0,0,1,0,0,1,0,0,1,0,0];
const IS_FIXED   = [0,1,0,0,1,0,0,1,0,0,1,0];
const IS_DUAL    = [0,0,1,0,0,1,0,0,1,0,0,1];

// Table 32 — 8th house for Rudra calculation (p.182)
// Indexed by sign index 0-11 (Ar=0)
const TABLE_32_8TH = [
  6,  // Ar → Sc (6)
  2,  // Ta → Ge (2)
  9,  // Ge → Cp (9)
  8,  // Cn → Sg (8)
  3,  // Le → Cn (3)
  10, // Vi → Aq (10)
  1,  // Li → Ta (1)
  8,  // Sc → Sg (8)
  3,  // Sg → Cn (3)
  2,  // Cp → Ge (2)
  9,  // Aq → Cp (9)
  4,  // Pi → Le (4)
];

function addSigns(fromIdx, n, forward) {
  if (forward) return (fromIdx + n) % 12;
  else         return ((fromIdx - n % 12) + 12 * 100) % 12;
}

/**
 * Niryaana Shoola Dasa duration per rasi.
 * Ch.22.2.1: Movable=7yr, Fixed=8yr, Dual=9yr
 */
function niryanaDuration(signIdx) {
  if (IS_MOVABLE[signIdx]) return 7;
  if (IS_FIXED[signIdx])   return 8;
  if (IS_DUAL[signIdx])    return 9;
  return 9;
}

/**
 * Compute Niryaana Shoola Dasa.
 * Source: Ch.22.2.1
 *
 * 1. Find stronger of 2nd and 8th houses
 * 2. If odd → forward; if even → backward
 * 3. Saturn exception: if Saturn in seed → forward (same as Narayana)
 * 4. Duration: movable=7, fixed=8, dual=9
 * 5. Sum of first 3 dasas always = 24 (footnote 61)
 * 6. Antardasa: same rules as Narayana dasa (from book Ch.22.2.1)
 *
 * @param {string} lagnaCode    - Lagna sign code
 * @param {object} bodies       - planet sign positions
 * @param {string} birthDate    - 'YYYY-MM-DD'
 * @param {Function} strongerRasiFn - from narayana-dasha module
 * @returns {object} dasha sequence with dates
 */
function computeNiryanaShoola(lagnaCode, bodies, birthDate, strongerRasiFn) {
  const lagnaIdx = SIGN_CODES.indexOf(lagnaCode);
  const secondHouseIdx  = (lagnaIdx + 1) % 12;
  const eighthHouseIdx  = (lagnaIdx + 7) % 12;
  const secondCode = SIGN_CODES[secondHouseIdx];
  const eighthCode = SIGN_CODES[eighthHouseIdx];

  // Find stronger of 2nd and 8th
  const seedCode = strongerRasiFn(secondCode, eighthCode, bodies);
  const seedIdx  = SIGN_CODES.indexOf(seedCode);

  // Direction: odd = forward, even = backward
  // Saturn exception: if Saturn in seed → forward
  const saturnInSeed = bodies['Saturn']?.signCode === seedCode;
  let forward = IS_ODD[seedIdx] === 1;
  if (saturnInSeed) forward = true; // Saturn exception

  // Generate 12-dasa sequence (one full cycle)
  const sequence = Array.from({length:12}, (_,i) =>
    SIGN_CODES[addSigns(seedIdx, i, forward)]
  );

  // First dasa remainder: use lagna advancement (same as Narayana)
  // Book does not specify fraction explicitly for Niryaana Shoola
  // Using 0 fraction (start from birth) — conservative
  const dasas = [];
  let currentDate = birthDate;
  let totalYears = 0;

  for (let cycle = 1; cycle <= 2 && totalYears < 120; cycle++) {
    sequence.forEach((rasi, i) => {
      if (totalYears >= 120) return;
      const sIdx = SIGN_CODES.indexOf(rasi);
      const yrs  = cycle === 1 ? niryanaDuration(sIdx) : (12 - niryanaDuration(sIdx));
      if (yrs <= 0) return;

      const startDate = currentDate;
      const endDate   = addYearsToDate(currentDate, yrs);

      // Antardasas: 12 equal parts
      const adDuration = yrs / 12;
      const antardasas = [];
      let adCurrent = startDate;
      for (let j = 0; j < 12; j++) {
        const adEnd = addYearsToDate(adCurrent, adDuration);
        // Antardasa sequence starts from dasa rasi itself (forward)
        const adRasi = SIGN_CODES[(sIdx + j) % 12];
        antardasas.push({ rasi: adRasi, rasiName: SIGN_NAMES[SIGN_CODES.indexOf(adRasi)], startDate: adCurrent, endDate: adEnd });
        adCurrent = adEnd;
      }

      dasas.push({ rasi, rasiName: SIGN_NAMES[sIdx], years: yrs, cycle, startDate, endDate, antardasas });
      currentDate = endDate;
      totalYears += yrs;
    });
  }

  return {
    system: 'NiryanaShoola',
    purpose: 'LONGEVITY ONLY — timing of death (Ch.22). Do NOT use for general events.',
    seed: seedCode,
    direction: forward ? 'forward' : 'backward',
    saturnException: saturnInSeed,
    dasas
  };
}

/**
 * Compute Shoola Dasa.
 * Source: Ch.23.2
 *
 * 1. Find stronger of lagna and 7th house
 * 2. ALWAYS go in forward (zodiacal) direction
 * 3. Each dasa = 9 years (all equal, unlike Niryaana)
 * 4. Antardasas = same rules as dasas (treating dasa rasi as lagna)
 *
 * Variants:
 *   Pitri Shoola  (father): stronger of 9th and 3rd
 *   Matri Shoola  (mother): stronger of 4th and 10th
 *   Bhratri Shoola(sibling): stronger of 3rd and 9th
 *   Dara Shoola   (spouse): stronger of 7th and 1st (= regular Shoola)
 *   Putra Shoola  (child): stronger of 5th house and 11th
 */
function computeShoola(lagnaCode, bodies, birthDate, strongerRasiFn, variant) {
  const lagnaIdx = SIGN_CODES.indexOf(lagnaCode);

  // Determine seed houses based on variant
  let h1Idx, h2Idx;
  switch (variant) {
    case 'pitri':    h1Idx = (lagnaIdx + 8) % 12; h2Idx = (lagnaIdx + 2) % 12; break; // 9th and 3rd
    case 'matri':    h1Idx = (lagnaIdx + 3) % 12; h2Idx = (lagnaIdx + 9) % 12; break; // 4th and 10th
    case 'bhratri':  h1Idx = (lagnaIdx + 2) % 12; h2Idx = (lagnaIdx + 8) % 12; break; // 3rd and 9th
    case 'putra':    h1Idx = (lagnaIdx + 4) % 12; h2Idx = (lagnaIdx + 10) % 12; break; // 5th and 11th
    default: // regular (dara)
      h1Idx = lagnaIdx;
      h2Idx = (lagnaIdx + 6) % 12;
  }

  const code1 = SIGN_CODES[h1Idx];
  const code2 = SIGN_CODES[h2Idx];
  const seedCode = strongerRasiFn(code1, code2, bodies);
  const seedIdx  = SIGN_CODES.indexOf(seedCode);

  // Shoola ALWAYS goes forward (Ch.23.2: "always go in regular zodiacal order")
  const dasas = [];
  let currentDate = birthDate;
  let totalYears = 0;
  const SHOOLA_YEARS = 9; // All dasas = 9 years

  for (let i = 0; i < 12 && totalYears < 108; i++) {
    const rasi = SIGN_CODES[(seedIdx + i) % 12];
    const rIdx = SIGN_CODES.indexOf(rasi);

    const startDate = currentDate;
    const endDate   = addYearsToDate(currentDate, SHOOLA_YEARS);

    // Antardasas: 12 equal parts of 9 months each
    const adDuration = SHOOLA_YEARS / 12; // = 0.75 years = 9 months
    const antardasas = [];
    let adCurrent = startDate;

    // Antardasa seed: stronger of dasa rasi and 7th from it (same as dasa rule)
    const antiSeventh = (rIdx + 6) % 12;
    const adSeedCode  = strongerRasiFn(rasi, SIGN_CODES[antiSeventh], bodies);
    const adSeedIdx   = SIGN_CODES.indexOf(adSeedCode);

    for (let j = 0; j < 12; j++) {
      const adRasi = SIGN_CODES[(adSeedIdx + j) % 12];
      const adEnd  = addYearsToDate(adCurrent, adDuration);
      antardasas.push({ rasi: adRasi, rasiName: SIGN_NAMES[SIGN_CODES.indexOf(adRasi)], startDate: adCurrent, endDate: adEnd });
      adCurrent = adEnd;
    }

    dasas.push({ rasi, rasiName: SIGN_NAMES[rIdx], years: SHOOLA_YEARS, startDate, endDate, antardasas });
    currentDate = endDate;
    totalYears += SHOOLA_YEARS;
  }

  const variantName = variant
    ? { pitri:'Pitri Shoola (father)', matri:'Matri Shoola (mother)',
        bhratri:'Bhratri Shoola (siblings)', putra:'Putra Shoola (children)' }[variant]
    : 'Shoola Dasa (self/spouse)';

  return {
    system: 'Shoola',
    variant: variantName,
    purpose: 'LONGEVITY ONLY — timing of death/suffering (Ch.23). Death of relevant person in trine from AL.',
    seed: seedCode,
    direction: 'forward (always)',
    dasas
  };
}

/**
 * Compute Rudra, Trishoola, Maheswara — Ch.14.3
 *
 * Table 32: 8th house from each sign for Rudra calculation.
 * Rudra = stronger of 8th lords from lagna and 7th house (using Table 32).
 * Trishoola = 3 trines from Rudra's position in rasi chart.
 * Maheswara = lord of 8th from AK (exceptions apply).
 */
function computeRudraAndTrishoola(lagnaCode, bodies, akPlanet) {
  const lagnaIdx    = SIGN_CODES.indexOf(lagnaCode);
  const seventhIdx  = (lagnaIdx + 6) % 12;

  // 8th from lagna using Table 32
  const eighth8thFromLagna  = TABLE_32_8TH[lagnaIdx];
  const eighth8thFrom7th    = TABLE_32_8TH[seventhIdx];

  // Lords of those 8th houses
  const SIGN_LORDS = ['Mars','Venus','Mercury','Moon','Sun','Mercury',
                      'Venus','Mars','Jupiter','Saturn','Saturn','Jupiter'];
  const lord1 = SIGN_LORDS[eighth8thFromLagna];
  const lord2 = SIGN_LORDS[eighth8thFrom7th];

  // Stronger planet = Rudra
  // Rules (p.182): more conjunctions > exalted > joined exalted > aspected by more > more advanced
  const b1 = bodies[lord1], b2 = bodies[lord2];
  let rudra;
  if (!b1) rudra = lord2;
  else if (!b2) rudra = lord1;
  else {
    // Count companions
    const companions = (p) => {
      const b = bodies[p];
      if (!b) return 0;
      return Object.values(bodies).filter(x => x && x !== b && x.signCode === b.signCode).length;
    };
    const c1 = companions(lord1), c2 = companions(lord2);
    if (c1 !== c2) rudra = c1 > c2 ? lord1 : lord2;
    else {
      const EXALTED = {Sun:'Ar',Moon:'Ta',Mars:'Cp',Mercury:'Vi',Jupiter:'Cn',Venus:'Pi',Saturn:'Li',Rahu:'Ge',Ketu:'Sg'};
      const e1 = EXALTED[lord1] === b1?.signCode;
      const e2 = EXALTED[lord2] === b2?.signCode;
      if (e1 !== e2) rudra = e1 ? lord1 : lord2;
      else rudra = (b1.longitudeInSign || 0) >= (b2.longitudeInSign || 0) ? lord1 : lord2;
    }
  }

  // Trishoola: trines from Rudra's position (sign)
  const rudraBody = bodies[rudra];
  const rudraSignIdx = rudraBody ? SIGN_CODES.indexOf(rudraBody.signCode) : -1;
  const trishoola = rudraSignIdx >= 0 ? [
    SIGN_CODES[rudraSignIdx],
    SIGN_CODES[(rudraSignIdx + 4) % 12],
    SIGN_CODES[(rudraSignIdx + 8) % 12]
  ] : [];

  // Maheswara: lord of 8th from AK (Ch.14.3)
  let maheswara = null;
  if (akPlanet && bodies[akPlanet]) {
    const akSignIdx = SIGN_CODES.indexOf(bodies[akPlanet].signCode);
    const akBody = bodies[akPlanet];
    const ak8thIdx = TABLE_32_8TH[akSignIdx];

    // Exception: if Rahu or Ketu joins AK or 8th from AK → take 6th from AK
    const rahuInAK = bodies['Rahu']?.signCode === akBody?.signCode;
    const ketuInAK = bodies['Ketu']?.signCode === akBody?.signCode;
    const rahuIn8th = bodies['Rahu']?.signCode === SIGN_CODES[ak8thIdx];
    const ketuIn8th = bodies['Ketu']?.signCode === SIGN_CODES[ak8thIdx];

    if (rahuInAK || ketuInAK || rahuIn8th || ketuIn8th) {
      const sixth = (akSignIdx + 5) % 12;
      maheswara = SIGN_LORDS[sixth];
    } else {
      const ak8thLord = SIGN_LORDS[ak8thIdx];
      // Exception: if 8th lord from AK is in own/exaltation rasi
      const ak8thBody = bodies[ak8thLord];
      const EXALTED = {Sun:'Ar',Moon:'Ta',Mars:'Cp',Mercury:'Vi',Jupiter:'Cn',Venus:'Pi',Saturn:'Li'};
      const OWN_SIGNS = {Sun:['Le'],Moon:['Cn'],Mars:['Ar','Sc'],Mercury:['Ge','Vi'],
                         Jupiter:['Sg','Pi'],Venus:['Ta','Li'],Saturn:['Cp','Aq']};
      const isExalted = ak8thBody && EXALTED[ak8thLord] === ak8thBody.signCode;
      const isOwn = ak8thBody && (OWN_SIGNS[ak8thLord]||[]).includes(ak8thBody.signCode);

      if (isExalted || isOwn) {
        // Take stronger of 8th and 12th lords from Maheswara
        const maheswaraIdx = SIGN_CODES.indexOf(ak8thBody.signCode);
        const from8th  = TABLE_32_8TH[maheswaraIdx];
        const from12th = (maheswaraIdx + 11) % 12;
        const l8 = SIGN_LORDS[from8th], l12 = SIGN_LORDS[from12th];
        maheswara = l8; // simplified: take 8th lord
      } else {
        maheswara = ak8thLord;
      }
    }
  }

  return { rudra, rudraSign: rudraBody?.signCode, trishoola, maheswara };
}

/**
 * Method of Three Pairs — longevity category (Ch.14.5)
 * Returns 'short' (0-36), 'middle' (36-72), or 'long' (72-108)
 *
 * Three pairs:
 *   (a) Lagna lord + 8th lord
 *   (b) Moon + Saturn
 *   (c) Lagna + Hora Lagna
 *
 * Movable = short, Fixed = middle, Dual = long
 * For each pair: take sign type of each, combine:
 *   Same type → that type; Different → middle
 *   Exception (footnote): use Moon-Saturn pair if Moon in lagna or 7th
 */
function computeLongevityCategory(lagnaCode, bodies, hlCode) {
  const SIGN_LORDS_MAP = {
    Ar:'Mars',Ta:'Venus',Ge:'Mercury',Cn:'Moon',Le:'Sun',Vi:'Mercury',
    Li:'Venus',Sc:'Mars',Sg:'Jupiter',Cp:'Saturn',Aq:'Saturn',Pi:'Jupiter'
  };

  function signType(code) {
    const idx = SIGN_CODES.indexOf(code);
    if (idx < 0) return null;
    if (IS_MOVABLE[idx]) return 'short';
    if (IS_FIXED[idx])   return 'middle';
    if (IS_DUAL[idx])    return 'long';
    return null;
  }

  function pairResult(type1, type2) {
    if (!type1 || !type2) return null;
    if (type1 === type2) return type1;
    // Different types → middle (standard interpretation)
    return 'middle';
  }

  const lagnaIdx = SIGN_CODES.indexOf(lagnaCode);
  const eighthLordCode = SIGN_LORDS_MAP[SIGN_CODES[(lagnaIdx + 7) % 12]];
  const lagnaLordCode  = SIGN_LORDS_MAP[lagnaCode];

  // Pair (a): lagna lord sign + 8th lord sign
  const lagnaLordSign = bodies[lagnaLordCode]?.signCode;
  const eighthLordSign = bodies[eighthLordCode]?.signCode;
  const pairA = pairResult(signType(lagnaLordSign), signType(eighthLordSign));

  // Pair (b): Moon sign + Saturn sign
  const moonSign    = bodies['Moon']?.signCode;
  const saturnSign  = bodies['Saturn']?.signCode;
  const pairB = pairResult(signType(moonSign), signType(saturnSign));

  // Pair (c): Lagna + Hora Lagna
  const pairC = hlCode ? pairResult(signType(lagnaCode), signType(hlCode)) : null;

  // Determine final answer
  // "When there is a three-way tie, use Moon-Saturn pair if Moon in lagna or 7th"
  const moonInLagna = bodies['Moon']?.signCode === lagnaCode;
  const moonIn7th   = bodies['Moon']?.signCode === SIGN_CODES[(lagnaIdx + 6) % 12];

  const votes = [pairA, pairB, pairC].filter(Boolean);
  const counts = { short:0, middle:0, long:0 };
  votes.forEach(v => { if (v) counts[v]++; });

  const maxCount = Math.max(...Object.values(counts));
  const winners  = Object.entries(counts).filter(([,v]) => v === maxCount).map(([k]) => k);

  let category;
  if (winners.length === 1) {
    category = winners[0];
  } else if (moonInLagna || moonIn7th) {
    category = pairB || 'middle';
  } else {
    category = pairC || 'middle';
  }

  const RANGES = { short:'0-36 years', middle:'36-72 years', long:'72-108 years' };

  return {
    category,
    range: RANGES[category],
    pairA: { lagnaLord: lagnaLordCode, sign: lagnaLordSign, eighthLord: eighthLordCode, sign8th: eighthLordSign, result: pairA },
    pairB: { moon: moonSign, saturn: saturnSign, result: pairB },
    pairC: { lagna: lagnaCode, hl: hlCode, result: pairC },
    note: 'Method of Three Pairs (Ch.14.5). For guidance only — do not scare client.'
  };
}

function addYearsToDate(dateStr, years) {
  const d = new Date(dateStr);
  d.setTime(d.getTime() + years * 365.25636 * 86400000);
  return d.toISOString().split('T')[0];
}

/**
 * Find active period in shoola/niryaana dasha for a date
 */
function findActiveShoola(dasas, dateStr) {
  for (const md of dasas) {
    if (md.startDate <= dateStr && md.endDate > dateStr) {
      for (const ad of (md.antardasas || [])) {
        if (ad.startDate <= dateStr && ad.endDate > dateStr) {
          return { mahadasha: md.rasi, antardasha: ad.rasi,
                   mdPeriod: { startDate: md.startDate, endDate: md.endDate },
                   adPeriod: { startDate: ad.startDate, endDate: ad.endDate } };
        }
      }
      return { mahadasha: md.rasi, antardasha: null,
               mdPeriod: { startDate: md.startDate, endDate: md.endDate } };
    }
  }
  return null;
}

module.exports = {
  computeNiryanaShoola,
  computeShoola,
  computeRudraAndTrishoola,
  computeLongevityCategory,
  findActiveShoola,
  TABLE_32_8TH,
  SIGN_CODES
};
