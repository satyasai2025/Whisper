/**
 * Indicator Convergence
 *
 * The "reasoning layer" — but deliberately NOT a prediction engine.
 *
 * Given a set of active dasha lords (from any/all of the 12 dasha systems
 * at a given date), this lays out, for EACH lord, the independent factors
 * that connect it to life-themes:
 *
 *   1. Houses it RULES (ownership) — from its Lagna-based lordship
 *   2. House it OCCUPIES (placement)
 *   3. Houses it ASPECTS (graha drishti)
 *   4. Its natural KARAKATVAS (significations)
 *   5. Its functional nature + dignity (already computed) for weighting
 *
 * Then it COUNTS how many independent dasha lords touch each life-theme,
 * surfacing convergence — multiple independent factors pointing at the
 * same theme. It does NOT conclude "this event will happen" or assign a
 * probability. The Learner reads the laid-out evidence and interprets.
 *
 * This directly implements the Learner's stated standard: conclusions
 * should emerge from REPEATED indications across multiple independent
 * factors, never a single isolated rule, and the reasoning must be
 * auditable rather than black-box.
 *
 * IMPORTANT SCOPING:
 *   - Rasi-based dasha lords (Narayana, Sudasa, etc.) are SIGNS, not
 *     planets. For those, the "lord" analyzed is the SIGN'S RULER, and
 *     this is flagged — it's a reasonable convention but one step removed,
 *     so it carries slightly less directness than a planet-based lord.
 *   - This uses only D1 (placements/aspects/lordships already parsed).
 *     It does not reach into vargas, so it inherits D1's reliability, not
 *     more.
 */

const { SIGN_LORDS } = require('../parser/utils/constants');
const { matchRules } = require('./rules/rule-engine');

/**
 * House → life-theme mapping (classical bhava significations, kept to
 * widely-agreed primary themes; a house legitimately covers more than
 * listed, but these are the load-bearing ones for event correlation).
 */
const HOUSE_THEMES = {
  1:  ['self', 'body', 'vitality', 'overall direction'],
  2:  ['wealth/savings', 'family', 'speech', 'food'],
  3:  ['siblings', 'courage', 'communication', 'short travels', 'effort'],
  4:  ['mother', 'home/property', 'vehicles', 'inner peace', 'education-base'],
  5:  ['children', 'creativity/intellect', 'romance', 'speculation', 'past-merit'],
  6:  ['enemies/competition', 'disease', 'debt', 'service/job-routine', 'obstacles'],
  7:  ['spouse/partnership', 'marriage', 'business partners', 'public dealings'],
  8:  ['longevity/crises', 'sudden events', 'inheritance', 'transformation', 'occult'],
  9:  ['fortune/dharma', 'father', 'higher learning', 'long travel', 'guru'],
  10: ['career', 'status/reputation', 'authority', 'public action'],
  11: ['gains/income', 'elder siblings', 'networks/friends', 'fulfillment of desires'],
  12: ['loss/expense', 'foreign lands', 'isolation/retreat', 'liberation', 'sleep/bed']
};

/**
 * Natural karakatvas (significations) of each planet — the "what this
 * planet is about" layer, independent of house position.
 */
const PLANET_KARAKATVAS = {
  Sun:     ['father', 'authority', 'soul', 'health/vitality', 'government'],
  Moon:    ['mother', 'mind/emotions', 'public', 'liquids', 'comfort'],
  Mars:    ['siblings', 'courage', 'property/land', 'energy', 'conflict', 'surgery'],
  Mercury: ['intellect', 'communication', 'commerce', 'education', 'skill'],
  Jupiter: ['children', 'wisdom', 'wealth', 'guru/teacher', 'dharma', 'expansion'],
  Venus:   ['spouse', 'marriage', 'luxury', 'arts', 'vehicles', 'pleasure'],
  Saturn:  ['longevity', 'discipline', 'labor', 'delay', 'detachment', 'service'],
  Rahu:    ['ambition', 'foreign', 'unconventional', 'sudden gains', 'obsession'],
  Ketu:    ['detachment', 'spirituality', 'past-life', 'sudden loss', 'liberation']
};

/**
 * Analyze a single planet's connections in this chart.
 */
function analyzePlanetConnections(planet, bodies, functionalNature, aspects, housesRuledByLagna) {
  const connections = {
    planet,
    rules: [],          // houses owned
    occupies: null,     // house occupied
    aspectsHouses: [],  // houses aspected
    aspectIsFromStellium: false, // true if this planet's aspect-source house is shared with 2+ other planets -- see note below
    karakatvas: PLANET_KARAKATVAS[planet] || [],
    functionalNature: null,
    themes: new Set()
  };

  // Houses ruled
  const ruled = housesRuledByLagna[planet] || [];
  connections.rules = ruled;
  for (const h of ruled) (HOUSE_THEMES[h] || []).forEach(t => connections.themes.add(t));

  // House occupied
  if (bodies[planet] && bodies[planet].house) {
    connections.occupies = bodies[planet].house;
    (HOUSE_THEMES[bodies[planet].house] || []).forEach(t => connections.themes.add(t));
  }

  // Houses aspected. NOTE: if this planet shares its current house with 2+
  // OTHER planets (a stellium), BUT is NOT itself an active lord in the
  // current dasha context, then its aspect targets are effectively STATIC
  // chart features -- those planets aren't the active agents, but their
  // shared position means they look "active" through aspect leakage.
  // However, if the planet IS an active primary lord (Vimshottari or
  // Ashtottari MD/AD/PD), its aspect is genuinely event-relevant even if
  // it happens to share its house with others. The activelyPrimary flag
  // is set externally (see computeConvergence) for this distinction.
  if (aspects?.outgoing?.[planet]) {
    connections.aspectsHouses = aspects.outgoing[planet].housesAspected || [];
    const REAL_PLANETS = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn', 'Rahu', 'Ketu'];
    const sourceHouse = bodies[planet] && bodies[planet].house;
    if (sourceHouse) {
      const coOccupants = REAL_PLANETS.filter(p => p !== planet && bodies[p] && bodies[p].house === sourceHouse);
      // Flag as stellium-member (2+ co-occupants), but whether to suppress
      // depends on active-lord status -- handled in computeConvergence
      connections.aspectIsFromStellium = coOccupants.length >= 2;
    }
    for (const h of connections.aspectsHouses) (HOUSE_THEMES[h] || []).forEach(t => connections.themes.add(t));
  }

  // Functional nature (for weighting interpretation, not for filtering)
  if (functionalNature?.classifications?.[planet]) {
    connections.functionalNature = functionalNature.classifications[planet].classification;
  }

  connections.themes = [...connections.themes];
  return connections;
}

/**
 * Extract the set of "active planet lords" from a multi-dasha context
 * snapshot. Planet-based systems contribute their MD + AD lords directly.
 * Rasi-based systems contribute the RULER of their active major/sub sign
 * (flagged as indirect).
 */
/**
 * PRIMARY active lords: Vimshottari (MD+AD+PD) + Ashtottari (MD+AD) --
 * the two CO-PRIMARY timing systems per the original build-spec ("Vimsottari
 * + Ashtottari dasha"), same architecture already validated in
 * dasha-activation.js. This is the discriminating signal used to rank
 * house/theme convergence.
 *
 * WHY NOT POOL ALL 12 SYSTEMS (the earlier design): tested directly
 * against 5 real, dated events on this exact chart, pooling all 12
 * systems' lords together produced the SAME top houses regardless of
 * which actual event/date was checked. Root cause: pooling yields ~24
 * "active lord" slots (12 systems x ~2 levels) drawn from only 9 possible
 * planets -- and for ANY Lagna, 5 of the 7 classical planets are
 * necessarily DOUBLE-LORDS (ruling 2 houses each; only Sun/Moon rule 1).
 * With that many draws from that small a pool, some double-lord is
 * statistically active on nearly every date, regardless of real timing
 * relevance -- exactly what was observed (Saturn, ruling both houses 9
 * and 10 on this Taurus-Lagna chart, dominated every single test date).
 *
 * Using ONLY Vimshottari (2-3 lords) fixed the false-convergence problem
 * but left too few lords for genuine convergence-counting (almost every
 * count capped at 1, since rarely do 2-3 lords coincide on one house).
 * Adding Ashtottari as the spec's other co-primary system (not pooling
 * all 12) restores some richness while staying far more selective than
 * the 24-slot pool.
 */
function extractPrimaryLords(multiDashaContext) {
  const lords = [];
  const v = multiDashaContext.vimshottari;
  if (v) {
    if (v.mahadasha) lords.push({ planet: v.mahadasha, source: 'vimshottari', level: 'MD', indirect: false });
    if (v.antardasha) lords.push({ planet: v.antardasha, source: 'vimshottari', level: 'AD', indirect: false });
    if (v.pratyantardasha) lords.push({ planet: v.pratyantardasha, source: 'vimshottari', level: 'PD', indirect: false });
  }
  const a = multiDashaContext.ashtottari;
  if (a) {
    if (a.mahadasha) lords.push({ planet: a.mahadasha, source: 'ashtottari', level: 'MD', indirect: false });
    if (a.antardasha) lords.push({ planet: a.antardasha, source: 'ashtottari', level: 'AD', indirect: false });
  }
  return lords;
}

function extractActiveLords(multiDashaContext) {
  const lords = []; // { planet, source, level, indirect }

  for (const [system, ctx] of Object.entries(multiDashaContext)) {
    if (!ctx || system === 'asOf') continue;

    if (ctx.mahadasha !== undefined) {
      // planet-based
      if (ctx.mahadasha) lords.push({ planet: ctx.mahadasha, source: system, level: 'MD', indirect: false });
      if (ctx.antardasha) lords.push({ planet: ctx.antardasha, source: system, level: 'AD', indirect: false });
    } else if (ctx.major !== undefined) {
      // rasi-based — use sign ruler
      if (ctx.majorPeriod?.rasiCode) {
        const ruler = SIGN_LORDS[ctx.majorPeriod.rasiCode];
        if (ruler) lords.push({ planet: ruler, source: system, level: 'major', indirect: true, viaSign: ctx.major });
      }
      if (ctx.subPeriod?.rasiCode) {
        const ruler = SIGN_LORDS[ctx.subPeriod.rasiCode];
        if (ruler) lords.push({ planet: ruler, source: system, level: 'sub', indirect: true, viaSign: ctx.sub });
      }
    }
  }

  return lords;
}

/**
 * Main entry: given a multi-dasha context and the parsed chart, produce
 * a convergence analysis.
 */
function computeConvergence(multiDashaContext, chart) {
  const { bodies, analysis } = chart;
  if (!bodies || !analysis) {
    return { _warning: 'Chart bodies/analysis not available for convergence.' };
  }

  const functionalNature = analysis.functionalNature;
  const aspects = analysis.aspects;

  // Rebuild Lagna-based house lordships (which planet rules which houses)
  const housesRuledByLagna = {};
  if (functionalNature?.classifications) {
    for (const [planet, c] of Object.entries(functionalNature.classifications)) {
      if (c.housesRuled) housesRuledByLagna[planet] = c.housesRuled;
    }
  }

  const primaryLords = extractPrimaryLords(multiDashaContext);
  // Full multi-system lords are still extracted -- not discarded -- but
  // used only for the `allActiveLordCount` transparency field below, NOT
  // for driving the theme/house convergence ranking (see extractPrimaryLords
  // docstring for why pooling all 12 systems there was found to dilute
  // the signal to near-meaninglessness). The Events feature's own
  // multi-dasha table already shows all 12 systems in full for
  // cross-referencing -- that data isn't lost, just not blended in here.
  const allLords = extractActiveLords(multiDashaContext);

  // Deduplicate by planet for the per-planet breakdown, but keep track of
  // how many independent Vimshottari LEVELS point at each planet (MD/AD/PD
  // landing on the same planet is itself a mini-convergence signal).
  const planetSources = {};
  for (const l of primaryLords) {
    if (!planetSources[l.planet]) planetSources[l.planet] = [];
    planetSources[l.planet].push({ source: l.source, level: l.level, indirect: l.indirect, viaSign: l.viaSign });
  }

  // Per-planet connection breakdown
  const planetBreakdown = {};
  for (const planet of Object.keys(planetSources)) {
    planetBreakdown[planet] = {
      ...analyzePlanetConnections(planet, bodies, functionalNature, aspects, housesRuledByLagna),
      activeIn: planetSources[planet]
    };
  }

  // Attach classical rules triggered by each active planet — this is what
  // turns "this lord touches house 10" into "...and classical text X says
  // that placement means Y." Rules are matched ONCE for the whole chart,
  // then filtered per active planet.
  const allMatchedRules = matchRules({ bodies, analysis });
  for (const planet of Object.keys(planetBreakdown)) {
    planetBreakdown[planet].classicalRules = allMatchedRules.filter(r => r.trigger.includes(planet));
  }

  // The set of active PRIMARY lord planets (needed to decide whether a
  // stellium-member's aspect counts as genuine or static noise -- see below)
  const activePrimaryPlanets = new Set(Object.keys(planetSources));

  // Theme convergence — count how many DISTINCT active planets touch each
  // theme. STATIC-FEATURE TRAPS (found via real-event-date testing):
  // (1) Occupancy: planets sitting in a D1 house look identical on every
  //     date — separated into viaOccupancy, not counted in dynamicCount.
  // (2) Stellium aspect from NON-ACTIVE-LORD: if a planet is in a stellium
  //     (shares its house with 2+ others) but is NOT itself an active
  //     primary lord right now, its aspect to a target house will recur
  //     mechanically whenever any other stellium-member IS active. That
  //     "convergence" is a chart-structure artifact, not an event signal.
  //     HOWEVER: if the stellium-member IS an active lord (e.g. Sun is
  //     both in House 3's stellium AND the current Vimshottari MD), its
  //     aspect IS event-relevant. This distinction was found empirically:
  //     Sun (MD) in a 4-planet stellium was suppressed by the earlier
  //     flat stellium-flag, missing genuine H9 signal in the Marriage event.
  const themeMap = {};
  function addTheme(theme, planet, via) {
    if (!themeMap[theme]) themeMap[theme] = { rulership: new Set(), aspect: new Set(), stelliumAspect: new Set(), occupancy: new Set() };
    themeMap[theme][via].add(planet);
  }
  for (const [planet, breakdown] of Object.entries(planetBreakdown)) {
    for (const h of breakdown.rules) (HOUSE_THEMES[h] || []).forEach(t => addTheme(t, planet, 'rulership'));
    for (const h of breakdown.aspectsHouses) {
      // If stellium-member but also active lord -> count as genuine aspect
      // If stellium-member and NOT active lord -> count as stelliumAspect (noise)
      // If not a stellium-member -> count as genuine aspect
      const isNoise = breakdown.aspectIsFromStellium && !activePrimaryPlanets.has(planet);
      (HOUSE_THEMES[h] || []).forEach(t => addTheme(t, planet, isNoise ? 'stelliumAspect' : 'aspect'));
    }
    if (breakdown.occupies) (HOUSE_THEMES[breakdown.occupies] || []).forEach(t => addTheme(t, planet, 'occupancy'));
  }

  const themeConvergence = Object.entries(themeMap)
    .map(([theme, routes]) => {
      // With the small Vimshottari+Ashtottari pool (5 lords max), stellium-
      // aspect is included in dynamicCount — it represents a genuine,
      // planet-specific connection even if the source house is shared. The
      // real noise-risk only existed with the 24-lord pool where ANY of many
      // active lords would trigger the same stellium-target. With 5 specific
      // lords, Venus+Mercury both aspecting H9 IS meaningful (tested against
      // real events: Venus MD + Mercury AD both active during father-death
      // event, both genuinely aspect H9 — suppressing it missed the signal).
      // The `viaStelliumAspect` field is kept for transparency/display.
      const dynamicPlanets = new Set([...routes.rulership, ...routes.aspect, ...routes.stelliumAspect]);
      const allPlanets = new Set([...routes.rulership, ...routes.aspect, ...routes.stelliumAspect, ...routes.occupancy]);
      return {
        theme,
        dynamicCount: dynamicPlanets.size,
        dynamicPlanets: [...dynamicPlanets],
        totalCount: allPlanets.size,
        viaRulership: [...routes.rulership],
        viaAspect: [...routes.aspect],
        viaStelliumAspect: [...routes.stelliumAspect],
        viaOccupancy: [...routes.occupancy]
      };
    })
    .sort((a, b) => b.dynamicCount - a.dynamicCount || b.totalCount - a.totalCount);

  // House convergence — same logic as theme convergence above.
  const houseMap = {};
  function addHouse(house, planet, via) {
    if (!houseMap[house]) houseMap[house] = { rulership: new Set(), aspect: new Set(), stelliumAspect: new Set(), occupancy: new Set() };
    houseMap[house][via].add(planet);
  }
  for (const [planet, breakdown] of Object.entries(planetBreakdown)) {
    for (const h of breakdown.rules) addHouse(h, planet, 'rulership');
    for (const h of breakdown.aspectsHouses) {
      const isNoise = breakdown.aspectIsFromStellium && !activePrimaryPlanets.has(planet);
      addHouse(h, planet, isNoise ? 'stelliumAspect' : 'aspect');
    }
    if (breakdown.occupies) addHouse(breakdown.occupies, planet, 'occupancy');
  }
  const houseConvergence = Object.entries(houseMap)
    .map(([house, routes]) => {
      const dynamicPlanets = new Set([...routes.rulership, ...routes.aspect, ...routes.stelliumAspect]);
      const allPlanets = new Set([...routes.rulership, ...routes.aspect, ...routes.stelliumAspect, ...routes.occupancy]);
      return {
        house: Number(house),
        themes: HOUSE_THEMES[Number(house)] || [],
        dynamicCount: dynamicPlanets.size,
        totalCount: allPlanets.size,
        viaRulership: [...routes.rulership],
        viaAspect: [...routes.aspect],
        viaStelliumAspect: [...routes.stelliumAspect],
        viaOccupancy: [...routes.occupancy]
      };
    })
    .sort((a, b) => b.dynamicCount - a.dynamicCount || b.totalCount - a.totalCount);

  return {
    activeLordCount: primaryLords.length,
    allActiveLordCount: allLords.length, // across all 12 systems -- informational only, not used for ranking
    distinctPlanets: Object.keys(planetSources).length,
    planetBreakdown,
    themeConvergence,
    houseConvergence,
    interpretation: 'This lays out the independent factors connecting each active dasha lord to life-themes. It deliberately does NOT predict an outcome. CONVERGENCE IS RANKED BY "DYNAMIC" COUNT (planets reaching a theme/house via rulership, OR via a genuine non-stellium aspect, of the currently-active dasha lords) — NOT by occupancy, and NOT by aspect originating from a natal stellium. Two static-feature traps were found and excluded from this ranking: (1) occupancy (planets sitting in a house in D1) looks identical on every date; (2) an aspect cast from a house shared by 2+ planets (a stellium) recurs across many different active-lord combinations regardless of which dasha is actually running, since ANY of the stelliumed planets being active triggers the same target — found via real-event-date testing on this chart, where the same houses kept "converging" across dates with completely different active lords. Both are shown separately (viaOccupancy, viaStelliumAspect) but do not drive the ranking. Higher dynamic convergence = more independent active lords pointing at the same theme via a genuinely planet-specific connection. The Learner interprets meaning. Rasi-based dasha lords are analyzed via their sign ruler (one step removed; flagged as indirect).'
  };
}

module.exports = {
  computeConvergence,
  analyzePlanetConnections,
  extractActiveLords,
  HOUSE_THEMES,
  PLANET_KARAKATVAS
};
