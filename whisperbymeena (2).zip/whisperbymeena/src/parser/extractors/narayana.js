/**
 * Narayana Dasha Extractor
 *
 * JHora output format:
 *   Narayana Dasa of D-1 chart (a versatile phalita rasi dasa):
 *   Ge Sc 1998-11-25 Li 1999-04-23 Vi 1999-09-26 Le 2000-02-22 ...
 *   Ta 2001-05-23 Ar 2001-10-26 Pi 2002-03-23 ...
 *   Aq Ar 2003-11-25 Pi 2004-08-25 ...
 *
 * Structurally identical to Vimshottari but rasi-based:
 *   - Major period = rasi (2-letter sign code)
 *   - Sub-period = rasi + start date
 *   - Each major period has 12 sub-periods (one per rasi)
 */

const { normalizeSign, SIGN_INDEX } = require('../utils/constants');

function extractNarayana(sectionText) {
  // Strip header line
  const bodyStart = sectionText.indexOf('\n');
  if (bodyStart === -1) return { periods: [] };
  const bodyText = sectionText.substring(bodyStart + 1);

  const tokens = tokenizeRasiDasha(bodyText);
  const periods = groupRasiPeriods(tokens);
  computeRasiEndDates(periods);

  return { periods };
}

function tokenizeRasiDasha(text) {
  const tokens = [];
  for (const raw of text.split(/\s+/).filter(Boolean)) {
    // Handle potential glued rasi+date (e.g. "Ge1999-04-23")
    const m = raw.match(/^([A-Z][a-z])(\d{4}-\d{2}-\d{2})$/);
    if (m) {
      tokens.push(m[1]);
      tokens.push(m[2]);
    } else {
      tokens.push(raw);
    }
  }
  return tokens;
}

const isDate = t => /^\d{4}-\d{2}-\d{2}$/.test(t);
const isRasi = t => t in SIGN_INDEX;

function groupRasiPeriods(tokens) {
  const periods = [];
  let current = null;

  for (let i = 0; i < tokens.length; ) {
    if (isRasi(tokens[i]) && isRasi(tokens[i + 1])) {
      // Major boundary: <Major-rasi> <Sub-rasi> ...
      if (current) periods.push(current);
      current = {
        rasiCode: tokens[i],
        rasi: normalizeSign(tokens[i]),
        startDate: null,
        endDate: null,
        subPeriods: []
      };
      i++;
    } else if (isRasi(tokens[i]) && isDate(tokens[i + 1])) {
      if (!current) {
        i += 2;
        continue;
      }
      current.subPeriods.push({
        rasiCode: tokens[i],
        rasi: normalizeSign(tokens[i]),
        startDate: tokens[i + 1],
        endDate: null
      });
      i += 2;
    } else {
      i++;
    }
  }

  if (current) periods.push(current);
  return periods;
}

function computeRasiEndDates(periods) {
  const flat = [];
  periods.forEach((p, pIdx) => {
    p.subPeriods.forEach((sp, spIdx) => {
      flat.push({ pIdx, spIdx });
    });
  });

  for (let i = 0; i < flat.length; i++) {
    const { pIdx, spIdx } = flat[i];
    const sp = periods[pIdx].subPeriods[spIdx];
    const next = flat[i + 1];
    if (next) {
      sp.endDate = periods[next.pIdx].subPeriods[next.spIdx].startDate;
    }
  }

  for (const p of periods) {
    if (p.subPeriods.length > 0) {
      p.startDate = p.subPeriods[0].startDate;
      p.endDate = p.subPeriods[p.subPeriods.length - 1].endDate;
    }
  }
}

function findActiveNarayana(periods, targetDate) {
  const target = new Date(targetDate);
  for (const p of periods) {
    const start = new Date(p.startDate);
    const end = p.endDate ? new Date(p.endDate) : null;
    if (target >= start && (!end || target < end)) {
      for (const sp of p.subPeriods) {
        const spStart = new Date(sp.startDate);
        const spEnd = sp.endDate ? new Date(sp.endDate) : null;
        if (target >= spStart && (!spEnd || target < spEnd)) {
          return { major: p.rasi, sub: sp.rasi, majorPeriod: p, subPeriod: sp };
        }
      }
      return { major: p.rasi, sub: null, majorPeriod: p, subPeriod: null };
    }
  }
  return null;
}

module.exports = {
  extractNarayana,
  findActiveNarayana,
  tokenizeRasiDasha,
  groupRasiPeriods,
  computeRasiEndDates
};
