/**
 * Jaimini — Atmakaraka & Karakamsa Lagna
 *
 * The Atmakaraka (AK) is the planet with the highest degree (within its
 * sign) among the seven chara karakas — the "significator of the soul,"
 * the most important planet in Jaimini analysis. PVR's methodology treats
 * the AK and the Karakamsa Lagna as central to understanding the native's
 * deepest drives, spiritual direction, and life purpose.
 *
 * KARAKAMSA LAGNA (KL):
 * The sign the AK occupies IN THE NAVAMSA (D9) is called the Karakamsa.
 * Treated as a special Lagna, houses are counted FROM the Karakamsa to
 * read soul-level themes (career-of-the-soul, spiritual obstacles, etc.).
 * Jaimini's Karakamsa rules look at which planets occupy/aspect the
 * Karakamsa and the houses from it.
 *
 * AK NAKSHATRA:
 * The AK's nakshatra carries significance for spiritual inclination and,
 * in some traditions, the Ishta Devata (cherished deity) — though the
 * Ishta Devata is more precisely derived from the 12th-from-Karakamsa,
 * not the AK nakshatra directly. We surface the AK nakshatra + its lord
 * and the 12th-from-Karakamsa, clearly distinguishing the two.
 *
 * ============================ HONESTY CAVEATS ============================
 * 1. BIRTH-TIME SENSITIVITY: The Karakamsa is a NAVAMSA position. Like all
 *    D9-based analysis, it is highly sensitive to birth-time accuracy — a
 *    few minutes' error can shift the AK into a different navamsa sign and
 *    change the entire Karakamsa reading. This whole module is therefore a
 *    SUPPORTING layer, to be trusted only when birth time is reliable.
 *
 * 2. AK CALCULATION SCHEMES DIFFER: There are two schools on chara karaka
 *    calculation — the 7-karaka scheme (Sun..Saturn) and the 8-karaka
 *    scheme (including Rahu, counted by its reverse degree). JHora's output
 *    (which this tool consumes) has ALREADY assigned the karakas, so we use
 *    its assignment directly rather than recomputing — but the Learner
 *    should know the AK identity itself depends on which scheme the source
 *    software used.
 *
 * 3. Ishta Devata derivation has multiple classical variants. We show the
 *    raw indicators (12th-from-KL, its lord) rather than naming a specific
 *    deity, which would overstep into territory where traditions diverge.
 * =========================================================================
 */

const {
  SIGN_INDEX, SIGN_ORDER, SIGN_LORDS, NAKSHATRA_LORDS, normalizeNakshatra
} = require('../parser/utils/constants');

const JAIMINI_BODIES = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn', 'Rahu', 'Ketu'];

/**
 * Planets occupying a given navamsa sign, using the D9 positions already
 * parsed (each body's navamsaCode). Limited to the 7 grahas + 2 nodes —
 * special points (Maandi, upagrahas, sub-lagnas) are excluded, since
 * classical Karakamsa analysis reads graha occupancy.
 */
function planetsInNavamsaSign(bodies, signCode) {
  const occupants = [];
  for (const name of JAIMINI_BODIES) {
    const body = bodies[name];
    if (body && body.navamsaCode === signCode) occupants.push(name);
  }
  return occupants;
}

/**
 * Count a house from the Karakamsa sign.
 */
function signAtHouseFrom(fromSignCode, houseNum) {
  const idx = (SIGN_INDEX[fromSignCode] + houseNum - 1) % 12;
  return SIGN_ORDER[idx];
}

function computeJaimini(bodies, charaKarakas) {
  if (!charaKarakas || !charaKarakas.AK) {
    return { _warning: 'Atmakaraka not identified in parsed data — cannot compute Jaimini analysis.' };
  }

  const akPlanet = charaKarakas.AK;
  const akBody = bodies[akPlanet];
  if (!akBody) {
    return { _warning: `Atmakaraka (${akPlanet}) body not found in parsed positions.` };
  }

  // --- Karakamsa Lagna = AK's navamsa sign ---
  const karakamsaSign = akBody.navamsaCode;

  // Planets in the Karakamsa (navamsa occupants of that sign)
  const karakamsaOccupants = planetsInNavamsaSign(bodies, karakamsaSign);

  // 12th from Karakamsa (Ishta Devata indicator house) and its sign/lord
  const twelfthFromKL = signAtHouseFrom(karakamsaSign, 12);
  const twelfthLord = SIGN_LORDS[twelfthFromKL];
  const twelfthOccupants = planetsInNavamsaSign(bodies, twelfthFromKL);

  // --- AK nakshatra ---
  const akNakshatraName = normalizeNakshatra(akBody.nakshatraCode);
  const akNakshatraLord = NAKSHATRA_LORDS[akNakshatraName] || null;

  // --- AK's D1 placement (also meaningful in Jaimini) ---
  const akD1House = akBody.house;
  const akD1Sign = akBody.signCode;

  return {
    atmakaraka: {
      planet: akPlanet,
      d1Sign: akD1Sign,
      d1House: akD1House,
      d1DegreeInSign: Number(akBody.longitudeInSign?.toFixed(2)),
      nakshatra: akNakshatraName,
      nakshatraPada: akBody.pada,
      nakshatraLord: akNakshatraLord,
      note: 'The Atmakaraka is the soul-significator — the single most important planet in Jaimini analysis. Its themes describe the native\'s deepest drives and karmic focus.'
    },
    karakamsaLagna: {
      sign: karakamsaSign,
      occupants: karakamsaOccupants,
      note: 'Karakamsa = the AK\'s navamsa sign, read as a special Lagna for soul-level themes. Planets occupying it color the soul\'s expression.'
    },
    ishtaDevataIndicators: {
      twelfthFromKarakamsa: twelfthFromKL,
      twelfthLord,
      twelfthOccupants,
      note: 'The 12th-from-Karakamsa (its sign, lord, and occupants) is the classical Ishta Devata indicator — pointing toward the form of the divine the soul is drawn to for liberation. We surface the indicators rather than naming a specific deity, since traditions differ on the final mapping.'
    },
    allCharaKarakas: charaKarakas,
    caveats: {
      birthTime: 'Karakamsa is a NAVAMSA (D9) position — highly birth-time sensitive. A few minutes\' error can change the entire reading. Treat as supporting, not primary, unless birth time is confirmed reliable.',
      akScheme: 'The AK identity depends on whether the source software used the 7-karaka or 8-karaka scheme. This tool uses the assignment already made by JHora rather than recomputing.',
      ishtaDevata: 'Ishta Devata derivation has multiple classical variants; only the raw indicators are shown, not a named deity.'
    }
  };
}

module.exports = { computeJaimini };
