/**
 * Arudha Padas (Bhava Arudhas) — A1 through A12
 *
 * Source: Jaimini system, as documented in BPHS and central to PVR's
 * methodology. The Arudha represents how a house's matters MANIFEST/
 * APPEAR in the world — often described as the "image" or "perceived
 * reality" of that house, which can differ from the house's actual
 * (Graha-based) promise.
 *
 * Classical algorithm, applied independently to EACH house (1-12):
 *   1. Find the sign of house H (counting from Lagna).
 *   2. Find that sign's lord, and the house the lord currently occupies.
 *   3. Count the distance from H to the lord's house (H itself = 1).
 *   4. From the lord's house, count that same distance forward again —
 *      this gives the raw Arudha position.
 *   5. EXCEPTION: if the raw Arudha falls in the SAME house as H itself,
 *      or in the 7th house from H, shift it forward by 10 houses instead.
 *      (This avoids the Arudha collapsing onto the bhava it represents.)
 *
 * Named aliases in common use:
 *   A1  = Arudha Lagna (AL)   — how the native is perceived by the world
 *   A12 = Upapada Lagna (UL)  — spouse/marriage indicator (Jaimini)
 *   A7  = Darapada           — also spouse-related (alternate/complementary to UL)
 *   A10 = career image
 *
 * LIMITATION: This computation depends entirely on accurate house
 * placements (already computed from Lagna + body positions). It does
 * NOT use D9/D60 or birth-time-sensitive subtleties beyond what's already
 * in the parsed D1 — so it carries the same birth-time-reliability caveat
 * as the rest of this chart.
 */

const { SIGN_LORDS } = require('../parser/utils/constants');
const { signAtHouse } = require('./functional-nature');

const ARUDHA_ALIASES = {
  1: 'Arudha Lagna (AL)',
  7: 'Darapada',
  10: 'Career Image',
  12: 'Upapada Lagna (UL)'
};

function seventhFrom(house) {
  return ((house - 1 + 6) % 12) + 1;
}

function shiftByTen(house) {
  return ((house - 1 + 10) % 12) + 1;
}

/**
 * Compute the Arudha for a single house H, given the Lagna sign and
 * planet house-positions (from `bodies`).
 */
function computeSingleArudha(lagnaSignCode, houseNumber, bodies) {
  const bhavaSign = signAtHouse(lagnaSignCode, houseNumber);
  const lord = SIGN_LORDS[bhavaSign];

  if (!bodies[lord] || !bodies[lord].house) {
    return {
      bhava: houseNumber,
      bhavaSign,
      lord,
      error: `Could not locate ${lord} (lord of house ${houseNumber}) in parsed body positions.`
    };
  }

  const lordHouse = bodies[lord].house;
  const distance = ((lordHouse - houseNumber + 12) % 12) + 1;
  const rawArudhaHouse = ((lordHouse - 1 + distance - 1) % 12) + 1;

  const seventh = seventhFrom(houseNumber);
  const exceptionApplied = (rawArudhaHouse === houseNumber || rawArudhaHouse === seventh);
  const finalArudhaHouse = exceptionApplied ? shiftByTen(rawArudhaHouse) : rawArudhaHouse;

  return {
    bhava: houseNumber,
    bhavaSign,
    lord,
    lordHouse,
    distance,
    rawArudhaHouse,
    exceptionApplied,
    finalArudhaHouse,
    alias: ARUDHA_ALIASES[houseNumber] || null
  };
}

/**
 * Compute all 12 Bhava Arudhas (A1-A12) for the chart.
 */
function computeArudhas(lagnaSignCode, bodies) {
  const arudhas = {};
  for (let h = 1; h <= 12; h++) {
    arudhas[`A${h}`] = computeSingleArudha(lagnaSignCode, h, bodies);
  }

  return {
    arudhas,
    methodology: 'Jaimini Bhava Arudha algorithm (BPHS-documented): count from bhava to its lord, then the same distance again from the lord; shift by 10 houses if the result falls in the bhava itself or its 7th. Carries the same birth-time-reliability dependency as the rest of D1.'
  };
}

module.exports = { computeArudhas, computeSingleArudha, ARUDHA_ALIASES };
