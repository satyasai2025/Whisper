/**
 * Upagrahas Computation — Both Groups
 * Source: PVR Narasimha Rao "Vedic Astrology: An Integrated Approach" Ch.4
 *
 * Ch.4.2 Group A — Sun-based (Table 9, p.41-42)
 * Ch.4.3 Group B — Weekday+Sunrise-based (Table 10, p.43-44)
 *
 * Validated example in book:
 *   Exercise 7: Sun at Ta 13°19' (lon=43.3167°)
 *   Answer: Dhuma Vi 26°39', Vyatipaata Li 3°21', Parivesha Ar 3°21',
 *           Indrachaapa Pi 26°39', Upaketu Sc 19°1'
 */

'use strict';

const SIGN_NAMES = ['Aries','Taurus','Gemini','Cancer','Leo','Virgo',
                    'Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'];
const SIGN_CODES = ['Ar','Ta','Ge','Cn','Le','Vi','Li','Sc','Sg','Cp','Aq','Pi'];

function lonToSign(lon) {
  const l = ((lon % 360) + 360) % 360;
  const idx = Math.floor(l / 30);
  return {
    longitude: l,
    signIndex: idx,
    sign: SIGN_NAMES[idx],
    signCode: SIGN_CODES[idx],
    degreeInSign: Number((l % 30).toFixed(6)),
    malefic: true // all upagrahas are malefic per Ch.4.2
  };
}

// ── GROUP A: Sun-based (Table 9, Ch.4.2) ─────────────────────────────────────

/**
 * Compute Group A upagrahas from Sun's sidereal longitude.
 * @param {number} sunLon - Sun's sidereal longitude (0-360)
 * @returns {object} { Dhuma, Vyatipaata, Parivesha, Indrachaapa, Upaketu }
 */
function computeGroupA(sunLon) {
  const sun = ((sunLon % 360) + 360) % 360;

  const dhumaLon      = (sun + 133 + 20/60) % 360;
  const vyatipaataLon = (360 - dhumaLon + 360) % 360;
  const pariveshaLon  = (vyatipaataLon + 180) % 360;
  const indrachapaLon = (360 - pariveshaLon + 360) % 360;
  const upaketuLon    = (indrachapaLon + 16 + 40/60) % 360;
  // Note: book also states Upaketu = Sun - 30° (equivalent formula)

  return {
    Dhuma:      lonToSign(dhumaLon),
    Vyatipaata: lonToSign(vyatipaataLon),
    Parivesha:  lonToSign(pariveshaLon),
    Indrachaapa:lonToSign(indrachapaLon),
    Upaketu:    lonToSign(upaketuLon)
  };
}

// ── GROUP B: Weekday + Sunrise (Table 10, Ch.4.3) ────────────────────────────

/**
 * Table 10 from book — exact as printed (p.43)
 * Index 0=Sunday, 1=Monday, ... 6=Saturday
 * null = "lord-less" part
 */
const TABLE_10_DAY = [
  ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn',null],   // Sun
  ['Moon','Mars','Mercury','Jupiter','Venus','Saturn',null,'Sun'],   // Mon
  ['Mars','Mercury','Jupiter','Venus','Saturn',null,'Sun','Moon'],   // Tue
  ['Mercury','Jupiter','Venus','Saturn',null,'Sun','Moon','Mars'],   // Wed
  ['Jupiter','Venus','Saturn',null,'Sun','Moon','Mars','Mercury'],   // Thu
  ['Venus','Saturn',null,'Sun','Moon','Mars','Mercury','Jupiter'],   // Fri
  ['Saturn',null,'Sun','Moon','Mars','Mercury','Jupiter','Venus'],   // Sat
];

const TABLE_10_NIGHT = [
  ['Jupiter','Venus','Saturn',null,'Sun','Moon','Mars','Mercury'],   // Sun
  ['Venus','Saturn',null,'Sun','Moon','Mars','Mercury','Jupiter'],   // Mon
  ['Saturn',null,'Sun','Moon','Mars','Mercury','Jupiter','Venus'],   // Tue
  ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn',null],   // Wed
  ['Moon','Mars','Mercury','Jupiter','Venus','Saturn',null,'Sun'],   // Thu
  ['Mars','Mercury','Jupiter','Venus','Saturn',null,'Sun','Moon'],   // Fri
  ['Mercury','Jupiter','Venus','Saturn',null,'Sun','Moon','Mars'],   // Sat
];

/**
 * Compute Group B upagrahas.
 * Requires: sunrise time, sunset time, birth time, weekday, birth coordinates.
 * Returns longitudes by computing Lagna (ascendant) at specific times.
 *
 * @param {object} params
 * @param {number} params.weekday       - 0=Sunday ... 6=Saturday
 * @param {number} params.sunriseHour   - decimal hour of sunrise (local time)
 * @param {number} params.sunsetHour    - decimal hour of sunset (local time)
 * @param {number} params.birthHour     - decimal hour of birth (local time)
 * @param {number} params.birthYear     - birth year
 * @param {number} params.birthMonth    - birth month
 * @param {number} params.birthDay      - birth day
 * @param {number} params.lat           - latitude
 * @param {number} params.lon           - longitude (East positive)
 * @param {number} params.gmtOffset     - GMT offset in hours
 * @param {Function} params.computeLagna - function(year,month,day,hour,lat,lon,gmtOffset) → lagnaLon
 */
function computeGroupB(params) {
  const { weekday, sunriseHour, sunsetHour, birthHour,
          birthYear, birthMonth, birthDay,
          lat, lon, gmtOffset, computeLagnaFn,
          isNightBirth } = params;

  // Post-midnight births (1:31 AM) are night births from previous evening
  // isNightBirth can be explicitly passed, or auto-detected
  const isDayBirth = isNightBirth === true ? false 
                   : isNightBirth === false ? true
                   : (birthHour >= sunriseHour && birthHour < sunsetHour);
  const table = isDayBirth ? TABLE_10_DAY : TABLE_10_NIGHT;

  // weekday can be string ('Sun','Mon'...) or number (0-6)
  const WEEKDAY_TO_IDX = { Sun:0, Mon:1, Tue:2, Wed:3, Thu:4, Fri:5, Sat:6 };
  const weekdayIdx = typeof weekday === 'number' ? weekday : (WEEKDAY_TO_IDX[weekday] ?? 0);
  const rulers = table[weekdayIdx]; // 8 rulers for this weekday, day/night

  // Length of day or night in hours
  const dayLength   = sunsetHour - sunriseHour;
  const nightLength = 24 - dayLength;
  const periodLength = (isDayBirth ? dayLength : nightLength) / 8;

  // Period start times (relative to sunrise for day, sunset for night)
  // For post-midnight night births: sunset base is from previous day (add 24 to keep arithmetic)
  const periodBase = isDayBirth ? sunriseHour 
                   : (birthHour < 12 ? sunsetHour : sunsetHour);

  // For each upagraha, find the time and compute lagna there
  // Ch.4.3: Kaala=middle of Sun's part, Mrityu=middle of Mars's, etc.
  // Maandi=BEGINNING of Saturn's part (special case)
  const PLANET_TO_UPAGRAHA = {
    'Sun':     { name:'Kaala',         useMiddle: true  },
    'Mars':    { name:'Mrityu',        useMiddle: true  },
    'Mercury': { name:'ArthaPrahara',  useMiddle: true  },
    'Jupiter': { name:'YamaGhantaka',  useMiddle: true  },
    'Saturn':  { name:'Gulika',        useMiddle: true  },
    // Maandi = beginning of Saturn's part (Ch.4.3 step 6)
  };

  const result = {};

  rulers.forEach((ruler, partIdx) => {
    if (!ruler) return; // lord-less part — skip
    const upagraha = PLANET_TO_UPAGRAHA[ruler];
    if (!upagraha) return; // not one of the 5 we compute

    const partStart = periodBase + partIdx * periodLength;
    const partMiddle = partStart + periodLength / 2;

    // Compute lagna at partMiddle
    let computeHour = upagraha.useMiddle ? partMiddle : partStart;

    // Handle overflow past midnight
    let cHour = computeHour % 24;
    let cDay = birthDay + Math.floor(computeHour / 24);

    let lagnaLon;
    try {
      lagnaLon = computeLagnaFn(birthYear, birthMonth, cDay, cHour, lat, lon, gmtOffset);
    } catch(e) {
      lagnaLon = null;
    }

    if (lagnaLon !== null && lagnaLon !== undefined) {
      result[upagraha.name] = {
        ...lonToSign(lagnaLon),
        partIndex: partIdx + 1,
        partStart: partStart.toFixed(4),
        computedAt: computeHour.toFixed(4),
        malefic: ['Kaala','Mrityu','Gulika'].includes(upagraha.name), // ArthaPrahara~Mercury, YamaGhantaka~Jupiter are benefic
        nature: upagraha.name === 'ArthaPrahara' ? 'Mercury-like' :
                upagraha.name === 'YamaGhantaka' ? 'Jupiter-like' : 'Saturn-like'
      };
    }
  });

  // Maandi = beginning of Saturn's part (separate from Gulika which is middle)
  const saturnPartIdx = rulers.indexOf('Saturn');
  if (saturnPartIdx >= 0) {
    const maandiTime = periodBase + saturnPartIdx * periodLength; // START of Saturn's part
    let cHour = maandiTime % 24;
    let cDay = birthDay + Math.floor(maandiTime / 24);
    try {
      const lagnaLon = computeLagnaFn(birthYear, birthMonth, cDay, cHour, lat, lon, gmtOffset);
      result['Maandi'] = {
        ...lonToSign(lagnaLon),
        partIndex: saturnPartIdx + 1,
        computedAt: maandiTime.toFixed(4),
        malefic: true,
        nature: 'Saturn-like (start of part)'
      };
    } catch(e) {}
  }

  return result;
}

/**
 * Compute all 11 upagrahas.
 * @param {number} sunLon           - Sun's sidereal longitude
 * @param {object} groupBParams     - params for computeGroupB
 * @returns {object} all 11 upagrahas
 */
function computeAllUpagrahas(sunLon, groupBParams) {
  const groupA = computeGroupA(sunLon);
  const groupB = groupBParams ? computeGroupB(groupBParams) : {};
  return { ...groupA, ...groupB };
}

module.exports = { computeGroupA, computeGroupB, computeAllUpagrahas };
