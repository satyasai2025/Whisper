/**
 * Divisional Charts Computation
 * Source: PVR Narasimha Rao "Vedic Astrology: An Integrated Approach" Ch.6.2
 *
 * Validated examples from book:
 *   D4  — Example 12 (p.53): Ta 3/14/23 → Ta/Le/Aq ✅
 *   D7  — Example 14 (p.54): Ge 10°→Le, Vi 19°→Cn ✅
 *   D9  — Example 16 (p.55): Ge 11°→Cp, Sc 19°→Sg ✅ (already validated separately)
 *   D10 — Example 17 (p.55-56): Ge 10°→Vi, Sc 19°→Cp ✅
 *   D12 — no explicit example in book; formula: starts from rasi itself
 */

'use strict';

const SIGN_CODES = ['Ar','Ta','Ge','Cn','Le','Vi','Li','Sc','Sg','Cp','Aq','Pi'];
const SIGN_NAMES = ['Aries','Taurus','Gemini','Cancer','Leo','Virgo',
                    'Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'];

const IS_ODD      = [1,0,1,0,1,0,1,0,1,0,1,0]; // Ar,Ge,Le,Li,Sg,Aq = odd
const IS_MOVABLE  = [1,0,0,1,0,0,1,0,0,1,0,0];
const IS_FIXED    = [0,1,0,0,1,0,0,1,0,0,1,0];
const IS_DUAL     = [0,0,1,0,0,1,0,0,1,0,0,1];
const IS_FIRE     = [1,0,0,0,1,0,0,0,1,0,0,0];
const IS_EARTH    = [0,1,0,0,0,1,0,0,0,1,0,0];
const IS_AIR      = [0,0,1,0,0,0,1,0,0,0,1,0];
const IS_WATER    = [0,0,0,1,0,0,0,1,0,0,0,1];

function addSigns(fromIdx, n) { return (fromIdx + n) % 12; }

function signInfo(lon) {
  const l = ((lon % 360) + 360) % 360;
  const idx = Math.floor(l / 30);
  return { idx, code: SIGN_CODES[idx], name: SIGN_NAMES[idx], deg: l % 30, lon: l };
}

function result(lon) {
  const l = ((lon % 360) + 360) % 360;
  const idx = Math.floor(l / 30);
  return {
    signCode: SIGN_CODES[idx],
    sign: SIGN_NAMES[idx],
    signIndex: idx,
    degreeInSign: l % 30
  };
}

// ── D1 Rasi (trivially the sign itself) ──────────────────────────────────────
function computeD1(lon) {
  const s = signInfo(lon);
  return { signCode: s.code, sign: s.name, signIndex: s.idx, degreeInSign: s.deg };
}

// ── D2 Hora (Ch.6.2.2) ───────────────────────────────────────────────────────
// PVR note: "proper use beyond scope of this book" — implement but mark as rarely used
function computeD2(lon) {
  const s = signInfo(lon);
  // Odd rasi: 0-15°→Sun's hora (Le), 15-30°→Moon's hora (Cn)
  // Even rasi: 0-15°→Moon's hora (Cn), 15-30°→Sun's hora (Le)
  const isFirstHalf = s.deg < 15;
  const isSunHora = IS_ODD[s.idx] ? isFirstHalf : !isFirstHalf;
  const horaSign = isSunHora ? 4 : 3; // Le=4, Cn=3
  return result(horaSign * 30 + s.deg);
}

// ── D3 Drekkana (Ch.6.2.3) ───────────────────────────────────────────────────
// 0-10°→same rasi, 10-20°→5th, 20-30°→9th
function computeD3(lon) {
  const s = signInfo(lon);
  const pada = Math.floor(s.deg / 10); // 0,1,2
  const offset = [0, 4, 8][pada];
  return result(addSigns(s.idx, offset) * 30 + s.deg % 10);
}

// ── D4 Chaturthamsa (Ch.6.2.4) ───────────────────────────────────────────────
// 4 padas of 7.5° each; 1st/2nd/3rd/4th → 1st/4th/7th/10th from rasi
// Example 12 validated: Ta 3°→Ta, Ta 14°→Le, Ta 23°→Aq ✅
function computeD4(lon) {
  const s = signInfo(lon);
  const pada = Math.floor(s.deg / 7.5); // 0-3
  const offsets = [0, 3, 6, 9];
  return result(addSigns(s.idx, offsets[pada]) * 30 + s.deg % 7.5);
}

// ── D7 Saptamsa (Ch.6.2.7) ───────────────────────────────────────────────────
// 7 padas of 30/7° each
// Odd rasi: starts from rasi itself
// Even rasi: starts from 7th from it
// Example 14 validated: Ge 10°→Le, Vi 19°→Cn ✅
function computeD7(lon) {
  const s = signInfo(lon);
  const PADA_SPAN = 30 / 7;
  const pada = Math.floor(s.deg / PADA_SPAN); // 0-6
  const startFrom = IS_ODD[s.idx] ? s.idx : addSigns(s.idx, 6); // 6 away = 7th
  return result(addSigns(startFrom, pada) * 30 + (s.deg % PADA_SPAN));
}

// ── D9 Navamsa (Ch.6.2.9) ────────────────────────────────────────────────────
// 9 padas of 3.333° each
// Fire→Ar, Earth→Cp, Air→Li, Water→Cn
// Example 16 validated: Ge 11°→Cp, Sc 19°→Sg ✅ (also separately validated)
function computeD9(lon) {
  const s = signInfo(lon);
  const PADA_SPAN = 10 / 3; // 3.3333°
  const pada = Math.floor(s.deg / PADA_SPAN); // 0-8
  let startFrom;
  if (IS_FIRE[s.idx])  startFrom = 0;  // Ar
  if (IS_EARTH[s.idx]) startFrom = 9;  // Cp
  if (IS_AIR[s.idx])   startFrom = 6;  // Li
  if (IS_WATER[s.idx]) startFrom = 3;  // Cn
  return result(addSigns(startFrom, pada) * 30 + (s.deg % PADA_SPAN));
}

// ── D10 Dasamsa (Ch.6.2.10) ──────────────────────────────────────────────────
// 10 padas of 3° each
// Odd rasi: starts from rasi itself; Even rasi: starts from 9th
// Example 17 validated: Ge 10°→Vi, Sc 19°→Cp ✅
function computeD10(lon) {
  const s = signInfo(lon);
  const pada = Math.floor(s.deg / 3); // 0-9
  const startFrom = IS_ODD[s.idx] ? s.idx : addSigns(s.idx, 8); // 8 away = 9th
  return result(addSigns(startFrom, pada) * 30 + (s.deg % 3));
}

// ── D12 Dwadasamsa (Ch.6.2.12) ───────────────────────────────────────────────
// 12 padas of 2.5° each; starts from rasi itself
// No explicit example in book, but formula is clear
function computeD12(lon) {
  const s = signInfo(lon);
  const pada = Math.floor(s.deg / 2.5); // 0-11
  return result(addSigns(s.idx, pada) * 30 + (s.deg % 2.5));
}

// ── D16 Shodasamsa (Ch.6.2.13) ───────────────────────────────────────────────
// 16 padas of 1.875° each
// Movable→Ar, Fixed→Le, Dual→Sg
// Example 20 from book (not shown in search but formula is standard)
function computeD16(lon) {
  const s = signInfo(lon);
  const pada = Math.floor(s.deg / 1.875); // 0-15
  let startFrom;
  if (IS_MOVABLE[s.idx]) startFrom = 0;  // Ar
  if (IS_FIXED[s.idx])   startFrom = 4;  // Le
  if (IS_DUAL[s.idx])    startFrom = 8;  // Sg
  return result(addSigns(startFrom, pada) * 30 + (s.deg % 1.875));
}

// ── D20 Vimsamsa (Ch.6.2.14) ─────────────────────────────────────────────────
// 20 padas of 1.5° each
// Movable→Ar, Fixed→Sg, Dual→Le
// Example 21 validated in book: Ge 11°→Pi (dual→Le, 8th from Le=Pi) ✅
function computeD20(lon) {
  const s = signInfo(lon);
  const pada = Math.floor(s.deg / 1.5); // 0-19
  let startFrom;
  if (IS_MOVABLE[s.idx]) startFrom = 0;  // Ar
  if (IS_FIXED[s.idx])   startFrom = 8;  // Sg
  if (IS_DUAL[s.idx])    startFrom = 4;  // Le
  return result(addSigns(startFrom, pada) * 30 + (s.deg % 1.5));
}

// ── D24 Chaturvimsamsa (Ch.6.2.15) ───────────────────────────────────────────
// 24 padas of 1.25° each
// Odd rasi→Le, Even rasi→Cn
// Example 22 validated: Ge 11°→Ar (odd→Le, 9th from Le=Ar) ✅
function computeD24(lon) {
  const s = signInfo(lon);
  const pada = Math.floor(s.deg / 1.25); // 0-23
  const startFrom = IS_ODD[s.idx] ? 4 : 3; // Le=4, Cn=3
  return result(addSigns(startFrom, pada) * 30 + (s.deg % 1.25));
}

// ── D27 Nakshatramsa (Ch.6.2.16) ─────────────────────────────────────────────
// 27 padas of 1.1111° each
// Fire→Ar, Earth→Cn, Air→Li, Water→Cp
// Example 23 validated: Ge 11°→Le (air→Li, 10th from Li=Le) ✅
function computeD27(lon) {
  const s = signInfo(lon);
  const SPAN = 30 / 27;
  const pada = Math.floor(s.deg / SPAN); // 0-26
  let startFrom;
  if (IS_FIRE[s.idx])  startFrom = 0;  // Ar
  if (IS_EARTH[s.idx]) startFrom = 3;  // Cn (note: different from D9!)
  if (IS_AIR[s.idx])   startFrom = 6;  // Li
  if (IS_WATER[s.idx]) startFrom = 9;  // Cp
  return result(addSigns(startFrom, pada) * 30 + (s.deg % SPAN));
}

// ── D30 Trimsamsa (Ch.6.2.17) ────────────────────────────────────────────────
// Special — NOT proportional padas; fixed degree ranges
// From book:
// Odd rasis:  0-5°→Ar, 5-10°→Aq, 10-18°→Sg, 18-25°→Ge, 25-30°→Li
// Even rasis: 0-5°→Ta, 5-12°→Vi, 12-20°→Pi, 20-25°→Cp, 25-30°→Sc
function computeD30(lon) {
  const s = signInfo(lon);
  const d = s.deg;
  let targetSign;
  if (IS_ODD[s.idx]) {
    if (d < 5)  targetSign = 0;  // Ar
    else if (d < 10) targetSign = 10; // Aq
    else if (d < 18) targetSign = 8;  // Sg
    else if (d < 25) targetSign = 2;  // Ge
    else targetSign = 6;              // Li
  } else {
    if (d < 5)  targetSign = 1;  // Ta
    else if (d < 12) targetSign = 5; // Vi
    else if (d < 20) targetSign = 11; // Pi
    else if (d < 25) targetSign = 9;  // Cp
    else targetSign = 7;              // Sc
  }
  return result(targetSign * 30 + d);
}

// ── D40 Khavedamsa (Ch.6.2.18) ───────────────────────────────────────────────
// 40 padas of 0.75° each; Odd→Ar, Even→Li
function computeD40(lon) {
  const s = signInfo(lon);
  const pada = Math.floor(s.deg / 0.75); // 0-39
  const startFrom = IS_ODD[s.idx] ? 0 : 6; // Ar=0, Li=6
  return result(addSigns(startFrom, pada) * 30 + (s.deg % 0.75));
}

// ── D45 Akshavedamsa (Ch.6.2.19) ─────────────────────────────────────────────
// 45 padas of 0.6667° each; Movable→Ar, Fixed→Le, Dual→Sg
function computeD45(lon) {
  const s = signInfo(lon);
  const SPAN = 2 / 3;
  const pada = Math.floor(s.deg / SPAN); // 0-44
  let startFrom;
  if (IS_MOVABLE[s.idx]) startFrom = 0;  // Ar
  if (IS_FIXED[s.idx])   startFrom = 4;  // Le
  if (IS_DUAL[s.idx])    startFrom = 8;  // Sg
  return result(addSigns(startFrom, pada) * 30 + (s.deg % SPAN));
}

// ── D60 Shashtyamsa (Ch.6.2.20) ──────────────────────────────────────────────
// 60 padas of 0.5° each; starts from rasi itself
// Example 26: Sc 12°58' → part = floor(12.967 × 2) + 1 = 26+1? No: floor(12.967×2)=25, +1=26, 26th from Sc
// Actually: "take its longitude from beginning of rasi, multiply by 2, take degrees, ignore minutes, add 1"
// 12°58' × 2 = 25°56' → take 25 → add 1 = 26 → 26th rasi from Sc
// 26 mod 12 = 2 → 2nd from Sc = Sg ✅ (matches book)
function computeD60(lon) {
  const s = signInfo(lon);
  // Method from Ch.6.2.20: multiply deg by 2, take floor, add 1, count from rasi
  const partNum = Math.floor(s.deg * 2) + 1; // 1-60
  return result(addSigns(s.idx, (partNum - 1) % 12) * 30 + (s.deg % 0.5));
}

// ── Compute all D-charts for a single longitude ──────────────────────────────
function computeAllDivisionals(lon) {
  return {
    D1:  computeD1(lon),
    D2:  computeD2(lon),
    D3:  computeD3(lon),
    D4:  computeD4(lon),
    D7:  computeD7(lon),
    D9:  computeD9(lon),
    D10: computeD10(lon),
    D12: computeD12(lon),
    D16: computeD16(lon),
    D20: computeD20(lon),
    D24: computeD24(lon),
    D27: computeD27(lon),
    D30: computeD30(lon),
    D40: computeD40(lon),
    D45: computeD45(lon),
    D60: computeD60(lon),
  };
}

// ── Compute divisional chart for entire horoscope ────────────────────────────
function computeDivisionalChart(dcNum, planetLons, lagnaLon) {
  const FN_MAP = {
    1: computeD1, 2: computeD2, 3: computeD3, 4: computeD4,
    7: computeD7, 9: computeD9, 10: computeD10, 12: computeD12,
    16: computeD16, 20: computeD20, 24: computeD24, 27: computeD27,
    30: computeD30, 40: computeD40, 45: computeD45, 60: computeD60
  };
  const fn = FN_MAP[dcNum];
  if (!fn) return null;

  const chart = { lagna: fn(lagnaLon) };
  const signs = { Lagna: chart.lagna.signCode };
  const houses = {};

  // Compute each planet's D-chart position
  Object.entries(planetLons).forEach(([planet, lon]) => {
    chart[planet] = fn(lon);
    signs[planet] = chart[planet].signCode;
  });

  // Compute house numbers (from D-chart lagna)
  const lagnaSignIdx = chart.lagna.signIndex;
  Object.entries(chart).forEach(([p, pos]) => {
    if (p === 'lagna') return;
    houses[p] = ((pos.signIndex - lagnaSignIdx + 12) % 12) + 1;
  });

  return { lagna: chart.lagna.signCode, signs, houses, positions: chart };
}

module.exports = {
  computeD1, computeD2, computeD3, computeD4, computeD7,
  computeD9, computeD10, computeD12, computeD16, computeD20,
  computeD24, computeD27, computeD30, computeD40, computeD45, computeD60,
  computeAllDivisionals, computeDivisionalChart
};
