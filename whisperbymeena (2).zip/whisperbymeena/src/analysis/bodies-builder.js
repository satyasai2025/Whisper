// This module converts computed horoscope → bodies object for computeAnalysis

const SIGN_NAMES = ['Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'];
const SIGN_INDEX = {Ar:0,Ta:1,Ge:2,Cn:3,Le:4,Vi:5,Li:6,Sc:7,Sg:8,Cp:9,Aq:10,Pi:11};
const NAK_SPAN = 360/27;
const NAKSHATRAS = ['Ashwini','Bharani','Krittika','Rohini','Mrigashira','Ardra','Punarvasu','Pushya','Ashlesha','Magha','Purva Phalguni','Uttara Phalguni','Hasta','Chitra','Swati','Vishakha','Anuradha','Jyeshtha','Mula','Purva Ashadha','Uttara Ashadha','Shravana','Dhanishtha','Shatabhisha','Purva Bhadrapada','Uttara Bhadrapada','Revati'];
const NAK_CODES = ['Ashw','Bhar','Krit','Rohi','Mrig','Ardr','Puna','Push','Ashl','Magh','PPha','UPha','Hast','Chit','Swat','Vish','Anur','Jyes','Mula','PASh','UASh','Srav','Dhan','Shat','PBha','UBha','Reva'];

function nakshatra(lon) {
  const idx = Math.floor(lon / NAK_SPAN) % 27;
  const pada = Math.floor((lon % NAK_SPAN) / (NAK_SPAN / 4)) + 1;
  return { name: NAKSHATRAS[idx], code: NAK_CODES[idx], pada };
}

function buildBodies(horoscope) {
  const bodies = {};
  const d9signs = horoscope.d9.signs || {};

  function makeBody(name, lon, signCode, degInSign, rasiHouse, bhavaHouse) {
    const nak = nakshatra(lon);
    const d9code = d9signs[name] || signCode;
    return {
      name,
      sign:          SIGN_NAMES[SIGN_INDEX[signCode]] || signCode,
      signCode,
      degrees:       Math.floor(degInSign),
      minutes:       Math.floor((degInSign % 1) * 60),
      seconds:       Number((((degInSign % 1) * 60) % 1 * 60).toFixed(2)),
      longitudeInSign: degInSign,
      nakshatra:     nak.name,
      nakshatraCode: nak.code,
      pada:          nak.pada,
      rasi:          SIGN_NAMES[SIGN_INDEX[signCode]] || signCode,
      rasiCode:      signCode,
      navamsa:       SIGN_NAMES[SIGN_INDEX[d9code]] || d9code,
      navamsaCode:   d9code,
      retrograde:    false,
      charaKaraka:   null,   // assigned later by jaimini module
      house:         rasiHouse,
      bhavaHouse:    bhavaHouse
    };
  }

  // Lagna
  bodies.Lagna = makeBody('Lagna',
    horoscope.lagna.longitude, horoscope.lagna.signCode,
    horoscope.lagna.degreeInSign, 1, 1
  );

  // 9 planets
  const PLANETS = ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn','Rahu','Ketu'];
  PLANETS.forEach(p => {
    const pos = horoscope.planets[p];
    const bh  = horoscope.bhavachalit[p] || {};
    if (!pos) return;
    bodies[p] = makeBody(p,
      pos.siderealLongitude, pos.signCode,
      pos.degreeInSign,
      bh.rasiHouse || 1, bh.bhavaHouse || 1
    );
  });

  return bodies;
}

module.exports = { buildBodies };
