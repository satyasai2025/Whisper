/**
 * Graha Drishti (Planetary Aspects)
 *
 * Classical Parashari rule (BPHS Ch. 24):
 *   - Every planet casts its base aspect on the 7th house from itself.
 *   - Mars additionally aspects the 4th and 8th houses from itself.
 *   - Jupiter additionally aspects the 5th and 9th houses from itself.
 *   - Saturn additionally aspects the 3rd and 10th houses from itself.
 *   - Sun, Moon, Mercury, Venus have ONLY the base 7th house aspect.
 *
 * RAHU/KETU ASPECTS: Not part of core BPHS Parashari drishti. A later /
 * Jaimini-influenced convention (used by some modern astrologers) gives
 * Rahu and Ketu the same special aspects as Jupiter (5th, 7th, 9th).
 * This is included here but explicitly flagged as a less classically-
 * settled convention — weight it accordingly.
 *
 * This module computes aspects using HOUSE NUMBERS (from Lagna in D1),
 * not zodiacal sign distance — i.e. "Mars aspects the 4th house from
 * its own position" means 4 houses ahead in the native's own house count.
 */

const ASPECT_OFFSETS = {
  Sun:     [7],
  Moon:    [7],
  Mars:    [4, 7, 8],
  Mercury: [7],
  Jupiter: [5, 7, 9],
  Venus:   [7],
  Saturn:  [3, 7, 10],
  Rahu:    [5, 7, 9],   // flagged as derived convention, not core BPHS
  Ketu:    [5, 7, 9]    // flagged as derived convention, not core BPHS
};

const DERIVED_CONVENTION_PLANETS = ['Rahu', 'Ketu'];

/**
 * Target house aspected, given a source house and an "Nth house" offset.
 * E.g. source=1, offset=7 → target=7 (7th from 1st).
 */
function aspectedHouse(sourceHouse, offset) {
  return ((sourceHouse - 1 + (offset - 1)) % 12) + 1;
}

/**
 * Compute full aspect picture: for each planet, which houses/planets it
 * aspects, AND which planets aspect it back (incoming aspects).
 *
 * @param {object} bodies - parsed body positions (must have .house set, i.e.
 *                          D1 house number from Lagna — already computed
 *                          during body table parsing)
 */
function computeAspects(bodies) {
  const planets = Object.keys(ASPECT_OFFSETS).filter(p => bodies[p] && bodies[p].house);

  // Build house -> occupants map for cross-referencing
  const houseOccupants = {};
  for (let h = 1; h <= 12; h++) houseOccupants[h] = [];
  for (const p of planets) {
    houseOccupants[bodies[p].house].push(p);
  }
  // Lagna itself can be aspected too — include as a pseudo-occupant of house 1
  houseOccupants[1] = houseOccupants[1] || [];

  const outgoing = {}; // planet -> { housesAspected: [...], planetsAspected: [...] }
  for (const p of planets) {
    const sourceHouse = bodies[p].house;
    const offsets = ASPECT_OFFSETS[p];
    const housesAspected = offsets.map(off => aspectedHouse(sourceHouse, off));

    const planetsAspected = [];
    for (const h of housesAspected) {
      for (const occupant of houseOccupants[h]) {
        if (occupant !== p) planetsAspected.push({ planet: occupant, house: h });
      }
    }

    outgoing[p] = {
      sourceHouse,
      housesAspected,
      planetsAspected,
      isDerivedConvention: DERIVED_CONVENTION_PLANETS.includes(p)
    };
  }

  // Incoming aspects — reverse the outgoing map
  const incoming = {};
  for (const p of planets) incoming[p] = [];
  for (const [source, data] of Object.entries(outgoing)) {
    for (const { planet: target, house } of data.planetsAspected) {
      incoming[target].push({ from: source, house, isDerivedConvention: data.isDerivedConvention });
    }
  }

  return {
    outgoing,
    incoming,
    methodology: 'BPHS Ch. 24 — Graha Drishti. Base 7th-house aspect for all planets; Mars (4,7,8), Jupiter (5,7,9), Saturn (3,7,10) cast additional special aspects. Rahu/Ketu use a derived Jupiter-like (5,7,9) convention, flagged separately as less classically settled.'
  };
}

module.exports = { computeAspects, aspectedHouse, ASPECT_OFFSETS };
