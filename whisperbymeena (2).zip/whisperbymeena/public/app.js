/**
 * WhisperByMeena — Browser UI Logic
 */

var CHARA_KARAKA_NAMES = {
  AK: 'Atmakaraka',
  AmK: 'Amatyakaraka',
  BK: 'Bhratrukaraka',
  MK: 'Matrukaraka',
  PiK: 'Pitrukaraka',
  PK: 'Putrakaraka',
  GK: 'Gnatikaraka',
  DK: 'Darakaraka'
};

var KARAKA_MEANINGS = {
  AK: "Soul's deepest desire and direction",
  AmK: "Advisor, support, professional ally",
  BK: "Siblings, courage, communication",
  MK: "Mother, comforts, emotional ground",
  PiK: "Father, authority, paternal lineage",
  PK: "Children, creative output, progeny",
  GK: "Maternal relations, competitors",
  DK: "Spouse, partnerships, the 'other'"
};

var PLANET_SHORT = {
  Lagna: 'As', Sun: 'Su', Moon: 'Mo', Mars: 'Ma', Mercury: 'Me',
  Jupiter: 'Ju', Venus: 'Ve', Saturn: 'Sa', Rahu: 'Ra', Ketu: 'Ke',
  Uranus: 'Ur', Neptune: 'Ne', Pluto: 'Pl',
  Maandi: 'Md', Gulika: 'Gk',
  'Bhava Lagna': 'BL', 'Hora Lagna': 'HL', 'Ghati Lagna': 'GL'
};

let currentChartKey = null;

// ── Tab switching ─────────────────────────────────────────────────────────────
function switchTab(tab) {
  document.getElementById('panel-birthdata').style.display = tab === 'birthdata' ? '' : 'none';
  document.getElementById('panel-pdf').style.display = tab === 'pdf' ? '' : 'none';
  document.getElementById('tab-birthdata').classList.toggle('active', tab === 'birthdata');
  document.getElementById('tab-pdf').classList.toggle('active', tab === 'pdf');
}

// ── Geocoding: place name → lat/lon (Nominatim, free, no key needed) ──────
async function geocodePlace() {
  const place = document.getElementById('bd-place').value.trim();
  const status = document.getElementById('bd-geo-status');
  if (!place || place.length < 3) return;
  status.textContent = 'Looking up coordinates…';
  try {
    const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(place)}&format=json&limit=1`;
    const res = await fetch(url, { headers: { 'Accept-Language': 'en' } });
    const data = await res.json();
    if (data && data.length > 0) {
      const lat = parseFloat(data[0].lat).toFixed(4);
      const lon = parseFloat(data[0].lon).toFixed(4);
      document.getElementById('bd-lat').value = lat;
      document.getElementById('bd-lon').value = lon;
      status.textContent = `✓ ${data[0].display_name.split(',').slice(0,3).join(',')} → ${lat}°N, ${lon}°E`;
      status.style.color = '#2e6b3f';
    } else {
      status.textContent = 'Place not found — enter lat/lon manually.';
      status.style.color = '#c0392b';
    }
  } catch(e) {
    status.textContent = 'Geocoding unavailable (offline?) — enter lat/lon manually.';
    status.style.color = '#8a7a6a';
  }
}

// ── Past events rows ──────────────────────────────────────────────────────────
var EVENT_KEYS = [
  'firstJob','jobChange','promotion','termination','businessStart','retirement',
  'marriage','engagement','divorce','children','education','graduation','scholarship',
  'housePurchase','vehiclePurchase','foreignTravel','foreignSettlement',
  'majorIllness','surgery','accident','disease',
  'deathOfFather','deathOfMother','deathOfSpouse',
  'majorFinancialGain','majorFinancialLoss','wealth','courtCase','addiction'
];
var EVENT_LABELS = {
  firstJob:'First Job', jobChange:'Job Change', promotion:'Promotion',
  termination:'Job Termination', businessStart:'Business Start', retirement:'Retirement',
  marriage:'Marriage', engagement:'Engagement', divorce:'Divorce',
  children:'Child Birth', education:'Education', graduation:'Graduation',
  scholarship:'Scholarship', housePurchase:'House Purchase', vehiclePurchase:'Vehicle Purchase',
  foreignTravel:'Foreign Travel', foreignSettlement:'Foreign Settlement',
  majorIllness:'Major Illness', surgery:'Surgery', accident:'Accident', disease:'Disease',
  deathOfFather:'Death of Father', deathOfMother:'Death of Mother', deathOfSpouse:'Death of Spouse',
  majorFinancialGain:'Major Financial Gain', majorFinancialLoss:'Major Financial Loss',
  wealth:'Wealth Event', courtCase:'Court Case', addiction:'Addiction'
};

let pastEventRowCount = 0;
function addPastEventRow(prefill) {
  pastEventRowCount++;
  const id = 'per-' + pastEventRowCount;
  const div = document.createElement('div');
  div.className = 'past-event-row';
  div.id = id;
  div.innerHTML = `
    <select id="${id}-key">
      ${EVENT_KEYS.map(k => `<option value="${k}" ${prefill && prefill.eventKey===k?'selected':''}>${EVENT_LABELS[k]||k}</option>`).join('')}
    </select>
    <input type="date" id="${id}-date" value="${prefill ? prefill.date : ''}">
    <input type="text" id="${id}-label" placeholder="Your note (optional)" value="${prefill ? prefill.label||'' : ''}">
    <button type="button" onclick="document.getElementById('${id}').remove()" title="Remove">✕</button>
  `;
  document.getElementById('past-events-list').appendChild(div);
}

function getPastEvents() {
  const rows = document.querySelectorAll('.past-event-row');
  const events = [];
  rows.forEach(row => {
    const id = row.id;
    const eventKey = document.getElementById(id+'-key')?.value;
    const date = document.getElementById(id+'-date')?.value;
    const label = document.getElementById(id+'-label')?.value || EVENT_LABELS[eventKey] || eventKey;
    if (eventKey && date) events.push({ eventKey, date, label });
  });
  return events;
}

// ── Compute from birth data ───────────────────────────────────────────────────
async function computeFromBirthData() {
  const errEl = document.getElementById('compute-error');
  errEl.style.display = 'none';

  const year  = parseInt(document.getElementById('bd-date').value?.split('-')[0]);
  const month = parseInt(document.getElementById('bd-date').value?.split('-')[1]);
  const day   = parseInt(document.getElementById('bd-date').value?.split('-')[2]);
  const timeStr = document.getElementById('bd-time').value || '00:00';
  const hour  = parseInt(timeStr.split(':')[0]);
  const minute = parseInt(timeStr.split(':')[1]);
  const gmt   = parseFloat(document.getElementById('bd-gmt').value);
  const lat   = parseFloat(document.getElementById('bd-lat').value);
  const lon   = parseFloat(document.getElementById('bd-lon').value);
  const name  = document.getElementById('bd-name').value.trim();
  const gender = document.getElementById('bd-gender')?.value || 'female';

  if (!year || !month || !day || isNaN(lat) || isNaN(lon)) {
    errEl.textContent = 'Please fill in date, latitude, and longitude.';
    errEl.style.display = '';
    return;
  }

  const btn = document.getElementById('compute-btn');
  btn.textContent = 'Computing…';
  btn.disabled = true;

  const birthYear = year;
  const currentYear = new Date().getFullYear();

  try {
    const res = await fetch('/api/compute', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name, year, month, day, hour, minute, second: 0,
        gmtOffsetHours: gmt, latitude: lat, longitude: lon,
        gender,
        place: document.getElementById('bd-place').value,
        pastEvents: getPastEvents(),
        fromYear: birthYear,
        toYear: currentYear + 30
      })
    });
    const data = await res.json();
    if (!res.ok) {
      errEl.textContent = data.error || 'Computation failed.';
      errEl.style.display = '';
      return;
    }

    currentChartKey = data.chartKey;
    renderComputedResults(data);
  } catch (err) {
    errEl.textContent = 'Network error: ' + err.message;
    errEl.style.display = '';
  } finally {
    btn.textContent = 'Compute Horoscope';
    btn.disabled = false;
  }
}

// ── Render computed results ───────────────────────────────────────────────────
// Helper: safely set innerHTML of a content div (never crashes if missing)
function setContent(id, html) {
  const el = document.getElementById(id);
  if (el) el.innerHTML = html;
}

function renderComputedResults(data) {
  document.getElementById('results-section').classList.remove('hidden');

  // Show BTR, events, portrait, tajaka cards
  const btrCard = document.getElementById('btr-card');
  if (btrCard) btrCard.style.display = '';
  const evCard = document.getElementById('events-card');
  if (evCard) evCard.style.display = '';
  const databankCard = document.getElementById('databank-card');
  if (databankCard) {
    databankCard.style.display = '';
    fetch('/api/databank/status').then(r => r.json()).then(s => {
      const el = document.getElementById('databank-status');
      if (el && s.exists) {
        el.innerHTML = `Charts: <strong>${s.charts}</strong> &nbsp;|&nbsp; Events verified: <strong>${s.events}</strong> &nbsp;|&nbsp; Predictions: <strong>${s.predictions}</strong>`;
      }
    }).catch(()=>{});
  }

  const tajakaCard = document.getElementById('tajaka-card');
  if (tajakaCard) {
    tajakaCard.style.display = '';
    const tajakaYearEl = document.getElementById('tajaka-year');
    if (tajakaYearEl) tajakaYearEl.value = new Date().getFullYear();
  }

  const SIGN_NAMES = {Ar:'Aries',Ta:'Taurus',Ge:'Gemini',Cn:'Cancer',Le:'Leo',Vi:'Virgo',
    Li:'Libra',Sc:'Scorpio',Sg:'Sagittarius',Cp:'Capricorn',Aq:'Aquarius',Pi:'Pisces'};
  const PLANETS = ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn','Rahu','Ketu'];
  const l = data.lagna;

  // ── Native ──────────────────────────────────────────────────────
  setContent('native-content', `
    <table class="equal-table"><tbody>
      <tr><td>Name</td><td>${escapeHtml(data.native.name || '—')}</td></tr>
      <tr><td>Birth</td><td>${escapeHtml(data.native.birthDate)} ${escapeHtml(data.native.birthTime)} (GMT${escapeHtml(String(data.native.gmtOffset))})</td></tr>
      <tr><td>Place</td><td>${escapeHtml(data.native.place || (data.native.latitude+'°N, '+data.native.longitude+'°E'))}</td></tr>
      <tr><td>Lagna</td><td><strong>${escapeHtml(l.sign)} ${Number(l.degreeInSign).toFixed(4)}°</strong></td></tr>
      <tr><td>D9 Lagna</td><td>${escapeHtml(SIGN_NAMES[data.d9.lagna]||data.d9.lagna)}</td></tr>
      <tr><td>Ayanamsa</td><td>${Number(data.ayanamsa||l.ayanamsa||0).toFixed(4)}° Lahiri (validated)</td></tr>
    </tbody></table>`);

  // ── Planets + Bhavachalit ────────────────────────────────────────
  const shifts = PLANETS.filter(p => data.bhavachalit[p] && data.bhavachalit[p].shifted);
  setContent('bodies-content', `
    <table class="equal-table compact-table">
      <thead><tr><th>Planet</th><th>Sign</th><th>Deg</th><th>Rasi H</th><th>Bhava H</th><th>D9</th><th>D9 H</th><th>D1 Dignity</th><th>D9 Dignity</th></tr></thead>
      <tbody>
        ${PLANETS.map(p => {
          const pos = data.planets[p];
          if (!pos) return '';
          const bh = data.bhavachalit[p] || {};
          const d9s = data.d9.signs[p];
          const d9h = data.d9.houses[p];
          const dig = data.dignities && data.dignities[p];
          const shifted = bh.shifted ? ' <span class="conf-badge conf-interpretive">↑</span>' : '';
          return `<tr>
            <td><strong>${p}</strong></td>
            <td>${SIGN_NAMES[pos.signCode]||pos.signCode}</td>
            <td>${Number(pos.degreeInSign).toFixed(4)}°</td>
            <td>H${bh.rasiHouse||'?'}</td>
            <td>H${bh.bhavaHouse||'?'}${shifted}</td>
            <td>${SIGN_NAMES[d9s]||d9s||'—'}</td>
            <td>${d9h?'H'+d9h:'—'}</td>
            <td>${dig?escapeHtml(dig.d1):'—'}</td>
            <td>${dig?escapeHtml(dig.d9):'—'}</td>
          </tr>`;
        }).join('')}
      </tbody>
    </table>
    ${shifts.length ? '<p class="muted" style="margin-top:8px;font-size:0.8rem;">Bhavachalit shifts: '+shifts.map(p=>p+' H'+data.bhavachalit[p].rasiHouse+'→H'+data.bhavachalit[p].bhavaHouse).join(', ')+'</p>' : ''}`);

  // ── Active Dasha ─────────────────────────────────────────────────
  const today = new Date().toISOString().split('T')[0];
  const vD = data.vimshottariDashas || [];
  const aD = data.ashtottariDashas || [];
  const vMD = vD.find(m => m.startDate <= today && m.endDate >= today);
  const vAD = vMD && vMD.antardashas.find(a => a.startDate <= today && a.endDate >= today);
  const vPD = vAD && vAD.pratyantardashas && vAD.pratyantardashas.find(p => p.startDate <= today && p.endDate >= today);
  const aMD = aD.find(m => m.startDate <= today && m.endDate >= today);
  const aAD = aMD && aMD.antardashas.find(a => a.startDate <= today && a.endDate >= today);

  setContent('active-dasha-content', `
    <p class="muted" style="font-size:0.8rem;margin-bottom:8px;">Vimshottari (120yr) + Ashtottari (108yr) — both co-primary</p>
    <table class="equal-table"><tbody>
      <tr><th colspan="2" style="text-align:left;padding-bottom:4px;">Vimshottari</th></tr>
      <tr><td>Mahadasha</td><td><strong>${vMD?vMD.lord:'—'}</strong> (${vMD?vMD.startDate+' → '+vMD.endDate:'—'})</td></tr>
      <tr><td>Antardasha</td><td><strong>${vAD?vAD.lord:'—'}</strong> (${vAD?vAD.startDate+' → '+vAD.endDate:'—'})</td></tr>
      <tr><td>Pratyantardasha</td><td><strong>${vPD?vPD.lord:'—'}</strong> (${vPD?vPD.startDate+' → '+vPD.endDate:'—'})</td></tr>
      <tr><th colspan="2" style="text-align:left;padding:8px 0 4px;">Ashtottari</th></tr>
      <tr><td>Mahadasha</td><td><strong>${aMD?aMD.lord:'—'}</strong> (${aMD?aMD.startDate+' → '+aMD.endDate:'—'})</td></tr>
      <tr><td>Antardasha</td><td><strong>${aAD?aAD.lord:'—'}</strong> (${aAD?aAD.startDate+' → '+aAD.endDate:'—'})</td></tr>
    </tbody></table>`);

  // ── D9 Navamsa ───────────────────────────────────────────────────
  const d9Houses = data.d9.houses || {};
  const d9Signs  = data.d9.signs  || {};
  setContent('navamsa-content', `
    <p class="muted" style="font-size:0.8rem;margin-bottom:6px;">D9 Lagna: <strong>${SIGN_NAMES[data.d9.lagna]||data.d9.lagna}</strong></p>
    <table class="equal-table compact-table">
      <thead><tr><th>Planet</th><th>D9 Sign</th><th>D9 House</th><th>D9 Dignity</th></tr></thead>
      <tbody>
        ${PLANETS.map(p => {
          const s = d9Signs[p]; const h = d9Houses[p];
          const dig = data.dignities && data.dignities[p];
          return `<tr><td>${p}</td><td>${SIGN_NAMES[s]||s||'—'}</td><td>${h?'H'+h:'—'}</td><td>${dig?escapeHtml(dig.d9):'—'}</td></tr>`;
        }).join('')}
      </tbody>
    </table>`);

  // ── Wire existing render functions to computed analysis ───────────
  if (data.analysis) {
    const a = data.analysis;
    const b = data.bodies;

    if (a.aspects       && typeof renderAspects       === 'function') renderAspects(a.aspects);
    if (a.functionalNature && typeof renderFunctionalNature === 'function') renderFunctionalNature(a.functionalNature);
    if (a.dignity       && typeof renderDignity        === 'function') renderDignity(a.dignity);
    if (a.arudhas       && typeof renderArudhas        === 'function') renderArudhas(a.arudhas);
    if (a.yogas         && typeof renderYogas          === 'function') renderYogas(a.yogas);
    if (a.navamsa       && typeof renderNavamsa        === 'function') renderNavamsa(a.navamsa);
    if (a.jaimini       && typeof renderJaimini        === 'function') renderJaimini(a.jaimini);
    if (a.matchedRules  && typeof renderClassicalRules === 'function') renderClassicalRules(a.matchedRules);
    if (a.character     && typeof renderCharacter      === 'function') renderCharacter(a.character);
    if (a.portrait      && typeof renderPortrait       === 'function') renderPortrait(a.portrait);
    if (a.relationships && typeof renderRelationships  === 'function') renderRelationships(a.relationships);
  }

  // Rasi Chakra diagram
  if (typeof renderRasiChakra === 'function') renderRasiChakra(data);

  // ── Sections needing server data (fetch separately) ───────────────
  if (data.chartKey) {
    loadComputedSections(data.chartKey, today);
  }

  // ── Past events verification ──────────────────────────────────────
  if (data.pastVerification && data.pastVerification.length) {
    renderPastVerification(data.pastVerification);
  }

  // ── Future timeline — build from predictions ──────────────────────────
  // data.timeline doesn't exist in new engine, but predictions.windows do
  if (data.predictions) {
    const today = new Date().toISOString().split('T')[0];
    const futureWindows = [];
    Object.entries(data.predictions).forEach(([eventKey, p]) => {
      (p.windows||[]).forEach(w => {
        if (w.startDate >= today && w.score >= 50) {
          futureWindows.push({ ...w, eventKey, eventLabel: p.label, domainType: p.domainType });
        }
      });
    });
    if (futureWindows.length > 0) {
      renderFutureTimeline(futureWindows);
    }
  } else if (data.timeline && data.timeline.length) {
    renderFutureTimeline(data.timeline);
  }

  // ── Sections with no computed data yet — show placeholder ─────────
  // Only show placeholder for strengths (Shadbala etc) which need JHora PDF
  const pendingStrengths = ['shadbala-content','vimsopaka-content','ashtakavarga-content'];
  pendingStrengths.forEach(id => {
    const el = document.getElementById(id);
    if (el && !el.innerHTML.trim()) {
      el.innerHTML = '<p class="muted">Shadbala, Vimsopaka aur Ashtakavarga ke liye JHora PDF upload karo — ye metrics JHora ke computed values use karte hain.</p>';
    }
  });

  window.scrollTo({ top: document.getElementById('results-section').offsetTop - 20, behavior: 'smooth' });
}

// Fetch transit + predict for a computed chart
async function loadComputedSections(chartKey, today) {
  // Transit auto-compute
  try {
    const tRes = await fetch(`/api/transit/auto?chartKey=${encodeURIComponent(chartKey)}&date=${today}&time=12:00`);
    if (tRes.ok) {
      const tData = await tRes.json();
      if (typeof renderTransit === 'function') renderTransit(tData);
    }
  } catch(e) { /* transit optional */ }

  // Predict
  try {
    const pRes = await fetch(`/api/predict?chartKey=${encodeURIComponent(chartKey)}&asOf=${today}`);
    if (pRes.ok) {
      const pData = await pRes.json();
      if (typeof renderPredictions === 'function' && pData.predictions) {
        renderPredictions(pData.predictions, {
          education: pData.educationPath,
          career: pData.careerPath,
          foreignTravel: pData.foreignPath
        });
      }
    }
  } catch(e) { /* predict optional */ }
}

function renderPastVerification(verifications) {
  // Show the unified events card
  const evCard = document.getElementById('events-card');
  if (evCard) evCard.style.display = '';
  const btrCard = document.getElementById('btr-card');
  if (btrCard) btrCard.style.display = '';
  const contentEl = document.getElementById('events-content');
  if (!contentEl) return;

  // Old format (from horoscope-engine pastVerification) → adapt to new format
  let html = '';
  verifications.forEach(ev => {
    // Old structure has ev.score, ev.l1pass etc.
    // New structure (from verifyPastEvent) has ev.finalScore, ev.l1Score etc.
    const score     = ev.finalScore ?? ev.score ?? 0;
    const tier      = ev.tier ?? (score >= 70 ? 'strong' : score >= 50 ? 'moderate' : score >= 30 ? 'weak' : 'poor');
    const label     = ev.eventLabel || ev.userLabel || ev.eventKey || '—';
    const date      = ev.eventDate || ev.date || '—';
    const age       = ev.age ?? '—';
    // Fix: show event type as category, not generic life stage
    const category  = EVENT_LABELS[ev.eventKey] || ev.eventKey || '—';
    const vimsh     = ev.vimshottari?.display || [ev.vimshottari?.mahadasha, ev.vimshottari?.antardasha, ev.vimshottari?.pratyantardasha].filter(Boolean).join(' / ') || '—';
    const varga     = ev.vargaNarayana?.display || '';
    const l1        = ev.l1Score ?? (ev.l1pass ? 60 : 20);
    const l2        = ev.l2Score ?? (ev.l2pass ? 60 : 20);
    const l3        = ev.l3Score ?? (ev.l3pass ? 60 : 20);
    const tierBadge = tier === 'strong' ? 'conf-direct' : tier === 'moderate' ? 'conf-synthesized' : 'conf-interpretive';
    const scoreColor = score >= 65 ? '#166534' : score >= 45 ? '#7c4b00' : '#991b1b';

    html += `<div class="event-verify-card">
      <div class="ev-header">
        <span class="ev-label">${escapeHtml(label)}</span>
        <span class="ev-date">${escapeHtml(date)} · Age ${age} · <em>${escapeHtml(category)}</em></span>
        <span class="conf-badge ${tierBadge}" style="margin-left:auto;">${score}/100 ${tier.toUpperCase()}</span>
      </div>
      <div class="ev-dasha-row">
        <strong>Vimshottari:</strong> ${escapeHtml(vimsh)}
        ${varga ? ` &nbsp;|&nbsp; <strong>${escapeHtml(ev.vargaNarayana?.system||'D-chart Narayana')}:</strong> ${escapeHtml(varga)}` : ''}
      </div>`;

    // Karaka info if available
    if (ev.karakaActive) {
      const ka = ev.karakaActive;
      html += `<div class="ev-karaka-row">
        Natural karaka (${escapeHtml(ka.naturalKaraka||'—')}): <span style="color:${ka.isNaturalKarakaInMDAD?'#166534':'#7c4b00'}">${ka.isNaturalKarakaInMDAD?'✓ Active':'Not in MD/AD'}</span>
        &nbsp;|&nbsp; ${escapeHtml(ka.charaKaraka||'?')} (${escapeHtml(ka.charaKarakaPlanet||'?')}): <span style="color:${ka.isCharaKarakaActive?'#166534':'#7c4b00'}">${ka.isCharaKarakaActive?'✓ Active':'Not active'}</span>
      </div>`;
    }

    html += `<div class="ev-scores">
      <span title="Dasha: karaka + house lord + Narayana D1">L1 (Dasha): <strong style="color:${l1>=50?'#166534':l1>=30?'#7c4b00':'#991b1b'}">${l1}</strong></span>
      <span title="D-chart Narayana">L2 (D-chart): <strong style="color:${l2>=50?'#166534':l2>=30?'#7c4b00':'#991b1b'}">${l2}</strong></span>
      <span title="Transit: Vedha, Moorti, Tara, BAV/SAV">L3 (Transit): <strong style="color:${l3>=50?'#166534':l3>=30?'#7c4b00':'#991b1b'}">${l3}</strong></span>
    </div>`;

    if (ev.reasons?.length) {
      html += `<div class="ev-reasons">${ev.reasons.slice(0,5).map(r=>`<div class="ev-reason">✅ ${escapeHtml(r)}</div>`).join('')}</div>`;
    }
    if (ev.concerns?.length) {
      html += `<div class="ev-concerns">${ev.concerns.slice(0,3).map(c=>`<div class="ev-concern">⚠️ ${escapeHtml(c)}</div>`).join('')}</div>`;
    }
    if (ev.btrSignal) {
      html += `<div class="ev-btr">🔧 ${escapeHtml(ev.btrSignal)}</div>`;
    }

    html += `</div>`;
  });

  contentEl.innerHTML = html || '<p class="muted">No past events to display.</p>';
}

function renderFutureTimeline(windows) {
  const card = document.getElementById('future-timeline-card');
  if (!card) return;
  card.style.display = '';
  const today = new Date().toISOString().split('T')[0];

  // windows = array of { mdLord, adLord, startDate, endDate, score, label, eventKey, eventLabel, domainType }
  // Group by MD/AD period
  const byPeriod = {};
  (windows || []).forEach(w => {
    const key = `${w.mdLord}/${w.adLord} (${w.startDate?.slice(0,7)} – ${w.endDate?.slice(0,7)})`;
    if (!byPeriod[key]) byPeriod[key] = { mdLord: w.mdLord, adLord: w.adLord, start: w.startDate, end: w.endDate, windows: [] };
    byPeriod[key].windows.push(w);
  });

  let html = '';
  if (!Object.keys(byPeriod).length) {
    html = '<p class="muted">No high-confidence future windows found in the computed period.</p>';
  } else {
    Object.entries(byPeriod)
      .sort((a,b) => a[1].start?.localeCompare(b[1].start))
      .slice(0, 15)
      .forEach(([periodKey, data]) => {
        const topEvents = data.windows.sort((a,b) => b.score - a.score).slice(0, 5);
        const maxScore = topEvents[0]?.score || 0;
        const periodColor = maxScore >= 70 ? '#166534' : maxScore >= 50 ? '#7c4b00' : '#5c4a35';

        html += `<div class="timeline-period" style="margin-bottom:10px;border:1px solid #e0d8cc;border-radius:6px;padding:10px 14px;">
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px;">
            <strong style="color:${periodColor}">${escapeHtml(data.mdLord)} MD / ${escapeHtml(data.adLord)} AD</strong>
            <span class="muted" style="font-size:0.76rem;">${data.start} → ${data.end||'ongoing'}</span>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:6px;">
            ${topEvents.map(e => {
              const sc = e.score >= 70 ? '#166534' : e.score >= 50 ? '#7c4b00' : '#5c4a35';
              const bg = e.domainType === 'affliction' ? '#fff3f3' : '#f0f8f0';
              return `<span style="background:${bg};border:1px solid #e0d8cc;border-radius:4px;padding:3px 8px;font-size:0.78rem;">
                <strong style="color:${sc}">${e.score}%</strong> ${escapeHtml(e.eventLabel||e.eventKey)}
              </span>`;
            }).join('')}
          </div>
        </div>`;
      });
  }

  document.getElementById('future-timeline-content').innerHTML = html;
}

  let html = '';
  Object.entries(byPeriod)
    .sort((a,b) => a[1].start.localeCompare(b[1].start))



document.getElementById('upload-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const fileInput = document.getElementById('pdf-input');
  const statusEl = document.getElementById('upload-status');

  if (!fileInput.files.length) {
    showStatus('error', 'Please select a PDF file first.');
    return;
  }

  showStatus('', 'Parsing chart...');
  const formData = new FormData();
  formData.append('pdf', fileInput.files[0]);

  try {
    const res = await fetch('/api/parse', { method: 'POST', body: formData });
    const data = await res.json();
    if (!res.ok) {
      showStatus('error', 'Error: ' + (data.error || res.statusText));
      return;
    }

    // If server returned computed format (has chartKey directly), use that
    if (data.chartKey && data.lagna && data.bodies) {
      currentChartKey = data.chartKey;
      showStatus('success', 'Chart parsed and computed successfully.');
      renderComputedResults(data);
    } else if (data.metadata && data.metadata.chartKey) {
      // Old parsed format
      const sectionsCount = data.metadata.sectionsFound ? data.metadata.sectionsFound.length : '?';
      showStatus('success', `Parsed successfully — ${sectionsCount} sections detected.`);
      renderChart(data);
    } else {
      showStatus('error', 'Unexpected response format from server.');
    }
  } catch (err) {
    showStatus('error', 'Network error: ' + err.message);
  }
});

function showStatus(type, message) {
  const el = document.getElementById('upload-status');
  el.className = 'status ' + type;
  el.textContent = message;
}

function renderChart(data) {
  document.getElementById('results-section').classList.remove('hidden');
  currentChartKey = data.metadata.chartKey;

  // Show BTR card
  const btrCard = document.getElementById('btr-card');
  if (btrCard) btrCard.style.display = '';
  const evCard = document.getElementById('events-card');
  if (evCard) evCard.style.display = '';

  renderNative(data.native);
  renderPanchanga(data.panchanga);
  renderActiveDashas(data.metadata.activeDashas);
  renderBodies(data.bodies);
  renderKarakas(data.charaKarakas);
  renderRelationships(data.analysis.relationships);
  renderFunctionalNature(data.analysis.functionalNature);
  renderAspects(data.analysis.aspects);
  renderDignity(data.analysis.dignity);
  renderArudhas(data.analysis.arudhas);
  renderYogas(data.analysis.yogas);
  renderNavamsa(data.analysis.navamsa);
  renderPortrait(data.analysis.portrait);
  renderCharacter(data.analysis.character);
  renderJaimini(data.analysis.jaimini);
  renderClassicalRules(data.analysis.matchedRules);
  renderStrengths(data.strengths);
  loadAndRenderEvents();
  loadAndRenderPredictions();
  initTransitForm();

  window.scrollTo({ top: document.getElementById('results-section').offsetTop, behavior: 'smooth' });
}

function renderNative(n) {
  const el = document.getElementById('native-content');
  el.innerHTML = `
    <dl class="detail-grid">
      <dt>Name</dt><dd>${escapeHtml(n.name || '—')}</dd>
      <dt>Date of Birth</dt><dd>${n.dateOfBirth || '—'}</dd>
      <dt>Time of Birth</dt><dd>${n.timeOfBirth || '—'} (GMT ${n.gmtOffset || '—'})</dd>
      <dt>Place</dt><dd>${escapeHtml(n.placeOfBirth || '—')}</dd>
      <dt>Coordinates</dt><dd>${n.coordinates.latitude}°, ${n.coordinates.longitude}°</dd>
    </dl>
  `;
}

function renderPanchanga(p) {
  const el = document.getElementById('panchanga-content');
  if (!p || p._warning) {
    el.innerHTML = `<p class="muted">${escapeHtml(p?._warning || 'Panchanga not available.')}</p>`;
    return;
  }

  // Handle both old JHora-parsed format and new computed format
  const isComputed = p.tithi && typeof p.tithi === 'object';

  if (!isComputed) {
    // Old format fallback
    el.innerHTML = `<dl class="detail-grid">
      <dt>Tithi</dt><dd>${escapeHtml(p.tithi || '—')} (${p.tithiRemaining ?? '—'}% left)</dd>
      <dt>Nakshatra</dt><dd>${escapeHtml(p.janmaNakshatra || '—')} (${p.nakshatraRemaining ?? '—'}% left)</dd>
      <dt>Vara</dt><dd>${escapeHtml(p.vaar || '—')}</dd>
      <dt>Yoga</dt><dd>${escapeHtml(p.yoga || '—')}</dd>
      <dt>Karana</dt><dd>${escapeHtml(p.karana || '—')}</dd>
    </dl>`;
    return;
  }

  // ── Computed format — show full panchanga with tattva logic ─────────────
  // Source: PVR textbook Ch.1.3.8-1.3.12; Audio Lessons #46, #63
  const t = p.tithi;
  const n = p.nakshatra;
  const y = p.yoga;
  const k = p.karana;
  const v = p.vara;
  const h = p.hora;
  const st = p.specialTithis || {};
  const nt = p.navTaras || {};

  // Tattva color codes
  const TATTVA_COLOR = { Jala:'#3b82f6', Agni:'#ef4444', Bhu:'#92400e', Akasha:'#7c3aed', Vayu:'#10b981' };

  function tattvaTag(tattva) {
    const color = TATTVA_COLOR[tattva] || '#888';
    return `<span class="tattva-tag" style="background:${color}20;color:${color};border:1px solid ${color}40;">${tattva}</span>`;
  }

  let html = `
  <p class="muted" style="font-size:0.78rem; margin-bottom:12px;">
    Panchanga = Five Limbs of Time (Pancha Bhutas).
    Each element shows a different dimension of the birth moment.
    Source: PVR textbook Ch.1.3.8-1.3.12; Audio Lessons #46, #63.
  </p>

  <table class="equal-table panchanga-table">
    <thead>
      <tr>
        <th>Limb</th>
        <th>Value</th>
        <th>Tattva &amp; Significance</th>
        <th>Lord</th>
        <th>% Remaining</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><strong>Tithi</strong></td>
        <td>${t.number}. ${escapeHtml(t.name)} (${escapeHtml(t.paksha)}, ${escapeHtml(t.group)})</td>
        <td>${tattvaTag('Jala')} Prosperity, wealth, happiness</td>
        <td>${escapeHtml(t.lord)}</td>
        <td>${t.remainingPct}%</td>
      </tr>
      <tr>
        <td><strong>Nakshatra</strong></td>
        <td>${n.number}. ${escapeHtml(n.name)} pada ${n.pada}</td>
        <td>${tattvaTag('Vayu')} Strength, kinetic energy — if disturbed, troubles arise</td>
        <td>${escapeHtml(n.lord)}</td>
        <td>${n.remainingPct}%</td>
      </tr>
      <tr>
        <td><strong>Yoga</strong></td>
        <td>${y.number}. ${escapeHtml(y.name)} ${y.inauspicious ? '<span class="conf-badge conf-synthesized">inauspicious</span>' : '<span class="conf-badge conf-direct">auspicious</span>'}</td>
        <td>${tattvaTag('Akasha')} Binding force — holds all elements together</td>
        <td>—</td>
        <td>—</td>
      </tr>
      <tr>
        <td><strong>Karana</strong></td>
        <td>${escapeHtml(k.name)} ${k.auspicious ? '<span class="conf-badge conf-direct">good</span>' : ''}</td>
        <td>${tattvaTag('Bhu')} Achievement, earthly result</td>
        <td>${escapeHtml(k.lord)}</td>
        <td>—</td>
      </tr>
      <tr>
        <td><strong>Vara</strong></td>
        <td>${v ? escapeHtml(v.name) : '—'}</td>
        <td>${tattvaTag('Agni')} Life force, vitality, longevity — check Varesha strength</td>
        <td>${v ? escapeHtml(v.lord) : '—'}</td>
        <td>—</td>
      </tr>
    </tbody>
  </table>`;

  // Hora
  if (h) {
    html += `<p style="margin-top:8px; font-size:0.82rem;">
      <strong>Hora at birth:</strong> ${escapeHtml(h.lord)} hora (hora #${h.number} since sunrise).
      <span class="muted">Hora lord = planet ruling that hour — should be well-placed for activities of that nature.</span>
    </p>`;
  }

  // Special Tithis
  html += `
  <details style="margin-top:14px;">
    <summary style="font-size:0.84rem; font-weight:600; cursor:pointer;">Special Tithis (12 types) — Audio Lesson #63</summary>
    <p class="muted" style="font-size:0.76rem; margin:6px 0 8px;">
      Formula: (Moon−Sun difference × multiplier) / 12 + 1.
      Each special tithi relates to the corresponding house matters.
      Karma tithi (×10) is important for career events in transit.
      Dhana tithi (×2) is important for financial events in transit.
    </p>
    <table class="equal-table compact-table">
      <thead><tr><th>Special Tithi</th><th>Number</th><th>House</th><th>Use in transit</th></tr></thead>
      <tbody>
        ${[
          ['Janma (×1)',  st.janma,  1, 'Self, general'],
          ['Dhana (×2)',  st.dhana,  2, 'Wealth, finances — check in transit for financial events'],
          ['Bhratri (×3)',st.bhratri,3, 'Siblings, courage'],
          ['Matri (×4)',  st.matri,  4, 'Mother, home'],
          ['Putra (×5)',  st.putra,  5, 'Children, intelligence'],
          ['Satru (×6)',  st.satru,  6, 'Enemies, competition'],
          ['Kalatra (×7)',st.kalatra,7, 'Spouse, partnerships'],
          ['Mrityu (×8)', st.mrityu, 8, 'Longevity concerns'],
          ['Bhagya (×9)', st.bhagya, 9, 'Fortune, father'],
          ['Karma (×10)', st.karma,  10,'Career, work — most important for career transit analysis'],
          ['Labha (×11)', st.labha,  11,'Gains, fulfillment'],
          ['Vyaya (×12)', st.vyaya,  12,'Liberation, foreign'],
        ].map(([name, num, house, use]) =>
          `<tr>
            <td>${name}</td>
            <td><strong>${num || '—'}</strong></td>
            <td>H${house}</td>
            <td class="muted" style="font-size:0.74rem;">${use}</td>
          </tr>`
        ).join('')}
      </tbody>
    </table>
  </details>`;

  // Nav Tara
  const ntPlanets = Object.entries(nt).filter(([p,v]) => v);
  if (ntPlanets.length) {
    html += `
  <details style="margin-top:10px;">
    <summary style="font-size:0.84rem; font-weight:600; cursor:pointer;">Nav Tara from Moon — Audio Lessons #46, #63</summary>
    <p class="muted" style="font-size:0.76rem; margin:6px 0 8px;">
      9-tara cycle counted from natal Moon's nakshatra (${escapeHtml(n.name)}).
      All 3 Janma Taras ruled by same graha; all 3 Kshema Taras by same graha etc.
      Use in muhurtha: choose Sampath/Kshema/Sadhana/Mitra/Param Mitra tara nakshatras.
      Use in transit: which tara does transiting Jupiter/Saturn occupy from natal Moon?
    </p>
    <table class="equal-table compact-table">
      <thead><tr><th>Planet</th><th>Nakshatra</th><th>Tara</th><th>Favorable?</th></tr></thead>
      <tbody>
        ${ntPlanets.map(([planet, info]) => `
          <tr>
            <td><strong>${planet}</strong></td>
            <td>${escapeHtml(info.nakshatra)}</td>
            <td>${info.tara}. ${escapeHtml(info.taraName)}</td>
            <td>${info.favorable
              ? '<span class="conf-badge conf-direct">Yes</span>'
              : '<span class="conf-badge conf-synthesized">No</span>'}</td>
          </tr>`).join('')}
      </tbody>
    </table>
  </details>`;
  }

  el.innerHTML = html;
}


var DASHA_SYSTEM_LABELS = {
  narayana: 'Narayana',
  ashtottari: 'Ashtottari',
  moola: 'Moola',
  yogini: 'Yogini',
  vimshottariTribhagi: 'Vimshottari Tribhagi',
  kalachakra: 'Kalachakra',
  sudasa: 'Sudasa',
  lagnaKendradi: 'Lagna Kendradi',
  drigdasa: 'Drigdasa',
  shoola: 'Shoola',
  niryanaShoola: 'Niryana Shoola'
};

/**
 * Both findActiveDasha (planet-style: .mahadasha/.antardasha) and
 * findActiveNarayana (rasi-style: .major/.sub) results are normalized
 * to a single "MD → sub" display string here.
 */
function formatDashaContext(ctx) {
  if (!ctx) return '—';
  if (ctx.mahadasha !== undefined) return `${ctx.mahadasha}${ctx.antardasha ? ' → ' + ctx.antardasha : ''}`;
  if (ctx.major !== undefined) return `${ctx.major}${ctx.sub ? ' → ' + ctx.sub : ''}`;
  return '—';
}

function renderActiveDashas(ad) {
  const el = document.getElementById('active-dasha-content');
  let html = `<p class="muted">As of ${ad.asOf}</p>`;

  if (ad.vimshottari) {
    html += `
      <div class="active-dasha">
        <h3>Vimshottari (primary)</h3>
        <div class="dasha-lord">${ad.vimshottari.mahadasha} → ${ad.vimshottari.antardasha}${ad.vimshottari.pratyantardasha ? ' → ' + ad.vimshottari.pratyantardasha : ''}</div>
        <div class="dasha-period">
          MD: ${ad.vimshottari.mdPeriod.startDate} → ${ad.vimshottari.mdPeriod.endDate || 'ongoing'}<br>
          AD: ${ad.vimshottari.adPeriod?.startDate || '—'} → ${ad.vimshottari.adPeriod?.endDate || 'ongoing'}
          ${ad.vimshottari.pdPeriod ? `<br>PD: ${ad.vimshottari.pdPeriod.startDate} → ${ad.vimshottari.pdPeriod.endDate}` : ''}
        </div>
      </div>
    `;
  }

  // Compact one-line-per-system table for everything else — avoids
  // repeating the same large block 11 more times.
  const otherSystems = Object.keys(DASHA_SYSTEM_LABELS).filter(k => ad[k]);
  if (otherSystems.length > 0) {
    html += `
      <table class="equal-table compact-table" style="margin-top:10px;">
        <thead><tr><th class="row-label">System</th><th>Active Period</th></tr></thead>
        <tbody>
          ${otherSystems.map(k => `<tr><td class="row-label">${DASHA_SYSTEM_LABELS[k]}</td><td>${formatDashaContext(ad[k])}</td></tr>`).join('')}
        </tbody>
      </table>
    `;
  }

  el.innerHTML = html;
}

function renderBodies(bodies) {
  const order = ['Lagna', 'Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn',
                 'Rahu', 'Ketu', 'Uranus', 'Neptune', 'Pluto',
                 'Maandi', 'Gulika', 'Bhava Lagna', 'Hora Lagna', 'Ghati Lagna'];

  let html = `
    <table>
      <thead>
        <tr>
          <th>Body</th><th>Sign</th><th>Position</th><th>Nakshatra</th>
          <th>Navamsa</th><th>House</th><th>Flags</th>
        </tr>
      </thead>
      <tbody>
  `;

  for (const name of order) {
    const b = bodies[name];
    if (!b) continue;
    const flags = [];
    if (b.retrograde) flags.push('<span class="flag flag-retro">R</span>');
    if (b.charaKaraka) flags.push(`<span class="flag flag-karaka">${b.charaKaraka}</span>`);
    html += `
      <tr>
        <td class="body-name">${name}</td>
        <td>${b.sign}</td>
        <td>${b.degrees}° ${b.minutes}' ${Math.round(b.seconds)}"</td>
        <td>${b.nakshatra} — ${b.pada}</td>
        <td>${b.navamsa}</td>
        <td>${b.house || '—'}</td>
        <td>${flags.join(' ')}</td>
      </tr>
    `;
  }
  html += '</tbody></table>';
  document.getElementById('bodies-content').innerHTML = html;
}

function renderKarakas(karakas) {
  let html = '<div class="karaka-grid">';
  for (const code of ['AK', 'AmK', 'BK', 'MK', 'PiK', 'PK', 'GK', 'DK']) {
    const planet = karakas[code];
    if (!planet) continue;
    html += `
      <div class="karaka-tile">
        <div class="karaka-code">${code}</div>
        <div class="karaka-planet">${planet}</div>
        <div class="karaka-name">${CHARA_KARAKA_NAMES[code]}</div>
        <div class="muted" style="margin-top: 6px; font-size: 0.8rem;">${KARAKA_MEANINGS[code]}</div>
      </div>
    `;
  }
  html += '</div>';
  document.getElementById('karakas-content').innerHTML = html;
}

var PANCHADHA_CLASS = {
  'Adhi Mitra (Great Friend)': 'rel-great-friend',
  'Mitra (Friend)': 'rel-friend',
  'Sama (Neutral)': 'rel-neutral',
  'Shatru (Enemy)': 'rel-enemy',
  'Adhi Shatru (Great Enemy)': 'rel-great-enemy',
  'self': 'rel-self'
};

function renderRelationships(rel) {
  const el = document.getElementById('relationships-content');
  if (!rel || !rel.matrix) {
    el.innerHTML = '<p class="muted">Not available.</p>';
    return;
  }

  const planets = Object.keys(rel.matrix);

  let html = '<div style="overflow-x:auto;"><table><thead><tr><th></th>';
  for (const p of planets) html += `<th>${PLANET_SHORT[p] || p}</th>`;
  html += '</tr></thead><tbody>';

  for (const rowPlanet of planets) {
    html += `<tr><td class="body-name">${rowPlanet}</td>`;
    for (const colPlanet of planets) {
      const cell = rel.matrix[rowPlanet][colPlanet];
      const label = cell.panchadha === 'self' ? '—' : (cell.panchadha || '?').split(' ')[0];
      const cls = PANCHADHA_CLASS[cell.panchadha] || '';
      html += `<td class="${cls}" title="${cell.panchadha}">${label}</td>`;
    }
    html += '</tr>';
  }
  html += '</tbody></table></div>';

  if (rel.dispositorSubstitutions && Object.keys(rel.dispositorSubstitutions).length) {
    html += '<p class="muted" style="margin-top:10px;">Rahu/Ketu natural relationships use dispositor substitution: ';
    html += Object.entries(rel.dispositorSubstitutions).map(([node, lord]) => `${node} → via ${lord}`).join(', ');
    html += ' (derived convention, not literal BPHS text).</p>';
  }

  document.getElementById('relationships-content').innerHTML = html;
}

var FUNCTIONAL_CLASS = {
  'Yogakaraka': 'fn-yogakaraka',
  'Functional Benefic': 'fn-benefic',
  'Functional Benefic (Lagna Lord)': 'fn-benefic',
  'Functional Benefic (Lagna lord, mixed with Dusthana)': 'fn-benefic-mixed',
  'Functional Benefic (mixed)': 'fn-benefic-mixed',
  'Neutral': 'fn-neutral',
  'Mild Functional Malefic': 'fn-malefic-mild',
  'Functional Malefic': 'fn-malefic',
  'Not classified': 'fn-unclassified'
};

function renderFunctionalNature(fn) {
  const el = document.getElementById('functional-nature-content');
  if (!fn || !fn.classifications) {
    el.innerHTML = '<p class="muted">Not available.</p>';
    return;
  }

  let badhakaInfo = '';
  if (fn.badhaka) {
    badhakaInfo = `<p class="muted">Badhaka house: ${fn.badhaka.badhakaHouse} (${fn.badhaka.badhakaSign}) — Badhakesh: <strong>${fn.badhaka.badhakesh}</strong></p>`;
  }

  let html = `<p class="muted">Lagna: ${fn.lagnaSign}</p>${badhakaInfo}<div class="karaka-grid grid-3col">`;
  for (const [planet, c] of Object.entries(fn.classifications)) {
    const cls = FUNCTIONAL_CLASS[c.classification] || '';
    const badhakaBadge = c.isBadhakesh ? '<span class="flag flag-retro" style="margin-left:6px;">Badhakesh</span>' : '';
    html += `
      <div class="karaka-tile ${cls}">
        <div class="karaka-planet">${planet}${badhakaBadge}</div>
        <div class="karaka-code">${c.classification}</div>
        ${c.housesRuled ? `<div class="muted" style="margin-top:4px;">Rules: ${c.housesRuled.join(', ')}</div>` : ''}
        <div class="muted" style="margin-top:6px; font-size:0.78rem;">${c.reasoning}</div>
        ${c.marakaNote ? `<div class="muted" style="margin-top:4px; font-size:0.78rem; color:#a64030;">⚠ ${c.marakaNote}</div>` : ''}
        ${c.badhakaNote ? `<div class="muted" style="margin-top:4px; font-size:0.78rem; color:#8a5a24;">⚠ ${c.badhakaNote}</div>` : ''}
      </div>
    `;
  }
  html += '</div>';
  document.getElementById('functional-nature-content').innerHTML = html;
}

function renderAspects(asp) {
  const el = document.getElementById('aspects-content');
  if (!asp || !asp.outgoing) {
    el.innerHTML = '<p class="muted">Not available.</p>';
    return;
  }

  let html = `
    <table>
      <thead><tr><th>Planet</th><th>House</th><th>Aspects Houses</th><th>Aspects Planets</th></tr></thead>
      <tbody>
  `;
  for (const [planet, data] of Object.entries(asp.outgoing)) {
    const targets = data.planetsAspected.map(p => `${p.planet} (h${p.house})`).join(', ') || '—';
    const convention = data.isDerivedConvention ? ' <span class="flag flag-karaka" title="Derived convention, not core BPHS">derived</span>' : '';
    html += `
      <tr>
        <td class="body-name">${planet}${convention}</td>
        <td>${data.sourceHouse}</td>
        <td>${data.housesAspected.join(', ')}</td>
        <td>${targets}</td>
      </tr>
    `;
  }
  html += '</tbody></table>';
  document.getElementById('aspects-content').innerHTML = html;
}

var PLANET_ORDER_9 = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn', 'Rahu', 'Ketu'];
var PLANET_ORDER_7 = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn'];
var SIGN_SHORT = ['Ar', 'Ta', 'Ge', 'Cn', 'Le', 'Vi', 'Li', 'Sc', 'Sg', 'Cp', 'Aq', 'Pi'];

function renderStrengths(str) {
  if (!str) return;
  renderShadbalaTable(str.shadbala);
  renderVimsopakaTable(str.vimsopaka);
  renderAshtakavargaTable(str.ashtakavarga);
  renderBhavaBalaTable(str.bhavaBala);
  renderAvasthaGrid(str.avastha, str.activity);
}

function equalCols(n) {
  return `repeat(${n}, 1fr)`;
}

function renderShadbalaTable(sb) {
  const el = document.getElementById('shadbala-content');
  if (!sb || Object.keys(sb).length === 0) { el.innerHTML = '<p class="muted">Not available.</p>'; return; }

  let html = `<table class="equal-table"><colgroup><col style="width:18%"><col style="width:20.5%"><col style="width:20.5%"><col style="width:20.5%"><col style="width:20.5%"></colgroup>
    <thead><tr><th class="row-label">Planet</th><th>Rupas</th><th>% of Required</th><th>Ishta Phala</th><th>Kashta Phala</th></tr></thead><tbody>`;
  for (const planet of PLANET_ORDER_7) {
    const v = sb[planet];
    if (!v) continue;
    if (v._warning) { html += `<tr><td class="row-label">${planet}</td><td colspan="4" class="muted">parse issue</td></tr>`; continue; }
    html += `<tr><td class="row-label">${planet}</td><td>${v.rupas}</td><td>${v.percentOfRequired}%</td><td>${v.ishtaPhala}</td><td>${v.kashtaPhala}</td></tr>`;
  }
  html += '</tbody></table>';
  el.innerHTML = html;
}

function renderVimsopakaTable(vs) {
  const el = document.getElementById('vimsopaka-content');
  if (!vs || Object.keys(vs).length === 0) { el.innerHTML = '<p class="muted">Not available.</p>'; return; }

  let html = `<table class="equal-table"><colgroup><col style="width:18%"><col style="width:20.5%"><col style="width:20.5%"><col style="width:20.5%"><col style="width:20.5%"></colgroup>
    <thead><tr><th class="row-label">Planet</th><th>Dasa Varga(10)</th><th>Shodasa(16)</th><th>Sapta(7)</th><th>Shad(6)</th></tr></thead><tbody>`;
  for (const planet of PLANET_ORDER_9) {
    const v = vs[planet];
    if (!v) continue;
    if (v._warning) { html += `<tr><td class="row-label">${planet}</td><td colspan="4" class="muted">parse issue</td></tr>`; continue; }
    html += `<tr><td class="row-label">${planet}</td><td>${v.dasaVarga.percent}%</td><td>${v.shodasaVarga.percent}%</td><td>${v.saptaVarga.percent}%</td><td>${v.shadVarga.percent}%</td></tr>`;
  }
  html += '</tbody></table>';
  el.innerHTML = html;
}

function renderAshtakavargaTable(av) {
  const el = document.getElementById('ashtakavarga-content');
  if (!av || !av.sarva) { el.innerHTML = '<p class="muted">Not available.</p>'; return; }

  let html = `<table class="equal-table"><colgroup><col style="width:16%">${'<col style="width:7%">'.repeat(12)}</colgroup>
    <thead><tr><th class="row-label">Sign</th>${SIGN_SHORT.map(s => `<th>${s}</th>`).join('')}</tr></thead>
    <tbody><tr><td class="row-label">SAV</td>${av.sarva.map(v => `<td>${v}</td>`).join('')}</tr></tbody></table>`;
  html += '<p class="muted" style="margin-top:8px; font-size:0.78rem;">SAV = Sarvashtakavarga total bindus per sign (computed as the sum of all 8 Bhinnashtakavarga rows).</p>';
  el.innerHTML = html;
}

function renderBhavaBalaTable(bb) {
  const el = document.getElementById('bhavabala-content');
  if (!bb || Object.keys(bb).length === 0) { el.innerHTML = '<p class="muted">Not available.</p>'; return; }

  const houses = [1,2,3,4,5,6,7,8,9,10,11,12];
  let html = `<table class="equal-table compact-table"><colgroup><col style="width:8%">${'<col>'.repeat(12)}</colgroup>
    <thead><tr><th class="row-label">House</th>${houses.map(h => `<th>${h}</th>`).join('')}</tr></thead>
    <tbody><tr><td class="row-label">Rupas</td>${houses.map(h => `<td>${bb[h]?.rupas ?? '—'}</td>`).join('')}</tr></tbody></table>`;
  el.innerHTML = html;
}

function renderAvasthaGrid(avastha, activity) {
  const el = document.getElementById('avastha-content');
  if (!avastha || Object.keys(avastha).length === 0) { el.innerHTML = '<p class="muted">Not available.</p>'; return; }

  let html = `<table class="equal-table"><colgroup><col style="width:14%"><col style="width:20%"><col style="width:20%"><col style="width:26%"><col style="width:20%"></colgroup>
    <thead><tr><th class="row-label">Planet</th><th>Age</th><th>Alertness</th><th>Mood</th><th>Activity</th></tr></thead><tbody>`;
  for (const planet of PLANET_ORDER_9) {
    const a = avastha[planet];
    const act = activity?.[planet];
    if (!a) continue;
    if (a._warning) {
      html += `<tr><td class="row-label">${planet}</td><td colspan="4" class="muted">parse issue</td></tr>`;
      continue;
    }
    html += `
      <tr>
        <td class="row-label">${planet}</td>
        <td>${a.age.term}</td>
        <td>${a.alertness.term}</td>
        <td>${a.mood.map(m => m.term).join(', ')}</td>
        <td>${act ? act.term : '—'}</td>
      </tr>
    `;
  }
  html += '</tbody></table>';
  el.innerHTML = html;
}

var DIGNITY_CLASS = {
  'Exalted': 'dignity-exalted',
  'Moolatrikona': 'dignity-moolatrikona',
  'Own Sign (Swakshetra)': 'dignity-own',
  "Friend's Sign": 'dignity-friend',
  "Neutral's Sign": 'dignity-neutral',
  "Enemy's Sign": 'dignity-enemy',
  'Debilitated': 'dignity-debilitated',
  'Not classified': 'dignity-unclassified'
};

function renderDignity(dig) {
  const el = document.getElementById('dignity-content');
  if (!dig || !dig.classifications) {
    el.innerHTML = '<p class="muted">Not available.</p>';
    return;
  }
  let html = '<div class="karaka-grid grid-3col">';
  for (const [planet, d] of Object.entries(dig.classifications)) {
    const cls = DIGNITY_CLASS[d.tier] || '';
    html += `
      <div class="karaka-tile ${cls}">
        <div class="karaka-planet">${planet}</div>
        <div class="karaka-code">${d.tier}</div>
        <div class="muted" style="margin-top:6px; font-size:0.78rem;">${d.detail}</div>
      </div>
    `;
  }
  html += '</div>';
  el.innerHTML = html;
}

function renderArudhas(aru) {
  const el = document.getElementById('arudhas-content');
  if (!aru || !aru.arudhas) {
    el.innerHTML = '<p class="muted">Not available.</p>';
    return;
  }
  let html = `
    <table>
      <thead><tr><th>Arudha</th><th>Bhava</th><th>Lord</th><th>Lord's House</th><th>Result</th></tr></thead>
      <tbody>
  `;
  for (const [key, a] of Object.entries(aru.arudhas)) {
    if (a.error) {
      html += `<tr><td class="body-name">${key}</td><td colspan="4" class="muted">${escapeHtml(a.error)}</td></tr>`;
      continue;
    }
    html += `
      <tr>
        <td class="body-name">${key}${a.alias ? `<div class="arudha-alias">${a.alias}</div>` : ''}</td>
        <td>House ${a.bhava} (${a.bhavaSign})</td>
        <td>${a.lord}</td>
        <td>House ${a.lordHouse}</td>
        <td>House ${a.finalArudhaHouse}${a.exceptionApplied ? '<div class="arudha-exception">exception applied (+10)</div>' : ''}</td>
      </tr>
    `;
  }
  html += '</tbody></table>';
  el.innerHTML = html;
}

function renderYogas(yog) {
  const el = document.getElementById('yogas-content');
  if (!yog) {
    el.innerHTML = '<p class="muted">Not available.</p>';
    return;
  }

  let html = '';

  html += '<div class="yoga-group"><h3>Parivartana (Sign Exchange)</h3>';
  if (yog.parivartana.length === 0) {
    html += '<p class="yoga-empty">None detected.</p>';
  } else {
    for (const p of yog.parivartana) {
      const qClass = p.quality.startsWith('Favorable') ? 'quality-favorable' : p.quality.startsWith('Mixed') ? 'quality-mixed' : '';
      html += `<div class="yoga-item ${qClass}">${escapeHtml(p.detail)}<div class="muted" style="margin-top:4px;">${escapeHtml(p.quality)}</div></div>`;
    }
  }
  html += '</div>';

  html += '<div class="yoga-group"><h3>Gajakesari Yoga</h3>';
  if (!yog.gajakesari) {
    html += '<p class="yoga-empty">Not present (Moon and Jupiter not in mutual Kendra).</p>';
  } else {
    html += `<div class="yoga-item quality-favorable">${escapeHtml(yog.gajakesari.detail)}<div class="yoga-caveat">${escapeHtml(yog.gajakesari.caveat)}</div></div>`;
  }
  html += '</div>';

  html += '<div class="yoga-group"><h3>Raja Yoga (Kendra-Trikona connections)</h3>';
  if (yog.rajaYogas.length === 0) {
    html += '<p class="yoga-empty">None detected.</p>';
  } else {
    for (const r of yog.rajaYogas) {
      html += `<div class="yoga-item quality-favorable">${escapeHtml(r.detail)}</div>`;
    }
  }
  html += '</div>';

  html += '<div class="yoga-group"><h3>Dhana Yoga (Wealth connections)</h3>';
  if (yog.dhanaYogas.length === 0) {
    html += '<p class="yoga-empty">None detected.</p>';
  } else {
    for (const d of yog.dhanaYogas) {
      html += `<div class="yoga-item quality-favorable">${escapeHtml(d.detail)}</div>`;
    }
  }
  html += '</div>';

  html += '<div class="yoga-group"><h3>Vipreet Raja Yoga (Harsha/Sarala/Vimala)</h3>';
  if (yog.vipreetRajaYogas.length === 0) {
    html += '<p class="yoga-empty">None detected.</p>';
  } else {
    for (const v of yog.vipreetRajaYogas) {
      html += `<div class="yoga-item ${v.confidence === 'low' ? '' : 'quality-favorable'}">${v.name}: ${escapeHtml(v.detail)}</div>`;
    }
  }
  html += '</div>';

  el.innerHTML = html;
}

// ===== Personal Events =====

document.getElementById('event-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!currentChartKey) return;

  const date = document.getElementById('event-date').value;
  const category = document.getElementById('event-category').value;
  const description = document.getElementById('event-description').value;

  try {
    const res = await fetch('/api/events', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chartKey: currentChartKey, date, category, description })
    });
    const data = await res.json();
    if (!res.ok) {
      alert('Error adding event: ' + (data.error || res.statusText));
      return;
    }
    document.getElementById('event-form').reset();
    loadAndRenderEvents();
  } catch (err) {
    alert('Network error: ' + err.message);
  }
});

async function loadAndRenderEvents() {
  if (!currentChartKey) return;
  try {
    const res = await fetch(`/api/events?chartKey=${encodeURIComponent(currentChartKey)}`);
    const data = await res.json();
    renderEvents(data.events || []);
  } catch (err) {
    document.getElementById('events-content').innerHTML = '<p class="muted">Could not load events.</p>';
  }
}

async function deleteEvent(id) {
  try {
    await fetch(`/api/events/${id}`, { method: 'DELETE' });
    loadAndRenderEvents();
  } catch (err) {
    alert('Could not delete event: ' + err.message);
  }
}

function renderConvergenceBlock(conv, eventId) {
  if (!conv || conv._warning || !conv.houseConvergence) return '';

  const dynamicHouses = conv.houseConvergence.filter(h => h.dynamicCount > 0).slice(0, 6);
  if (dynamicHouses.length === 0) return '';

  const houseRows = dynamicHouses.map(h => `
    <tr>
      <td class="row-label">H${h.house}</td>
      <td style="text-align:left;">${h.themes.slice(0, 2).join(' / ')}</td>
      <td><strong>${h.dynamicCount}</strong></td>
      <td style="text-align:left; font-size:0.74rem;">
        ${h.viaRulership.length ? `<span title="rules this house">rules: ${h.viaRulership.join(', ')}</span>` : ''}
        ${h.viaAspect.length ? `<br><span title="aspects this house">aspects: ${h.viaAspect.join(', ')}</span>` : ''}
      </td>
    </tr>
  `).join('');

  // Classical rules per active lord — only lords that actually triggered rules
  const lordsWithRules = Object.entries(conv.planetBreakdown || {})
    .filter(([, b]) => b.classicalRules && b.classicalRules.length > 0);

  let rulesHtml = '';
  if (lordsWithRules.length > 0) {
    rulesHtml = `
      <p class="muted convergence-note" style="margin-top:12px;"><strong>What classical texts associate with these active lords:</strong></p>
      <div class="classical-rules-list">
        ${lordsWithRules.map(([planet, b]) => `
          <div class="classical-rule-planet">
            <div class="crp-name">${planet}</div>
            ${b.classicalRules.map(r => renderRuleLine(r)).join('')}
          </div>
        `).join('')}
      </div>
    `;
  }

  return `
    <details class="convergence-block">
      <summary>Why this period? — indicator convergence + classical rules (${conv.distinctPlanets} active planets)</summary>
      <div class="convergence-inner">
        <p class="muted convergence-note">
          Houses connected to the <em>active dasha lords</em> via rulership or aspect — ranked by how many independent active lords touch each. This shows where the active lords point and what classical texts associate with them; it does <strong>not</strong> predict an outcome. You interpret.
        </p>
        <table class="equal-table compact-table">
          <thead><tr><th class="row-label">House</th><th style="text-align:left;">Theme</th><th>Lords</th><th style="text-align:left;">How</th></tr></thead>
          <tbody>${houseRows}</tbody>
        </table>
        ${rulesHtml}
        <p class="muted convergence-note" style="margin-top:8px;">
          Note: planets merely <em>sitting</em> in a house (occupancy) are a fixed chart feature, identical on every date, so they're excluded from the house ranking to avoid false signal. Rasi-dasha lords are read via their sign ruler (one step removed).
        </p>
      </div>
    </details>
  `;
}

document.getElementById('download-report-btn').addEventListener('click', () => {
  if (!currentChartKey) {
    alert('Parse a chart first.');
    return;
  }
  // Opening the endpoint triggers the download (Content-Disposition: attachment)
  window.location.href = `/api/report?chartKey=${encodeURIComponent(currentChartKey)}`;
});

document.getElementById('download-xlsx-btn').addEventListener('click', () => {
  if (!currentChartKey) {
    alert('Parse a chart first.');
    return;
  }
  window.location.href = `/api/workbook?chartKey=${encodeURIComponent(currentChartKey)}`;
});

async function loadAndRenderPredictions() {
  if (!currentChartKey) return;
  const el = document.getElementById('predict-content');
  el.innerHTML = '<p class="muted">Loading...</p>';
  try {
    const res = await fetch(`/api/predict?chartKey=${encodeURIComponent(currentChartKey)}`);
    const data = await res.json();
    if (!res.ok) {
      el.innerHTML = `<p class="muted">${escapeHtml(data.error || 'Could not load predictions.')}</p>`;
      return;
    }
    renderPredictions(data.predictions, { education: data.educationPath, career: data.careerPath, foreignTravel: data.foreignPath });
  } catch (err) {
    el.innerHTML = '<p class="muted">Could not load predictions.</p>';
  }
}

function scoreBarColor(score, domainType) {
  // For 'affliction' domains, the color scale INVERTS: a high score means
  // elevated vulnerability (caution = red), not a good outcome (green).
  if (domainType === 'affliction') {
    if (score < 35) return '#4a8a3f';
    if (score < 55) return '#8a9a2f';
    if (score < 75) return '#b58a2f';
    return '#a64030';
  }
  if (score < 35) return '#a64030';
  if (score < 55) return '#b58a2f';
  if (score < 75) return '#8a9a2f';
  return '#4a8a3f';
}

/**
 * Map an indicator's polarity to a visual tone, respecting domainType.
 * For 'affliction' domains, "supports" means supports VULNERABILITY
 * (shown as a caution/red dot), the reverse of 'growth' domains.
 */
function indicatorTone(polarity, domainType) {
  if (polarity === 'neutral') return 'neutral';
  const isAffliction = domainType === 'affliction';
  if (polarity === 'supports') return isAffliction ? 'challenging' : 'favorable';
  return isAffliction ? 'favorable' : 'challenging';
}

function renderPredictions(predictions, pathClassifications) {
  const el = document.getElementById('predict-content');
  const entries = Object.values(predictions);
  if (entries.every(p => !p.windows || p.windows.length === 0)) {
    el.innerHTML = '<p class="muted">No relevant future dasha-windows found within the available data for any event category.</p>';
    return;
  }

  let html = '';
  for (const p of entries) {
    const afflictionBadge = p.domainType === 'affliction'
      ? '<span class="affliction-badge" title="Vulnerability/risk domain — not a growth/achievement domain">⚠ vulnerability domain</span>'
      : '';
    html += `<div class="predict-event"><h3>${escapeHtml(p.label)} ${afflictionBadge}</h3>`;

    if (p.extremeSensitivity) {
      html += `<div class="extreme-sensitivity-banner">⚠️ <strong>This is NOT a death prediction.</strong> This domain reflects classical significator-affliction patterns in the broadest sense — affliction to a relation's significator classically corresponds to many possible difficulties (health, distance, financial strain, relationship friction), not only death. Jyotish treats literal mortality timing with extreme caution even in dedicated analysis. Please read this as a general stress-pattern indicator, never as a forecast of someone's death.</div>`;
    }

    const pathData = pathClassifications && pathClassifications[p.event];
    if (pathData && pathData.leanings && pathData.leanings.length > 0) {
      html += `<div class="education-path-block">
        <p class="muted" style="font-size:0.78rem; margin-bottom:6px;"><strong>Path leanings</strong> (more interpretive than the promise checklist below — see confidence flags):</p>
        ${pathData.leanings.map(l => `
          <div class="leaning-item">
            <span class="conf-badge conf-${l.confidence}">${l.confidence}</span>
            <strong>${escapeHtml(l.path)}</strong>
            <ul>${l.indicators.map(i => `<li>${escapeHtml(i)}</li>`).join('')}</ul>
          </div>
        `).join('')}
        <p class="muted" style="font-size:0.74rem; margin-top:4px;">${escapeHtml(pathData.note)}</p>
      </div>`;
    }

    // Promise summary line
    html += `<p class="muted predict-promise-line">
      Promise (D1): <strong>${p.promise.supportCount}</strong> ${p.domainType === 'affliction' ? 'vulnerability-supporting' : 'supporting'}, <strong>${p.promise.weakenCount}</strong> ${p.domainType === 'affliction' ? 'protective' : 'weakening'}, ${p.promise.neutralCount} neutral indicator(s).
      <details class="promise-details"><summary>show indicators</summary>
        ${p.promise.indicators.map(i => `<div class="promise-indicator pol-${i.polarity}">${POLARITY_DOT[indicatorTone(i.polarity, p.domainType)]} ${escapeHtml(i.detail)} <span class="src">(${escapeHtml(i.source.text)})</span></div>`).join('')}
      </details>
    </p>`;

    if (p.domainType === 'affliction') {
      html += `<p class="caution-note">⚠ This is a classical tendency reading, not medical or psychological advice. If this is a live concern, please consult a qualified doctor or counselor.</p>`;
    }

    if (!p.windows || p.windows.length === 0) {
      html += '<p class="muted">No relevant future dasha-windows found for this event.</p></div>';
      continue;
    }

    for (const w of p.windows) {
      const color = scoreBarColor(w.score, p.domainType);
      const suppBadge = w.suppressionApplied
        ? `<span style="font-size:0.72rem;color:#991b1b;margin-left:6px;" title="${escapeHtml(w.suppressionApplied)}">⚡ suppressed</span>`
        : '';
      html += `
        <details class="predict-window">
          <summary>
            <span class="predict-score" style="color:${color};">${w.score}%</span>
            <span class="predict-label">${escapeHtml(w.label)}</span>${suppBadge}
            <span class="predict-period">${w.startDate} → ${w.endDate || 'ongoing'}</span>
            <span class="predict-lords">MD ${escapeHtml(w.mdLord)} / AD ${escapeHtml(w.adLord)}</span>
          </summary>
          <div class="predict-window-inner">
            <div class="score-bar-track"><div class="score-bar-fill" style="width:${w.score}%; background:${color};"></div></div>
            <table class="equal-table compact-table" style="margin-top:8px;">
              <thead><tr><th class="row-label">Component</th><th>Points</th><th style="text-align:left;">Reason</th></tr></thead>
              <tbody>
                ${(w.breakdown||[]).map(b => `<tr><td class="row-label">${escapeHtml(b.label)}</td><td>${b.value >= 0 ? '+' : ''}${b.value}</td><td style="text-align:left; font-size:0.78rem;">${escapeHtml(b.reason)}</td></tr>`).join('')}
              </tbody>
            </table>
            ${w.suppressionApplied ? `<p class="muted" style="font-size:0.74rem;color:#991b1b;margin-top:4px;">⚡ ${escapeHtml(w.suppressionApplied)}</p>` : ''}
          </div>
        </details>
      `;
    }
    html += '</div>';
  }

  html += `<p class="muted convergence-note" style="margin-top:10px;">${escapeHtml(Object.values(predictions)[0]?.note || '')}</p>`;
  el.innerHTML = html;
}

function renderPlacementLine(p, label) {
  if (!p) return `<p class="muted">${label}: not available.</p>`;
  return `
    <div class="character-placement">
      <strong>${label}: ${p.planet}</strong> — ${p.sign}, House ${p.house}
      <br><span class="muted" style="font-size:0.8rem;">Nakshatra: ${p.nakshatra} (pada ${p.nakshatraPada}), lord ${p.nakshatraLord || '—'}</span>
      <br><span class="muted" style="font-size:0.8rem;">Dignity: ${p.dignity || '—'}${p.functionalNature ? ' · ' + p.functionalNature : ''}</span>
    </div>
  `;
}

function renderPortrait(p) {
  const el = document.getElementById('portrait-content');
  if (!p || p._warning) {
    el.innerHTML = `<p class="muted">${escapeHtml(p?._warning || 'Not available.')}</p>`;
    return;
  }
  let html = '<div class="character-narrative">';
  (p.paragraphs || []).forEach(para => {
    html += `<p>${escapeHtml(para)}</p>`;
  });
  html += '</div>';
  html += `<p class="muted convergence-note" style="margin-top:10px;">${escapeHtml(p.note)}</p>`;
  el.innerHTML = html;
}

function renderCharacter(c) {
  const el = document.getElementById('character-content');
  if (!c || c._warning) {
    el.innerHTML = `<p class="muted">${escapeHtml(c?._warning || 'Not available.')}</p>`;
    return;
  }

  // PVR sequence: Lagna → AL → AK → Sun → Moon (Ch.13 textbook)
  // This section = FACTUAL chart indicators, not narrative
  let html = '';

  // Layer 1: Lagna (body, outward approach)
  const ll = c.lagnaLord;
  html += `<div class="char-layer">
    <div class="char-layer-label">Lagna — Body &amp; Outward Approach</div>
    <div class="char-layer-sign">${escapeHtml(c.lagnaSign)}</div>
    ${(c.lagnaArchetype?.structuralNotes||[]).map(n=>`<div class="char-note">${escapeHtml(n)}</div>`).join('')}
    ${ll ? `<div class="char-lord">Lagna lord <strong>${escapeHtml(ll.planet)}</strong> in ${escapeHtml(ll.sign)} H${ll.house} — ${escapeHtml(ll.nakshatra)} pada ${ll.nakshatraPada} · ${escapeHtml(ll.dignity||'')}</div>` : ''}
  </div>`;

  // Layer 2: Moon (mind, inner world)
  const mo = c.moon;
  html += `<div class="char-layer">
    <div class="char-layer-label">Moon — Mind &amp; Emotional Nature</div>
    ${mo ? `<div class="char-lord"><strong>Moon</strong> in ${escapeHtml(mo.sign)} H${mo.house} — ${escapeHtml(mo.nakshatra)} pada ${mo.nakshatraPada} · ${escapeHtml(mo.dignity||'')}</div>` : '<div class="char-note muted">Not computed</div>'}
  </div>`;

  // Layer 3: Sun (will, soul, self-expression)
  const su = c.sun;
  html += `<div class="char-layer">
    <div class="char-layer-label">Sun — Will &amp; Self-Expression</div>
    ${su ? `<div class="char-lord"><strong>Sun</strong> in ${escapeHtml(su.sign)} H${su.house} — ${escapeHtml(su.nakshatra)} pada ${su.nakshatraPada} · ${escapeHtml(su.dignity||'')}</div>` : '<div class="char-note muted">Not computed</div>'}
  </div>`;

  // Layer 4: Active dasha context
  html += `<div class="char-layer">
    <div class="char-layer-label">Active Dasha Context</div>
    <div class="char-lord">${escapeHtml(c.timing?.currentMD||'—')} MD / ${escapeHtml(c.timing?.currentAD||'—')} AD</div>
    ${(c.timing?.activeLayer||[]).map(r=>`<div class="char-note">${escapeHtml(r)}</div>`).join('')}
  </div>`;

  html += `<p class="muted convergence-note" style="margin-top:10px; font-size:0.76rem;">
    Lagna = how you act in the world. Moon = how you feel it. Sun = what drives you.
    Source: PVR textbook Ch.13 interpretation sequence.
  </p>`;

  el.innerHTML = html;
}

function renderJaimini(j) {
  const captionEl = document.getElementById('jaimini-caveat');
  const el = document.getElementById('jaimini-content');
  if (!j || j._warning) {
    captionEl.textContent = '';
    el.innerHTML = `<p class="muted">${escapeHtml(j?._warning || 'Not available.')}</p>`;
    return;
  }

  captionEl.textContent = j.caveats.birthTime;

  const ak = j.atmakaraka;
  const kl = j.karakamsaLagna;
  const id = j.ishtaDevataIndicators;

  el.innerHTML = `
    <div class="karaka-grid grid-3col">
      <div class="karaka-tile fn-yogakaraka">
        <div class="karaka-planet">Atmakaraka</div>
        <div class="karaka-code">${ak.planet}</div>
        <div class="muted" style="margin-top:6px; font-size:0.8rem;">
          ${ak.d1Sign} ${ak.d1DegreeInSign}° · House ${ak.d1House}<br>
          Nakshatra: ${ak.nakshatra} (pada ${ak.nakshatraPada}), lord ${ak.nakshatraLord || '—'}
        </div>
      </div>
      <div class="karaka-tile fn-benefic">
        <div class="karaka-planet">Karakamsa Lagna</div>
        <div class="karaka-code">${kl.sign}</div>
        <div class="muted" style="margin-top:6px; font-size:0.8rem;">
          AK's navamsa sign — read as a special Lagna for soul-themes.<br>
          Occupants: ${kl.occupants.join(', ') || 'none'}
        </div>
      </div>
      <div class="karaka-tile fn-benefic-mixed">
        <div class="karaka-planet">Ishta Devata indicators</div>
        <div class="karaka-code">12th from KL: ${id.twelfthFromKarakamsa}</div>
        <div class="muted" style="margin-top:6px; font-size:0.8rem;">
          Lord: ${id.twelfthLord}${id.twelfthOccupants.length ? ' · occupants: ' + id.twelfthOccupants.join(', ') : ''}<br>
          <em>Indicators only — no specific deity named (traditions differ).</em>
        </div>
      </div>
    </div>
    <p class="muted convergence-note" style="margin-top:10px;">
      ${escapeHtml(ak.note)} ${escapeHtml(j.caveats.akScheme)}
    </p>
  `;
}

function renderClassicalRules(rules) {
  const el = document.getElementById('classical-rules-content');
  if (!rules || rules.length === 0) {
    el.innerHTML = '<p class="muted">No rules matched.</p>';
    return;
  }

  // Show the specific/special rules prominently; house-lord rules are many,
  // so group them under an expandable section to avoid overwhelming.
  const special = rules.filter(r => r.category === 'special');
  const houseLord = rules.filter(r => r.category === 'house-lord-placement');

  let html = '';

  if (special.length > 0) {
    html += '<div class="classical-rules-list">';
    html += special.map(r => renderRuleLine(r)).join('');
    html += '</div>';
  }

  if (houseLord.length > 0) {
    html += `
      <details class="convergence-block" style="margin-top:12px;">
        <summary>House-lord placements (${houseLord.length}) — baseline classical associations</summary>
        <div class="convergence-inner classical-rules-list">
          ${houseLord.map(r => renderRuleLine(r)).join('')}
        </div>
      </details>
    `;
  }

  html += `
    <p class="muted convergence-note" style="margin-top:12px;">
      <strong>Reading these honestly:</strong> badges mark how directly each rule maps to classical text —
      ${CONFIDENCE_BADGE.direct} widely-agreed, ${CONFIDENCE_BADGE.interpretive} paraphrase (verify wording),
      ${CONFIDENCE_BADGE.synthesized} combined/modern. This is a curated subset, not the whole of any text.
      Every rule is a hypothesis to test against real charts — never a fixed prediction.
    </p>
  `;

  el.innerHTML = html;
}

function renderClassicalRulesPlaceholder() {}

var CONFIDENCE_BADGE = {
  direct: '<span class="conf-badge conf-direct" title="Corresponds to a specific, widely-agreed classical statement">direct</span>',
  interpretive: '<span class="conf-badge conf-interpretive" title="Reasonable paraphrase of classical principle; verify exact wording against original">interpretive</span>',
  synthesized: '<span class="conf-badge conf-synthesized" title="Combines multiple principles or reflects common modern practice">synthesized</span>'
};

var POLARITY_DOT = {
  favorable: '<span class="pol-dot pol-fav" title="favorable">●</span>',
  challenging: '<span class="pol-dot pol-chal" title="challenging">●</span>',
  mixed: '<span class="pol-dot pol-mix" title="mixed">●</span>',
  neutral: '<span class="pol-dot pol-neu" title="neutral">●</span>'
};

function renderRuleLine(r) {
  return `
    <div class="classical-rule-line">
      ${POLARITY_DOT[r.polarity] || ''}
      ${CONFIDENCE_BADGE[r.sourceConfidence] || ''}
      <span class="crl-trigger">${escapeHtml(r.trigger)}</span>
      <div class="crl-effect">${escapeHtml(r.effect)}</div>
      <div class="crl-source">— ${escapeHtml(r.source.text)}${r.source.area ? ', ' + escapeHtml(r.source.area) : ''}</div>
      ${r.caveat ? `<div class="crl-caveat">⚠ ${escapeHtml(r.caveat)}</div>` : ''}
    </div>
  `;
}

function renderEvents(events) {
  const el = document.getElementById('events-content');
  if (events.length === 0) {
    el.innerHTML = '<p class="events-empty">No events logged yet for this chart.</p>';
    return;
  }

  const sorted = [...events].sort((a, b) => a.date.localeCompare(b.date));

  let html = '';
  for (const ev of sorted) {
    let dashaHtml = '';
    const dc = ev.dashaContext;
    if (dc && Object.keys(dc).length > 0) {
      const rows = [];
      if (dc.vimshottari) {
        rows.push(['Vimshottari', `${dc.vimshottari.mahadasha} → ${dc.vimshottari.antardasha}${dc.vimshottari.pratyantardasha ? ' → ' + dc.vimshottari.pratyantardasha : ''}`]);
      }
      for (const [key, label] of Object.entries(DASHA_SYSTEM_LABELS)) {
        if (dc[key]) rows.push([label, formatDashaContext(dc[key])]);
      }
      if (rows.length > 0) {
        dashaHtml = `
          <div class="event-dasha-context">
            <table class="equal-table compact-table">
              <tbody>
                ${rows.map(([sys, val]) => `<tr><td class="row-label">${sys}</td><td style="text-align:left;">${val}</td></tr>`).join('')}
              </tbody>
            </table>
          </div>
        `;
      }
    }
    html += `
      <div class="event-item">
        <button class="event-delete" onclick="deleteEvent('${ev.id}')" title="Delete">✕</button>
        <span class="event-date">${ev.date}</span>
        <span class="event-category">${ev.category}</span>
        <div class="event-description">${escapeHtml(ev.description)}</div>
        ${dashaHtml}
        ${renderConvergenceBlock(ev.convergence, ev.id)}
      </div>
    `;
  }
  el.innerHTML = html;
}

var CONFIRMATION_CLASS = {
  'strong': 'fn-yogakaraka',
  'weak': 'fn-malefic',
  'mixed-pos': 'fn-benefic-mixed',
  'mixed-neg': 'fn-malefic-mild',
  'lean-pos': 'fn-benefic',
  'lean-neg': 'fn-malefic-mild',
  'neutral': 'fn-neutral'
};

function classifyReadTone(read) {
  if (read.startsWith('Vargottama')) return 'strong';
  if (read.startsWith('Confirmed strong')) return 'strong';
  if (read.startsWith('Confirmed weak')) return 'weak';
  if (read.includes('D1 promises strength but D9 tempers')) return 'mixed-neg';
  if (read.includes('D1 shows weakness but D9 supports')) return 'mixed-pos';
  if (read.includes('D9 adds unexpected strength')) return 'lean-pos';
  if (read.includes('D9 introduces weakness')) return 'lean-neg';
  if (read.includes('Mild, not fully cross-verified, support')) return 'lean-pos';
  return 'neutral';
}

function renderNavamsa(nav) {
  const captionEl = document.getElementById('navamsa-caveat');
  const el = document.getElementById('navamsa-content');
  if (!nav || nav._warning) {
    el.innerHTML = `<p class="muted">${escapeHtml(nav?._warning || 'Not available.')}</p>`;
    return;
  }

  captionEl.textContent = nav.birthTimeCaveat;

  let html = `<p class="muted">D9 Lagna: ${nav.d9LagnaSign}</p>
    <table class="equal-table">
      <colgroup><col style="width:12%"><col style="width:18%"><col style="width:18%"><col style="width:52%"></colgroup>
      <thead><tr><th class="row-label">Planet</th><th>D1</th><th>D9</th><th style="text-align:left;">Confirmation</th></tr></thead>
      <tbody>`;
  for (const [planet, c] of Object.entries(nav.confirmation)) {
    const tone = classifyReadTone(c.read);
    const cls = CONFIRMATION_CLASS[tone] || '';
    const vargottamaBadge = c.isVargottama ? ' <span class="flag flag-karaka">Vargottama</span>' : '';
    html += `
      <tr class="${cls}">
        <td class="row-label">${planet}${vargottamaBadge}</td>
        <td>${c.d1Tier}</td>
        <td>${c.d9Tier}</td>
        <td style="text-align:left; font-size:0.8rem;">${escapeHtml(c.read)}</td>
      </tr>
    `;
  }
  html += '</tbody></table>';
  el.innerHTML = html;
}

var SIGN_OPTIONS = [
  ['Ar', 'Aries'], ['Ta', 'Taurus'], ['Ge', 'Gemini'], ['Cn', 'Cancer'],
  ['Le', 'Leo'], ['Vi', 'Virgo'], ['Li', 'Libra'], ['Sc', 'Scorpio'],
  ['Sg', 'Sagittarius'], ['Cp', 'Capricorn'], ['Aq', 'Aquarius'], ['Pi', 'Pisces']
];
var TRANSIT_PLANET_LIST = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn', 'Rahu', 'Ketu'];

function initTransitForm() {
  const el = document.getElementById('transit-inputs');
  el.innerHTML = TRANSIT_PLANET_LIST.map(p => `
    <label class="transit-input-item">
      ${p}
      <select id="transit-${p}">
        <option value="">—</option>
        ${SIGN_OPTIONS.map(([code, name]) => `<option value="${code}">${name}</option>`).join('')}
      </select>
    </label>
  `).join('');

  const dateInput = document.getElementById('transit-date');
  if (!dateInput.value) dateInput.value = new Date().toISOString().split('T')[0];

  const autoDateInput = document.getElementById('transit-auto-date');
  if (!autoDateInput.value) autoDateInput.value = new Date().toISOString().split('T')[0];
}

document.getElementById('transit-auto-btn').addEventListener('click', async () => {
  if (!currentChartKey) {
    alert('Parse a chart first.');
    return;
  }
  const date = document.getElementById('transit-auto-date').value;
  const time = document.getElementById('transit-auto-time').value || '12:00';
  if (!date) {
    alert('Pick a date.');
    return;
  }

  const contentEl = document.getElementById('transit-content');
  contentEl.innerHTML = '<p class="muted">Computing...</p>';

  try {
    const res = await fetch('/api/transit/auto', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chartKey: currentChartKey, date, time })
    });
    const data = await res.json();
    if (!res.ok) {
      contentEl.innerHTML = `<p class="muted">${escapeHtml(data.error || 'Could not compute transit.')}</p>`;
      return;
    }
    renderTransitResult(data, true);
  } catch (err) {
    contentEl.innerHTML = '<p class="muted">Network error: ' + escapeHtml(err.message) + '</p>';
  }
});

document.getElementById('transit-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!currentChartKey) {
    alert('Parse a chart first.');
    return;
  }

  const positions = {};
  for (const p of TRANSIT_PLANET_LIST) {
    const val = document.getElementById('transit-' + p).value;
    if (val) positions[p] = val;
  }
  const asOfDate = document.getElementById('transit-date').value;

  if (Object.keys(positions).length === 0) {
    alert('Select at least one planet\'s transit sign.');
    return;
  }

  const contentEl = document.getElementById('transit-content');
  contentEl.innerHTML = '<p class="muted">Analyzing...</p>';

  try {
    const res = await fetch('/api/transit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chartKey: currentChartKey, positions, asOfDate })
    });
    const data = await res.json();
    if (!res.ok) {
      contentEl.innerHTML = `<p class="muted">${escapeHtml(data.error || 'Could not analyze transit.')}</p>`;
      return;
    }
    renderTransitResult(data);
  } catch (err) {
    contentEl.innerHTML = '<p class="muted">Network error: ' + escapeHtml(err.message) + '</p>';
  }
});

function renderTransitResult(d, isAuto) {
  const el = document.getElementById('transit-content');
  if (!d || d._warning) {
    el.innerHTML = `<p class="muted">${escapeHtml(d?._warning || 'No transit data available.')}</p>`;
    return;
  }
  // Transit analyzer returns 'planets', not 'results'
  const results = d.results || d.planets;
  if (!results || typeof results !== 'object') {
    el.innerHTML = '<p class="muted">Transit results not available — please try again.</p>';
    return;
  }
  d.results = results; // normalize

  let html = `<p class="muted">As of ${escapeHtml(d.asOfDate || '—')} · Natal Moon: ${escapeHtml(d.natalMoonSign)}${d.nativeAge !== null && d.nativeAge !== undefined ? ` · Native age: ~${d.nativeAge}` : ''}${isAuto ? ` · <span class="conf-badge conf-direct">auto-computed</span> ayanamsa ${d.ayanamsaUsed}°` : ''}</p>`;
  html += `<table class="equal-table compact-table">
    <thead><tr><th class="row-label">Planet</th><th>Transit Sign</th>${isAuto ? '<th>Degree</th>' : ''}<th>House from Moon</th><th>Classical</th><th>Chart-Adjusted</th></tr></thead>
    <tbody>
      ${Object.entries(d.results).map(([planet, r]) => `
        <tr>
          <td class="row-label">${planet}</td>
          <td>${escapeHtml(r.transitSign)}</td>
          ${isAuto ? `<td>${d.computedPositions?.[planet]?.degreeInSign?.toFixed(2) ?? '—'}°</td>` : ''}
          <td>${r.houseFromMoon}</td>
          <td><span class="conf-badge ${r.snapshot === 'Good' ? 'conf-direct' : 'conf-interpretive'}" title="${escapeHtml(r.result || '')}">${escapeHtml(r.snapshot || '—')}</span></td>
          <td>${r.chartAdjusted ? `<details class="transit-adjust-details"><summary>${escapeHtml(r.chartAdjusted.label)} (${r.chartAdjusted.combinedScore >= 0 ? '+' : ''}${r.chartAdjusted.combinedScore})</summary>
            <table class="equal-table compact-table" style="margin-top:6px;">
              <tbody>
                ${r.chartAdjusted.breakdown.map(b => `<tr><td class="row-label">${escapeHtml(b.label)}</td><td>${b.value>=0?'+':''}${b.value}</td><td style="text-align:left; font-size:0.74rem;">${escapeHtml(b.reason)}</td></tr>`).join('')}
              </tbody>
            </table>
          </details>` : '—'}</td>
        </tr>
        ${r.eventConnections && r.eventConnections.length ? `
        <tr class="event-connection-row">
          <td></td>
          <td colspan="${isAuto ? 5 : 4}">
            <div class="event-connections-block">
              <span class="muted" style="font-size:0.74rem;">Touches:</span>
              ${r.eventConnections.slice(0, 6).map(c => `
                <span class="event-connection-pill" title="${escapeHtml(c.reasons.join('; '))}">${escapeHtml(c.label)}</span>
              `).join('')}
              ${r.eventConnections.length > 6 ? `<span class="muted" style="font-size:0.72rem;">+${r.eventConnections.length - 6} more</span>` : ''}
              ${r.eventConnections.filter(c => c.ageContextNote).map(c => `
                <div class="age-context-note">⏳ <strong>${escapeHtml(c.label)}:</strong> ${escapeHtml(c.ageContextNote)}</div>
              `).join('')}
            </div>
          </td>
        </tr>` : ''}
      `).join('')}
    </tbody>
  </table>`;
  html += `<p class="muted" style="font-size:0.78rem; margin-top:4px;">Classical column = generic table result. <strong>Chart-Adjusted</strong> = same transit, re-read through THIS chart's functional nature + transit dignity + Ashtakavarga (BAV/SAV) — click to see the breakdown. <strong>Touches</strong> = which life-domains (from the Predictive Engine) this transit connects to, by occupancy/aspect/karakatva — hover a pill for the reason. Age-context notes (⏳) are gentle, not assertions about your actual life-stage.</p>`;

  if (d.warnings && d.warnings.length) {
    html += `<p class="muted" style="font-size:0.78rem; margin-top:6px;">${d.warnings.map(escapeHtml).join('<br>')}</p>`;
  }
  if (isAuto) {
    html += `<p class="muted convergence-note" style="margin-top:10px;">${escapeHtml(d.computationMethodology)}</p>`;
  }
  html += `<p class="muted convergence-note" style="margin-top:6px;">${escapeHtml(d.caveat)}</p>`;
  el.innerHTML = html;
}

/**
 * Render full transit analysis — sukshma dasha + house activation + karaka impact
 * Triggered from /api/transit/full
 */
/**
 * Add a past event and immediately verify it against the chart.
 * Called from the events card form.
 */
/**
 * Check if transit on a given date supports a specific event type.
 * Shows per-planet support/obstruction for the event.
 */
async function checkTransitForEvent() {
  const dateEl   = document.getElementById('transit-check-date');
  const eventEl  = document.getElementById('transit-check-event');
  const resultEl = document.getElementById('transit-event-result');

  const date     = dateEl?.value;
  const eventKey = eventEl?.value;
  if (!date || !eventKey) {
    resultEl.innerHTML = '<p class="muted">Please select a date and event type.</p>';
    return;
  }

  resultEl.innerHTML = '<p class="muted">Computing transit support…</p>';

  try {
    const res = await fetch('/api/transit/event-check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chartKey: currentChartKey, date, eventKey })
    });
    const d = await res.json();
    if (d.error) throw new Error(d.error);

    resultEl.innerHTML = renderTransitEventCheck(d);
  } catch(e) {
    resultEl.innerHTML = `<p class="muted" style="color:#c0392b;">Error: ${escapeHtml(e.message)}</p>`;
  }
}

function renderTransitEventCheck(d) {
  if (!d) return '';
  const scoreColor = d.overallSupport >= 65 ? '#166534' : d.overallSupport >= 40 ? '#7c4b00' : '#991b1b';

  let html = `
  <div style="border:1px solid #e0d8cc; border-radius:6px; padding:10px 12px; background:#faf8f4;">
    <div style="font-size:0.82rem; margin-bottom:6px;">
      <strong>Transit support for ${escapeHtml(d.eventLabel)}</strong> on ${escapeHtml(d.date)}
      &nbsp;|&nbsp; Overall: <strong style="color:${scoreColor}">${d.overallSupport}/100</strong>
      &nbsp;|&nbsp; ${escapeHtml(d.verdict)}
    </div>
    <table class="equal-table compact-table">
      <thead><tr>
        <th>Planet</th><th>Transit Sign</th><th>H (Moon)</th>
        <th>Event Rel.</th><th>Good?</th><th>Vedha?</th><th>Moorti</th><th>Tara</th>
      </tr></thead>
      <tbody>`;

  d.planets.forEach(p => {
    const goodColor   = p.isGoodFromMoon ? '#166534' : '#991b1b';
    const eventColor  = p.eventRelevance === 'primary' ? '#0f6292' : p.eventRelevance === 'secondary' ? '#7c4b00' : '';
    html += `<tr>
      <td><strong>${escapeHtml(p.planet)}</strong></td>
      <td>${escapeHtml(p.sign)}</td>
      <td>H${p.houseFromMoon}</td>
      <td style="color:${eventColor}; font-size:0.74rem;">${escapeHtml(p.eventRelevance||'—')}</td>
      <td style="color:${goodColor}; font-weight:600;">${p.isGoodFromMoon ? '✓' : '✗'}</td>
      <td>${p.vedhaObstructed ? `<span style="color:#991b1b;">⊗${escapeHtml(p.vedhaObstructor||'')}</span>` : '<span style="color:#166534;">Clear</span>'}</td>
      <td style="font-size:0.74rem;">${escapeHtml(p.moorti||'—')}</td>
      <td style="font-size:0.74rem;" title="${escapeHtml(p.taraName||'')}">${escapeHtml(p.taraName||'—')}</td>
    </tr>`;
  });

  html += `</tbody></table>
    <p class="muted" style="font-size:0.74rem; margin-top:6px;">
      Source: PVR textbook Table 63 (good/bad houses from Moon), Table 58 (Venus), p.319 (Rahu=Saturn, Ketu=Mars).
      Green = transit in good house from Moon, no Vedha. Red = bad house or obstructed.
      Event Rel. = how relevant this planet is for the selected event type.
    </p>
  </div>`;

  return html;
}

async function addAndVerifyEvent() {
  const dateEl = document.getElementById('post-event-date');
  const catEl  = document.getElementById('post-event-category');
  const descEl = document.getElementById('post-event-desc');
  const contEl = document.getElementById('events-content');

  const date     = dateEl?.value;
  const eventKey = catEl?.value;
  const desc     = descEl?.value || eventKey;

  if (!date || !eventKey) {
    alert('Please select a date and event type.');
    return;
  }

  // Get stored chart key from last compute
  const chartKey = window._lastChartKey || currentChartKey;
  if (!chartKey) {
    contEl.innerHTML = '<p class="muted">Please compute a horoscope first.</p>';
    return;
  }

  contEl.innerHTML = '<p class="muted">Verifying event against chart…</p>';

  try {
    const res = await fetch('/api/verify-event', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chartKey, eventKey, eventDate: date, eventLabel: desc,
        gender: document.getElementById('bd-gender')?.value || 'female' })
    });
    const r = await res.json();
    if (r.error) throw new Error(r.error);

    // Append to existing events
    const existing = contEl.innerHTML === '<p class="muted">Verifying event against chart…</p>' ? '' : contEl.innerHTML;
    contEl.innerHTML = existing + renderEventVerificationCard(r);

    // Clear inputs
    dateEl.value = '';
    catEl.value  = '';
    descEl.value = '';
  } catch(e) {
    contEl.innerHTML = `<p class="muted" style="color:#c0392b;">Error: ${escapeHtml(e.message)}</p>`;
  }
}

function renderEventVerificationCard(r) {
  if (!r || r.error) return `<p class="muted" style="color:#c0392b;">${escapeHtml(r?.error||'Unknown error')}</p>`;

  const scoreColor = r.finalScore >= 65 ? '#166534' : r.finalScore >= 45 ? '#7c4b00' : '#991b1b';
  const tierBadge  = r.tier === 'strong' ? 'conf-direct' : r.tier === 'moderate' ? 'conf-synthesized' : 'conf-interpretive';

  return `<div class="event-verify-card">
    <div class="ev-header">
      <span class="ev-label">${escapeHtml(r.eventLabel||r.eventKey)}</span>
      <span class="ev-date">${escapeHtml(r.eventDate)} · Age ${r.age}</span>
      <span class="conf-badge ${tierBadge}" style="margin-left:auto;">${r.finalScore}/100 ${r.tier?.toUpperCase()}</span>
    </div>
    <div class="ev-dasha-row">
      <strong>Vimshottari:</strong> ${escapeHtml(r.vimshottari?.display||'—')}
      ${r.vargaNarayana ? ` &nbsp;|&nbsp; <strong>${escapeHtml(r.vargaNarayana.system)}:</strong> ${escapeHtml(r.vargaNarayana.display)}` : ''}
    </div>
    <div class="ev-karaka-row">
      Natural karaka (${escapeHtml(r.karakaActive?.naturalKaraka||'—')}):
      <span style="color:${r.karakaActive?.isNaturalKarakaInMDAD?'#166534':'#7c4b00'}">
        ${r.karakaActive?.isNaturalKarakaInMDAD ? '✓ Active in MD/AD' : 'Not in MD/AD'}
      </span>
      &nbsp;|&nbsp;
      ${escapeHtml(r.karakaActive?.charaKaraka||'?')} (${escapeHtml(r.karakaActive?.charaKarakaPlanet||'?')}):
      <span style="color:${r.karakaActive?.isCharaKarakaActive?'#166534':'#7c4b00'}">
        ${r.karakaActive?.isCharaKarakaActive ? '✓ Active' : 'Not active'}
      </span>
    </div>
    <div class="ev-scores">
      <span title="Dasha: karaka + house lord + Narayana D1">L1 (Dasha): <strong style="color:${r.l1Score>=50?'#166534':r.l1Score>=30?'#7c4b00':'#991b1b'}">${r.l1Score}</strong></span>
      <span title="D-chart Narayana: event-specific divisional chart">L2 (D-chart): <strong style="color:${r.l2Score>=50?'#166534':r.l2Score>=30?'#7c4b00':'#991b1b'}">${r.l2Score}</strong></span>
      <span title="Transit: Vedha, Moorti, Tara, BAV/SAV">L3 (Transit): <strong style="color:${r.l3Score>=50?'#166534':r.l3Score>=30?'#7c4b00':'#991b1b'}">${r.l3Score}</strong></span>
    </div>
    ${r.reasons?.length ? `<div class="ev-reasons">${r.reasons.slice(0,5).map(x=>`<div class="ev-reason">✅ ${escapeHtml(x)}</div>`).join('')}</div>` : ''}
    ${r.concerns?.length ? `<div class="ev-concerns">${r.concerns.slice(0,3).map(x=>`<div class="ev-concern">⚠️ ${escapeHtml(x)}</div>`).join('')}</div>` : ''}
    ${r.btrSignal ? `<div class="ev-btr">🔧 ${escapeHtml(r.btrSignal)}</div>` : ''}
  </div>`;
}


// ── Rasi Chakra (North Indian Diamond style) ────────────────────────────────

const SIGN_ABBR = {
  Ar:'Ar',Ta:'Ta',Ge:'Ge',Cn:'Cn',Le:'Le',Vi:'Vi',
  Li:'Li',Sc:'Sc',Sg:'Sg',Cp:'Cp',Aq:'Aq',Pi:'Pi'
};
const SIGN_FULL = {
  Ar:'Aries',Ta:'Taurus',Ge:'Gemini',Cn:'Cancer',Le:'Leo',Vi:'Virgo',
  Li:'Libra',Sc:'Scorpio',Sg:'Sagittarius',Cp:'Capricorn',Aq:'Aquarius',Pi:'Pisces'
};
var SIGN_CODES_12 = ['Ar','Ta','Ge','Cn','Le','Vi','Li','Sc','Sg','Cp','Aq','Pi'];

/**
 * North Indian style Rasi Chakra
 * Fixed sign positions (not rotating with lagna):
 * Ar=top-mid, Ta=top-right, Ge=right-upper, ...
 *
 * Layout (12 triangular cells in a square):
 *   Pi  Ar  Ta
 *   Aq  [C] Ge
 *   Cp  Sg  Sc  ← bottom row
 *       Le  Li  ← with Cn on left
 *
 * Standard North Indian fixed layout:
 *   Pi | Ar | Ta
 *   Aq |    | Ge
 *   Cp | Sg | Sc
 *       Le  Li  Cn
 */
function renderRasiChakra(data) {
  const card = document.getElementById('rasi-chakra-card');
  if (!card) return;
  card.style.display = '';

  const lagna = data.lagna?.signCode;
  const bodies = data.bodies || data.planets || {};
  const SIGNS = SIGN_CODES_12;

  // Build planet list per sign
  const inSign = {};
  SIGNS.forEach(s => inSign[s] = []);

  // Mark lagna sign
  if (lagna) inSign[lagna].push('As');

  // Place planets
  Object.entries(bodies).forEach(([planet, body]) => {
    const sc = body?.signCode;
    if (sc && inSign[sc] !== undefined) {
      const abbr = PLANET_SHORT[planet] || planet.slice(0,2);
      const retro = body?.retrograde ? '(R)' : '';
      inSign[sc].push(abbr + retro);
    }
  });

  // SVG size
  const SZ = 300; // total square
  const C  = SZ / 2; // center
  const Q  = SZ / 4; // quarter

  // North Indian fixed cell centers & clip paths
  // 12 cells arranged as diamond-in-square
  // Each cell is a triangle or irregular polygon
  // Cell order by sign number (0=Ar at top):
  // Ar=top, Ta=top-right, Ge=right-top, Cn=right-bot,
  // Le=bot-right, Vi=bot, Li=bot-left, Sc=left-bot,
  // Sg=left-top, Cp=top-left, Aq=mid-left, Pi=mid-top

  // 12 cells: define as polygons (North Indian square style)
  const cells = [
    // Sign, polygon points (x,y pairs), text center x, text center y
    { sign:'Ar', pts:[[C,0],[SZ,0],[C,C]],             tx:C+Q/2, ty:Q/2 },      // top-center triangle → actually top
    { sign:'Ta', pts:[[SZ,0],[SZ,C],[C,C]],             tx:SZ-Q/2, ty:Q/2 },    // top-right
    { sign:'Ge', pts:[[SZ,C],[SZ,SZ],[C,C]],            tx:SZ-Q/2, ty:C+Q/2 },  // right-bottom
    { sign:'Cn', pts:[[SZ,SZ],[C,SZ],[C,C]],            tx:C+Q/2, ty:SZ-Q/2 },  // bottom-right
    { sign:'Le', pts:[[C,SZ],[0,SZ],[C,C]],             tx:Q/2, ty:SZ-Q/2 },    // bottom-left
    { sign:'Vi', pts:[[0,SZ],[0,C],[C,C]],              tx:Q/2, ty:C+Q/2 },     // left-bottom
    { sign:'Li', pts:[[0,C],[0,0],[C,C]],               tx:Q/2, ty:Q/2 },       // left-top
    { sign:'Sc', pts:[[0,0],[C,0],[C,C]],               tx:C-Q/2, ty:Q/2 },     // top-left
    // Center is split into 4 squares
    { sign:'Sg', pts:[[C,C],[C,SZ/2+Q/4],[C-Q/2,SZ/2],[C-Q/4,C-Q/4]], tx:C-Q/2+4, ty:C+8, _center:true },
    { sign:'Cp', pts:[[C,C],[C-Q/2,SZ/2],[C,SZ/2-Q/4],[C+Q/4,C-Q/4]], tx:C-12, ty:C-8, _center:true },
    { sign:'Aq', pts:[[C,C],[C+Q/4,C-Q/4],[C,SZ/2-Q/4],[C+Q/2,SZ/2]], tx:C+Q/2-4, ty:C-8, _center:true },
    { sign:'Pi', pts:[[C,C],[C+Q/2,SZ/2],[C+Q/4,C+Q/4],[C,SZ/2+Q/4]], tx:C+12, ty:C+8, _center:true },
  ];

  // Simpler center: 4 diamonds = 4 smaller triangles meeting at center
  // Let's use a cleaner layout:
  // Outer 8 triangles (8 signs) + center square split into 4 (4 signs)
  const centerCells = [
    { sign:'Sg', pts:[[C,C],[C,C+Q],[C-Q,C]],   tx:C-Q/2, ty:C+Q/2 },
    { sign:'Cp', pts:[[C,C],[C-Q,C],[C,C-Q]],   tx:C-Q/2, ty:C-Q/2 },
    { sign:'Aq', pts:[[C,C],[C,C-Q],[C+Q,C]],   tx:C+Q/2, ty:C-Q/2 },
    { sign:'Pi', pts:[[C,C],[C+Q,C],[C,C+Q]],   tx:C+Q/2, ty:C+Q/2 },
  ];

  const outerCells = cells.slice(0, 8);
  const allCells   = [...outerCells, ...centerCells];

  // Colors
  const BG_OUTER  = '#fdf6e3';
  const BG_CENTER = '#f5ede0';
  const BG_LAGNA  = '#fff8e7';
  const STROKE    = '#b89060';
  const LAGNA_STK = '#8a5a1a';
  const TEXT_SIGN = '#9a7040';
  const TEXT_PL   = '#1a1a2e';
  const TEXT_AS   = '#c0392b';

  function pts2str(pts) {
    return pts.map(([x,y]) => x.toFixed(1)+','+y.toFixed(1)).join(' ');
  }

  function cellSVG(cell) {
    const isLagna = cell.sign === lagna;
    const bg = isLagna ? BG_LAGNA : (cell === centerCells[0]||centerCells.includes(cell)) ? BG_CENTER : BG_OUTER;
    const stk = isLagna ? LAGNA_STK : STROKE;
    const sw  = isLagna ? '2.5' : '1.5';

    const planets = inSign[cell.sign] || [];
    const lines = [];

    // Sign abbreviation
    lines.push(`<text x="${cell.tx.toFixed(1)}" y="${(cell.ty-10).toFixed(1)}" 
      text-anchor="middle" font-size="9" fill="${TEXT_SIGN}" font-family="serif" font-style="italic">
      ${SIGN_ABBR[cell.sign]}
    </text>`);

    // Planets (max 4 per cell, 2 columns if needed)
    planets.forEach((pl, i) => {
      const isAs = pl === 'As';
      const col  = i % 2;
      const row  = Math.floor(i / 2);
      const px   = cell.tx + (col === 0 ? -10 : 10);
      const py   = cell.ty + 4 + row * 13;
      lines.push(`<text x="${px.toFixed(1)}" y="${py.toFixed(1)}"
        text-anchor="middle" font-size="${isAs?10:9}" font-weight="${isAs?'bold':'normal'}"
        fill="${isAs ? TEXT_AS : TEXT_PL}" font-family="sans-serif">
        ${escapeHtml(pl)}
      </text>`);
    });

    return `
      <polygon points="${pts2str(cell.pts)}" 
        fill="${bg}" stroke="${stk}" stroke-width="${sw}"/>
      ${lines.join('')}
    `;
  }

  const svgContent = `
    <svg width="${SZ}" height="${SZ}" xmlns="http://www.w3.org/2000/svg"
      style="border:2px solid ${STROKE};border-radius:4px;background:#fdf6e3;">
      <!-- Background -->
      <rect width="${SZ}" height="${SZ}" fill="#fdf6e3"/>
      <!-- Cells -->
      ${allCells.map(cellSVG).join('')}
      <!-- Outer border -->
      <rect x="1" y="1" width="${SZ-2}" height="${SZ-2}" fill="none" stroke="${STROKE}" stroke-width="2"/>
    </svg>
  `;

  document.getElementById('rasi-chakra-svg').innerHTML = svgContent;

  // Legend
  const lagnaSign = SIGN_FULL[lagna] || lagna;
  let legend = `<div style="margin-bottom:8px;font-weight:700;color:#3d2e1a;">
    Lagna: <span style="color:#c0392b;">${lagnaSign}</span>
  </div>`;
  legend += '<table style="font-size:0.8rem;border-collapse:collapse;width:100%;">';
  legend += '<tr style="color:#9a7040;font-weight:600;"><th style="padding:2px 6px;text-align:left;">H</th><th style="padding:2px 6px;text-align:left;">Sign</th><th style="padding:2px 6px;text-align:left;">Planets</th></tr>';

  const lagnaIdx = SIGNS.indexOf(lagna);
  for (let h = 1; h <= 12; h++) {
    const sc = SIGNS[(lagnaIdx + h - 1) % 12];
    const pls = inSign[sc].filter(p => p !== 'As');
    if (pls.length === 0) continue;
    legend += `<tr style="border-top:1px solid #e8dcc8;">
      <td style="padding:2px 6px;color:#9a7040;">H${h}</td>
      <td style="padding:2px 6px;">${SIGN_FULL[sc]||sc}</td>
      <td style="padding:2px 6px;font-weight:600;">${pls.join(', ')}</td>
    </tr>`;
  }
  legend += '</table>';
  document.getElementById('rasi-chakra-legend').innerHTML = legend;
}



async function loadTajakaChart() {
  const yearEl = document.getElementById('tajaka-year');
  const el     = document.getElementById('tajaka-content');
  const year   = parseInt(yearEl?.value || new Date().getFullYear());

  if (!currentChartKey) {
    el.innerHTML = '<p class="muted">Pehle horoscope compute karo.</p>';
    return;
  }
  el.innerHTML = `<p class="muted">Tajaka ${year} compute ho raha hai... (solar return dhundh raha hoon)</p>`;

  try {
    const res = await fetch('/api/tajaka', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chartKey: currentChartKey, year })
    });
    const d = await res.json();
    if (d.error) throw new Error(d.error);
    el.innerHTML = renderTajakaChart(d);
  } catch(e) {
    el.innerHTML = `<p class="muted" style="color:#c0392b;">Error: ${escapeHtml(e.message)}</p>`;
  }
}

function renderTajakaChart(t) {
  if (!t) return '<p class="muted">Data nahi mila.</p>';

  const SIGN_NAMES = {
    Ar:'Aries',Ta:'Taurus',Ge:'Gemini',Cn:'Cancer',Le:'Leo',Vi:'Virgo',
    Li:'Libra',Sc:'Scorpio',Sg:'Sagittarius',Cp:'Capricorn',Aq:'Aquarius',Pi:'Pisces'
  };

  const lagna    = t.lagna?.signCode || '—';
  const lagnaFull = SIGN_NAMES[lagna] || lagna;
  const srDate   = t.solarReturn ? t.solarReturn.split('T')[0] : '—';
  const srTime   = t.solarReturn ? t.solarReturn.split('T')[1]?.slice(0,5) : '—';

  let html = `
  <div style="background:#f0ede8;border-radius:6px;padding:10px 14px;margin-bottom:12px;">
    <div style="font-size:0.88rem;font-weight:700;color:#3d2e1a;margin-bottom:4px;">
      Tajaka ${t.year} — Age ${t.age}
    </div>
    <div style="font-size:0.82rem;color:#5c4a35;">
      Solar Return: <strong>${srDate}</strong> at <strong>${srTime}</strong> (birthplace time)
      &nbsp;|&nbsp; Annual Lagna: <strong>${lagnaFull}</strong> ${(t.lagna?.degreeInSign||0).toFixed(1)}°
    </div>
    <div style="font-size:0.8rem;color:#7c4b00;margin-top:4px;">
      ${escapeHtml(t.muntha?.description || '—')}
      &nbsp;|&nbsp; ${escapeHtml(t.scDasa?.description || '—')}
    </div>
  </div>

  <div class="transit-section-label">Annual Chart Planets</div>
  <table class="equal-table compact-table">
    <thead><tr><th>Planet</th><th>Sign</th><th>H (Annual)</th><th>Retro</th></tr></thead>
    <tbody>
    ${['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn','Rahu','Ketu']
      .filter(p => t.bodies?.[p])
      .map(p => {
        const b = t.bodies[p];
        return `<tr>
          <td><strong>${p}</strong></td>
          <td>${escapeHtml(b.signCode)}</td>
          <td>H${b.house}</td>
          <td>${b.retrograde ? '<span style="color:#991b1b;">R</span>' : '—'}</td>
        </tr>`;
      }).join('')}
    </tbody>
  </table>

  <div class="transit-section-label" style="margin-top:12px;">Year Themes</div>
  <div>
  ${(t.yearThemes||[]).map(th => {
    const color = th.quality==='favorable'?'#166534':th.quality==='challenging'||th.quality==='unfavorable'?'#991b1b':th.quality==='unexpected'?'#7c4b00':'#5c4a35';
    const icon  = th.quality==='favorable'?'✅':th.quality==='challenging'||th.quality==='unfavorable'?'⚠️':th.quality==='unexpected'?'🔄':'📌';
    return `<div style="font-size:0.8rem;margin-bottom:4px;color:${color};">${icon} ${escapeHtml(th.reason)}</div>`;
  }).join('')}
  </div>

  <p class="muted" style="font-size:0.74rem;margin-top:10px;">
    Source: PVR Ch.27.1 (Solar return = natal Sun longitude), Ch.31.2 (SC from Lagna/Moon/Sun),
    Ch.31.3 (SC Dasa = year% 12), Audio lessons p.40 (Muntha, benefic/malefic rules).
    Birthplace coordinates used always (p.368).
  </p>`;

  return html;
}



async function loadPortrait() {
  const el = document.getElementById('portrait-content');
  if (!currentChartKey) {
    el.innerHTML = '<p class="muted">Pehle horoscope compute karo.</p>';
    return;
  }
  el.innerHTML = '<p class="muted">Portrait generate ho raha hai...</p>';
  try {
    const res = await fetch('/api/portrait', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chartKey: currentChartKey })
    });
    const d = await res.json();
    if (d.error) throw new Error(d.error);
    renderPortrait(d);
  } catch(e) {
    el.innerHTML = `<p class="muted" style="color:#c0392b;">Error: ${escapeHtml(e.message)}</p>`;
  }
}

function renderPortrait(d) {
  const el = document.getElementById('portrait-content');
  if (!d || !d.sections) {
    el.innerHTML = '<p class="muted">Portrait data nahi mila.</p>';
    return;
  }

  // Simple markdown-like rendering
  function renderText(text) {
    return text
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.+?)\*/g, '<em>$1</em>')
      .replace(/\n\n/g, '</p><p>')
      .replace(/\n•/g, '<br>•')
      .replace(/\n/g, '<br>');
  }

  let html = '';

  d.sections.forEach(section => {
    html += `
    <div class="portrait-section">
      <h3 class="portrait-section-title">${escapeHtml(section.title)}</h3>
      <div class="portrait-section-body">
        <p>${renderText(section.content)}</p>
      </div>
    </div>`;
  });

  // Evidence summary
  if (d.evidence) {
    const ev = d.evidence;
    html += `
    <details class="portrait-evidence" style="margin-top:16px;">
      <summary style="cursor:pointer;font-size:0.8rem;color:#8a7a6a;font-weight:600;">
        Chart Evidence (technical details)
      </summary>
      <div style="margin-top:8px;font-size:0.78rem;color:#5c4a35;line-height:1.6;">
        <strong>Lagna:</strong> ${escapeHtml(ev.lagna||'—')} | 
        <strong>Lagna Lord:</strong> ${escapeHtml(ev.lagnaLord||'—')} in H${ev.lagnaLordHouse||'?'} (${escapeHtml(ev.lagnaLordDig||'—')})<br>
        <strong>Moon:</strong> ${escapeHtml(ev.moonSign||'—')} H${ev.moonHouse||'?'} | 
        <strong>Sun:</strong> ${escapeHtml(ev.sunSign||'—')} H${ev.sunHouse||'?'}<br>
        <strong>AK:</strong> ${escapeHtml(ev.ak||'—')} in ${escapeHtml(ev.akSign||'—')} | 
        <strong>AMK:</strong> ${escapeHtml(ev.amk||'—')} in ${escapeHtml(ev.amkSign||'—')}<br>
        <strong>Raja Yogas:</strong> ${ev.rajaYogaCount||0} | 
        <strong>Dhana Yogas:</strong> ${ev.dhanaYogaCount||0}<br>
        ${ev.crowdedHouses?.length ? '<strong>Concentrated houses:</strong> '+ev.crowdedHouses.join(', ') : ''}
      </div>
    </details>`;
  }

  el.innerHTML = html;
}



let _btrQuestions = [];

async function loadBTRQuestions() {
  const area = document.getElementById('btr-questions-area');
  if (!currentChartKey) { area.innerHTML = '<p class="muted">Compute a horoscope first.</p>'; return; }
  area.innerHTML = '<p class="muted">Generating chart-specific questions…</p>';
  try {
    const res = await fetch('/api/btr/questions', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ chartKey: currentChartKey, maxQ: 12 })
    });
    const d = await res.json();
    if (d.error) throw new Error(d.error);
    _btrQuestions = d.questions;
    renderBTRQuestions(d.questions);
  } catch(e) {
    area.innerHTML = `<p class="muted" style="color:#c0392b;">Error: ${escapeHtml(e.message)}</p>`;
  }
}

function renderBTRQuestions(questions) {
  const area = document.getElementById('btr-questions-area');
  let html = `<p style="font-size:0.82rem;color:#5c4a35;margin-bottom:12px;">
    Answer each question with <strong>Yes</strong> or <strong>No</strong> based on your actual experience.
  </p><div id="btr-questions-list">`;

  questions.forEach((q,i) => {
    const typeIcon = q.type === 'personality' ? '🧠' :
                     q.type === 'period_quality' ? '📅' : '📌';

    // Format date range for user — readable, no jargon
    let dateDisplay = '';
    if (q.type === 'personality') {
      dateDisplay = 'About yourself (always)';
    } else if (q.startDate && q.endDate) {
      const s = q.startDate.slice(0,7).replace('-','/');
      const e = q.endDate.slice(0,7).replace('-','/');
      dateDisplay = `${s} — ${e}`;
    } else {
      dateDisplay = q.ageLabel || '';
    }

    html += `
    <div class="btr-question" id="btr-q-${i}" data-id="${escapeHtml(q.id)}">
      <div class="btr-q-header">
        <span class="btr-type-badge">${typeIcon} ${q.type==='personality'?'Personality':q.type==='period_quality'?'Life Period':'Life Event'}</span>
        <span class="btr-date-range">${escapeHtml(dateDisplay)}</span>
      </div>
      <div class="btr-q-text">${escapeHtml(q.question)}</div>
      <div class="btr-q-buttons">
        <button type="button" class="btr-btn btr-yes" onclick="answerBTR(${i},true)">✓ Yes</button>
        <button type="button" class="btr-btn btr-no"  onclick="answerBTR(${i},false)">✗ No</button>
      </div>
    </div>`;
  });

  html += `</div>
  <div style="margin-top:16px;padding-top:12px;border-top:1px solid #e0d8cc;">
    <button type="button" onclick="submitBTRAnswers()"
      style="font-size:0.9rem;padding:10px 28px;background:#8a6a3a;color:#fff;border:none;border-radius:6px;cursor:pointer;font-weight:600;">
      Calculate Birth Time Score →
    </button>
  </div>`;

  area.innerHTML = html;
}

function answerBTR(idx, answer) {
  if (!_btrQuestions[idx]) return;
  _btrQuestions[idx].answer = answer;
  const qEl = document.getElementById('btr-q-' + idx);
  if (!qEl) return;
  qEl.querySelectorAll('.btr-btn').forEach(b => b.classList.remove('selected'));
  if (answer === true)  qEl.querySelector('.btr-yes')?.classList.add('selected');
  if (answer === false) qEl.querySelector('.btr-no')?.classList.add('selected');
  qEl.classList.add('answered');
}

async function submitBTRAnswers() {
  const unanswered = _btrQuestions.filter(q => q.answer === null || q.answer === undefined);
  if (unanswered.length > 0) {
    alert(`Please answer all ${_btrQuestions.length} questions before submitting.\n${unanswered.length} still unanswered.`);
    // Highlight unanswered
    unanswered.forEach(q => {
      const idx = _btrQuestions.indexOf(q);
      document.getElementById('btr-q-'+idx)?.scrollIntoView({behavior:'smooth',block:'center'});
    });
    return;
  }
  const scoreArea = document.getElementById('btr-score-area');
  scoreArea.style.display = '';
  scoreArea.innerHTML = '<p class="muted">Scoring…</p>';
  try {
    const res = await fetch('/api/btr/score', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ chartKey: currentChartKey,
        answers: _btrQuestions.map(q => ({ id: q.id, answer: q.answer ?? null })) })
    });
    const d = await res.json();
    if (d.error) throw new Error(d.error);
    scoreArea.innerHTML = renderBTRScore(d);
  } catch(e) {
    scoreArea.innerHTML = `<p class="muted" style="color:#c0392b;">Error: ${escapeHtml(e.message)}</p>`;
  }
}

function renderBTRScore(d) {
  const sc = d.score >= 70 ? '#166534' : d.score >= 50 ? '#7c4b00' : '#991b1b';
  let html = `<div style="border:2px solid ${sc};border-radius:8px;padding:14px;margin-top:10px;">
    <div style="font-size:1.4rem;font-weight:700;color:${sc}">${d.score}/100
      <span style="font-size:0.9rem;font-weight:400"> — ${escapeHtml(d.reliability?.replace('_',' ').toUpperCase()||'')}</span>
    </div>
    <p style="margin:6px 0;font-size:0.88rem;">${escapeHtml(d.message)}</p>
    <p class="muted" style="font-size:0.8rem;">${escapeHtml(d.recommendation)}</p>
    <p class="muted" style="font-size:0.78rem;">${d.answeredCount} answered · ${d.yesCount} Yes · ${d.noCount} No · ${d.earnedPoints}/${d.totalPoints} pts</p>
  </div>
  <table class="equal-table compact-table" style="margin-top:10px;">
    <thead><tr><th>Period</th><th>Domain</th><th>You</th><th>Chart</th><th>Points</th></tr></thead>
    <tbody>
    ${(d.results||[]).map(r => {
      const mc = r.points>=8?'#166534':r.points>=5?'#7c4b00':'#991b1b';
      return `<tr>
        <td style="font-size:0.74rem;">${escapeHtml(r.period)}<div class="muted">${escapeHtml(r.ageLabel)}</div></td>
        <td style="font-size:0.74rem;">${escapeHtml(r.domain)}</td>
        <td>${r.userAnswer===true?'<span style="color:#166534">Yes</span>':r.userAnswer===false?'<span style="color:#991b1b">No</span>':'—'}</td>
        <td style="font-size:0.74rem;">${r.chartPredicts?'Expected':'Not expected'}</td>
        <td style="font-weight:700;color:${mc}">${r.points}/${r.maxPoints}</td>
      </tr>`;
    }).join('')}
    </tbody>
  </table>`;
  return html;
}

function renderFullTransit(d) {
  const el = document.getElementById('transit-content');
  if (!d || d.error) {
    el.innerHTML = `<p class="muted">${escapeHtml(d?.error || 'Transit data not available.')}</p>`;
    return;
  }

  const dashaDisplay = d.dasha?.display || '—';

  // ── Header: Dasha at this date ──────────────────────────────────────────────
  let html = `
  <div class="transit-header-block">
    <div class="transit-date-label">${escapeHtml(d.date)} ${d.transitTime ? '· '+escapeHtml(d.transitTime) : ''}</div>
    <div class="transit-dasha-row">
      <span class="transit-dasha-label">Dasha:</span>
      <span class="transit-dasha-value">${escapeHtml(dashaDisplay)}</span>
      <span class="muted" style="font-size:0.75rem;">MD / AD / PD / Sukshma</span>
    </div>
    <div class="transit-overall ${d.overallQuality}">
      Overall: <strong>${d.overallScore}/100</strong> — ${escapeHtml(d.overallQuality?.toUpperCase() || '—')}
    </div>
  </div>`;

  // ── Dasha lord house activations ────────────────────────────────────────────
  if (d.dasha?.dashaActivatedHouses?.length) {
    html += `<div class="transit-section-label">Dasha Lords Activating Houses</div>
    <table class="equal-table compact-table">
      <thead><tr>
        <th>Dasha Lord</th><th>Occupies</th><th>Rules</th><th>Karakatva</th>
      </tr></thead>
      <tbody>
      ${d.dasha.dashaActivatedHouses.map(dh => `
        <tr>
          <td><strong>${escapeHtml(dh.planet)}</strong></td>
          <td>H${dh.occupiesHouse} (${escapeHtml(dh.signCode || '')})</td>
          <td>${dh.rulesHouses?.length ? 'H'+dh.rulesHouses.join(', H') : '—'}</td>
          <td class="muted" style="font-size:0.74rem;">${escapeHtml((dh.karakatva||'').slice(0,50))}</td>
        </tr>`).join('')}
      </tbody>
    </table>`;
  }

  // ── Main transit table — AstroNidan style ───────────────────────────────────
  html += `<div class="transit-section-label" style="margin-top:14px;">Planet Transits — House Activation &amp; Quality</div>
  <table class="equal-table compact-table transit-full-table">
    <thead>
      <tr>
        <th>Planet</th>
        <th>Sign / °</th>
        <th>H (Lagna)</th>
        <th>House Domain</th>
        <th>House Lord</th>
        <th>Karaka</th>
        <th>Vedha</th>
        <th>Moorti</th>
        <th>Tara</th>
        <th>BAV</th>
        <th>SAV</th>
        <th>Score</th>
      </tr>
    </thead>
    <tbody>
    ${['Saturn','Jupiter','Rahu','Ketu','Mars','Sun','Venus','Mercury','Moon']
      .filter(p => d.planets?.[p])
      .map(p => {
        const pt = d.planets[p];
        const scoreColor = pt.score >= 65 ? '#166534' : pt.score >= 40 ? '#7c4b00' : '#991b1b';
        const mColor     = pt.moorti?.name==='Swarna' ? '#166534' : pt.moorti?.name==='Rajata' ? '#0f6292' : pt.moorti?.name==='Loha' ? '#991b1b' : '';
        const tColor     = ['Param Mitra','Mitra','Sampath','Kshema','Sadhana'].includes(pt.tara?.name) ? '#166534' :
                           ['Vipat','Pratyak','Naidhana'].includes(pt.tara?.name) ? '#991b1b' : '';
        return `
        <tr>
          <td><strong>${p}</strong></td>
          <td>${escapeHtml(pt.sign||'—')} ${pt.degreeInSign?.toFixed(1)||''}°
            ${pt.nakshatra ? `<div class="muted" style="font-size:0.68rem;">${escapeHtml(pt.nakshatra)}</div>` : ''}
          </td>
          <td><strong>H${pt.houseFromLagna}</strong>
            <div class="muted" style="font-size:0.68rem;">Moon:H${pt.houseFromMoon}</div>
          </td>
          <td style="font-size:0.74rem;">${escapeHtml((pt.houseDomain||'').split(',')[0])}
            ${pt.natalPlanetsHere?.length ? `<div style="color:#0f6292;font-size:0.67rem;">Natal: ${pt.natalPlanetsHere.join(',')}</div>` : ''}
          </td>
          <td style="font-size:0.74rem;">${escapeHtml(pt.houseLord||'—')}</td>
          <td style="font-size:0.74rem;">${escapeHtml(pt.naturalKaraka||'—')}</td>
          <td>${pt.vedhaObstructed
              ? `<span style="color:#991b1b;font-weight:600;" title="Obstructed by ${pt.vedhaObstructor}">⊗ ${escapeHtml(pt.vedhaObstructor||'')}</span>`
              : '<span style="color:#166534;">Clear</span>'}</td>
          <td style="color:${mColor};font-weight:600;">${escapeHtml(pt.moorti?.name||'—')}</td>
          <td style="color:${tColor};font-weight:600;" title="${escapeHtml(pt.tara?.meaning||'')}">${escapeHtml(pt.tara?.name||'—')}</td>
          <td>${pt.bav !== null && pt.bav !== undefined ? pt.bav : '—'}</td>
          <td>${pt.sav !== null && pt.sav !== undefined ? pt.sav : '—'}</td>
          <td style="color:${scoreColor};font-weight:700;">${pt.score}</td>
        </tr>`;
    }).join('')}
    </tbody>
  </table>`;

  // ── Kakshya detail for slow planets ────────────────────────────────────────
  html += `<details style="margin-top:10px;"><summary style="font-size:0.82rem;cursor:pointer;">Kakshya detail (slow planets)</summary>
  <table class="equal-table compact-table" style="margin-top:6px;">
    <thead><tr><th>Planet</th><th>Kakshya Lord</th><th>Rekha?</th><th>Range</th></tr></thead>
    <tbody>
    ${['Saturn','Jupiter','Rahu','Mars'].filter(p=>d.planets?.[p]?.kakshya).map(p => {
      const k = d.planets[p].kakshya;
      return `<tr>
        <td><strong>${p}</strong></td>
        <td>${escapeHtml(k.lord||'—')}</td>
        <td>${k.hasRekha===true ? '<span style="color:#166534;">Yes ✓</span>' : k.hasRekha===false ? '<span style="color:#991b1b;">No ✗</span>' : '—'}</td>
        <td class="muted" style="font-size:0.73rem;">${k.startDeg?.toFixed(2)||'—'}° – ${k.endDeg?.toFixed(2)||'—'}°</td>
      </tr>`;
    }).join('')}
    </tbody>
  </table></details>`;

  // ── Source note ─────────────────────────────────────────────────────────────
  html += `<p class="muted convergence-note" style="margin-top:8px; font-size:0.74rem;">
    Transit quality from PVR textbook Ch.25: Vedha (Table 63), Moorti (2nd/12th=Swarna, 3rd/11th=Rajata, 4th/10th=Tamra, 5th/9th=Loha), 
    Tara (Nav Tara from natal Moon), BAV/SAV/Kakshya (Ch.12, Table 60). 
    Sukshma dasha = PD proportionally divided. Scores: 70+ favorable, 45-70 mixed, &lt;45 challenging.
  </p>`;

  el.innerHTML = html;
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}
