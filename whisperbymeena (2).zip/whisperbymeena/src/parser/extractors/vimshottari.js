/**
 * Vimshottari Dasha Extractor
 *
 * JHora output format:
 *   Vimsottari Dasa ():
 *   Moon Moon1994-04-11 Mars 1995-02-11 Rah 1995-09-15 ...
 *   Merc 2000-02-11 Ket 2001-07-14 Ven 2002-02-10 Sun 2003-10-15
 *   Mars Mars 2004-04-11 Rah 2004-09-11 ...
 *
 * Notes:
 *   - Dates can be GLUED to lord names ("Moon1994-04-11") with no space
 *   - Each MD has exactly 9 antardashas (one per Vimshottari planet)
 *   - MD boundary = two consecutive lord tokens (no date between)
 */

const { normalizePlanetName } = require('../utils/constants');

/**
 * Pratyantar Dasha (PD) — JHora's text export only lists Mahadasha (MD)
 * and Antardasha (AD) explicitly. Pratyantar is computed here via the
 * standard classical proportional-subdivision algorithm: each Vimshottari
 * period is divided into 9 sub-periods, in the FIXED planetary order,
 * starting from the period's own lord (the "self-first" rule), with each
 * sub-period's share of the total duration proportional to that planet's
 * total Vimshottari years (out of 120).
 */
const VIMSHOTTARI_YEARS = {
  Ketu: 7, Venus: 20, Sun: 6, Moon: 10, Mars: 7,
  Rahu: 18, Jupiter: 16, Saturn: 19, Mercury: 17
};
const VIMSHOTTARI_ORDER = ['Ketu', 'Venus', 'Sun', 'Moon', 'Mars', 'Rahu', 'Jupiter', 'Saturn', 'Mercury'];
const TOTAL_YEARS = 120;

function rotateSequenceFrom(startLord) {
  const idx = VIMSHOTTARI_ORDER.indexOf(startLord);
  if (idx === -1) return [...VIMSHOTTARI_ORDER];
  return [...VIMSHOTTARI_ORDER.slice(idx), ...VIMSHOTTARI_ORDER.slice(0, idx)];
}

/**
 * Compute the 9 Pratyantar sub-periods within a given Antardasha.
 */
function computePratyantar(adStartDate, adEndDate, adLord) {
  const startMs = new Date(adStartDate).getTime();
  const endMs = new Date(adEndDate).getTime();
  const totalMs = endMs - startMs;

  const sequence = rotateSequenceFrom(adLord);
  const periods = [];
  let cursor = startMs;

  for (const lord of sequence) {
    const shareMs = totalMs * (VIMSHOTTARI_YEARS[lord] / TOTAL_YEARS);
    const periodStart = cursor;
    const periodEnd = cursor + shareMs;
    periods.push({
      lord,
      startDate: new Date(periodStart).toISOString().split('T')[0],
      endDate: new Date(periodEnd).toISOString().split('T')[0]
    });
    cursor = periodEnd;
  }

  return periods;
}

function extractVimshottari(sectionText) {
  // Strip the header line "Vimsottari Dasa ():"
  const bodyStart = sectionText.indexOf('\n');
  if (bodyStart === -1) return { mahadashas: [] };
  const bodyText = sectionText.substring(bodyStart + 1);

  const tokens = tokenizeDashaText(bodyText);
  const mahadashas = groupIntoMahadashas(tokens);
  computeEndDates(mahadashas);

  return { mahadashas };
}

/**
 * Tokenize, splitting glued "Lord+Date" tokens like "Moon2010-09-14"
 */
function tokenizeDashaText(text) {
  const tokens = [];
  for (const raw of text.split(/\s+/).filter(Boolean)) {
    const m = raw.match(/^([A-Z][a-z]+)(\d{4}-\d{2}-\d{2})$/);
    if (m) {
      tokens.push(m[1]);
      tokens.push(m[2]);
    } else {
      tokens.push(raw);
    }
  }
  return tokens;
}

const isDate = t => /^\d{4}-\d{2}-\d{2}$/.test(t);
const isLord = t => /^[A-Z][a-z]+$/.test(t);

function groupIntoMahadashas(tokens) {
  const mahadashas = [];
  let current = null;

  for (let i = 0; i < tokens.length; ) {
    if (isLord(tokens[i]) && isLord(tokens[i + 1])) {
      // MD boundary: <MD-lord> <AD-lord> ...
      if (current) mahadashas.push(current);
      current = {
        lord: normalizePlanetName(tokens[i]),
        startDate: null,
        endDate: null,
        antardashas: []
      };
      i++; // advance to first AD lord
    } else if (isLord(tokens[i]) && isDate(tokens[i + 1])) {
      if (!current) {
        i += 2;
        continue;
      }
      current.antardashas.push({
        lord: normalizePlanetName(tokens[i]),
        startDate: tokens[i + 1],
        endDate: null
      });
      i += 2;
    } else {
      i++;
    }
  }

  if (current) mahadashas.push(current);
  return mahadashas;
}

/**
 * Each AD's end date = next AD's start date (across MD boundaries).
 * Each MD's start = first AD start, end = last AD end.
 */
function computeEndDates(mahadashas) {
  // Flatten to compute AD end dates
  const flat = [];
  mahadashas.forEach((md, mdIdx) => {
    md.antardashas.forEach((ad, adIdx) => {
      flat.push({ mdIdx, adIdx });
    });
  });

  for (let i = 0; i < flat.length; i++) {
    const { mdIdx, adIdx } = flat[i];
    const ad = mahadashas[mdIdx].antardashas[adIdx];
    const next = flat[i + 1];
    if (next) {
      ad.endDate = mahadashas[next.mdIdx].antardashas[next.adIdx].startDate;
    }
  }

  // Roll up to MD level
  for (const md of mahadashas) {
    if (md.antardashas.length > 0) {
      md.startDate = md.antardashas[0].startDate;
      md.endDate = md.antardashas[md.antardashas.length - 1].endDate;
    }
  }
}

/**
 * Find currently active MD/AD given a target date.
 */
function findActiveDasha(mahadashas, targetDate) {
  const target = new Date(targetDate);
  for (const md of mahadashas) {
    const mdStart = new Date(md.startDate);
    const mdEnd = md.endDate ? new Date(md.endDate) : null;
    if (target >= mdStart && (!mdEnd || target < mdEnd)) {
      for (const ad of md.antardashas) {
        const adStart = new Date(ad.startDate);
        const adEnd = ad.endDate ? new Date(ad.endDate) : null;
        if (target >= adStart && (!adEnd || target < adEnd)) {
          return { mahadasha: md.lord, antardasha: ad.lord, mdPeriod: md, adPeriod: ad };
        }
      }
      return { mahadasha: md.lord, antardasha: null, mdPeriod: md, adPeriod: null };
    }
  }
  return null;
}

/**
 * Find active MD/AD/PD for a given date — extends findActiveDasha by
 * computing Pratyantar on-the-fly for whichever AD is active.
 */
function findActiveDashaWithPratyantar(mahadashas, targetDate) {
  const base = findActiveDasha(mahadashas, targetDate);
  if (!base || !base.adPeriod) return base;

  const pratyantarPeriods = computePratyantar(base.adPeriod.startDate, base.adPeriod.endDate, base.antardasha);
  const target = new Date(targetDate).getTime();

  let activePD = null;
  for (const pd of pratyantarPeriods) {
    const pdStart = new Date(pd.startDate).getTime();
    const pdEnd = new Date(pd.endDate).getTime();
    if (target >= pdStart && target < pdEnd) {
      activePD = pd;
      break;
    }
  }

  return {
    ...base,
    pratyantardasha: activePD ? activePD.lord : null,
    pdPeriod: activePD,
    allPratyantarInThisAD: pratyantarPeriods
  };
}

module.exports = {
  extractVimshottari,
  findActiveDasha,
  findActiveDashaWithPratyantar,
  computePratyantar,
  tokenizeDashaText,
  groupIntoMahadashas,
  computeEndDates,
  VIMSHOTTARI_YEARS,
  VIMSHOTTARI_ORDER
};
