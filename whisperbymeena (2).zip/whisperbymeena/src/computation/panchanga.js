/**
 * Panchanga — Five Limbs of Time
 * Source: PVR Narasimha Rao "Vedic Astrology: An Integrated Approach"
 *   Ch.1.3.8  Tithis (p.12-13)
 *   Ch.1.3.9  Yogas (p.15-16, Table 5)
 *   Ch.1.3.10 Karanas (p.17)
 *   Ch.1.3.11 Hora (p.18)
 *   Ch.1.3.12 Panchaanga (p.18)
 * Audio Lessons Vol.II:
 *   Lesson #46 Nav Tara (p.9)
 *   Lesson #63 Special Tithis, Panchanga Tattvas (p.9-10)
 *
 * Tattvas (Lesson #63):
 *   Tithi     = Jala tattva   — prosperity, wealth, happiness
 *   Vara      = Agni tattva   — life force, vitality, longevity
 *   Karana    = Bhu tattva    — achievement
 *   Yoga      = Akasha tattva — binding force
 *   Nakshatra = Vayu tattva   — strength, kinetic energy
 */

'use strict';

// ── Tithi names (p.12-13) ─────────────────────────────────────────────────────
const TITHI_NAMES = [
  'Pratipada','Dwitiya','Tritiya','Chaturthi','Panchami',
  'Shashthi','Saptami','Ashtami','Navami','Dashami',
  'Ekadashi','Dwadashi','Trayodashi','Chaturdashi','Purnima',
  'Pratipada','Dwitiya','Tritiya','Chaturthi','Panchami',
  'Shashthi','Saptami','Ashtami','Navami','Dashami',
  'Ekadashi','Dwadashi','Trayodashi','Chaturdashi','Amavasya'
];

const TITHI_GROUPS = {
  Nanda: [1,6,11,16,21,26], Bhadra: [2,7,12,17,22,27],
  Jaya:  [3,8,13,18,23,28], Rikta:  [4,9,14,19,24,29],
  Poorna:[5,10,15,20,25,30]
};

// ── Yoga names (Table 5, p.15-16) ────────────────────────────────────────────
const YOGA_NAMES = [
  'Vishkambha','Preeti','Aayushmaan','Saubhaagya','Sobhana',
  'Atiganda','Sukarman','Dhriti','Shoola','Ganda',
  'Vriddhi','Dhruva','Vyaaghata','Harshana','Vajra',
  'Siddhi','Vyatipaata','Variyan','Parigha','Shiva',
  'Siddha','Saadhya','Subha','Sukla','Brahma',
  'Indra','Vaidhriti'
];

const INAUSPICIOUS_YOGAS = new Set([
  'Vishkambha','Atiganda','Shoola','Ganda','Vyaaghata',
  'Vyatipaata','Parigha','Vaidhriti'
]);

// ── Karana names (p.17) ───────────────────────────────────────────────────────
const KARANA_MOVABLE = ['Bava','Balava','Kaulava','Taitula','Garija','Vanija','Vishti'];
const KARANA_LORDS = {
  Bava:'Sun', Balava:'Moon', Kaulava:'Mars', Taitula:'Mercury',
  Garija:'Jupiter', Vanija:'Venus', Vishti:'Saturn',
  Sakuna:'Rahu', Chatushpada:'Sun', Naga:'Mercury', Kimstughna:'Moon'
};
const GOOD_KARANAS = new Set(['Garija','Vanija','Balava','Kaulava','Bava']);

// ── Hora planet order (p.18) ──────────────────────────────────────────────────
// "lords come in order of decreasing speed: Saturn, Jupiter, Mars, Sun, Venus, Mercury, Moon"
const HORA_ORDER = ['Saturn','Jupiter','Mars','Sun','Venus','Mercury','Moon'];
const WEEKDAY_LORDS = ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn'];
const VARA_NAMES = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];

// ── Nakshatra table (Table 2, p.11) ──────────────────────────────────────────
const NAKSHATRA_NAMES = [
  'Aswini','Bharani','Krittika','Rohini','Mrigasira','Aardra',
  'Punarvasu','Pushyami','Asresha','Makha','Poorva Phalguni','Uttara Phalguni',
  'Hasta','Chitra','Swaati','Visaakha','Anooraadha','Jyeshtha',
  'Moola','Poorvaashaadha','Uttaraashaadha','Sravanam','Dhanishtha','Satabhishak',
  'Poorvaabhaadra','Uttaraabhaadra','Revati'
];

const NAKSHATRA_LORDS = [
  'Ketu','Venus','Sun','Moon','Mars','Rahu',
  'Jupiter','Saturn','Mercury','Ketu','Venus','Sun',
  'Moon','Mars','Rahu','Jupiter','Saturn','Mercury',
  'Ketu','Venus','Sun','Moon','Mars','Rahu',
  'Jupiter','Saturn','Mercury'
];

// ── Nav Tara (Audio Lesson #46 p.9, Lesson #63) ──────────────────────────────
// "There are Nav Taras from Moon. All 3 Janma Taras ruled by same graha."
const NAV_TARA = [
  'Janma','Sampath','Vipat','Kshema','Pratyak',
  'Sadhana','Naidhana','Mitra','Param Mitra'
];
const FAVORABLE_TARAS = new Set(['Sampath','Kshema','Sadhana','Mitra','Param Mitra']);

// ── Special tithi multipliers (Audio Lesson #63 p.9-10) ──────────────────────
// "calculate Mo-Su and multiply with the tithi factor and subtract 360 if > 360
//  and divide the remainder by 12 and add 1"
const SPECIAL_TITHI_MULTIPLIERS = {
  janma:1, dhana:2, bhratri:3, matri:4, putra:5, satru:6,
  kalatra:7, mrityu:8, bhagya:9, karma:10, labha:11, vyaya:12
};

// ─────────────────────────────────────────────────────────────────────────────

/**
 * Get nakshatra info for any sidereal longitude.
 * Source: Table 2, Ch.1.3.6 — "each nakshatra = 360/27 = 13°20'"
 */
function getNakshatra(longitude) {
  const NAK_SPAN = 360 / 27;
  const lon = ((longitude % 360) + 360) % 360;
  const idx = Math.floor(lon / NAK_SPAN) % 27;
  const degInNak = lon % NAK_SPAN;
  return {
    index: idx,
    number: idx + 1,
    name: NAKSHATRA_NAMES[idx],
    lord: NAKSHATRA_LORDS[idx],
    pada: Math.floor(degInNak / (NAK_SPAN / 4)) + 1,
    degreeInNakshatra: Number(degInNak.toFixed(6))
  };
}

/**
 * Get Nav Tara for a target nakshatra relative to natal Moon nakshatra.
 * Source: Audio Lesson #46 p.9
 */
function getNavTara(natalMoonNakIndex, targetNakIndex) {
  const count = ((targetNakIndex - natalMoonNakIndex) + 27) % 27;
  const taraIdx = count % 9;
  return {
    count: count + 1,
    tara: taraIdx + 1,
    taraName: NAV_TARA[taraIdx],
    favorable: FAVORABLE_TARAS.has(NAV_TARA[taraIdx])
  };
}

/**
 * Compute complete Panchanga.
 *
 * @param {number} moonLon      Moon sidereal longitude (0-360)
 * @param {number} sunLon       Sun sidereal longitude (0-360)
 * @param {object} opts         Optional: { birthDate (JS Date), sunriseHour, birthHour }
 */
function computePanchanga(moonLon, sunLon, opts = {}) {
  const { birthDate, sunriseHour, birthHour } = opts;
  const NAK_SPAN = 360 / 27;

  // ── 1. Tithi ─────────────────────────────────────────────────────────────
  // Ch.1.3.8: "period in which Moon-Sun difference changes by exactly 12°"
  const diffRaw = ((moonLon - sunLon) + 360) % 360;
  const tithiIdx = Math.floor(diffRaw / 12);   // 0-29
  const tithiNum = tithiIdx + 1;                // 1-30
  let tithiGroup = '';
  for (const [g, nums] of Object.entries(TITHI_GROUPS)) {
    if (nums.includes(tithiNum)) { tithiGroup = g; break; }
  }
  const TITHI_LORDS_LIST = [
    'Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn',
    'Rahu','Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn',
    'Sun','Moon','Mars','Mercury','Jupiter',
    'Venus','Saturn','Rahu','Sun','Moon',
    'Mars','Mercury','Jupiter','Venus','Rahu'
  ];

  // ── 2. Nakshatra ─────────────────────────────────────────────────────────
  // Ch.1.3.6: "each nakshatra = 13°20'"
  const nakIdx  = Math.floor(((moonLon % 360) + 360) % 360 / NAK_SPAN) % 27;
  const degInNak = moonLon % NAK_SPAN;

  // ── 3. Yoga ──────────────────────────────────────────────────────────────
  // Ch.1.3.9: "(Moon+Sun) / nakshatra_span, ignore fraction, add 1"
  const yogaSum = (moonLon + sunLon) % 360;
  const yogaIdx = Math.floor(yogaSum / NAK_SPAN);

  // ── 4. Karana ─────────────────────────────────────────────────────────────
  // Ch.1.3.10: "each tithi divided into 2 karanas"
  const halfTithiIdx = Math.floor(diffRaw / 6); // 0-59
  let karanaName;
  if (halfTithiIdx === 0) {
    karanaName = 'Kimstughna';
  } else if (halfTithiIdx >= 57) {
    karanaName = ['Sakuna','Chatushpada','Naga'][halfTithiIdx - 57];
  } else {
    karanaName = KARANA_MOVABLE[(halfTithiIdx - 1) % 7];
  }

  // ── 5. Vara ───────────────────────────────────────────────────────────────
  let vara = null;
  if (birthDate) {
    const varaIdx = birthDate.getDay();
    vara = { index: varaIdx, name: VARA_NAMES[varaIdx], lord: WEEKDAY_LORDS[varaIdx] };
  }

  // ── 6. Hora ───────────────────────────────────────────────────────────────
  // Ch.1.3.11: "first hora of day = weekday lord; planets in order of decreasing speed"
  let hora = null;
  if (vara !== null && sunriseHour != null && birthHour != null) {
    const elapsed = birthHour - sunriseHour;
    if (elapsed >= 0) {
      const horaNum = Math.floor(elapsed) + 1;
      const startIdx = HORA_ORDER.indexOf(vara.lord);
      const horaLord = HORA_ORDER[(startIdx + horaNum - 1) % 7];
      hora = { number: horaNum, lord: horaLord };
    }
  }

  // ── 7. Special Tithis ─────────────────────────────────────────────────────
  // Audio Lesson #63: formula verified from source
  const specialTithis = {};
  for (const [name, mult] of Object.entries(SPECIAL_TITHI_MULTIPLIERS)) {
    const val = (diffRaw * mult) % 360;
    specialTithis[name] = Math.floor(val / 12) + 1;
  }

  return {
    tithi: {
      number: tithiNum,
      name: TITHI_NAMES[tithiIdx],
      paksha: tithiNum <= 15 ? 'Sukla' : 'Krishna',
      group: tithiGroup,
      lord: TITHI_LORDS_LIST[tithiIdx],
      progressPct: Number(((diffRaw % 12) / 12 * 100).toFixed(2)),
      remainingPct: Number((100 - (diffRaw % 12) / 12 * 100).toFixed(2))
    },
    nakshatra: {
      number: nakIdx + 1,
      name: NAKSHATRA_NAMES[nakIdx],
      lord: NAKSHATRA_LORDS[nakIdx],
      pada: Math.floor(degInNak / (NAK_SPAN / 4)) + 1,
      progressPct: Number((degInNak / NAK_SPAN * 100).toFixed(2)),
      remainingPct: Number((100 - degInNak / NAK_SPAN * 100).toFixed(2)),
      index: nakIdx
    },
    yoga: {
      number: yogaIdx + 1,
      name: YOGA_NAMES[yogaIdx],
      inauspicious: INAUSPICIOUS_YOGAS.has(YOGA_NAMES[yogaIdx])
    },
    karana: {
      name: karanaName,
      lord: KARANA_LORDS[karanaName] || '',
      auspicious: GOOD_KARANAS.has(karanaName)
    },
    vara,
    hora,
    specialTithis,
    _moonSunDiff: Number(diffRaw.toFixed(6))
  };
}

module.exports = { computePanchanga, getNakshatra, getNavTara, NAKSHATRA_NAMES, NAKSHATRA_LORDS, NAV_TARA };
