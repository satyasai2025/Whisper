/**
 * Analysis Orchestrator
 *
 * Combines all analysis layers into one object attached to the parsed
 * chart: relationships, functional nature (incl. Badhakesh), aspects,
 * arudhas, dignity, and yogas.
 */

const { computeRelationships } = require('./relationships');
const { computeFunctionalNature } = require('./functional-nature');
const { computeAspects } = require('./aspects');
const { computeArudhas } = require('./arudhas');
const { computeDignity } = require('./dignity');
const { computeYogas } = require('./yogas');
const { computeNavamsaAnalysis } = require('./navamsa');
const { matchRules } = require('./rules/rule-engine');
const { computeJaimini } = require('./jaimini');
const { computeSahams } = require('./sahams');
const { computeCharacterAnalysis } = require('./character');

function computeAnalysis(bodies, charaKarakasInput, dashas) {
  if (!bodies || !bodies.Lagna) {
    return { _warning: 'Lagna not found — analysis requires Lagna sign to compute most layers.' };
  }

  const lagnaSignCode = bodies.Lagna.signCode;
  const aspects = computeAspects(bodies); // yogas needs this, compute first
  const dignity = computeDignity(bodies); // navamsa confirmation needs D1 dignity

  // Compute Chara Karakas from bodies if not provided (7-karaka scheme)
  // Rank planets Sun-Saturn by degree within sign (descending) → AK, AMK, BK, MK, PK, GK, DK
  const charaKarakas = charaKarakasInput && charaKarakasInput.AK ? charaKarakasInput : (function() {
    const KARAKA_PLANETS = ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn'];
    const KARAKA_NAMES = ['AK','AMK','BK','MK','PK','GK','DK'];
    const sorted = KARAKA_PLANETS
      .filter(p => bodies[p])
      .map(p => ({ planet: p, deg: bodies[p].longitudeInSign || 0 }))
      .sort((a,b) => b.deg - a.deg);
    const result = {};
    sorted.forEach((item, i) => {
      if (i < KARAKA_NAMES.length) result[KARAKA_NAMES[i]] = item.planet;
    });
    return result;
  })();

  const analysis = {
    relationships: computeRelationships(bodies),
    functionalNature: computeFunctionalNature(lagnaSignCode),
    aspects,
    arudhas: computeArudhas(lagnaSignCode, bodies),
    dignity,
    yogas: computeYogas(lagnaSignCode, bodies, aspects),
    navamsa: computeNavamsaAnalysis(bodies, dignity.classifications),
    jaimini: computeJaimini(bodies, charaKarakas),
    sahams: computeSahams(bodies)
  };

  // Rule matching needs the analysis it reads from — run last, on a chart-
  // like object exposing bodies + the analysis computed above.
  analysis.matchedRules = matchRules({ bodies, analysis });

  // Character analysis needs dashas for the timing layer, so it's
  // computed here in the orchestrator (which has access to the full
  // chart) rather than inside computeAnalysis's usual bodies-only scope.
  // It's attached after the fact in jhora-parser.js once dashas are known.

  return analysis;
}

module.exports = { computeAnalysis };
