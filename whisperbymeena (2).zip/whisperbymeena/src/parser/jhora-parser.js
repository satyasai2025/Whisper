/**
 * JHora Parser — Main Orchestrator (v3)
 *
 * Chart diagram parsing (D1/D9/D10/.../D60 visual layouts) has been
 * REMOVED from the default output — the Learner already has the source
 * PDF for visual reference. Instead, the parser now feeds planet
 * positions into the analysis layer (relationships, functional nature,
 * aspects) which is what's actually useful for chart study.
 *
 * House numbers for each body (needed by the analysis layer) are computed
 * directly from sign positions relative to Lagna — no diagram parsing
 * required for this.
 */

const { extractTextFromPDF, normalizeText } = require('./utils/pdf-text-extract');
const { splitSections } = require('./utils/section-router');
const { extractHeader } = require('./extractors/header');
const { extractBodies } = require('./extractors/bodies');
const { extractVimshottari } = require('./extractors/vimshottari');
const { extractNarayana } = require('./extractors/narayana');
const {
  extractAshtottari, extractMoola, extractVimshottariTribhagi, extractYogini,
  extractSudasa, extractLagnaKendradi, extractDrigdasa, extractShoola,
  extractNiryanaShoola, extractKalachakra
} = require('./extractors/conditional-dashas');
const {
  extractAshtakavarga, extractShadbala, extractBhavaBala,
  extractAvastha, extractActivity, extractVimsopaka
} = require('./extractors/strengths');
const { computeAnalysis } = require('../analysis');
const { computeCharacterAnalysis } = require('../analysis/character');
const { generatePortrait } = require('../analysis/narrative-portrait');

const PARSER_VERSION = '0.5.0';

async function parseJHoraPDF(pdfPath) {
  const rawText = await extractTextFromPDF(pdfPath);
  return parseJHoraText(rawText, { sourceFile: pdfPath });
}

function parseJHoraText(rawText, options = {}) {
  const text = normalizeText(rawText);
  const sections = splitSections(text);

  const { native, panchanga } = extractHeader(sections.header || '');
  const { bodies, charaKarakas } = extractBodies(sections.bodyTable || '');

  const dashas = {
    vimshottari: extractVimshottari(sections.vimshottari || ''),
    narayana: extractNarayana(sections.narayana || ''),
    ashtottari: extractAshtottari(sections.ashtottari || ''),
    moola: extractMoola(sections.moola || ''),
    vimshottariTribhagi: extractVimshottariTribhagi(sections.vimshottariTribhagi || ''),
    yogini: extractYogini(sections.yogini || ''),
    kalachakra: extractKalachakra(sections.kalachakra || ''),
    sudasa: extractSudasa(sections.sudasa || ''),
    lagnaKendradi: extractLagnaKendradi(sections.lagnaKendradi || ''),
    drigdasa: extractDrigdasa(sections.drigdasa || ''),
    shoola: extractShoola(sections.shoola || ''),
    niryanaShoola: extractNiryanaShoola(sections.niryanaShoola || '')
  };

  const strengths = {
    ashtakavarga: extractAshtakavarga(sections.ashtakavarga || ''),
    shadbala: extractShadbala(sections.shadbala || ''),
    bhavaBala: extractBhavaBala(sections.bhavaBala || ''),
    avastha: extractAvastha(sections.avastha || ''),
    activity: extractActivity(sections.activity || ''),
    vimsopaka: extractVimsopaka(sections.vimsopaka || ''),
    _note: 'Pinda (Sodhya/Rasi/Graha) is not extracted — see strengths.js module documentation for why.'
  };

  const analysis = computeAnalysis(bodies, charaKarakas);
  analysis.character = computeCharacterAnalysis({ bodies, analysis, dashas });
  analysis.portrait = generatePortrait({ bodies, analysis });

  return {
    metadata: {
      parserVersion: PARSER_VERSION,
      parsedAt: new Date().toISOString(),
      sourceFile: options.sourceFile || null,
      sectionsFound: Object.keys(sections).filter(k => k !== 'header')
    },
    native,
    panchanga,
    bodies,
    charaKarakas,
    dashas,
    strengths,
    analysis
  };
}

module.exports = { parseJHoraPDF, parseJHoraText };
