/**
 * Excel Data Bank
 * 
 * Har chart compute hone ke baad ek Excel file mein entry add karta hai.
 * File: data/WhisperByMeena_DataBank.xlsx
 * 
 * Sheets:
 *   1. Charts     — basic chart data (lagna, planets, karakas, dashas)
 *   2. Events     — past events jo verify kiye gaye
 *   3. Predictions — future prediction scores
 *   4. Validation  — rule accuracy tracking
 */

'use strict';

const XLSX = require('xlsx');
const path = require('path');
const fs   = require('fs');

const DATA_DIR  = path.join(__dirname, '..', '..', 'data');
const BANK_FILE = path.join(DATA_DIR, 'WhisperByMeena_DataBank.xlsx');

const SIGN_CODES = ['Ar','Ta','Ge','Cn','Le','Vi','Li','Sc','Sg','Cp','Aq','Pi'];
const PLANETS    = ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn','Rahu','Ketu'];

// ── Column definitions ────────────────────────────────────────────────────────

const CHART_COLUMNS = [
  'ChartID', 'Name', 'DOB', 'TOB', 'GMT_Offset', 'Latitude', 'Longitude', 'Place',
  'Gender', 'Lagna', 'Lagna_Deg',
  // Planet signs
  'Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn', 'Rahu', 'Ketu',
  // Planet houses
  'Sun_H', 'Moon_H', 'Mars_H', 'Mercury_H', 'Jupiter_H', 'Venus_H', 'Saturn_H', 'Rahu_H', 'Ketu_H',
  // Karakas
  'AK', 'AMK', 'BK', 'MK', 'PK', 'GK', 'DK',
  // Special points
  'AL', 'UL', 'GL',
  // D9 lagna
  'D9_Lagna',
  // Active dasha (today)
  'MD_Today', 'AD_Today', 'PD_Today',
  // Functional nature key planets
  'Yogakaraka', 'Func_Benefics', 'Func_Malefics',
  // Sahams
  'Vivaha_Saham', 'Karma_Saham',
  // SAV
  'SAV_Total',
  // Nakshatra
  'Moon_Nak', 'Lagna_Nak',
  // Computed at
  'Computed_At'
];

const EVENT_COLUMNS = [
  'ChartID', 'Name', 'EventKey', 'EventLabel', 'EventDate',
  'Age_At_Event', 'MD', 'AD', 'PD',
  'L1_Score', 'L2_Score', 'L3_Score', 'L4_Score', 'Final_Score',
  'Tier', 'Convergence_Level',
  'Saham_Activated', 'Degree_Trigger',
  'Verified_At'
];

const PREDICTION_COLUMNS = [
  'ChartID', 'Name', 'EventKey', 'EventLabel',
  'Window_Start', 'Window_End', 'MD', 'AD',
  'Score', 'Suppressed', 'Tier',
  'Convergence',
  'Predicted_At'
];

// ── Helper: load or create workbook ──────────────────────────────────────────

function loadOrCreateWorkbook() {
  if (fs.existsSync(BANK_FILE)) {
    try {
      return XLSX.readFile(BANK_FILE);
    } catch(e) {
      console.warn('DataBank: could not read existing file, creating new:', e.message);
    }
  }

  const wb = XLSX.utils.book_new();

  // Create sheets with headers
  const chartWs  = XLSX.utils.aoa_to_sheet([CHART_COLUMNS]);
  const eventWs  = XLSX.utils.aoa_to_sheet([EVENT_COLUMNS]);
  const predWs   = XLSX.utils.aoa_to_sheet([PREDICTION_COLUMNS]);

  // Style headers (bold)
  [chartWs, eventWs, predWs].forEach(ws => {
    const range = XLSX.utils.decode_range(ws['!ref']);
    for (let C = range.s.c; C <= range.e.c; C++) {
      const addr = XLSX.utils.encode_cell({ r: 0, c: C });
      if (!ws[addr]) continue;
      ws[addr].s = { font: { bold: true }, fill: { fgColor: { rgb: 'C8B89A' } } };
    }
  });

  XLSX.utils.book_append_sheet(wb, chartWs,  'Charts');
  XLSX.utils.book_append_sheet(wb, eventWs,  'Events');
  XLSX.utils.book_append_sheet(wb, predWs,   'Predictions');

  return wb;
}

function saveWorkbook(wb) {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  XLSX.writeFile(wb, BANK_FILE, { compression: true });
}

// ── Check duplicate ───────────────────────────────────────────────────────────

function rowExistsInSheet(ws, keyCol, keyValue) {
  const range = XLSX.utils.decode_range(ws['!ref'] || 'A1:A1');
  const headers = [];
  for (let C = range.s.c; C <= range.e.c; C++) {
    const cell = ws[XLSX.utils.encode_cell({ r: 0, c: C })];
    headers.push(cell ? cell.v : '');
  }
  const keyIdx = headers.indexOf(keyCol);
  if (keyIdx < 0) return false;

  for (let R = 1; R <= range.e.r; R++) {
    const cell = ws[XLSX.utils.encode_cell({ r: R, c: keyIdx })];
    if (cell && cell.v === keyValue) return true;
  }
  return false;
}

// ── Main: Add chart to data bank ─────────────────────────────────────────────

function addChartToDataBank(chart, options) {
  options = options || {};
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

    const wb = loadOrCreateWorkbook();
    const ws = wb.Sheets['Charts'];

    const native   = chart.native || {};
    const bodies   = chart.bodies || {};
    const analysis = chart.analysis || {};
    const jaimini  = analysis.jaimini || {};
    const karakas  = jaimini.allCharaKarakas || {};
    const arudhas  = analysis.arudhas?.arudhas || {};
    const sahams   = analysis.sahams?.sahams || {};
    const fn       = analysis.functionalNature?.classifications || {};

    const chartID = options.chartKey || (native.name || 'chart').replace(/\s+/g,'_') + '_' + (native.year||'?');

    // Skip if already exists
    if (rowExistsInSheet(ws, 'ChartID', chartID)) {
      return { added: false, reason: 'duplicate', chartID };
    }

    // Today's active dasha
    const today = new Date().toISOString().split('T')[0];
    const vimsh = Array.isArray(chart.vimshottariDashas) ? chart.vimshottariDashas : [];
    const vMD   = vimsh.find(m => m.startDate <= today && m.endDate >= today);
    const vAD   = vMD?.antardashas?.find(a => a.startDate <= today && a.endDate >= today);
    const vPD   = vAD?.pratyantardashas?.find(p => p.startDate <= today && p.endDate >= today);

    // Functional nature
    const yogakaraka    = Object.entries(fn).filter(([,c]) => c.classification?.includes('Yogakaraka')).map(([p]) => p).join(',');
    const funcBenefics  = Object.entries(fn).filter(([,c]) => c.classification?.includes('Benefic')).map(([p]) => p).join(',');
    const funcMalefics  = Object.entries(fn).filter(([,c]) => c.classification?.includes('Malefic') && !c.classification?.includes('Yogakaraka')).map(([p]) => p).join(',');

    // Moon nakshatra
    const moonNak  = bodies.Moon?.nakshatra || bodies.Moon?.nakshatraCode || '';
    const lagnaLon = chart.lagna?.degreeInSign || 0;
    const { getNakshatra, getFullLongitude } = require('../computation/nakshatra');
    const lagnaFullLon = SIGN_CODES.indexOf(chart.lagna?.signCode) * 30 + lagnaLon;
    const lagnaNav  = getNakshatra(lagnaFullLon);

    const row = [
      chartID,
      native.name || '—',
      `${native.year||'?'}-${String(native.month||1).padStart(2,'0')}-${String(native.day||1).padStart(2,'0')}`,
      `${String(native.hour||0).padStart(2,'0')}:${String(native.minute||0).padStart(2,'0')}`,
      native.gmtOffsetHours ?? native.gmtOffset ?? 5.5,
      native.latitude || '',
      native.longitude || '',
      native.place || '',
      native.gender || '',
      chart.lagna?.signCode || '',
      Number((chart.lagna?.degreeInSign || 0).toFixed(4)),
      // Planet signs
      ...PLANETS.map(p => bodies[p]?.signCode || ''),
      // Planet houses
      ...PLANETS.map(p => bodies[p]?.house || bodies[p]?.rasiHouse || ''),
      // Karakas
      karakas.AK || jaimini.atmakaraka?.planet || '',
      karakas.AMK || '', karakas.BK || '', karakas.MK || '',
      karakas.PK || '', karakas.GK || '', karakas.DK || '',
      // Special points
      arudhas.A1?.finalArudhaHouse ? 'H'+arudhas.A1.finalArudhaHouse : '',
      arudhas.A12?.finalArudhaHouse ? 'H'+arudhas.A12.finalArudhaHouse : '',
      chart.specialLagnas?.GL?.signCode || '',
      // D9 lagna
      chart.d9?.lagna || '',
      // Active dasha
      vMD?.lord || '', vAD?.lord || '', vPD?.lord || '',
      // Functional nature
      yogakaraka, funcBenefics, funcMalefics,
      // Sahams
      sahams.vivaha?.sign || '',
      sahams.karma?.sign || '',
      // SAV
      chart.ashtakavarga?.savTotal || '',
      // Nakshatras
      moonNak,
      lagnaNav?.name || '',
      // Timestamp
      new Date().toISOString().split('T')[0],
    ];

    XLSX.utils.sheet_add_aoa(ws, [row], { origin: -1 });
    saveWorkbook(wb);

    return { added: true, chartID };
  } catch(e) {
    console.error('DataBank addChart error:', e.message);
    return { added: false, error: e.message };
  }
}

// ── Add event verification result ─────────────────────────────────────────────

function addEventToDataBank(chartID, name, eventResult) {
  try {
    const wb = loadOrCreateWorkbook();
    const ws = wb.Sheets['Events'];

    const r = eventResult;
    const vimsh = r.vimshottari || {};

    const row = [
      chartID, name,
      r.eventKey || '', r.eventLabel || '',
      r.eventDate || '',
      r.age || '',
      vimsh.mahadasha || vimsh.md || '',
      vimsh.antardasha || vimsh.ad || '',
      vimsh.pratyantardasha || vimsh.pd || '',
      r.l1Score || 0, r.l2Score || 0, r.l3Score || 0, r.l4Score || 0,
      r.finalScore || 0,
      r.tier || '',
      r.convergence?.level || '',
      r.signals?.some(s => s.type === 'saham') ? 'Yes' : 'No',
      r.signals?.some(s => s.type === 'degree_trigger') ? 'Yes' : 'No',
      new Date().toISOString().split('T')[0],
    ];

    XLSX.utils.sheet_add_aoa(ws, [row], { origin: -1 });
    saveWorkbook(wb);

    return { added: true };
  } catch(e) {
    console.error('DataBank addEvent error:', e.message);
    return { added: false, error: e.message };
  }
}

// ── Add prediction windows ────────────────────────────────────────────────────

function addPredictionsToDataBank(chartID, name, predictions) {
  try {
    const wb = loadOrCreateWorkbook();
    const ws = wb.Sheets['Predictions'];

    const today = new Date().toISOString().split('T')[0];
    const rows  = [];

    Object.entries(predictions).forEach(([eventKey, pred]) => {
      (pred.windows || []).slice(0, 3).forEach(w => {
        if (!w.startDate || w.startDate < today) return;
        rows.push([
          chartID, name,
          eventKey, pred.label || eventKey,
          w.startDate, w.endDate || '',
          w.mdLord || '', w.adLord || '',
          w.score || 0,
          w.suppressionApplied ? 'Yes' : 'No',
          w.label || '',
          w.convergence?.level || '',
          today,
        ]);
      });
    });

    if (rows.length > 0) {
      XLSX.utils.sheet_add_aoa(ws, rows, { origin: -1 });
      saveWorkbook(wb);
    }

    return { added: true, rowsAdded: rows.length };
  } catch(e) {
    console.error('DataBank addPredictions error:', e.message);
    return { added: false, error: e.message };
  }
}

// ── Get bank file path ────────────────────────────────────────────────────────

function getBankFilePath() { return BANK_FILE; }

module.exports = {
  addChartToDataBank,
  addEventToDataBank,
  addPredictionsToDataBank,
  getBankFilePath
};
