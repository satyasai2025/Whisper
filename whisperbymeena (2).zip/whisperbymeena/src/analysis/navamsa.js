/**
 * D9 (Navamsa) Strength Analysis
 *
 * Classical significance (BPHS, central to PVR's methodology): D9 confirms
 * or modifies what D1 promises. A planet strong in BOTH D1 and D9 gives
 * reliable results; strong in one but weak in the other gives mixed
 * results; weak in both is a genuine concern. This is one of the most
 * important convergence checks in Parashari analysis.
 *
 * BIRTH-TIME RELIABILITY CAVEAT (carried from the Learner's own framework):
 * D9 positions are MORE sensitive to birth-time accuracy than D1, because
 * each D1 sign (30°) maps to 9 Navamsa divisions (~3°20' each) — a few
 * minutes of birth-time error can shift a planet into a neighboring
 * Navamsa sign. Treat this entire module as a SUPPORTING layer, not a
 * primary one, unless birth time is independently confirmed reliable.
 *
 * Three things computed here:
 *   1. D9 house positions (from D9 Lagna = Lagna's own Navamsa sign)
 *   2. D9 dignity (sign-level only — Exalted/Debilitated/Own/Friend-
 *      Neutral-Enemy sign; NOT degree-refined since JHora's D9 column
 *      only gives the sign, not exact degree within it)
 *   3. Vargottama — planets in the SAME sign in both D1 and D9 (classically
 *      a significant strength booster, "as if exalted" per some texts)
 *   4. D1-vs-D9 confirmation summary per planet
 */

const { SIGN_INDEX, SIGN_LORDS, computeHouse } = require('../parser/utils/constants');
const { getNaturalRelationship } = require('./relationships');
const { EXALTATION, DEBILITATION, getOwnSigns } = require('./dignity');

const CLASSICAL_PLANETS = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn'];

const NATURAL_TO_TIER = {
  friend: "Friend's Sign",
  neutral: "Neutral's Sign",
  enemy: "Enemy's Sign"
};

/**
 * Sign-only dignity (no degree refinement) — reusable for any varga where
 * only the sign (not exact degree) is known.
 */
function classifySignDignity(planet, signCode) {
  if (EXALTATION[planet] && signCode === EXALTATION[planet].sign) {
    return { tier: 'Exalted', strength: 'very strong' };
  }
  if (DEBILITATION[planet] && signCode === DEBILITATION[planet]) {
    return { tier: 'Debilitated', strength: 'weak (pending cancellation check)' };
  }
  if (getOwnSigns(planet).includes(signCode)) {
    return { tier: 'Own Sign (Swakshetra)', strength: 'strong' };
  }
  const signLord = SIGN_LORDS[signCode];
  const natural = getNaturalRelationship(planet, signLord);
  if (natural && NATURAL_TO_TIER[natural]) {
    return {
      tier: NATURAL_TO_TIER[natural],
      strength: natural === 'friend' ? 'moderate-favorable' : natural === 'enemy' ? 'moderate-unfavorable' : 'moderate-neutral'
    };
  }
  return { tier: 'Unclassified', strength: 'unknown' };
}

/**
 * Compute D9 house positions for all bodies, given D9 Lagna sign
 * (= the natal Lagna's own Navamsa sign).
 */
function computeD9Houses(bodies) {
  if (!bodies.Lagna || !bodies.Lagna.navamsaCode) return null;
  const d9LagnaSign = bodies.Lagna.navamsaCode;

  const houses = {};
  for (const [name, body] of Object.entries(bodies)) {
    if (!body.navamsaCode) continue;
    houses[name] = name === 'Lagna' ? 1 : computeHouse(d9LagnaSign, body.navamsaCode);
  }
  return { d9LagnaSign, houses };
}

/**
 * Vargottama — planet occupies the SAME sign in D1 and D9.
 */
function computeVargottama(bodies) {
  const result = {};
  for (const planet of [...CLASSICAL_PLANETS, 'Rahu', 'Ketu']) {
    if (!bodies[planet]) continue;
    const { signCode, navamsaCode } = bodies[planet];
    result[planet] = {
      isVargottama: signCode === navamsaCode,
      d1Sign: signCode,
      d9Sign: navamsaCode
    };
  }
  return result;
}

/**
 * D1 vs D9 confirmation — compares D1 dignity tier to D9 dignity tier
 * and produces a plain-language read on convergence.
 */
const STRONG_TIERS = ['Exalted', 'Moolatrikona', 'Own Sign (Swakshetra)'];
const WEAK_TIERS = ['Debilitated', "Enemy's Sign"];

function tierBand(tier) {
  if (STRONG_TIERS.includes(tier)) return 'strong';
  if (WEAK_TIERS.includes(tier)) return 'weak';
  return 'neutral';
}

function compareD1D9(d1Tier, d9Tier, isVargottama) {
  if (isVargottama) {
    return {
      d1Tier, d9Tier, isVargottama,
      read: 'Vargottama — same sign in D1 and D9. Classically treated as a significant strength booster regardless of the dignity tier itself.'
    };
  }

  const d1Band = tierBand(d1Tier);
  const d9Band = tierBand(d9Tier);

  const MATRIX = {
    'strong|strong': 'Confirmed strong — strong in both D1 and D9. A reliable, well-supported signal.',
    'strong|neutral': 'D1 shows strength; D9 is neutral (neither confirms nor contradicts). Mild, not fully cross-verified, support.',
    'strong|weak': 'Mixed — D1 promises strength but D9 tempers it. The promise may not fully or reliably manifest.',
    'neutral|strong': 'D1 is neutral; D9 adds unexpected strength. Lean positive, but the signal originates from D9 alone.',
    'neutral|neutral': 'No strong signal from either D1 or D9 — genuinely unremarkable placement for this planet.',
    'neutral|weak': 'D1 is neutral; D9 introduces weakness not visible in D1 alone. Lean cautious.',
    'weak|strong': 'Mixed — D1 shows weakness but D9 supports/redeems it. Better than D1 alone suggests.',
    'weak|neutral': 'D1 shows weakness; D9 is neutral (doesn\'t confirm or deny it). Inconclusive — the weakness isn\'t strongly cross-verified.',
    'weak|weak': 'Confirmed weak — weak in both D1 and D9. A genuine concern, not just a one-chart artifact.'
  };

  return { d1Tier, d9Tier, isVargottama, read: MATRIX[`${d1Band}|${d9Band}`] };
}

function computeNavamsaAnalysis(bodies, d1DignityClassifications) {
  if (!bodies.Lagna || !bodies.Lagna.navamsaCode) {
    return { _warning: 'D9 Lagna (navamsa of Lagna) not available — cannot compute D9 analysis.' };
  }

  const d9Houses = computeD9Houses(bodies);
  const vargottama = computeVargottama(bodies);

  const d9Dignity = {};
  for (const planet of CLASSICAL_PLANETS) {
    if (!bodies[planet]) continue;
    d9Dignity[planet] = classifySignDignity(planet, bodies[planet].navamsaCode);
  }

  const confirmation = {};
  for (const planet of CLASSICAL_PLANETS) {
    if (!bodies[planet] || !d1DignityClassifications[planet]) continue;
    confirmation[planet] = compareD1D9(
      d1DignityClassifications[planet].tier,
      d9Dignity[planet].tier,
      vargottama[planet]?.isVargottama || false
    );
  }

  return {
    d9LagnaSign: d9Houses.d9LagnaSign,
    d9Houses: d9Houses.houses,
    d9Dignity,
    vargottama,
    confirmation,
    birthTimeCaveat: 'D9 positions are more sensitive to birth-time accuracy than D1 (each D1 sign spans 9 Navamsa divisions of ~3°20\' each). Treat this layer as supporting, not primary, unless birth time is independently confirmed reliable.',
    methodology: 'BPHS-documented D1-D9 confirmation principle, central to PVR\'s methodology. Vargottama = same sign in D1 and D9. Dignity here is sign-level only (no degree refinement, since only the D9 sign — not exact degree within it — is available from the parsed data).'
  };
}

module.exports = {
  computeNavamsaAnalysis,
  computeD9Houses,
  computeVargottama,
  classifySignDignity,
  compareD1D9
};
