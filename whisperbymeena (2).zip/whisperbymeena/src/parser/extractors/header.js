/**
 * Header Extractor (v2)
 * Handles real JHora PDF text including:
 *   - "Please enter your name and address here" placeholder
 *   - Page footers like "Meena 29 2" that bleed into header section
 *   - Name field which may have placeholder + actual name on separate lines
 */

const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];
const MONTH_INDEX = Object.fromEntries(MONTHS.map((m, i) => [m, i + 1]));

const PLACEHOLDER_PATTERNS = [
  /^Please enter your name and address here/i,
  /^Click here to enter/i,
  /^\d+$/  // Lines containing only a page number
];

function extractHeader(headerText) {
  const lines = headerText.split('\n').map(l => l.trim()).filter(Boolean);

  return {
    native: extractNative(lines),
    panchanga: extractPanchanga(lines)
  };
}

function extractNative(lines) {
  const native = {
    name: null,
    dateOfBirth: null,
    timeOfBirth: null,
    gmtOffset: null,
    coordinates: { latitude: null, longitude: null },
    placeOfBirth: null
  };

  // Find the date line — it anchors everything else
  let dateLineIdx = -1;
  for (let i = 0; i < lines.length; i++) {
    if (parseDateLine(lines[i])) {
      dateLineIdx = i;
      break;
    }
  }

  if (dateLineIdx === -1) return native;

  // Name = lines before date, EXCLUDING placeholders
  const nameLines = lines.slice(0, dateLineIdx)
    .filter(l => !PLACEHOLDER_PATTERNS.some(p => p.test(l)));
  native.name = nameLines.length > 0 ? nameLines.join(' ').trim() : null;

  // Date line
  native.dateOfBirth = parseDateLine(lines[dateLineIdx]);

  // Time line
  if (dateLineIdx + 1 < lines.length) {
    const t = parseTimeLine(lines[dateLineIdx + 1]);
    if (t) {
      native.timeOfBirth = t.time;
      native.gmtOffset = t.gmtOffset;
    }
  }

  // Coordinates line
  if (dateLineIdx + 2 < lines.length) {
    const c = parseCoordinatesLine(lines[dateLineIdx + 2]);
    if (c) {
      native.coordinates = c.coordinates;
      native.placeOfBirth = c.place;
    }
  }

  return native;
}

function extractPanchanga(lines) {
  const panchanga = {
    tithi: null, tithiRemaining: null,
    janmaNakshatra: null, nakshatraRemaining: null,
    vaar: null, yoga: null, karana: null, hora: null
  };

  for (const line of lines) {
    let m = line.match(/^Lunar day:\s*(.+?)\s*\(([\d.]+)%\s*left\)/);
    if (m) {
      panchanga.tithi = m[1].trim();
      panchanga.tithiRemaining = parseFloat(m[2]);
      continue;
    }
    m = line.match(/^Nakshatra:\s*(.+?)\s*\(([\d.]+)%\s*left\)/);
    if (m) {
      panchanga.janmaNakshatra = m[1].trim();
      panchanga.nakshatraRemaining = parseFloat(m[2]);
      continue;
    }
    m = line.match(/^(\w+day),\s*(.+?)\s*Yoga,\s*(.+?)\s*Karana,\s*(.+?)\s*Hora/i);
    if (m) {
      panchanga.vaar = m[1].trim();
      panchanga.yoga = m[2].trim();
      panchanga.karana = m[3].trim();
      panchanga.hora = m[4].trim();
    }
  }

  return panchanga;
}

function parseDateLine(line) {
  const m = line.match(/^([A-Z][a-z]+)\s+(\d{1,2}),\s+(\d{4})$/);
  if (!m) return null;
  const month = MONTH_INDEX[m[1]];
  if (!month) return null;
  return `${m[3]}-${String(month).padStart(2, '0')}-${m[2].padStart(2, '0')}`;
}

function parseTimeLine(line) {
  const m = line.match(/^(\d{1,2}):(\d{2}):(\d{2})\s+(am|pm)\s*\(([\d:.]+)\s*(East|West)\s+of\s+GMT\)/i);
  if (!m) return null;

  let hour = parseInt(m[1], 10);
  if (m[4].toLowerCase() === 'pm' && hour < 12) hour += 12;
  if (m[4].toLowerCase() === 'am' && hour === 12) hour = 0;

  const time = `${String(hour).padStart(2, '0')}:${m[2]}:${m[3]}`;
  const [offH, offM] = m[5].split(':');
  const sign = m[6].toLowerCase() === 'east' ? '+' : '-';
  const gmtOffset = `${sign}${String(parseInt(offH, 10)).padStart(2, '0')}:${(offM || '00').padStart(2, '0')}`;

  return { time, gmtOffset };
}

function parseCoordinatesLine(line) {
  const m = line.match(
    /(\d+)\s*([EW])\s*(\d+)'\s*([\d.]+)",\s*(\d+)\s*([NS])\s*(\d+)'\s*([\d.]+)"\s*\((.+)\)/
  );
  if (!m) return null;

  let lon = parseInt(m[1], 10) + parseInt(m[3], 10) / 60 + parseFloat(m[4]) / 3600;
  if (m[2] === 'W') lon = -lon;

  let lat = parseInt(m[5], 10) + parseInt(m[7], 10) / 60 + parseFloat(m[8]) / 3600;
  if (m[6] === 'S') lat = -lat;

  return {
    coordinates: {
      latitude: parseFloat(lat.toFixed(6)),
      longitude: parseFloat(lon.toFixed(6))
    },
    place: m[9].trim()
  };
}

module.exports = { extractHeader, parseDateLine, parseTimeLine, parseCoordinatesLine };
