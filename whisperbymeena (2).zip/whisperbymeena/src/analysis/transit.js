/**
 * GOCHAR (TRANSIT) -- MANUAL-INPUT VERSION
 *
 * ============================ WHY MANUAL INPUT ============================
 * Every other module in this tool works off STATIC birth-moment data
 * already computed by JHora -- pure classification/arithmetic on fixed
 * numbers, no astronomy required. Transit is fundamentally different: it
 * needs to know where planets ARE on an arbitrary date (today, or any
 * future date), which is a real astronomical computation (ephemeris), not
 * classification.
 *
 * This tool deliberately does NOT compute planetary positions itself.
 * Available JS ephemeris libraries (e.g. astronomia) have not been
 * validated here against a known-accurate reference, and a wrong
 * computed position -- especially near a sign boundary -- would silently
 * produce a wrong house and therefore a wrong classical result. Given
 * this tool's data-integrity standard ("never guess, never fabricate"),
 * the responsible choice is: the LEARNER supplies the transit positions
 * (from JHora or any source they trust), and this module does the
 * CLASSIFICATION -- which is exactly the kind of static math every other
 * module already does safely.
 *
 * A separate, clearly-labeled automatic-computation path (using a
 * validated ephemeris library) may be added later as an ADDITIONAL
 * option -- this manual module is not replaced by it, since manual input
 * remains the zero-computation-risk baseline.
 * =========================================================================
 *
 * CLASSICAL MECHANISM (source: BPHS-tradition textbook, Tables 53-59):
 *   1. Count the transiting planet's house position FROM THE NATAL MOON
 *      (Chandra Lagna) -- the primary classical reference for general
 *      transit results (Lagna-based and Arudha-based transit reading
 *      also exist classically but are not implemented here).
 *   2. Each house-from-Moon has a classical Good/Bad snapshot + typical
 *      result, per planet (Tables 53-59 in the reference text).
 *   3. Rahu's behavior is classically treated as similar to Saturn's,
 *      and Ketu's similar to Mars's (explicitly stated in the source --
 *      not a separate invented convention).
 *   4. Transit is a FINER TIME-RESOLUTION layer on top of dasha: dasha
 *      shows the broad active period; transit shows which specific
 *      stretch within that period is most active. This module does not
 *      attempt that dasha-transit synthesis -- it reports transit results
 *      on their own, for the Learner to weigh alongside the dasha
 *      timing already computed elsewhere in this tool.
 */

const { SIGN_INDEX, SIGN_ORDER, SIGN_CODES, computeHouse } = require('../parser/utils/constants');
const { classifyDignity } = require('./dignity');
const { ASPECT_OFFSETS, aspectedHouse } = require('./aspects');

/**
 * Classical transit-result tables -- House (from Moon) -> {snapshot, result}.
 * Source: reference textbook, Tables 53-59. Rahu uses Saturn's table,
 * Ketu uses Mars's table (per the explicit classical equivalence noted
 * in the source -- not invented here).
 */
const TRANSIT_TABLES = {
  Sun: {
    1: { snapshot: 'Bad', result: 'Financial loss, many travels, discomfort' },
    2: { snapshot: 'Bad', result: 'Unhappiness, eye troubles, fear' },
    3: { snapshot: 'Good', result: 'Wealth, good health, victory' },
    4: { snapshot: 'Bad', result: 'Marital disharmony, loss of name' },
    5: { snapshot: 'Bad', result: 'Bad health, fear from enemies' },
    6: { snapshot: 'Good', result: 'Success over enemies, good health' },
    7: { snapshot: 'Bad', result: 'Travels, physical pain' },
    8: { snapshot: 'Bad', result: 'Disease, setbacks in marriage' },
    9: { snapshot: 'Bad', result: 'Mental worries, obstacles' },
    10: { snapshot: 'Good', result: 'Success, honors, gains' },
    11: { snapshot: 'Good', result: 'Good health, prosperity, honors' },
    12: { snapshot: 'Bad', result: 'Expenditure, losses' }
  },
  Moon: {
    1: { snapshot: 'Good', result: 'Comfort, good spirits' },
    2: { snapshot: 'Bad', result: 'Obstacles, losses' },
    3: { snapshot: 'Good', result: 'Gains, happiness' },
    4: { snapshot: 'Bad', result: 'Lack of peace of mind, distrust' },
    5: { snapshot: 'Bad', result: 'Failures, disappointments, sadness' },
    6: { snapshot: 'Good', result: 'Happiness, health, wealth' },
    7: { snapshot: 'Good', result: 'Respect, gains' },
    8: { snapshot: 'Bad', result: 'Losses, tension, worries' },
    9: { snapshot: 'Bad', result: 'Mental uneasiness' },
    10: { snapshot: 'Good', result: 'Success, gains, authority' },
    11: { snapshot: 'Good', result: 'Prosperity, comforts, gains' },
    12: { snapshot: 'Bad', result: 'Injuries, expenditure, sadness' }
  },
  Mars: {
    1: { snapshot: 'Bad', result: 'Troubles, bodily afflictions' },
    2: { snapshot: 'Bad', result: 'Accidents, losses, thefts, quarrels' },
    3: { snapshot: 'Good', result: 'Gains, power, wealth' },
    4: { snapshot: 'Bad', result: 'Stomach problems, fevers, bad health' },
    5: { snapshot: 'Bad', result: 'Troubles from enemies, trouble with children' },
    6: { snapshot: 'Good', result: 'Success over enemies, wealth, well-being' },
    7: { snapshot: 'Bad', result: 'Quarrels, marital troubles, eye problems' },
    8: { snapshot: 'Bad', result: 'Worries, accidents, bad name, losses' },
    9: { snapshot: 'Bad', result: 'Losses, insults, illness' },
    10: { snapshot: 'Bad', result: 'Change of place, unexpected wealth' },
    11: { snapshot: 'Good', result: 'Authority, gains, good name' },
    12: { snapshot: 'Bad', result: 'Expenses, quarrels with wife, diseases' }
  },
  Mercury: {
    1: { snapshot: 'Bad', result: 'Quarrels, imprisonment, losses, poor advice' },
    2: { snapshot: 'Good', result: 'Success, wealth, gains' },
    3: { snapshot: 'Bad', result: 'Wandering, losses, trouble from authorities' },
    4: { snapshot: 'Good', result: 'Prosperity in family, gains' },
    5: { snapshot: 'Bad', result: 'Quarrels with wife and children, suffering' },
    6: { snapshot: 'Good', result: 'Renown, success, ornaments' },
    7: { snapshot: 'Bad', result: 'Quarrels, mental discomfort, addictions' },
    8: { snapshot: 'Good', result: 'Childbirth, happiness, gains, success' },
    9: { snapshot: 'Bad', result: 'Mental worries, obstacles' },
    10: { snapshot: 'Good', result: 'Money, happiness, domestic harmony, success' },
    11: { snapshot: 'Good', result: 'Childbirth, happiness, wealth' },
    12: { snapshot: 'Bad', result: 'Disease, domestic disharmony, losses' }
  },
  Jupiter: {
    1: { snapshot: 'Bad', result: 'Loss of money and intelligence, wandering' },
    2: { snapshot: 'Good', result: 'Happiness, domestic harmony, success' },
    3: { snapshot: 'Bad', result: 'Obstacles, loss of position, travels' },
    4: { snapshot: 'Bad', result: 'Troubles, defeat, losses' },
    5: { snapshot: 'Good', result: 'Childbirth, intelligence, prosperity, wealth' },
    6: { snapshot: 'Bad', result: 'Mental uneasiness, enemies, worries' },
    7: { snapshot: 'Good', result: 'Health, happiness, erotic pleasures, well-being' },
    8: { snapshot: 'Bad', result: 'Disease, imprisonment, illness, grief' },
    9: { snapshot: 'Good', result: 'Success, wealth, childbirth, religiousness' },
    10: { snapshot: 'Bad', result: 'Loss of position and money, ill-health, wandering' },
    11: { snapshot: 'Good', result: 'Recovery of health and position, happiness' },
    12: { snapshot: 'Bad', result: 'Fall from grace, misconduct' }
  },
  Venus: {
    1: { snapshot: 'Good', result: 'Comforts, pleasures, happiness, good spirits' },
    2: { snapshot: 'Good', result: 'Money, fortune, erotic pleasures, childbirth' },
    3: { snapshot: 'Good', result: 'Respect, wealth, good spirits' },
    4: { snapshot: 'Good', result: 'Prosperity, success over enemies, comforts' },
    5: { snapshot: 'Good', result: 'Fame, power, good name' },
    6: { snapshot: 'Bad', result: 'Loss of fame, bad name, quarrels' },
    7: { snapshot: 'Bad', result: 'Humiliation, disease, troubles' },
    8: { snapshot: 'Bad', result: 'Fears, mental worries, injuries, troubles from women' },
    9: { snapshot: 'Good', result: 'Fortune, luxuries, marital happiness' },
    10: { snapshot: 'Bad', result: 'Troubles, unpleasant events, disgrace' },
    11: { snapshot: 'Good', result: 'Gains, happiness, prosperity, comforts' },
    12: { snapshot: 'Bad', result: 'New friends, money, pleasures, gains' }
  },
  Saturn: {
    1: { snapshot: 'Bad', result: 'Fear of incarceration, worries, foreign trips' },
    2: { snapshot: 'Bad', result: 'Physical weakness, discomfort, unhappiness' },
    3: { snapshot: 'Good', result: 'Wealth, health, happiness, all-round success' },
    4: { snapshot: 'Bad', result: 'Stomach problems, separation from family' },
    5: { snapshot: 'Bad', result: 'Separation from children, uneasiness, quarrels' },
    6: { snapshot: 'Good', result: 'Freedom from disease and enemies, success' },
    7: { snapshot: 'Bad', result: 'Wandering, quarrels with spouse, trouble from authorities' },
    8: { snapshot: 'Bad', result: 'Suffering, loss of status and balance, imprisonment' },
    9: { snapshot: 'Bad', result: 'Diseases, suffering, loss of status' },
    10: { snapshot: 'Bad', result: 'Loss of money, bad name, career changes, laziness' },
    11: { snapshot: 'Good', result: 'Wealth, success, gains' },
    12: { snapshot: 'Bad', result: 'Grief, misery, losses, ill-health, frustration' }
  }
};
// Per the source: "Rahu's behavior is similar to that of Saturn's and
// Ketu's behavior to Mars's" -- not a separate invented convention.
TRANSIT_TABLES.Rahu = TRANSIT_TABLES.Saturn;
TRANSIT_TABLES.Ketu = TRANSIT_TABLES.Mars;

const TRANSIT_PLANETS = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn', 'Rahu', 'Ketu'];

/**
 * House-from-Moon: count from the natal Moon's sign to the transiting
 * planet's CURRENT sign.
 */
function houseFromMoon(moonSignCode, transitSignCode) {
  return ((SIGN_INDEX[transitSignCode] - SIGN_INDEX[moonSignCode] + 12) % 12) + 1;
}

/**
 * CHART-SPECIFIC ADJUSTMENT (the textbook's own caveat, actually implemented)
 *
 * The classical Good/Bad tables above are GENERIC -- same for every chart.
 * But classical principle (and the reference textbook's own note) is that
 * a transiting planet's result is colored by what that planet MEANS for
 * THIS specific native: a planet that is this chart's Yogakaraka or a
 * Functional Benefic tends to soften "bad" classical results and amplify
 * "good" ones; a Functional Malefic tends to do the reverse. The planet's
 * CURRENT transiting dignity (is it exalted, debilitated, etc. in the
 * sign it's passing through right now) adds a second, independent
 * adjustment in the same direction.
 *
 * This produces a SEPARATE "chart-adjusted" reading alongside the
 * classical generic one -- it never silently overrides the classical
 * table, both are always shown with their own reasoning.
 */
function functionalNatureModifier(functionalNature, planet) {
  const c = functionalNature && functionalNature.classifications ? functionalNature.classifications[planet] : null;
  if (!c) return { tier: 'Unknown', direction: 0, detail: 'No functional-nature data for ' + planet + ' in this chart.' };
  if (c.isYogakaraka) return { tier: 'Yogakaraka', direction: 2, detail: planet + ' is this chart\'s Yogakaraka -- its transits tend to be read more favorably than the generic table alone suggests.' };
  if (c.classification === 'Functional Benefic') return { tier: 'Functional Benefic', direction: 1, detail: planet + ' is a Functional Benefic for this Lagna -- favorable lean on its transits.' };
  if (c.classification === 'Functional Malefic') return { tier: 'Functional Malefic', direction: -1, detail: planet + ' is a Functional Malefic for this Lagna -- unfavorable lean on its transits.' };
  if (c.classification === 'Mild Functional Malefic') return { tier: 'Mild Functional Malefic', direction: -0.5, detail: planet + ' is a Mild Functional Malefic for this Lagna -- a slight unfavorable lean on its transits.' };
  return { tier: c.classification || 'Neutral', direction: 0, detail: planet + ' is functionally neutral for this Lagna -- no strong lean either way.' };
}

function transitDignityModifier(planet, signCode, degreeInSign) {
  const usedDefault = degreeInSign === undefined || degreeInSign === null;
  const d = classifyDignity(planet, signCode, usedDefault ? 15 : degreeInSign);
  let direction = 0;
  if (['Exalted', 'Moolatrikona'].includes(d.tier)) direction = 1.5;
  else if (d.tier === 'Own Sign (Swakshetra)') direction = 1;
  else if (d.tier === 'Debilitated') direction = -1.5;
  else if (d.tier === "Enemy's Sign") direction = -1;
  return {
    tier: d.tier,
    direction: direction,
    approximated: usedDefault,
    detail: planet + ' is transiting ' + d.tier + (usedDefault ? ' (degree not supplied -- assumed mid-sign, so this tier may be imprecise near a sign boundary)' : '') + '.'
  };
}

/**
 * ASHTAKAVARGA MODIFIER -- classically, Ashtakavarga (specifically a
 * planet's own Bhinnashtakavarga bindu-count in the sign it is currently
 * transiting, plus the Sarvashtakavarga total for that sign) is the
 * PRIMARY classical tool for assessing transit strength -- arguably more
 * authoritative than the simple house-from-Moon table alone. A planet
 * transiting a sign where it holds few bindus in its own Bhinnashtakavarga
 * is considered weak there regardless of what the generic table says;
 * many bindus (classically ~5+ of 8) is considered favorable. The same
 * applies to Sarvashtakavarga for that sign as a broader strength check.
 *
 * Thresholds used here (BAV >=5 favorable / <=3 weak; SAV >=30 favorable
 * / <=25 weak) are commonly-cited classical guidelines, not a single
 * universally-fixed standard -- different classical sub-traditions state
 * slightly different cutoffs, so this is marked 'interpretive', not
 * 'direct'.
 */
function ashtakavargaModifier(strengths, planet, signCode) {
  const bhinna = strengths && strengths.ashtakavarga && strengths.ashtakavarga.bhinna ? strengths.ashtakavarga.bhinna[planet] : null;
  const sarva = strengths && strengths.ashtakavarga ? strengths.ashtakavarga.sarva : null;
  if (!bhinna || !sarva) {
    return { direction: 0, bav: null, sav: null, detail: 'No Ashtakavarga data available for this chart.' };
  }

  const signIdx = SIGN_INDEX[signCode];
  const bav = bhinna[signIdx];
  const sav = sarva[signIdx];
  let direction = 0;
  const notes = [];

  if (bav >= 5) { direction += 1; notes.push(planet + '\'s own Bhinnashtakavarga here is ' + bav + '/8 (favorable, classically >=5)'); }
  else if (bav <= 3) { direction -= 1; notes.push(planet + '\'s own Bhinnashtakavarga here is ' + bav + '/8 (weak, classically <=3)'); }
  else { notes.push(planet + '\'s own Bhinnashtakavarga here is ' + bav + '/8 (moderate)'); }

  if (sav >= 30) { direction += 0.5; notes.push('Sarvashtakavarga for this sign is ' + sav + ' (favorable, classically >=30)'); }
  else if (sav <= 25) { direction -= 0.5; notes.push('Sarvashtakavarga for this sign is ' + sav + ' (weak, classically <=25)'); }
  else { notes.push('Sarvashtakavarga for this sign is ' + sav + ' (moderate)'); }

  return { direction: direction, bav: bav, sav: sav, detail: notes.join('; ') + '.' };
}

/**
 * EVENT-DOMAIN CONNECTION -- checks whether the transiting planet (at its
 * CURRENT house from natal Lagna, not from Moon -- Lagna is the standard
 * reference for "which life-area is this touching") connects to any of
 * the 8 predictive-engine life-domains (promise.js's EVENT_DEFINITIONS),
 * via occupancy of that domain's house, transit-aspect onto it (using the
 * same classical drishti rules as the natal aspects module), or being
 * that domain's natural karaka.
 *
 * This mirrors dasha-activation.js's getRelevance logic but for a
 * TRANSITING position rather than a dasha lord's natal placement.
 */
function connectToEventDomains(planet, lagnaSignCode, transitSignCode) {
  const { EVENT_DEFINITIONS } = require('./promise');
  const transitHouse = computeHouse(lagnaSignCode, transitSignCode);
  if (!transitHouse) return [];

  const offsets = ASPECT_OFFSETS[planet] || [];
  const aspectedHouses = offsets.map(function (o) { return aspectedHouse(transitHouse, o); });

  const connections = [];
  for (const eventKey of Object.keys(EVENT_DEFINITIONS)) {
    const def = EVENT_DEFINITIONS[eventKey];
    const allHouses = def.houses.concat(def.secondaryHouses || []);
    const reasons = [];
    if (allHouses.includes(transitHouse)) reasons.push('transiting through house ' + transitHouse + ' (' + (def.houses.includes(transitHouse) ? 'primary' : 'secondary') + ')');
    const aspectMatch = aspectedHouses.filter(function (h) { return allHouses.includes(h); });
    if (aspectMatch.length) reasons.push('aspecting house ' + aspectMatch.join(',') + ' by transit-drishti');
    if (def.karakas.includes(planet)) reasons.push('is the karaka for ' + def.label);
    if (reasons.length) connections.push({ event: eventKey, label: def.label, reasons: reasons });
  }
  return connections;
}

/**
 * DESH-KAAL-PATRA (AGE / LIFE-STAGE CONTEXT)
 *
 * Classical principle: the SAME transit/dasha result reads differently
 * depending on the native's place, time, and PERSON (desh-kaal-patra) --
 * a "childbirth" indication has a different plausible meaning for a
 * native at 25 than for one at 76. Generic classical tables don't encode
 * this; this module adds a GENTLE, NON-PRESUMPTUOUS note when an event-
 * domain's classical result seems biologically/socially unlikely at the
 * native's current age -- it never asserts the event "won't" happen
 * (the chart doesn't know the native's actual life history -- existing
 * marriage, children, retirement status, etc. -- so confident claims here
 * would be a data-integrity violation), only flags age-based plausibility
 * as something worth weighing, and suggests alternate readings.
 *
 * ============================ HONESTY NOTE ============================
 * This is INTENTIONALLY conservative: wide age bands, hedged language
 * ("classically less typical," "consider whether"), and explicit
 * acknowledgment that exceptions are real (remarriage, adoption, late
 * education, career changes post-retirement, etc. all happen). The goal
 * is to prevent a literal, decontextualized reading (e.g. presenting a
 * "childbirth" result to a 76-year-old with no context) -- not to make
 * confident claims about what stage of life the native is actually in.
 * =========================================================================
 */
const AGE_CONTEXT_NOTES = {
  children: {
    typicalRange: [18, 50],
    note: 'a classical "childbirth" indication at this age is less typical in the literal sense -- consider whether it may instead point toward grandchildren, a creative/intellectual "offspring" (a project, book, institution), mentorship of a younger person, or simply may not be the most direct reading right now.'
  },
  marriage: {
    typicalRange: [18, 55],
    note: 'a classical "marriage" indication at this age, if the native is not already partnered, may point to companionship, a significant new relationship, or a renewal/deepening of an existing partnership rather than a first marriage in the conventional sense -- context matters here more than the table alone.'
  },
  education: {
    typicalRange: [5, 35],
    note: 'a classical "education" indication at this age less often means formal degree-seeking -- consider whether it points toward teaching/mentoring others, self-directed study, or a spiritual/philosophical learning phase instead.'
  },
  career: {
    typicalRange: [18, 65],
    note: 'a classical "career" indication at this age (often past typical retirement) may point toward consulting, advisory roles, a passion project, or renewed engagement with existing work rather than a literal new job search.'
  }
};

function computeAgeAtDate(birthDateStr, asOfDateStr) {
  if (!birthDateStr || !asOfDateStr) return null;
  const birth = new Date(birthDateStr);
  const asOf = new Date(asOfDateStr);
  if (isNaN(birth.getTime()) || isNaN(asOf.getTime())) return null;
  let age = asOf.getFullYear() - birth.getFullYear();
  const monthDiff = asOf.getMonth() - birth.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && asOf.getDate() < birth.getDate())) age--;
  return age;
}

/**
 * Filter event connections by age appropriateness.
 * Age-inappropriate events are removed entirely — not annotated.
 * Only events clearly outside age range with hard limits are removed.
 * Events with soft limits get a note but stay visible.
 */
function annotateWithAgeContext(eventConnections, age) {
  if (age === null || age === undefined) return eventConnections;

  // Hard age limits — remove these events entirely if outside range
  const HARD_AGE_LIMITS = {
    education:    { earliest: 5,  latest: 38  },
    graduation:   { earliest: 14, latest: 40  },
    scholarship:  { earliest: 12, latest: 36  },
    children:     { earliest: 18, latest: 50  },
    firstJob:     { earliest: 17, latest: 36  },
    retirement:   { earliest: 45, latest: 100 },
    deathOfFather:{ earliest: 10, latest: 100 },
    deathOfMother:{ earliest: 10, latest: 100 },
    addiction:    { earliest: 12, latest: 80  },
  };

  return eventConnections
    .filter(function(conn) {
      const limit = HARD_AGE_LIMITS[conn.event];
      if (!limit) return true; // no hard limit, keep it
      return age >= limit.earliest && age <= limit.latest;
    })
    .map(function(conn) {
      // Soft notes for borderline cases
      const ctx = AGE_CONTEXT_NOTES[conn.event];
      if (!ctx) return conn;
      const [minAge, maxAge] = ctx.typicalRange;
      // Only show note if age is within 2 years of upper boundary
      if (age > maxAge - 2 && age <= maxAge) {
        return Object.assign({}, conn, {
          ageContextNote: 'Age ' + age + ': ' + ctx.note
        });
      }
      return conn;
    });
}

function combinedLabel(score) {
  if (score >= 3) return 'Strongly favorable (chart-adjusted)';
  if (score > 0.5) return 'Mildly favorable (chart-adjusted)';
  if (score >= -0.5) return 'Neutral / mixed (chart-adjusted)';
  if (score > -3) return 'Mildly challenging (chart-adjusted)';
  return 'Strongly challenging (chart-adjusted)';
}

/**
 * Build the chart-adjusted reading for one planet's transit, combining
 * the classical snapshot with all three modifiers above.
 */
function adjustForChart(planet, classicalSnapshot, functionalNature, signCode, degreeInSign, strengths) {
  const baseScore = classicalSnapshot === 'Good' ? 1 : classicalSnapshot === 'Bad' ? -1 : 0;
  const fnMod = functionalNatureModifier(functionalNature, planet);
  const dignityMod = transitDignityModifier(planet, signCode, degreeInSign);
  const avMod = ashtakavargaModifier(strengths, planet, signCode);
  const combined = baseScore + fnMod.direction + dignityMod.direction + avMod.direction;

  return {
    label: combinedLabel(combined),
    combinedScore: Number(combined.toFixed(2)),
    breakdown: [
      { label: 'Classical table (generic)', value: baseScore, reason: 'Classical Good/Bad table says "' + classicalSnapshot + '" for this house-from-Moon.' },
      { label: 'Functional nature (this chart)', value: fnMod.direction, reason: fnMod.detail },
      { label: 'Transit dignity (this moment)', value: dignityMod.direction, reason: dignityMod.detail },
      { label: 'Ashtakavarga (BAV/SAV)', value: avMod.direction, reason: avMod.detail }
    ]
  };
}

/**
 * Analyze a manually-supplied set of transit positions against a natal
 * chart's Moon.
 *
 * @param {object} natalChart - parsed chart (needs .bodies.Moon.signCode)
 * @param {object} transitPositions - { Sun: 'Ar', Moon: 'Ta', ... } sign
 *   codes for each transiting planet, as supplied by the Learner
 * @param {string} asOfDate - the date these positions are valid for
 *   (informational only -- not computed by this tool)
 */
function analyzeTransit(natalChart, transitPositions, asOfDate) {
  const moonSignCode = natalChart && natalChart.bodies && natalChart.bodies.Moon ? natalChart.bodies.Moon.signCode : null;
  if (!moonSignCode) {
    return { _warning: 'Natal Moon sign not found -- cannot compute Gochar (transit needs Chandra Lagna as reference).' };
  }
  const functionalNature = natalChart.analysis ? natalChart.analysis.functionalNature : null;
  const strengths = natalChart.strengths || null;
  const lagnaSignCode = natalChart.bodies.Lagna ? natalChart.bodies.Lagna.signCode : null;

  const results = {};
  const warnings = [];

  for (const planet of TRANSIT_PLANETS) {
    const rawInput = transitPositions[planet];
    if (!rawInput) {
      warnings.push(planet + ': no transit position supplied -- skipped.');
      continue;
    }
    // Accept either a plain sign-code string (manual input) or an
    // { signCode, degreeInSign } object (auto-compute, more precise).
    const signCode = typeof rawInput === 'string' ? rawInput : rawInput.signCode;
    const degreeInSign = typeof rawInput === 'object' ? rawInput.degreeInSign : undefined;

    if (!(signCode in SIGN_INDEX)) {
      warnings.push('"' + signCode + '" is not a recognized sign code for ' + planet + ' -- skipped.');
      continue;
    }

    const house = houseFromMoon(moonSignCode, signCode);
    const table = TRANSIT_TABLES[planet];
    const entry = table ? table[house] : null;
    const snapshot = entry ? entry.snapshot : null;

    const chartAdjusted = snapshot
      ? adjustForChart(planet, snapshot, functionalNature, signCode, degreeInSign, strengths)
      : null;

    const eventConnections = lagnaSignCode ? connectToEventDomains(planet, lagnaSignCode, signCode) : [];
    const ageAtDate = computeAgeAtDate(natalChart.native ? natalChart.native.dateOfBirth : null, asOfDate);
    const annotatedConnections = annotateWithAgeContext(eventConnections, ageAtDate);

    results[planet] = {
      transitSign: SIGN_CODES[signCode] || signCode,
      houseFromMoon: house,
      snapshot: snapshot,
      result: entry ? entry.result : null,
      chartAdjusted: chartAdjusted,
      eventConnections: annotatedConnections
    };
  }

  return {
    asOfDate: asOfDate || null,
    nativeAge: computeAgeAtDate(natalChart.native ? natalChart.native.dateOfBirth : null, asOfDate),
    natalMoonSign: SIGN_CODES[moonSignCode] || moonSignCode,
    results: results,
    warnings: warnings,
    methodology: 'Classical Gochar reading: each transiting planet\'s house FROM THE NATAL MOON (Chandra Lagna), matched against classical Good/Bad result tables for that house (source: BPHS-tradition reference text, Tables 53-59; Rahu follows Saturn\'s table, Ketu follows Mars\'s). Each result is further layered: a CHART-ADJUSTED reading (functional nature + transit dignity + Ashtakavarga BAV/SAV for this chart specifically), an EVENT-DOMAIN CONNECTION check (which of the 8 predictive-engine life-domains this transit touches, by occupancy, aspect, or karakatva), and an AGE-CONTEXT note (desh-kaal-patra) when a domain\'s classical result seems atypical for the native\'s age at this date.',
    caveat: 'The classical "snapshot/result" columns are GENERIC, same for every chart -- the chart-adjusted reading is the one that accounts for THIS chart specifically. Transit is also a finer time layer ON TOP OF dasha timing, not a replacement for it -- weigh this alongside the Dasha Activation / Convergence results already computed elsewhere in this tool. Age-context notes are deliberately gentle and non-presumptuous -- they flag a result as worth re-reading in context, never assert what life-stage the native is actually in (the chart doesn\'t know their marital/parental/employment history). For manually-entered positions, accuracy depends entirely on the source you used to look them up.'
  };
}

module.exports = { analyzeTransit, houseFromMoon, TRANSIT_TABLES, TRANSIT_PLANETS, adjustForChart, functionalNatureModifier, transitDignityModifier, ashtakavargaModifier, connectToEventDomains, computeAgeAtDate, annotateWithAgeContext };
