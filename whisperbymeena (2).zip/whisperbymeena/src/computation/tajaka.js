/**
 * Tajaka Annual Chart (Varshaphal / Solar Return)
 * 
 * Source: PVR Narasimha Rao "Vedic Astrology: An Integrated Approach"
 * Part 4: Tajaka Analysis, Ch.27-31
 * 
 * Key principles:
 *   1. When Sun returns to exact natal longitude → new year begins (Ch.27.1)
 *   2. Chart cast at birthplace coordinates always, not current location (p.368)
 *   3. Annual chart gives finer insight than natal — but only confirms natal promise
 *   4. Muntha (progressed Lagna) is very important in Tajaka (audio lesson p.40)
 *   5. Sudarshana Chakra: analyze from Lagna, Moon, AND Sun (Ch.31.2)
 *   6. SC Dasa: 12-year cycle, house dasa based on (year % 12) (Ch.31.3)
 * 
 * Tajaka aspects (different from Parashari):
 *   Deeptamsha (strong aspect orbs) — within 7° for all aspects
 *   Square (90°), Trine (120°), Opposition (180°), Sextile (60°) — all considered
 * 
 * Note on precision (p.427):
 *   "Using approximate formula for ayanamsa brings minor discrepancy in Sun's longitude
 *    which is multiplied by 360 in longitude of lagna. This results in serious error."
 *   We use VSOP87 + Lahiri for precision.
 */

'use strict';

const { computeFullHoroscope } = require('../analysis/ephemeris');

const SIGN_CODES = ['Ar','Ta','Ge','Cn','Le','Vi','Li','Sc','Sg','Cp','Aq','Pi'];
const SIGN_LORDS = {
  Ar:'Mars',Ta:'Venus',Ge:'Mercury',Cn:'Moon',Le:'Sun',Vi:'Mercury',
  Li:'Venus',Sc:'Mars',Sg:'Jupiter',Cp:'Saturn',Aq:'Saturn',Pi:'Jupiter'
};

// ── Solar Return Time Finder ───────────────────────────────────────────────────

/**
 * Find exact UTC millisecond when Sun returns to natal longitude in a given year.
 * Uses binary search on ephemeris — sub-second accuracy.
 * 
 * @param {number} natalSunLon - natal Sun sidereal longitude (0-360)
 * @param {number} year        - target year (CE)
 * @param {number} latitude    - birthplace latitude
 * @param {number} longitude   - birthplace longitude
 * @param {number} gmtOffset   - birthplace GMT offset (hours)
 * @returns {object} { utcMs, isoString, localDatetime }
 */
function findSolarReturn(natalSunLon, year, latitude, longitude, gmtOffset) {
  // Start search 5 days before expected solar return (same calendar date as birth)
  // Sun moves ~1°/day so natal longitude recurs within ±5 days of birthday
  const approxDate = new Date(Date.UTC(year, 5, 15)); // mid-year start
  // Better: estimate from birth month — Sun at natal lon happens near same month
  const birthMonth = estimateBirthMonth(natalSunLon);
  let searchStart = Date.UTC(year, birthMonth - 1, 1);
  let searchEnd   = Date.UTC(year, birthMonth, 10); // 40 days window

  // Binary search — 50 iterations gives microsecond precision
  let lo = searchStart;
  let hi = searchEnd;

  for (let i = 0; i < 60; i++) {
    const mid = Math.floor((lo + hi) / 2);
    const d   = new Date(mid);
    const h   = computeFullHoroscope({
      year: d.getUTCFullYear(), month: d.getUTCMonth() + 1, day: d.getUTCDate(),
      hour: d.getUTCHours(), minute: d.getUTCMinutes(), second: d.getUTCSeconds(),
      gmtOffsetHours: 0
    }, latitude, longitude);

    let diff = h.planets.Sun.siderealLongitude - natalSunLon;
    if (diff > 180) diff -= 360;
    if (diff < -180) diff += 360;

    if (diff < 0) lo = mid;
    else hi = mid;
  }

  const utcMs = Math.round((lo + hi) / 2);
  const utcDate = new Date(utcMs);

  // Convert to local time
  const localMs = utcMs + gmtOffset * 3600 * 1000;
  const localDate = new Date(localMs);

  return {
    utcMs,
    utcISO: utcDate.toISOString(),
    localISO: localDate.toISOString().replace('Z', ''),
    localYear: localDate.getUTCFullYear(),
    localMonth: localDate.getUTCMonth() + 1,
    localDay: localDate.getUTCDate(),
    localHour: localDate.getUTCHours(),
    localMinute: localDate.getUTCMinutes(),
    localSecond: localDate.getUTCSeconds(),
  };
}

function estimateBirthMonth(natalSunLon) {
  // Sun longitude → approximate calendar month
  // 0° (Ar) = ~Apr 14, 30° (Ta) = ~May 14, etc. (sidereal)
  // Sidereal 0 Ar ≈ April 14 (Lahiri ayanamsa ~24°)
  const months = [4,5,6,7,8,9,10,11,12,1,2,3];
  const signIdx = Math.floor(natalSunLon / 30);
  return months[signIdx % 12] || 7;
}

// ── Muntha Computation ─────────────────────────────────────────────────────────

/**
 * Muntha = progressed Lagna.
 * Advances 1 sign per year from natal Lagna.
 * At age N, Muntha is in (natal_lagna + N - 1) sign.
 * 
 * Source: PVR audio lessons p.40: "Muntha is very important in Tajaka chart"
 */
function computeMuntha(natalLagnaSign, age) {
  const lagnaIdx    = SIGN_CODES.indexOf(natalLagnaSign);
  const munthaIdx   = (lagnaIdx + age - 1) % 12;
  const munthaSign  = SIGN_CODES[munthaIdx];
  const munthaLord  = SIGN_LORDS[munthaSign];
  return {
    sign:   munthaSign,
    index:  munthaIdx,
    lord:   munthaLord,
    age,
    description: `Muntha at age ${age}: ${munthaSign} (lord: ${munthaLord})`
  };
}

// ── Sudarshana Chakra Dasa ────────────────────────────────────────────────────

/**
 * SC Dasa = 12-year cycle based on year number.
 * House dasa = (years_completed % 12) with 0→12 correction.
 * 
 * Source: PVR Ch.31.3
 * "Divide year number by 12, remainder = house whose dasa runs"
 */
function computeSCDasa(age, lagnaSign, moonSign, sunSign) {
  const remainder = age % 12 || 12; // if 0, make 12

  const lagnaIdx = SIGN_CODES.indexOf(lagnaSign);
  const moonIdx  = SIGN_CODES.indexOf(moonSign);
  const sunIdx   = SIGN_CODES.indexOf(sunSign);

  const dasaFromLagna = SIGN_CODES[(lagnaIdx + remainder - 1) % 12];
  const dasaFromMoon  = SIGN_CODES[(moonIdx  + remainder - 1) % 12];
  const dasaFromSun   = SIGN_CODES[(sunIdx   + remainder - 1) % 12];

  return {
    age,
    houseNumber: remainder,
    dasaFromLagna,
    dasaFromMoon,
    dasaFromSun,
    description: `SC Dasa H${remainder}: from Lagna=${dasaFromLagna}, Moon=${dasaFromMoon}, Sun=${dasaFromSun}`
  };
}

// ── Annual Tajaka Chart ────────────────────────────────────────────────────────

/**
 * Compute complete Tajaka annual chart for a given year.
 * 
 * @param {object} nativeData - { year, month, day, hour, minute, second, gmtOffsetHours, latitude, longitude }
 * @param {number} targetYear - the year to compute annual chart for
 * @returns {object} complete Tajaka annual chart
 */
function computeTajakaChart(nativeData, targetYear) {
  const { year:bYear, month:bMonth, day:bDay, hour:bHour, minute:bMin, second:bSec,
          gmtOffsetHours, latitude, longitude } = nativeData;

  // Step 1: Get natal Sun longitude
  const natalChart = computeFullHoroscope({
    year:bYear, month:bMonth, day:bDay,
    hour:bHour, minute:bMin, second:bSec||0,
    gmtOffsetHours
  }, latitude, longitude);

  const natalSunLon  = natalChart.planets.Sun.siderealLongitude;
  const natalLagnaSc = natalChart.lagna.signCode;
  const natalMoonSc  = natalChart.lagna.signCode; // will update from natal body

  // Step 2: Find exact solar return time
  const solarReturn = findSolarReturn(natalSunLon, targetYear, latitude, longitude, gmtOffsetHours);

  // Step 3: Compute Tajaka chart at solar return moment (birthplace always)
  const tajakaRaw = computeFullHoroscope({
    year:   solarReturn.localYear,
    month:  solarReturn.localMonth,
    day:    solarReturn.localDay,
    hour:   solarReturn.localHour,
    minute: solarReturn.localMinute,
    second: solarReturn.localSecond,
    gmtOffsetHours
  }, latitude, longitude);

  // Step 4: Age at this solar return
  const age = targetYear - bYear;

  // Step 5: Muntha
  const muntha = computeMuntha(natalLagnaSc, age);

  // Step 6: SC Dasa
  const natalMoon = Object.values(natalChart.planets||{}).find(p => p.name === 'Moon') || natalChart.planets?.Moon;
  const natalSun  = natalChart.planets?.Sun;
  const scDasa = computeSCDasa(
    age,
    natalChart.lagna.signCode,
    natalChart.planets?.Moon?.signCode || 'Ar',
    natalChart.planets?.Sun?.signCode  || 'Ar'
  );

  // Step 7: Build planet positions for annual chart
  const annualBodies = {};
  const PLANET_NAMES = ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn','Rahu','Ketu'];
  PLANET_NAMES.forEach(p => {
    const planet = tajakaRaw.planets?.[p];
    if (!planet) return;
    const sigIdx = SIGN_CODES.indexOf(planet.signCode);
    const lagnaIdx = SIGN_CODES.indexOf(tajakaRaw.lagna.signCode);
    const house = ((sigIdx - lagnaIdx + 12) % 12) + 1;
    annualBodies[p] = {
      signCode: planet.signCode,
      longitudeInSign: planet.degreeInSign,
      siderealLongitude: planet.siderealLongitude,
      house,
      retrograde: planet.retrograde || false,
    };
  });

  const natalLagnaSign  = natalChart.lagna.signCode;
  const natalLagnaIdx   = SIGN_CODES.indexOf(natalLagnaSign);
  const annualLagnaIdx  = SIGN_CODES.indexOf(tajakaRaw.lagna.signCode);
  const annualLagnaFromNatal = ((annualLagnaIdx - natalLagnaIdx + 12) % 12) + 1;

  // Step 9: Key Tajaka indicators
  const tajaka = {
    year:        targetYear,
    age,
    solarReturn: solarReturn.localISO,
    solarReturnUTC: solarReturn.utcISO,

    // Annual chart basics
    lagna:     tajakaRaw.lagna,
    bodies:    annualBodies,
    natalSunLon: +natalSunLon.toFixed(6),

    // Tajaka-specific
    muntha,
    scDasa,

    // Natal comparison
    annualLagnaFromNatal,
    annualLagnaSign: tajakaRaw.lagna.signCode,
    natalLagnaSign,

    // Year themes
    yearThemes: analyzeYearThemes(annualBodies, tajakaRaw.lagna.signCode, muntha, scDasa),
  };

  return tajaka;
}

// ── Year Theme Analysis ────────────────────────────────────────────────────────

/**
 * Analyze key themes for the year from Tajaka chart.
 * Based on PVR audio lesson rules (p.40-41).
 */
function analyzeYearThemes(bodies, lagnaSign, muntha, scDasa) {
  const themes = [];
  const lagnaIdx = SIGN_CODES.indexOf(lagnaSign);

  const NATURAL_BENEFICS  = new Set(['Jupiter','Venus']);
  const NATURAL_MALEFICS  = new Set(['Saturn','Mars','Rahu','Ketu']);

  Object.entries(bodies).forEach(([planet, body]) => {
    const house = body.house;
    const isBenefic = NATURAL_BENEFICS.has(planet);
    const isMalefic = NATURAL_MALEFICS.has(planet);

    // PVR audio p.40 rules:
    // Benefics in kendras (1,4,7,10), trikonas (1,5,9), 8th = good
    // Benefics in 3rd, 6th = bad
    // Malefics in 3rd, 6th, 11th = good
    // Malefics in 8th = unexpected results

    if (isBenefic) {
      if ([1,4,7,10,5,9].includes(house)) {
        themes.push({ planet, house, quality:'favorable', reason:`${planet} (benefic) in H${house} — kendra/trikona, good results` });
      } else if ([3,6].includes(house)) {
        themes.push({ planet, house, quality:'unfavorable', reason:`${planet} (benefic) in H${house} — upachaya, mixed for benefic` });
      } else if (house === 8) {
        themes.push({ planet, house, quality:'mixed', reason:`${planet} (benefic) in H8 — supports longevity but with transformation` });
      }
    }

    if (isMalefic) {
      if ([3,6,11].includes(house)) {
        themes.push({ planet, house, quality:'favorable', reason:`${planet} (malefic) in H${house} — strong position for malefic` });
      } else if (house === 8) {
        themes.push({ planet, house, quality:'unexpected', reason:`${planet} (malefic) in H8 — sudden/unexpected results this year` });
      } else if ([1,4,7,10,5,9].includes(house)) {
        themes.push({ planet, house, quality:'challenging', reason:`${planet} (malefic) in H${house} — challenging for kendra/trikona` });
      }
    }
  });

  // Muntha house analysis
  const munthaHouseFromLagna = ((SIGN_CODES.indexOf(muntha.sign) - SIGN_CODES.indexOf(lagnaSign) + 12) % 12) + 1;
  themes.push({
    planet: 'Muntha',
    house: munthaHouseFromLagna,
    quality: [1,4,5,7,9,10,11].includes(munthaHouseFromLagna) ? 'favorable' : 'challenging',
    reason: `Muntha in ${muntha.sign} (H${munthaHouseFromLagna}) — key annual reference point`
  });

  // SC Dasa house
  themes.push({
    planet: 'SC_Dasa',
    house: scDasa.houseNumber,
    quality: 'theme',
    reason: `SC Dasa H${scDasa.houseNumber} — ${scDasa.dasaFromLagna} from Lagna, ${scDasa.dasaFromMoon} from Moon, ${scDasa.dasaFromSun} from Sun`
  });

  return themes;
}

/**
 * Compute multiple Tajaka charts for a range of years.
 * 
 * @param {object} nativeData
 * @param {number} fromYear
 * @param {number} toYear
 * @returns {object[]} array of annual charts
 */
function computeTajakaRange(nativeData, fromYear, toYear) {
  const charts = [];
  for (let year = fromYear; year <= toYear; year++) {
    try {
      const chart = computeTajakaChart(nativeData, year);
      charts.push(chart);
    } catch(e) {
      charts.push({ year, error: e.message });
    }
  }
  return charts;
}

module.exports = { computeTajakaChart, computeTajakaRange, computeMuntha, computeSCDasa, findSolarReturn };
