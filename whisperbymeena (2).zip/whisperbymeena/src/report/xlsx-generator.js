/**
 * Excel Workbook Generator
 *
 * Produces a real .xlsx (multi-worksheet) that opens directly in Excel AND
 * Google Sheets — no import/conversion step. Where the HTML report is for
 * READING, this workbook is for ANALYSIS: every sheet is a clean tabular
 * dataset you can filter, sort, pivot, and compare across charts.
 *
 * Sheet design philosophy:
 *  - Each sheet is a flat table with a header row (filter-ready).
 *  - "Wide" reference sheets (one row per planet, all attributes as
 *    columns) for at-a-glance comparison.
 *  - "Long" fact sheets (Events×Dashas, Rules) for pivot-table analysis —
 *    e.g. pivot Events×Dashas to see which dasha lords recur across a
 *    given category of life event. This is the format that plugs into the
 *    Learner's broader research-database approach.
 *  - Confidence flags and sources are COLUMNS, never stripped — so you can
 *    filter classical rules to just 'direct' ones, etc.
 *
 * Honesty note carried from the rest of the tool: nothing here is a
 * prediction. The "Effect" / "Confirmation" columns are classical
 * associations and convergence readings — hypotheses to test, with their
 * sourcing attached.
 */

const ExcelJS = require('exceljs');

const HEADER_FILL = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF5C4A35' } };
const HEADER_FONT = { bold: true, color: { argb: 'FFFAF7F2' }, name: 'Arial' };
const BASE_FONT = { name: 'Arial', size: 10 };

const DASHA_LABELS = {
  vimshottari: 'Vimshottari', narayana: 'Narayana', ashtottari: 'Ashtottari',
  moola: 'Moola', yogini: 'Yogini', vimshottariTribhagi: 'Vim. Tribhagi',
  kalachakra: 'Kalachakra', sudasa: 'Sudasa', lagnaKendradi: 'Lagna Kendradi',
  drigdasa: 'Drigdasa', shoola: 'Shoola', niryanaShoola: 'Niryana Shoola'
};

const PLANET_ORDER = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn', 'Rahu', 'Ketu'];

function fmtDashaCtx(ctx) {
  if (!ctx) return '';
  if (ctx.mahadasha !== undefined) {
    return [ctx.mahadasha, ctx.antardasha, ctx.pratyantardasha].filter(Boolean).join(' → ');
  }
  if (ctx.major !== undefined) {
    return [ctx.major, ctx.sub].filter(Boolean).join(' → ');
  }
  return '';
}

/** Add a sheet from an array-of-objects, with a styled header + autofilter. */
function addTableSheet(wb, name, columns, rows) {
  const ws = wb.addWorksheet(name, { views: [{ state: 'frozen', ySplit: 1 }] });
  ws.columns = columns.map(c => ({ header: c.header, key: c.key, width: c.width || 18 }));

  // Style header row
  const headerRow = ws.getRow(1);
  headerRow.eachCell(cell => {
    cell.fill = HEADER_FILL;
    cell.font = HEADER_FONT;
    cell.alignment = { vertical: 'middle', wrapText: true };
  });
  headerRow.height = 22;

  for (const r of rows) ws.addRow(r);

  // Base font + wrap on body
  ws.eachRow((row, idx) => {
    if (idx === 1) return;
    row.eachCell(cell => {
      cell.font = BASE_FONT;
      cell.alignment = { vertical: 'top', wrapText: true };
    });
  });

  // Autofilter across the header
  if (columns.length > 0) {
    ws.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1, column: columns.length } };
  }
  return ws;
}

function buildSummarySheet(wb, chart) {
  const a = chart.analysis || {};
  const native = chart.native || {};
  const fn = a.functionalNature?.classifications || {};
  const yogakaraka = Object.entries(fn).filter(([, c]) => c.isYogakaraka).map(([p]) => p).join(', ') || 'none';
  const ak = a.jaimini?.atmakaraka;

  const rows = [
    { field: 'Name', value: native.name || '' },
    { field: 'Date of birth', value: native.dateOfBirth || '' },
    { field: 'Time of birth', value: native.timeOfBirth || '' },
    { field: 'Place', value: native.placeOfBirth || '' },
    { field: 'Lagna', value: chart.bodies?.Lagna?.sign || '' },
    { field: 'Janma Nakshatra', value: chart.panchanga?.janmaNakshatra || '' },
    { field: 'Yogakaraka', value: yogakaraka },
    { field: 'Atmakaraka', value: ak ? `${ak.planet} (${ak.nakshatra})` : '' },
    { field: 'Karakamsa Lagna', value: a.jaimini?.karakamsaLagna?.sign || '' },
    { field: 'Badhakesh', value: a.functionalNature?.badhaka?.badhakesh || '' },
    { field: 'Classical rules matched', value: (a.matchedRules || []).length },
    { field: 'Generated', value: new Date().toISOString().split('T')[0] }
  ];

  addTableSheet(wb, 'Summary', [
    { header: 'Field', key: 'field', width: 26 },
    { header: 'Value', key: 'value', width: 50 }
  ], rows);
}

function buildPlanetsSheet(wb, chart) {
  const a = chart.analysis || {};
  const fn = a.functionalNature?.classifications || {};
  const dig = a.dignity?.classifications || {};
  const conf = a.navamsa?.confirmation || {};
  const vargottama = a.navamsa?.vargottama || {};

  const rows = PLANET_ORDER.filter(p => chart.bodies?.[p]).map(p => {
    const b = chart.bodies[p];
    return {
      planet: p,
      sign: b.sign,
      degree: Number(b.longitudeInSign?.toFixed(2)),
      house: b.house,
      nakshatra: `${b.nakshatra}-${b.pada}`,
      navamsa: b.navamsa,
      charaKaraka: b.charaKaraka || '',
      retrograde: b.retrograde ? 'R' : '',
      dignity: dig[p]?.tier || '',
      functionalNature: fn[p]?.classification || '',
      rules: fn[p]?.housesRuled ? fn[p].housesRuled.join(', ') : '',
      isYogakaraka: fn[p]?.isYogakaraka ? 'Yes' : '',
      isMaraka: fn[p]?.isMaraka ? 'Yes' : '',
      isBadhakesh: fn[p]?.isBadhakesh ? 'Yes' : '',
      vargottama: vargottama[p]?.isVargottama ? 'Yes' : '',
      d9Confirmation: conf[p]?.read || ''
    };
  });

  addTableSheet(wb, 'Planets', [
    { header: 'Planet', key: 'planet', width: 10 },
    { header: 'Sign', key: 'sign', width: 12 },
    { header: 'Degree', key: 'degree', width: 9 },
    { header: 'House', key: 'house', width: 7 },
    { header: 'Nakshatra', key: 'nakshatra', width: 16 },
    { header: 'Navamsa', key: 'navamsa', width: 12 },
    { header: 'Chara Karaka', key: 'charaKaraka', width: 12 },
    { header: 'Retro', key: 'retrograde', width: 7 },
    { header: 'Dignity', key: 'dignity', width: 18 },
    { header: 'Functional Nature', key: 'functionalNature', width: 22 },
    { header: 'Rules Houses', key: 'rules', width: 12 },
    { header: 'Yogakaraka', key: 'isYogakaraka', width: 11 },
    { header: 'Maraka', key: 'isMaraka', width: 9 },
    { header: 'Badhakesh', key: 'isBadhakesh', width: 10 },
    { header: 'Vargottama', key: 'vargottama', width: 11 },
    { header: 'D9 Confirmation', key: 'd9Confirmation', width: 50 }
  ], rows);
}

function buildYogasSheet(wb, chart) {
  const y = chart.analysis?.yogas;
  if (!y) return;
  const rows = [];
  y.parivartana.forEach(p => rows.push({ type: 'Parivartana', detail: p.detail, quality: p.quality }));
  if (y.gajakesari) rows.push({ type: 'Gajakesari', detail: y.gajakesari.detail, quality: y.gajakesari.caveat });
  y.rajaYogas.forEach(r => rows.push({ type: 'Raja Yoga', detail: r.detail, quality: '' }));
  y.dhanaYogas.forEach(d => rows.push({ type: 'Dhana Yoga', detail: d.detail, quality: '' }));
  y.vipreetRajaYogas.forEach(v => rows.push({ type: v.name, detail: v.detail, quality: '' }));

  addTableSheet(wb, 'Yogas', [
    { header: 'Type', key: 'type', width: 18 },
    { header: 'Detail', key: 'detail', width: 70 },
    { header: 'Quality / Caveat', key: 'quality', width: 50 }
  ], rows);
}

function buildArudhasSheet(wb, chart) {
  const aru = chart.analysis?.arudhas?.arudhas;
  if (!aru) return;
  const rows = Object.entries(aru).map(([k, a]) => ({
    arudha: k,
    alias: a.alias || '',
    bhava: a.error ? '' : `H${a.bhava} ${a.bhavaSign}`,
    lord: a.error ? '' : a.lord,
    result: a.error ? a.error : `H${a.finalArudhaHouse}`
  }));
  addTableSheet(wb, 'Arudhas', [
    { header: 'Arudha', key: 'arudha', width: 10 },
    { header: 'Alias', key: 'alias', width: 22 },
    { header: 'Bhava', key: 'bhava', width: 16 },
    { header: 'Lord', key: 'lord', width: 10 },
    { header: 'Result House', key: 'result', width: 14 }
  ], rows);
}

function buildRulesSheet(wb, chart) {
  const rules = chart.analysis?.matchedRules || [];
  const rows = rules.map(r => ({
    confidence: r.sourceConfidence,
    polarity: r.polarity,
    category: r.category,
    trigger: r.trigger,
    effect: r.effect,
    source: `${r.source.text}${r.source.area ? ' — ' + r.source.area : ''}`,
    caveat: r.caveat || ''
  }));
  addTableSheet(wb, 'Classical Rules', [
    { header: 'Confidence', key: 'confidence', width: 13 },
    { header: 'Polarity', key: 'polarity', width: 12 },
    { header: 'Category', key: 'category', width: 20 },
    { header: 'Trigger', key: 'trigger', width: 36 },
    { header: 'Effect (classical association)', key: 'effect', width: 60 },
    { header: 'Source', key: 'source', width: 40 },
    { header: 'Caveat', key: 'caveat', width: 60 }
  ], rows);
}

function buildEventsSheet(wb, events) {
  // Wide format: one row per event, each dasha system as its own column
  const rows = events.map(ev => {
    const row = { date: ev.date, category: ev.category, description: ev.description };
    const dc = ev.dashaContext || {};
    for (const [key, label] of Object.entries(DASHA_LABELS)) {
      row[key] = fmtDashaCtx(dc[key]);
    }
    return row;
  });

  const columns = [
    { header: 'Date', key: 'date', width: 12 },
    { header: 'Category', key: 'category', width: 14 },
    { header: 'Description', key: 'description', width: 36 },
    ...Object.entries(DASHA_LABELS).map(([key, label]) => ({ header: label, key, width: 20 }))
  ];
  addTableSheet(wb, 'Events', columns, rows);
}

function buildEventsLongSheet(wb, events) {
  // Long format: one row per (event × dasha system) — pivot-ready.
  // This is the sheet for asking "which dasha lords recur across my
  // 'career' events?" via a pivot table.
  const rows = [];
  for (const ev of events) {
    const dc = ev.dashaContext || {};
    for (const [key, label] of Object.entries(DASHA_LABELS)) {
      const ctx = dc[key];
      if (!ctx) continue;
      // Extract MD-lord and AD-lord separately so they can be pivoted on
      let mdLord = '', adLord = '';
      if (ctx.mahadasha !== undefined) { mdLord = ctx.mahadasha || ''; adLord = ctx.antardasha || ''; }
      else if (ctx.major !== undefined) { mdLord = ctx.major || ''; adLord = ctx.sub || ''; }
      rows.push({
        date: ev.date,
        category: ev.category,
        description: ev.description,
        dashaSystem: label,
        mdLord,
        adLord,
        full: fmtDashaCtx(ctx)
      });
    }
  }

  addTableSheet(wb, 'Events x Dashas (long)', [
    { header: 'Date', key: 'date', width: 12 },
    { header: 'Category', key: 'category', width: 14 },
    { header: 'Description', key: 'description', width: 30 },
    { header: 'Dasha System', key: 'dashaSystem', width: 18 },
    { header: 'MD / Major Lord', key: 'mdLord', width: 16 },
    { header: 'AD / Sub Lord', key: 'adLord', width: 16 },
    { header: 'Full', key: 'full', width: 26 }
  ], rows);
}

function buildEventConvergenceSheet(wb, events) {
  // Long format: one row per (event × converged house) — for analyzing
  // which houses light up across event types.
  const rows = [];
  for (const ev of events) {
    const hc = ev.convergence?.houseConvergence;
    if (!hc) continue;
    for (const h of hc.filter(x => x.dynamicCount > 0)) {
      rows.push({
        date: ev.date,
        category: ev.category,
        description: ev.description,
        house: h.house,
        themes: (h.themes || []).slice(0, 3).join(' / '),
        dynamicCount: h.dynamicCount,
        rules: (h.viaRulership || []).join(', '),
        aspects: (h.viaAspect || []).join(', ')
      });
    }
  }
  if (rows.length === 0) return;
  addTableSheet(wb, 'Event Convergence (long)', [
    { header: 'Date', key: 'date', width: 12 },
    { header: 'Category', key: 'category', width: 14 },
    { header: 'Description', key: 'description', width: 30 },
    { header: 'House', key: 'house', width: 8 },
    { header: 'Themes', key: 'themes', width: 36 },
    { header: 'Active Lords (count)', key: 'dynamicCount', width: 16 },
    { header: 'Rules House', key: 'rules', width: 22 },
    { header: 'Aspects House', key: 'aspects', width: 22 }
  ], rows);
}

async function generateWorkbook(chart, events) {
  const wb = new ExcelJS.Workbook();
  wb.creator = 'WhisperByMeena';
  wb.created = new Date();

  buildSummarySheet(wb, chart);
  buildPlanetsSheet(wb, chart);
  buildYogasSheet(wb, chart);
  buildArudhasSheet(wb, chart);
  buildRulesSheet(wb, chart);
  if (events && events.length) {
    buildEventsSheet(wb, events);
    buildEventsLongSheet(wb, events);
    buildEventConvergenceSheet(wb, events);
  }

  return wb.xlsx.writeBuffer();
}

module.exports = { generateWorkbook };
