/**
 * Convergence Engine
 * 
 * Purpose: Check whether multiple INDEPENDENT indicators agree on an event.
 * 
 * Core principle (PVR approach):
 *   "The same planet driving multiple dashas does not count as independent confirmation.
 *    True confirmation requires different planets or different systems pointing to same event."
 * 
 * Independence rules:
 *   1. L1 + L2: If the same planet is active dasha lord AND the only reason D9 Narayana
 *      is activated — they are NOT independent. They share a common driver.
 *   2. L3 (Transit): ALWAYS independent — it depends on planetary motion, not natal chart.
 *   3. L4 (Degree Trigger): Partially independent — transit planet moving to natal degree
 *      is independent of the natal chart's dasha activation.
 *   4. Different karakas: If Vimshottari says DK and Narayana D9 says 7th house lord
 *      (a different planet) — that IS independent.
 * 
 * Convergence levels:
 *   HIGH:   3+ truly independent sources agree  → multiply score by 1.15
 *   MEDIUM: 2 independent sources agree         → multiply score by 1.0 (no change)
 *   LOW:    Only 1 truly independent source     → multiply score by 0.85
 *   NONE:   Same planet driving everything      → multiply score by 0.70
 */

'use strict';

/**
 * Check independence between two signals.
 * Returns true if they are genuinely independent (different causal source).
 */
function areSignalsIndependent(sigA, sigB) {
  // Extract planet driving each signal
  const planetA = extractDrivingPlanet(sigA);
  const planetB = extractDrivingPlanet(sigB);

  // If same planet drives both — NOT independent
  if (planetA && planetB && planetA === planetB) return false;

  // Transit (L3) is always independent of natal dasha (L1/L2)
  if (sigA.layer === 3 && sigB.layer <= 2) return true;
  if (sigB.layer === 3 && sigA.layer <= 2) return true;

  // Degree trigger (L4) is partially independent
  if (sigA.layer === 4 && sigB.layer <= 2) return true;
  if (sigB.layer === 4 && sigA.layer <= 2) return true;

  // L1 vs L2 from same planet = not independent
  if (sigA.layer === 1 && sigB.layer === 2 && planetA === planetB) return false;
  if (sigA.layer === 2 && sigB.layer === 1 && planetA === planetB) return false;

  // Different layers, different planets = independent
  if (sigA.layer !== sigB.layer && planetA !== planetB) return true;

  // Same layer, different planet = partially independent
  if (sigA.layer === sigB.layer && planetA !== planetB) return true;

  return false;
}

/**
 * Extract the driving planet from a signal
 */
function extractDrivingPlanet(signal) {
  if (!signal?.signal) return null;
  const s = signal.signal;

  // Patterns: 'DK_PD', 'Venus_MD', 'Jupiter_transit', 'H7_lord_MD', 'karma_nak_Jupiter'
  const PLANETS = ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn','Rahu','Ketu'];

  // Direct planet match
  for (const p of PLANETS) {
    if (s.startsWith(p + '_') || s.endsWith('_' + p) || s.includes('_' + p + '_')) {
      return p;
    }
  }

  // Chara karaka — get planet from karaka name
  if (s.startsWith('DK_') || s.startsWith('AMK_') || s.startsWith('PK_') ||
      s.startsWith('MK_') || s.startsWith('BK_') || s.startsWith('GK_')) {
    // Can't determine planet without karakas map, return karaka as proxy
    return s.split('_')[0];
  }

  // House lord — return 'house_lord' as generic
  if (s.includes('lord_MD') || s.includes('lord_AD') || s.includes('lord_PD')) {
    return 'house_lord_' + s;
  }

  return null;
}

/**
 * Count truly independent sources confirming an event
 * 
 * @param {object[]} signals - all signals from L1/L2/L3/L4
 * @param {string} eventKey  - for context
 * @returns {object} independence analysis
 */
function analyzeConvergence(signals, eventKey) {
  if (!signals || signals.length === 0) {
    return { level: 'none', count: 0, multiplier: 0.70, details: [], summary: 'No signals' };
  }

  // Group signals by layer
  const byLayer = { 1: [], 2: [], 3: [], 4: [] };
  signals.forEach(s => {
    if (byLayer[s.layer]) byLayer[s.layer].push(s);
  });

  // Build independent source groups
  const independentGroups = [];

  // Group 1: L1 Vimshottari — identify unique driving planets
  const l1Planets = new Set();
  byLayer[1].forEach(s => {
    const p = extractDrivingPlanet(s);
    if (p) l1Planets.add(p);
  });
  if (byLayer[1].length > 0) {
    independentGroups.push({
      source: 'Vimshottari Dasha',
      layer: 1,
      drivingPlanets: [...l1Planets],
      score: byLayer[1].reduce((sum, s) => sum + s.weight, 0),
      signals: byLayer[1]
    });
  }

  // Group 2: L2 D-chart Narayana
  const l2Planets = new Set();
  byLayer[2].forEach(s => {
    const p = extractDrivingPlanet(s);
    if (p) l2Planets.add(p);
  });

  // Check: Are L1 and L2 driven by same planet?
  const l1l2Overlap = [...l1Planets].filter(p => l2Planets.has(p));
  const l2TrulyIndependent = l2Planets.size > 0 && l1l2Overlap.length < l2Planets.size;

  if (byLayer[2].length > 0) {
    independentGroups.push({
      source: 'Narayana D-chart',
      layer: 2,
      drivingPlanets: [...l2Planets],
      score: byLayer[2].reduce((sum, s) => sum + s.weight, 0),
      signals: byLayer[2],
      independentOfL1: l2TrulyIndependent,
      sharedWithL1: l1l2Overlap,
      // Reduce weight if same planet driving L1 and L2
      effectiveWeight: l2TrulyIndependent ? 1.0 : 0.5
    });
  }

  // Group 3: L3 Transit — always independent
  if (byLayer[3].length > 0) {
    const l3Planets = new Set(byLayer[3].map(s => extractDrivingPlanet(s)).filter(Boolean));
    independentGroups.push({
      source: 'Gochar (Transit)',
      layer: 3,
      drivingPlanets: [...l3Planets],
      score: byLayer[3].reduce((sum, s) => sum + s.weight, 0),
      signals: byLayer[3],
      independentOfL1: true,  // Always independent
      effectiveWeight: 1.0
    });
  }

  // Group 4: L4 Degree Trigger — mostly independent
  if (byLayer[4].length > 0) {
    const l4Planets = new Set(byLayer[4].map(s => extractDrivingPlanet(s)).filter(Boolean));
    // Degree trigger is independent unless it's triggered by the same transit planet
    const l3Planets_set = new Set(byLayer[3].map(s => extractDrivingPlanet(s)).filter(Boolean));
    const l4l3Overlap = [...l4Planets].filter(p => l3Planets_set.has(p));
    const l4TrulyIndependent = l4l3Overlap.length < l4Planets.size;

    independentGroups.push({
      source: 'Degree Trigger / Karma Nakshatra',
      layer: 4,
      drivingPlanets: [...l4Planets],
      score: byLayer[4].reduce((sum, s) => sum + s.weight, 0),
      signals: byLayer[4],
      independentOfL1: true,
      effectiveWeight: l4TrulyIndependent ? 0.8 : 0.5 // Partial weight
    });
  }

  // Count truly independent sources
  let trueIndependentCount = 0;
  const details = [];

  independentGroups.forEach(g => {
    const isIndependent = g.independentOfL1 !== false || g.layer >= 3;
    const effectiveW = g.effectiveWeight || 1.0;
    const contribution = effectiveW >= 0.8 ? 'full' : effectiveW >= 0.5 ? 'partial' : 'weak';

    if (effectiveW >= 0.8) trueIndependentCount++;
    else if (effectiveW >= 0.5) trueIndependentCount += 0.5;

    details.push({
      source: g.source,
      layer: g.layer,
      drivingPlanets: g.drivingPlanets,
      sharedWithPrevious: g.sharedWithL1 || [],
      effectiveWeight: effectiveW,
      contribution,
      score: g.score
    });
  });

  // Determine convergence level
  let level, multiplier;
  if (trueIndependentCount >= 3) {
    level = 'high';
    multiplier = 1.15;
  } else if (trueIndependentCount >= 2) {
    level = 'medium';
    multiplier = 1.0;
  } else if (trueIndependentCount >= 1) {
    level = 'low';
    multiplier = 0.85;
  } else {
    level = 'none';
    multiplier = 0.70;
  }

  // Build summary
  const independent = details.filter(d => d.contribution === 'full').map(d => d.source);
  const partial     = details.filter(d => d.contribution === 'partial').map(d => d.source);
  const shared      = details.filter(d => d.sharedWithPrevious?.length > 0);

  let summary = `${level.toUpperCase()} convergence (${trueIndependentCount.toFixed(1)} independent sources)`;
  if (independent.length) summary += `. Independent: ${independent.join(', ')}`;
  if (partial.length) summary += `. Partial: ${partial.join(', ')}`;
  if (shared.length) {
    shared.forEach(d => {
      summary += `. Note: ${d.source} shares planet(s) ${d.sharedWithPrevious.join(',')} with Vimshottari — not fully independent`;
    });
  }

  return {
    level,
    multiplier,
    trueIndependentCount,
    details,
    summary,
    independentGroups,
    warning: trueIndependentCount < 2 ? 'Single source — prediction less reliable' : null
  };
}

/**
 * Apply convergence multiplier to a score
 */
function applyConvergence(baseScore, signals, eventKey) {
  const conv = analyzeConvergence(signals, eventKey);
  const adjusted = Math.min(100, Math.round(baseScore * conv.multiplier));
  return { adjusted, convergence: conv };
}

module.exports = {
  analyzeConvergence,
  applyConvergence,
  areSignalsIndependent,
  extractDrivingPlanet
};
