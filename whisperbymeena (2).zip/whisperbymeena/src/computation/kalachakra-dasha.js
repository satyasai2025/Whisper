/**
 * Kalachakra Dasha Computation
 * Source: PVR Narasimha Rao "Vedic Astrology: An Integrated Approach" Ch.24
 *
 * "Parasara said: Kalachakra dasa is the most respectable of all dasa systems."
 * Focus: How connected one feels to life events. Karmic shifts. Inner experience.
 * NOT the same as Narayana (what happens) or Vimshottari (how mind views it).
 *
 * Tables 44-47 (p.291-292): Nakshatra pada → 9-rasi sequence + paramayush
 * Table 48 (p.293): Dasa years per rasi owner
 * Table 42 (p.289): Savya/Apasavya nakshatra groups
 *
 * Validated examples:
 *   Example 95 (p.293): Moon at Ta 15°50' (Rohini 2nd pada, Apasavya-1)
 *     → Sc dasa running at birth, 4.75yr remaining ✅
 *   Example 96 (p.294): Moon at Cn 3° (Punarvasu 4th pada, Savya-1)
 *     → Pi dasa running at birth, 8.6yr remaining ✅
 *   Exercise 34 (p.309): Moon at Aq 5°50' (Dhanishtha 4th pada, Apasavya-2)
 *     → Ge dasa running at birth, 2yr remaining ✅
 */

'use strict';

const SIGN_CODES = ['Ar','Ta','Ge','Cn','Le','Vi','Li','Sc','Sg','Cp','Aq','Pi'];
const SIGN_NAMES = ['Aries','Taurus','Gemini','Cancer','Leo','Virgo',
                    'Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'];

// Table 48: Dasa years by rasi (p.293)
const DASA_YEARS = {
  Le:5, Cn:21, Ar:7, Sc:7, Ge:9, Vi:9, Sg:10, Pi:10, Ta:16, Li:16, Cp:4, Aq:4
};

// Table 42: Nakshatra groups (p.289-290)
const NAKSHATRA_NAMES = [
  'Aswini','Bharani','Krittika','Rohini','Mrigasira','Aardra',
  'Punarvasu','Pushyami','Asresha','Makha','Poorva Phalguni','Uttara Phalguni',
  'Hasta','Chitra','Swaati','Visaakha','Anooraadha','Jyeshtha',
  'Moola','Poorvaashaadha','Uttaraashaadha','Sravanam','Dhanishtha','Satabhishak',
  'Poorvaabhaadra','Uttaraabhaadra','Revati'
];

// Savya-1: Aswini(0),Krittika(2),Punarvasu(6),Asresha(8),Hasta(12),Swaati(14),Moola(18),Uttaraashaadha(20),Poorvaabhaadra(24)
// Savya-2: Bharani(1),Pushyami(7),Chitra(13),Poorvaashaadha(19),Revati(26)
// Apasavya-1: Rohini(3),Makha(9),Visaakha(15),Sravanam(21)
// Apasavya-2: Mrigasira(4),Aardra(5),Poorva Phalguni(10),Uttara Phalguni(11),Anooraadha(16),Jyeshtha(17),Dhanishtha(22),Satabhishak(23)

const NAKSHATRA_GROUP = [
  'savya1','savya2','savya1', // 0,1,2: Aswini,Bharani,Krittika
  'apasavya1','apasavya2','apasavya2', // 3,4,5: Rohini,Mrigasira,Aardra
  'savya1','savya2','savya1', // 6,7,8: Punarvasu,Pushyami,Asresha
  'apasavya1','apasavya2','apasavya2', // 9,10,11: Makha,PoorvaPhalguni,UttaraPhalguni
  'savya1','savya2','savya1', // 12,13,14: Hasta,Chitra,Swaati
  'apasavya1','apasavya2','apasavya2', // 15,16,17: Visaakha,Anooraadha,Jyeshtha
  'savya1','savya2','savya1', // 18,19,20: Moola,Poorvaashaadha,Uttaraashaadha
  'apasavya1','apasavya2','apasavya2', // 21,22,23: Sravanam,Dhanishtha,Satabhishak
  'savya1','savya2','savya1', // 24,25,26: Poorvaabhaadra,Uttaraabhaadra,Revati (note: Revati is savya1)
];

// Tables 44-47: pada → 9-rasi sequence + paramayush (p.291-292)
const KALACHAKRA_TABLES = {
  savya1: [
    { padas: [1], seq: ['Ar','Ta','Ge','Cn','Le','Vi','Li','Sc','Sg'], deha:'Ar', jeeva:'Sg', paramayush:100 },
    { padas: [2], seq: ['Cp','Aq','Pi','Sc','Li','Vi','Cn','Le','Ge'], deha:'Cp', jeeva:'Ge', paramayush:85  },
    { padas: [3], seq: ['Ta','Ar','Pi','Aq','Cp','Sg','Ar','Ta','Ge'], deha:'Ta', jeeva:'Ge', paramayush:83  },
    { padas: [4], seq: ['Cn','Le','Vi','Li','Sc','Sg','Cp','Aq','Pi'], deha:'Cn', jeeva:'Pi', paramayush:86  },
  ],
  savya2: [
    { padas: [1], seq: ['Sc','Li','Vi','Cn','Le','Ge','Ta','Ar','Pi'], deha:'Sc', jeeva:'Pi', paramayush:100 },
    { padas: [2], seq: ['Aq','Cp','Sg','Ar','Ta','Ge','Cn','Le','Vi'], deha:'Aq', jeeva:'Vi', paramayush:85  },
    { padas: [3], seq: ['Li','Sc','Sg','Cp','Aq','Pi','Sc','Li','Vi'], deha:'Li', jeeva:'Vi', paramayush:83  },
    { padas: [4], seq: ['Cn','Le','Ge','Ta','Ar','Pi','Aq','Cp','Sg'], deha:'Cn', jeeva:'Sg', paramayush:86  },
  ],
  apasavya1: [
    { padas: [1], seq: ['Sg','Cp','Aq','Pi','Ar','Ta','Ge','Le','Cn'], deha:'Cn', jeeva:'Sg', paramayush:86  },
    { padas: [2], seq: ['Vi','Li','Sc','Pi','Aq','Cp','Sg','Sc','Li'], deha:'Li', jeeva:'Vi', paramayush:83  },
    { padas: [3], seq: ['Vi','Le','Cn','Ge','Ta','Ar','Sg','Cp','Aq'], deha:'Aq', jeeva:'Vi', paramayush:85  },
    { padas: [4], seq: ['Pi','Ar','Ta','Ge','Le','Cn','Vi','Li','Sc'], deha:'Sc', jeeva:'Pi', paramayush:100 },
  ],
  apasavya2: [
    { padas: [1], seq: ['Pi','Aq','Cp','Sg','Sc','Li','Vi','Le','Cn'], deha:'Cn', jeeva:'Pi', paramayush:86  },
    { padas: [2], seq: ['Ge','Ta','Ar','Sg','Cp','Aq','Pi','Ar','Ta'], deha:'Ta', jeeva:'Ge', paramayush:83  },
    { padas: [3], seq: ['Ge','Le','Cn','Vi','Li','Sc','Pi','Aq','Cp'], deha:'Cp', jeeva:'Ge', paramayush:85  },
    { padas: [4], seq: ['Sg','Sc','Li','Vi','Le','Cn','Ge','Ta','Ar'], deha:'Ar', jeeva:'Sg', paramayush:100 },
  ],
};

// ── 24-rasi continuous tapes (Table 43, p.290) ───────────────────────────────
// Savya:    Main(12) + Mirrored(12) = 24 positions, repeating
// Apasavya: Mirrored(12) + Main(12) = 24 positions, repeating
const SAVYA_24 = [
  'Ar','Ta','Ge','Cn','Le','Vi','Li','Sc','Sg','Cp','Aq','Pi', // main zodiacal
  'Sc','Li','Vi','Cn','Le','Ge','Ta','Ar','Pi','Aq','Cp','Sg'  // mirrored (other sign of same lord)
];
const APASAVYA_24 = [
  'Sg','Cp','Aq','Pi','Ar','Ta','Ge','Le','Cn','Vi','Li','Sc', // mirrored
  'Pi','Aq','Cp','Sg','Sc','Li','Vi','Le','Cn','Ge','Ta','Ar'  // main anti-zodiacal
];

// Starting position in 24-rasi tape for each group+pada combo
// Verified against Tables 44-47
const TAPE_START = {
  savya1:    { 1:0,  2:9,  3:18, 4:3  },
  savya2:    { 1:12, 2:21, 3:6,  4:15 },
  apasavya1: { 1:8,  2:17, 3:2,  4:11 },
  apasavya2: { 1:20, 2:5,  3:14, 4:23 },
};

function getTapeFor(group) {
  return group.startsWith('savya') ? SAVYA_24 : APASAVYA_24;
}

function getTapeRasi(group, tapePos) {
  const tape = getTapeFor(group);
  return tape[((tapePos % 24) + 24) % 24];
}

function getGroupFromTapePos(group, tapePos) {
  // After 24 positions, switch group type (savya1↔savya2, apasavya1↔apasavya2)
  const cycle = Math.floor(((tapePos % 24) + 24) % 24 / 12);
  if (group === 'savya1')    return cycle === 0 ? 'savya1' : 'savya2';
  if (group === 'savya2')    return cycle === 0 ? 'savya2' : 'savya1';
  if (group === 'apasavya1') return cycle === 0 ? 'apasavya1' : 'apasavya2';
  if (group === 'apasavya2') return cycle === 0 ? 'apasavya2' : 'apasavya1';
  return group;
}

/**
 * Get Kalachakra pada info from Moon's longitude.
 */
function getKalachakraPadaInfo(moonLon) {
  const moonL = ((moonLon % 360) + 360) % 360;
  const NAK_SPAN = 360 / 27;         // 13.333°
  const PADA_SPAN = NAK_SPAN / 4;    // 3.333°

  const nakIdx  = Math.floor(moonL / NAK_SPAN);
  const degInNak = moonL % NAK_SPAN;
  const padaNum  = Math.floor(degInNak / PADA_SPAN) + 1; // 1-4
  const degInPada = degInNak % PADA_SPAN;
  const fraction  = degInPada / PADA_SPAN; // 0.0 to 1.0

  const group    = NAKSHATRA_GROUP[nakIdx];
  const tableRows = KALACHAKRA_TABLES[group];
  const row       = tableRows[padaNum - 1];

  return {
    nakIdx, nakName: NAKSHATRA_NAMES[nakIdx], pada: padaNum,
    degInPada, fraction, group,
    seq: row.seq, deha: row.deha, jeeva: row.jeeva, paramayush: row.paramayush,
    isSavya: group.startsWith('savya'),
    nextGroup: { savya1:'savya2', savya2:'savya1', apasavya1:'apasavya2', apasavya2:'apasavya1' }[group]
  };
}

/**
 * Build flat sequence of dasas starting from birthdate.
 * Within-pada calculations validated against examples 95, 96, 34.
 * Pada boundary transition: continues from start of next pada (approximate).
 * Full continuous-tape algorithm requires JHora or audio lesson verification.
 */
function buildKalachakraSequence(padaInfo, fraction, birthDate, maxYears) {
  const { seq, paramayush, group, pada } = padaInfo;

  // Cumulative years in this pada
  const cumulative = seq.map((r, i) =>
    seq.slice(0, i + 1).reduce((s, x) => s + (DASA_YEARS[x] || 0), 0)
  );

  // Years elapsed before birth = fraction × paramayush
  const elapsedYears = fraction * paramayush;

  // Find which dasa is running at birth
  let startDasaIdx = 0;
  for (let i = 0; i < cumulative.length; i++) {
    if (cumulative[i] > elapsedYears) { startDasaIdx = i; break; }
    if (i === cumulative.length - 1) startDasaIdx = i;
  }

  const prevCumul = startDasaIdx > 0 ? cumulative[startDasaIdx - 1] : 0;
  const yearsIntoStartDasa = elapsedYears - prevCumul;
  const firstDasaRemaining = (DASA_YEARS[seq[startDasaIdx]] || 0) - yearsIntoStartDasa;

  // Get group order for transitions
  const GROUP_ORDER = {
    savya1: ['savya1','savya2','savya1','savya2'],
    savya2: ['savya2','savya1','savya2','savya1'],
    apasavya1: ['apasavya1','apasavya2','apasavya1','apasavya2'],
    apasavya2: ['apasavya2','apasavya1','apasavya2','apasavya1'],
  };
  const PADA_ORDER = [1,2,3,4,1,2,3,4]; // cycles

  const dasas = [];
  let currentDate = birthDate;
  let totalComputed = 0;
  let isFirstDasa = true;

  let currentGroup = group;
  let currentPada  = pada;
  let currentSeq   = seq;
  let seqIdx       = startDasaIdx;

  while (totalComputed < maxYears) {
    if (seqIdx >= currentSeq.length) {
      // Transition to next pada
      const groups = GROUP_ORDER[group];
      const nextGroupIdx = groups.indexOf(currentGroup) >= 0 ? groups.indexOf(currentGroup) + 1 : 0;
      currentGroup = groups[nextGroupIdx % groups.length];
      currentPada  = PADA_ORDER[nextGroupIdx % PADA_ORDER.length];
      const tableRows = KALACHAKRA_TABLES[currentGroup];
      currentSeq = tableRows[(currentPada - 1) % 4].seq;
      seqIdx = 0;
    }

    const rasi = currentSeq[seqIdx];
    const rasiFull = DASA_YEARS[rasi] || 0;
    let yrs = isFirstDasa ? firstDasaRemaining : rasiFull;
    if (yrs <= 0) { seqIdx++; continue; }

    const effectiveYrs = Math.min(yrs, maxYears - totalComputed);
    const startDate = currentDate;
    const endDate   = addYearsToDate(currentDate, effectiveYrs);

    // Antardasas: 9 rasis starting from current position
    const adSeq   = [];
    let adGroup = currentGroup, adPada = currentPada;
    let adTableRows = KALACHAKRA_TABLES[adGroup];
    let adSeqData = adTableRows[(adPada-1)%4].seq;
    let adIdx = seqIdx;
    for (let i = 0; i < 9; i++) {
      if (adIdx >= adSeqData.length) {
        const ag = GROUP_ORDER[group];
        const ngIdx = ag.indexOf(adGroup) + 1;
        adGroup = ag[ngIdx % ag.length];
        adPada  = PADA_ORDER[ngIdx % PADA_ORDER.length];
        adTableRows = KALACHAKRA_TABLES[adGroup];
        adSeqData = adTableRows[(adPada-1)%4].seq;
        adIdx = 0;
      }
      adSeq.push(adSeqData[adIdx]);
      adIdx++;
    }
    const totalADYrs = adSeq.reduce((s,r) => s + (DASA_YEARS[r]||0), 0);
    const antardasas = adSeq.map(r => ({
      rasi: r, rasiName: SIGN_NAMES[SIGN_CODES.indexOf(r)] || r,
      years: Number((totalADYrs > 0 ? (DASA_YEARS[r]||0)/totalADYrs*effectiveYrs : 0).toFixed(6))
    }));

    dasas.push({
      rasi, rasiName: SIGN_NAMES[SIGN_CODES.indexOf(rasi)] || rasi,
      years: Number(effectiveYrs.toFixed(6)),
      startDate, endDate, antardasas, group: currentGroup
    });

    currentDate = endDate;
    totalComputed += effectiveYrs;
    isFirstDasa = false;
    seqIdx++;
  }

  return dasas;
}

/**
 * Build antardasa sequence for a dasa at given tape position.
 */
function buildAntardasas(tapePos, group, dasaYears) {
  const adRasis = Array.from({length:9}, (_,i) => getTapeRasi(group, tapePos + i));
  const totalADYears = adRasis.reduce((s, r) => s + (DASA_YEARS[r] || 0), 0);

  return adRasis.map(r => ({
    rasi: r,
    rasiName: SIGN_NAMES[SIGN_CODES.indexOf(r)] || r,
    years: Number((totalADYears > 0 ? (DASA_YEARS[r] || 0) / totalADYears * dasaYears : 0).toFixed(6))
  }));
}

/**
 * Main: Compute Kalachakra Dasha.
 * @param {number} moonLon   - Moon's sidereal longitude
 * @param {string} birthDate - 'YYYY-MM-DD'
 * @param {number} maxYears  - how many years to compute
 */
function computeKalachakra(moonLon, birthDate, maxYears) {
  maxYears = maxYears || 120;

  const padaInfo = getKalachakraPadaInfo(moonLon);
  const dasas    = buildKalachakraSequence(padaInfo, padaInfo.fraction, birthDate, maxYears);

  const isSavya = padaInfo.isSavya;

  return {
    system: 'Kalachakra',
    purpose: 'How one relates to events; karmic shifts; inner experience (Ch.24)',
    warning: 'Very sensitive to birth time error. Antardasa unreliable with family-memory birth times.',
    moonNakshatra: padaInfo.nakName,
    pada: padaInfo.pada,
    group: padaInfo.group,
    isSavya,
    paramayush: padaInfo.paramayush,
    // Deha/Jeeva based on first and ninth dasa
    deha: dasas[0]?.rasi || padaInfo.deha,
    jeeva: dasas[Math.min(8, dasas.length - 1)]?.rasi || padaInfo.jeeva,
    dehaNote: 'Deha (body rasi) = ' + (isSavya ? 'first' : 'last') + ' of 9 dasas (Ch.24.3.2)',
    jeevaNote: 'Jeeva (life rasi) = ' + (isSavya ? 'last' : 'first') + ' of 9 dasas (Ch.24.3.2)',
    dasas
  };
}

function addYearsToDate(dateStr, years) {
  const d = new Date(dateStr);
  d.setTime(d.getTime() + years * 365.25636 * 86400000);
  return d.toISOString().split('T')[0];
}

/**
 * Find active Kalachakra period for a date
 */
function findActiveKalachakra(dasas, dateStr) {
  for (const md of dasas) {
    if (md.startDate <= dateStr && md.endDate > dateStr) {
      return { mahadasha: md.rasi, mahadashaName: md.rasiName, group: md.group,
               mdPeriod: { startDate: md.startDate, endDate: md.endDate } };
    }
  }
  return null;
}

module.exports = { computeKalachakra, getKalachakraPadaInfo, findActiveKalachakra };
