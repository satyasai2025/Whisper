/**
 * Specific Classical Rules
 *
 * Unlike the principle-generated house-lord rules, these are SPECIFIC,
 * individually-documented classical statements that recur consistently
 * across translations and commentaries. They carry higher confidence
 * because they are concrete, named, and widely cited — but each still
 * carries its source and any standard caveat.
 *
 * Scope here: well-known planet-in-house effects, classical yogas already
 * detected elsewhere (cross-referenced for explanation), and a few
 * frequently-applied special rules. This is explicitly a curated set, not
 * exhaustive.
 */

const { SOURCES } = require('./schema');

const SPECIFIC_RULES = [
  // ---- Benefic/malefic in kendra/trikona (foundational) ----
  {
    id: 'benefic-in-kendra',
    category: 'special',
    condition: { type: 'naturalBeneficInHouses', planets: ['Jupiter', 'Venus', 'Mercury', 'Moon'], houses: [1, 4, 7, 10] },
    effect: 'A natural benefic occupying a Kendra (angular house) is classically held to strengthen the chart\'s overall stability and protective capacity.',
    source: { text: SOURCES.BPHS, area: 'Kendra/benefic principles' },
    sourceConfidence: 'direct',
    caveat: 'The Moon as benefic depends on its waxing/waning state and association; a waning or afflicted Moon is treated more cautiously.',
    polarity: 'favorable'
  },
  {
    id: 'malefic-in-3-6-11',
    category: 'special',
    condition: { type: 'naturalMaleficInHouses', planets: ['Saturn', 'Mars', 'Sun'], houses: [3, 6, 11] },
    effect: 'Natural malefics in the Upachaya houses (3, 6, 11) are classically considered well-placed — they give the drive to overcome enemies, competition, and obstacles, with results improving over time.',
    source: { text: SOURCES.BPHS, area: 'Upachaya/malefic principles' },
    sourceConfidence: 'direct',
    caveat: 'This is about the malefic\'s own functioning; it does not by itself cancel any harm to the houses those malefics also rule.',
    polarity: 'favorable'
  },

  // ---- Exalted / debilitated dasha lord (timing-relevant) ----
  {
    id: 'exalted-planet-general',
    category: 'special',
    condition: { type: 'planetDignity', tier: 'Exalted' },
    effect: 'An exalted planet expresses its significations at full strength; results tied to it (and its dasha periods) tend to manifest strongly and favorably.',
    source: { text: SOURCES.BPHS, area: 'Exaltation (Uchcha) principles' },
    sourceConfidence: 'direct',
    caveat: 'Strength of expression is not the same as benefic outcome — an exalted functional malefic expresses strongly in its own (possibly difficult) domain. Read alongside functional nature.',
    polarity: 'favorable'
  },
  {
    id: 'debilitated-planet-general',
    category: 'special',
    condition: { type: 'planetDignity', tier: 'Debilitated' },
    effect: 'A debilitated planet struggles to deliver its significations cleanly; its periods can bring frustration in those areas — UNLESS Neecha Bhanga (debilitation-cancellation) conditions apply, which can powerfully reverse the result.',
    source: { text: SOURCES.BPHS, area: 'Debilitation (Neecha) & Neecha Bhanga principles' },
    sourceConfidence: 'direct',
    caveat: 'Always check Neecha Bhanga conditions before treating a debilitated planet as simply weak — a cancelled debilitation can become a source of great strength (Neecha Bhanga Raja Yoga).',
    polarity: 'challenging'
  },

  // ---- Yogakaraka (cross-reference to functional nature) ----
  {
    id: 'yogakaraka-dasha',
    category: 'special',
    condition: { type: 'isYogakaraka' },
    effect: 'The Yogakaraka — a single planet ruling both a Kendra and a Trikona — is among the most auspicious period-givers in a chart; its dasha/antardasha is classically expected to elevate status, fortune, and overall results.',
    source: { text: SOURCES.BPHS, area: 'Yogakaraka principles' },
    sourceConfidence: 'direct',
    caveat: 'The Yogakaraka must still be reasonably placed and not heavily afflicted to deliver fully; placement in a dusthana or deep affliction tempers the promise.',
    polarity: 'favorable'
  },

  // ---- Lagna lord strength ----
  {
    id: 'lagna-lord-strong',
    category: 'special',
    condition: { type: 'lagnaLordInHouses', houses: [1, 4, 5, 7, 9, 10, 11] },
    effect: 'A well-placed Lagna lord (in a Kendra, Trikona, or 11th) supports vitality, self-direction, and the native\'s ability to steer their own life favorably.',
    source: { text: SOURCES.PHALADEEPIKA, area: 'Lagna and Lagnesha strength' },
    sourceConfidence: 'interpretive',
    caveat: 'A strong Lagna lord in a dusthana (6/8/12) is read very differently — strength turned toward difficult houses. Position matters as much as strength.',
    polarity: 'favorable'
  },

  // ---- Atmakaraka (Jaimini soul-significator) ----
  {
    id: 'atmakaraka-dasha',
    category: 'special',
    condition: { type: 'isAtmakaraka' },
    effect: 'The Atmakaraka is the soul-significator (highest-degree chara karaka). Its dasha/antardasha periods are classically when soul-level themes, karmic lessons, and the native\'s deepest drives come to the foreground — often pivotal, identity-shaping times.',
    source: { text: SOURCES.JAIMINI, area: 'Atmakaraka principles (also central to PVR methodology)' },
    sourceConfidence: 'interpretive',
    caveat: 'The AK\'s identity itself depends on the 7- vs 8-karaka scheme used by the source software. AK periods are about inner/karmic significance and do not, by themselves, predict external good or bad outcomes — read the AK\'s house/dignity context for that.',
    polarity: 'neutral'
  },

  // ---- Maraka (timing caution) ----
  {
    id: 'maraka-dasha-caution',
    category: 'special',
    condition: { type: 'isMaraka' },
    effect: 'Maraka lords (rulers of the 2nd and 7th) are classically flagged as significators of physical danger or major endings, particularly active during their own periods in later life.',
    source: { text: SOURCES.BPHS, area: 'Maraka principles' },
    sourceConfidence: 'interpretive',
    caveat: 'Maraka potential is heavily age- and longevity-dependent; in early/mid life these periods often manifest as endings/transitions (jobs, relationships, relocations) rather than literal danger. This is one of the most over-read and misapplied classical rules — treat with great caution and never as a fixed prediction.',
    polarity: 'challenging'
  },

  // ---- Badhakesh (obstacle timing) ----
  {
    id: 'badhakesh-dasha',
    category: 'special',
    condition: { type: 'isBadhakesh' },
    effect: 'The Badhakesh (lord of the Badhaka house, determined by the Lagna\'s movable/fixed/dual nature) is classically associated with obstacles, blockages, and delays, especially active during its own periods.',
    source: { text: SOURCES.BPHS, area: 'Badhaka/Badhakesh principles' },
    sourceConfidence: 'interpretive',
    caveat: 'Badhaka effects are about obstruction, not destruction; they often describe friction and delay rather than outright loss. A Badhakesh that is also a functional benefic gives mixed results.',
    polarity: 'challenging'
  }
];

module.exports = { SPECIFIC_RULES };
