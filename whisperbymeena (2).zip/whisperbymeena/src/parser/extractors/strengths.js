/**
 * Strength Systems Extractor
 *
 * Parses Ashtakavarga, Shadbala, Bhava Bala, Avastha (planetary states),
 * and Vimsopaka from JHora's PDF text. These are DISTINCT strength
 * dimensions that must not be conflated with each other or with the
 * Functional Nature / Dignity classifications computed elsewhere:
 *
 *   - Ashtakavarga: point-based benefic-contribution system per sign,
 *     used heavily for transit (gochar) strength assessment
 *   - Shadbala: six-fold classical strength (positional, directional,
 *     temporal, motional, natural, aspectual) combined into one rupa value
 *   - Bhava Bala: house strength (distinct from planet strength)
 *   - Avastha: a planet's "state" (age/alertness/mood) — a qualitative,
 *     not point-based, strength indicator
 *   - Vimsopaka: a 20-point divisional-chart-weighted strength score,
 *     conceptually different from Shadbala (which is NOT divisional-
 *     chart-based) — kept separate per design intent
 *
 * KNOWN LIMITATION — Pinda values NOT extracted: JHora's text export
 * glues Sodhya/Rasi/Graha Pinda values into a single unbroken integer
 * string per planet (e.g. "Lagna19990109" for 199/90/109) with NO
 * separator (no decimal point, no space) to reliably split on. Unlike
 * Shadbala's glued values (which have a consistent 2-decimal-place
 * format that makes splitting unambiguous), Pinda's pure-integer gluing
 * cannot be reliably reconstructed without risking silently wrong
 * numbers. Per this project's data-integrity standard, Pinda is left
 * unparsed here rather than guessed.
 */

const PLANET_ORDER_AV = ['As', 'Su', 'Mo', 'Ma', 'Me', 'Ju', 'Ve', 'Sa'];
const AV_PLANET_NAMES = { As: 'Lagna', Su: 'Sun', Mo: 'Moon', Ma: 'Mars', Me: 'Mercury', Ju: 'Jupiter', Ve: 'Venus', Sa: 'Saturn' };
const SIGN_NAMES_ORDER = ['Aries', 'Taurus', 'Gemini', 'Cancer', 'Leo', 'Virgo', 'Libra', 'Scorpio', 'Sagittarius', 'Capricorn', 'Aquarius', 'Pisces'];

/**
 * Ashtakavarga — 8 rows (Lagna + 7 grahas) x 12 sign-values, each row
 * terminated by a 2-letter planet code label.
 *
 * SAV (Sarvashtakavarga) is COMPUTED here (sum of the 8 parsed rows),
 * not parsed from JHora's own printed SAV row — this sidesteps any
 * text-extraction ambiguity in that row and is mathematically guaranteed
 * correct by Ashtakavarga's own definition (SAV = sum of all Bhinnas).
 */
function extractAshtakavarga(sectionText) {
  const tokens = sectionText.split('\n').map(l => l.trim()).filter(Boolean);
  // Drop the header line "Ashtakavarga of Rasi Chart:"
  const dataTokens = tokens.slice(1);

  const bhinna = {};
  let buffer = [];
  let consumed = 0;

  for (const token of dataTokens) {
    if (PLANET_ORDER_AV.includes(token) && buffer.length === 12) {
      const planetName = AV_PLANET_NAMES[token];
      bhinna[planetName] = buffer.map(Number);
      buffer = [];
      consumed++;
      if (consumed === 8) break; // stop after Lagna + 7 grahas; ignore JHora's own SAV row entirely
    } else if (/^\d+$/.test(token)) {
      buffer.push(token);
    } else {
      // Unexpected token (shouldn't happen with clean data) — abort this row
      buffer = [];
    }
  }

  if (Object.keys(bhinna).length !== 8) {
    return {
      _warning: `Expected 8 Bhinnashtakavarga rows (Lagna + 7 grahas), parsed ${Object.keys(bhinna).length}. Data may be incomplete.`,
      bhinna
    };
  }

  // Compute SAV ourselves — sum of the 8 rows, per-sign
  const sarva = [];
  for (let signIdx = 0; signIdx < 12; signIdx++) {
    let sum = 0;
    for (const planet of Object.keys(bhinna)) sum += bhinna[planet][signIdx];
    sarva.push(sum);
  }

  return {
    bhinna,         // { Lagna: [12 values, Aries->Pisces], Sun: [...], ... }
    sarva,          // [12 values, Aries->Pisces] — computed, not parsed
    signOrder: SIGN_NAMES_ORDER,
    note: 'Sarvashtakavarga (sarva) is computed as the sum of the 8 Bhinnashtakavarga rows, not parsed from JHora\'s own SAV row (see module documentation for why).'
  };
}

/**
 * Shadbala — 5 numeric columns per planet (JHora's header phrasing is
 * ambiguous about exact column semantics — "Shadbala In rupas % Strength
 * IshtaPhala KashtaPhala" reads as 4 labels but the data consistently has
 * 5 numbers per row). Columns, in order: a raw Shadbala score, its rupas
 * equivalent, % of required strength, IshtaPhala, KashtaPhala.
 * Handles the occasional glued-decimal case (e.g. "95.725.1343.71") via
 * a fallback regex that exploits the consistent 2-decimal-place format.
 */
function extractShadbala(sectionText) {
  const lines = sectionText.split('\n').map(l => l.trim()).filter(Boolean).slice(1); // drop header
  const result = {};

  for (const line of lines) {
    const m = line.match(/^([A-Z][a-z]+)\s+(.+)$/);
    if (!m) continue;
    const planet = m[1];
    const rest = m[2];

    let values = rest.split(/\s+/).filter(Boolean);
    if (values.length !== 5) {
      values = rest.match(/-?\d+\.\d{2}/g) || [];
    }

    if (values.length !== 5) {
      result[planet] = { _warning: `Could not reliably parse Shadbala values from: "${line}" (got ${values.length} values, expected 5)` };
      continue;
    }

    const [shadbalaRaw, rupas, percentOfRequired, ishtaPhala, kashtaPhala] = values.map(Number);
    result[planet] = { shadbalaRaw, rupas, percentOfRequired, ishtaPhala, kashtaPhala };
  }

  return result;
}

/**
 * Bhava Bala — 5 numeric columns per house (same column-count ambiguity
 * as Shadbala's header). Columns, in order: a raw Bhava Bala score, its
 * rupas equivalent, Lord's Bala, DigBala, DrigBala.
 */
function extractBhavaBala(sectionText) {
  const lines = sectionText.split('\n').map(l => l.trim()).filter(Boolean).slice(1);
  const result = {};

  for (const line of lines) {
    const m = line.match(/^(\d+)(?:st|nd|rd|th)\s+([\d.-]+)\s+([\d.-]+)\s+([\d.-]+)\s+([\d.-]+)\s+([\d.-]+)$/);
    if (!m) continue;
    const house = parseInt(m[1], 10);
    result[house] = {
      bhavaBalaRaw: parseFloat(m[2]),
      rupas: parseFloat(m[3]),
      lordsBala: parseFloat(m[4]),
      digBala: parseFloat(m[5]),
      drigBala: parseFloat(m[6])
    };
  }

  return result;
}

/**
 * Avastha (Age/Alertness/Mood) + Activity — parenthetical Word(desc)
 * pattern extraction, robust to missing spaces between glued segments.
 */
const WORD_PAREN = /([A-Z][a-zA-Z]*)\s*\(([a-z][a-zA-Z\s,]*?)\)/g;

function extractAvastha(sectionText) {
  const lines = sectionText.split('\n').map(l => l.trim()).filter(Boolean).slice(1); // drop header
  const result = {};

  for (const line of lines) {
    const planetMatch = line.match(/^([A-Z][a-z]+)\s+/);
    if (!planetMatch) continue;
    const planet = planetMatch[1];

    const pairs = [...line.matchAll(WORD_PAREN)].map(m => ({ term: m[1], description: m[2].trim() }));
    if (pairs.length < 2) {
      result[planet] = { _warning: `Could not parse Avastha for ${planet} from: "${line}"` };
      continue;
    }

    result[planet] = {
      age: pairs[0],
      alertness: pairs[1],
      mood: pairs.slice(2) // 1 or 2 mood states
    };
  }

  return result;
}

function extractActivity(sectionText) {
  const lines = sectionText.split('\n').map(l => l.trim()).filter(Boolean).slice(1);
  const result = {};

  for (const line of lines) {
    const m = line.match(/^([A-Z][a-z]+)\s+([A-Z][a-zA-Z]*)\s*\(([a-z][a-zA-Z\s]*?)\)/);
    if (!m) continue;
    result[m[1]] = { term: m[2], description: m[3].trim() };
  }

  return result;
}

/**
 * Vimsopaka — Planet | DasaVarga(10) | ShodasaVarga(16) | SaptaVarga(7) | ShadVarga(6)
 * Each value is "X.XX (YY.YY%)". Handles glued planet-name+first-value
 * (e.g. "Sun14.85" for short names where PDF column spacing collapses).
 */
function extractVimsopaka(sectionText) {
  const lines = sectionText.split('\n').map(l => l.trim()).filter(Boolean).slice(1);
  const result = {};
  const PLANET_NAMES = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn', 'Rahu', 'Ketu'];

  for (const line of lines) {
    let planet = null, rest = line;
    for (const name of PLANET_NAMES) {
      if (line.startsWith(name)) {
        planet = name;
        rest = line.slice(name.length).trim();
        break;
      }
    }
    if (!planet) continue;

    const valuePattern = /([\d.]+)\s*\(([\d.]+)%\)/g;
    const matches = [...rest.matchAll(valuePattern)];
    if (matches.length !== 4) {
      result[planet] = { _warning: `Expected 4 Vimsopaka values, found ${matches.length} in: "${line}"` };
      continue;
    }

    const [dasaVarga, shodasaVarga, saptaVarga, shadVarga] = matches.map(m => ({
      value: parseFloat(m[1]), percent: parseFloat(m[2])
    }));

    result[planet] = { dasaVarga, shodasaVarga, saptaVarga, shadVarga };
  }

  return result;
}

module.exports = {
  extractAshtakavarga,
  extractShadbala,
  extractBhavaBala,
  extractAvastha,
  extractActivity,
  extractVimsopaka
};
