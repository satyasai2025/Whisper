/**
 * Debug — Raw Text Extraction
 *
 * Usage:
 *   node debug-extract.js path/to/your-jhora-export.pdf
 *
 * Outputs the raw extracted text to a .txt file with the same base name,
 * plus a section-detection report. Share the .txt file with Claude to
 * tune parser regex patterns against your actual JHora output format.
 */

const fs = require('fs').promises;
const path = require('path');
const pdfParse = require('pdf-parse');
const { splitSections } = require('./src/parser/utils/section-router');
const { normalizeText } = require('./src/parser/utils/pdf-text-extract');

async function main() {
  const pdfPath = process.argv[2];
  if (!pdfPath) {
    console.error('Usage: node debug-extract.js <path-to-pdf>');
    process.exit(1);
  }

  const buf = await fs.readFile(pdfPath);
  const data = await pdfParse(buf);
  const rawText = data.text;
  const normalized = normalizeText(rawText);

  // Save raw text alongside the PDF
  const base = pdfPath.replace(/\.pdf$/i, '');
  const rawOut = base + '_raw.txt';
  const normalizedOut = base + '_normalized.txt';
  const reportOut = base + '_report.txt';

  await fs.writeFile(rawOut, rawText);
  await fs.writeFile(normalizedOut, normalized);

  // Section detection report
  const sections = splitSections(normalized);
  let report = `=== JHora PDF Debug Report ===\n`;
  report += `Source: ${pdfPath}\n`;
  report += `PDF pages: ${data.numpages}\n`;
  report += `Raw text length: ${rawText.length} chars\n`;
  report += `Normalized length: ${normalized.length} chars\n\n`;
  report += `=== Sections Detected (${Object.keys(sections).length}) ===\n`;
  for (const [key, text] of Object.entries(sections)) {
    const preview = text.substring(0, 200).replace(/\n/g, ' ⏎ ');
    report += `\n--- ${key} (${text.length} chars) ---\n${preview}${text.length > 200 ? '...' : ''}\n`;
  }

  await fs.writeFile(reportOut, report);

  console.log(`\n  Raw text saved to:        ${rawOut}`);
  console.log(`  Normalized text saved to: ${normalizedOut}`);
  console.log(`  Section report saved to:  ${reportOut}`);
  console.log(`\n  Share these three files (or just the report + normalized .txt)`);
  console.log(`  for parser tuning.\n`);
}

main().catch(err => {
  console.error('Error:', err.message);
  process.exit(1);
});
