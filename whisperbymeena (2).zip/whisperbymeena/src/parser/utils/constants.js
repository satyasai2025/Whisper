/**
 * Constants — sign codes, planet codes, nakshatra mappings
 * Used across all parser modules for consistent encoding.
 */

// Sign codes as used in JHora output
const SIGN_CODES = {
  Ar: 'Aries',     Ta: 'Taurus',   Ge: 'Gemini',     Cn: 'Cancer',
  Le: 'Leo',       Vi: 'Virgo',    Li: 'Libra',      Sc: 'Scorpio',
  Sg: 'Sagittarius', Cp: 'Capricorn', Aq: 'Aquarius', Pi: 'Pisces'
};

// Ordered array for index <-> code round-tripping (index 0 = Aries ... 11 = Pisces)
const SIGN_ORDER = ['Ar', 'Ta', 'Ge', 'Cn', 'Le', 'Vi', 'Li', 'Sc', 'Sg', 'Cp', 'Aq', 'Pi'];

const SIGN_INDEX = {
  Ar: 0, Ta: 1, Ge: 2, Cn: 3, Le: 4, Vi: 5,
  Li: 6, Sc: 7, Sg: 8, Cp: 9, Aq: 10, Pi: 11
};

const SIGN_LORDS = {
  Ar: 'Mars',    Ta: 'Venus',   Ge: 'Mercury', Cn: 'Moon',
  Le: 'Sun',     Vi: 'Mercury', Li: 'Venus',   Sc: 'Mars',
  Sg: 'Jupiter', Cp: 'Saturn',  Aq: 'Saturn',  Pi: 'Jupiter'
};

const SIGN_TATTVAS = {
  Ar: 'Fire',  Le: 'Fire',  Sg: 'Fire',
  Ta: 'Earth', Vi: 'Earth', Cp: 'Earth',
  Ge: 'Air',   Li: 'Air',   Aq: 'Air',
  Cn: 'Water', Sc: 'Water', Pi: 'Water'
};

// Planet name normalization — JHora uses various abbreviations
const PLANET_ALIASES = {
  Su: 'Sun', Sun: 'Sun',
  Mo: 'Moon', Moon: 'Moon',
  Ma: 'Mars', Mars: 'Mars',
  Me: 'Mercury', Mer: 'Mercury', Merc: 'Mercury', Mercury: 'Mercury',
  Ju: 'Jupiter', Jup: 'Jupiter', Jupiter: 'Jupiter',
  Ve: 'Venus', Ven: 'Venus', Venus: 'Venus',
  Sa: 'Saturn', Sat: 'Saturn', Saturn: 'Saturn',
  Ra: 'Rahu', Rah: 'Rahu', Rahu: 'Rahu',
  Ke: 'Ketu', Ket: 'Ketu', Ketu: 'Ketu',
  // Outer planets
  Uranus: 'Uranus', Neptune: 'Neptune', Pluto: 'Pluto',
  // Special points
  Lagna: 'Lagna', As: 'Lagna',
  Maandi: 'Maandi', Md: 'Maandi',
  Gulika: 'Gulika', Gk: 'Gulika'
};

// Chara Karaka codes
const CHARA_KARAKAS = {
  AK: 'Atmakaraka',
  AmK: 'Amatyakaraka',
  BK: 'Bhratrukaraka',
  MK: 'Matrukaraka',
  PiK: 'Pitrukaraka',
  PK: 'Putrakaraka',
  GK: 'Gnatikaraka',
  DK: 'Darakaraka'
};

// 27 Nakshatras with codes used by JHora
const NAKSHATRAS = {
  Aswi: 'Ashwini',     Bhar: 'Bharani',      Krit: 'Krittika',
  Rohi: 'Rohini',      Mrig: 'Mrigashira',   Aard: 'Ardra',
  Puna: 'Punarvasu',   Push: 'Pushya',       Asle: 'Ashlesha',
  Magh: 'Magha',       PPha: 'Purva Phalguni', UPha: 'Uttara Phalguni',
  Hast: 'Hasta',       Chit: 'Chitra',       Swat: 'Swati',
  Visa: 'Vishakha',    Anu: 'Anuradha',      Jye: 'Jyeshtha',
  Mool: 'Mula',        PSha: 'Purva Ashadha', USha: 'Uttara Ashadha',
  Srav: 'Shravana',    Dhan: 'Dhanishta',    Sata: 'Shatabhisha',
  PBha: 'Purva Bhadrapada', UBha: 'Uttara Bhadrapada', Reva: 'Revati'
};

// Nakshatra lords for Vimshottari dasha
const NAKSHATRA_LORDS = {
  Ashwini: 'Ketu',    Bharani: 'Venus',     Krittika: 'Sun',
  Rohini: 'Moon',     Mrigashira: 'Mars',   Ardra: 'Rahu',
  Punarvasu: 'Jupiter', Pushya: 'Saturn',   Ashlesha: 'Mercury',
  Magha: 'Ketu',      'Purva Phalguni': 'Venus', 'Uttara Phalguni': 'Sun',
  Hasta: 'Moon',      Chitra: 'Mars',       Swati: 'Rahu',
  Vishakha: 'Jupiter', Anuradha: 'Saturn',  Jyeshtha: 'Mercury',
  Mula: 'Ketu',       'Purva Ashadha': 'Venus', 'Uttara Ashadha': 'Sun',
  Shravana: 'Moon',   Dhanishta: 'Mars',    Shatabhisha: 'Rahu',
  'Purva Bhadrapada': 'Jupiter', 'Uttara Bhadrapada': 'Saturn', Revati: 'Mercury'
};

/**
 * Compute house number given lagna sign and target sign
 * Houses are 1-indexed
 */
function computeHouse(lagnaSignCode, targetSignCode) {
  if (!(lagnaSignCode in SIGN_INDEX) || !(targetSignCode in SIGN_INDEX)) {
    return null;
  }
  return ((SIGN_INDEX[targetSignCode] - SIGN_INDEX[lagnaSignCode] + 12) % 12) + 1;
}

function normalizePlanetName(code) {
  return PLANET_ALIASES[code] || code;
}

function normalizeSign(code) {
  return SIGN_CODES[code] || code;
}

function normalizeNakshatra(code) {
  return NAKSHATRAS[code] || code;
}

module.exports = {
  SIGN_CODES, SIGN_INDEX, SIGN_ORDER, SIGN_LORDS, SIGN_TATTVAS,
  PLANET_ALIASES, CHARA_KARAKAS,
  NAKSHATRAS, NAKSHATRA_LORDS,
  computeHouse, normalizePlanetName, normalizeSign, normalizeNakshatra
};
