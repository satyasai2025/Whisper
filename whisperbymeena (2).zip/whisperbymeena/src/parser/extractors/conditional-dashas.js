/**
 * Conditional Dashas Extractor
 *
 * JHora's text export structures ALL planet-based dashas (MD-lord then
 * AD-lord+date pairs) identically to Vimshottari, and ALL rasi-based
 * dashas (major-rasi then sub-rasi+date pairs) identically to Narayana —
 * just with different planet/rasi sets, different total cycle lengths,
 * and occasionally extra header metadata (e.g. Kalachakra). Rather than
 * re-implement the same tokenizer/grouper five separate times, this
 * module reuses the generic functions already built and tested for
 * Vimshottari and Narayana.
 *
 * Extracted here (planet-based, reuses vimshottari.js internals):
 *   - Ashtottari Dasa (108-year cycle, 8 grahas — no Ketu)
 *   - Moola Dasa (past-karma indicator)
 *   - Vimshottari Tribhagi (1/3-scale Vimshottari variant)
 *   - Yogini Dasa (8 Yoginis mapped to 8 grahas — no Ketu)
 *
 * Extracted here (rasi-based, reuses narayana.js internals):
 *   - Kalachakra Dasa (+ Paksha/Paramayush/Deha/Jiva metadata)
 *   - Sudasa
 *   - Lagna Kendradi Rasi Dasa
 *   - Drigdasa
 *   - Shoola Dasa
 *   - Niryana Shoola Dasa
 *
 * NOT extracted: each of these has its own classical total-cycle-length
 * and sub-period proportions (unlike Vimshottari's well-known 120-year/
 * 9-planet proportional system) — Pratyantar-level subdivision is NOT
 * computed for these (only for Vimshottari, where the proportional
 * subdivision algorithm is unambiguous and widely agreed upon). Only
 * MD/sub-period (JHora's own AD-equivalent level) is available here.
 */

const {
  tokenizeDashaText, groupIntoMahadashas, computeEndDates, findActiveDasha
} = require('./vimshottari');
const {
  tokenizeRasiDasha, groupRasiPeriods, computeRasiEndDates, findActiveNarayana
} = require('./narayana');

function stripHeaderLine(sectionText) {
  const bodyStart = sectionText.indexOf('\n');
  return bodyStart === -1 ? '' : sectionText.substring(bodyStart + 1);
}

/**
 * Generic planet-based dasha extraction (Ashtottari, Moola, Tribhagi, Yogini).
 */
function extractGenericPlanetDasha(sectionText) {
  const bodyText = stripHeaderLine(sectionText);
  const tokens = tokenizeDashaText(bodyText);
  const mahadashas = groupIntoMahadashas(tokens);
  computeEndDates(mahadashas);
  return { mahadashas };
}

/**
 * Generic rasi-based dasha extraction (Sudasa, Lagna Kendradi, Drigdasa,
 * Shoola, Niryana Shoola, and Kalachakra's period structure).
 */
function extractGenericRasiDasha(sectionText) {
  const bodyText = stripHeaderLine(sectionText);
  const tokens = tokenizeRasiDasha(bodyText);
  const periods = groupRasiPeriods(tokens);
  computeRasiEndDates(periods);
  return { periods };
}

// ===== Planet-based =====

function extractAshtottari(sectionText) {
  return extractGenericPlanetDasha(sectionText);
}

function extractMoola(sectionText) {
  return extractGenericPlanetDasha(sectionText);
}

function extractVimshottariTribhagi(sectionText) {
  return extractGenericPlanetDasha(sectionText);
}

function extractYogini(sectionText) {
  return extractGenericPlanetDasha(sectionText);
}

// ===== Rasi-based =====

function extractSudasa(sectionText) {
  return extractGenericRasiDasha(sectionText);
}

function extractLagnaKendradi(sectionText) {
  return extractGenericRasiDasha(sectionText);
}

function extractDrigdasa(sectionText) {
  return extractGenericRasiDasha(sectionText);
}

function extractShoola(sectionText) {
  return extractGenericRasiDasha(sectionText);
}

function extractNiryanaShoola(sectionText) {
  return extractGenericRasiDasha(sectionText);
}

/**
 * Kalachakra Dasa — rasi-based like the others, but its header carries
 * extra classical metadata worth capturing:
 *   "Kalachakra Dasa (From Moon of D-1, Apasavya, Paramayush: 97 yr, Deha: Li, Jiva: Vi):"
 *   - Paksha: Savya or Apasavya (direction of counting, based on Moon's
 *     nakshatra pada)
 *   - Paramayush: maximum lifespan in years per this system
 *   - Deha rasi: body-significator sign
 *   - Jiva rasi: soul-significator sign
 */
function extractKalachakra(sectionText) {
  const headerLine = sectionText.split('\n')[0] || '';
  const meta = {};

  const pakshaMatch = headerLine.match(/\b(Savya|Apasavya)\b/);
  if (pakshaMatch) meta.paksha = pakshaMatch[1];

  const ayushMatch = headerLine.match(/Paramayush:\s*(\d+)\s*yr/);
  if (ayushMatch) meta.paramayushYears = parseInt(ayushMatch[1], 10);

  const dehaMatch = headerLine.match(/Deha:\s*([A-Z][a-z])/);
  if (dehaMatch) meta.dehaRasiCode = dehaMatch[1];

  const jivaMatch = headerLine.match(/Jiva:\s*([A-Z][a-z])/);
  if (jivaMatch) meta.jivaRasiCode = jivaMatch[1];

  const periods = extractGenericRasiDasha(sectionText);
  return { ...periods, meta };
}

/**
 * Multi-Dasha Convergence Snapshot
 *
 * Given the full `dashas` object (Vimshottari + Narayana + all conditional
 * systems) and a target date, return which period is active in EVERY
 * system at once. This is the core "convenience" this whole module exists
 * for: the Learner's analytical standard is that conclusions should be
 * supported by REPEATED indications across independent factors — applying
 * that to dasha timing means checking whether multiple dasha systems
 * agree on what's active during a given life event, not relying on
 * Vimshottari alone.
 *
 * findActiveDasha (despite its Vimshottari-originating name) is generic
 * over any { lord, startDate, endDate, antardashas } array, so it's
 * reused for all planet-based systems. Likewise findActiveNarayana is
 * generic over any { rasi, startDate, endDate, subPeriods } array and is
 * reused for all rasi-based systems.
 */
function computeMultiDashaContext(dashas, targetDate) {
  const context = {};

  if (dashas.vimshottari?.mahadashas) {
    context.vimshottari = findActiveDasha(dashas.vimshottari.mahadashas, targetDate);
  }
  if (dashas.narayana?.periods) {
    context.narayana = findActiveNarayana(dashas.narayana.periods, targetDate);
  }
  if (dashas.ashtottari?.mahadashas) {
    context.ashtottari = findActiveDasha(dashas.ashtottari.mahadashas, targetDate);
  }
  if (dashas.moola?.mahadashas) {
    context.moola = findActiveDasha(dashas.moola.mahadashas, targetDate);
  }
  if (dashas.yogini?.mahadashas) {
    context.yogini = findActiveDasha(dashas.yogini.mahadashas, targetDate);
  }
  if (dashas.vimshottariTribhagi?.mahadashas) {
    context.vimshottariTribhagi = findActiveDasha(dashas.vimshottariTribhagi.mahadashas, targetDate);
  }
  if (dashas.kalachakra?.periods) {
    context.kalachakra = findActiveNarayana(dashas.kalachakra.periods, targetDate);
  }
  if (dashas.sudasa?.periods) {
    context.sudasa = findActiveNarayana(dashas.sudasa.periods, targetDate);
  }
  if (dashas.lagnaKendradi?.periods) {
    context.lagnaKendradi = findActiveNarayana(dashas.lagnaKendradi.periods, targetDate);
  }
  if (dashas.drigdasa?.periods) {
    context.drigdasa = findActiveNarayana(dashas.drigdasa.periods, targetDate);
  }
  if (dashas.shoola?.periods) {
    context.shoola = findActiveNarayana(dashas.shoola.periods, targetDate);
  }
  if (dashas.niryanaShoola?.periods) {
    context.niryanaShoola = findActiveNarayana(dashas.niryanaShoola.periods, targetDate);
  }

  return context;
}

module.exports = {
  extractAshtottari,
  extractMoola,
  extractVimshottariTribhagi,
  extractYogini,
  extractSudasa,
  extractLagnaKendradi,
  extractDrigdasa,
  extractShoola,
  extractNiryanaShoola,
  extractKalachakra,
  computeMultiDashaContext
};
