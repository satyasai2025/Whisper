const fs = require('fs');
const path = require('path');
const { parseJHoraText } = require('../src/parser/jhora-parser');
const { findActiveDasha } = require('../src/parser/extractors/vimshottari');
const { findActiveNarayana } = require('../src/parser/extractors/narayana');

const TEST_INPUT = path.join(__dirname, '../data/test_input/meena_sample.txt');
const OUTPUT_FILE = path.join(__dirname, '../data/test_input/meena_parsed.json');

function pass(msg) { console.log(`  ✓ ${msg}`); }
function fail(msg) { console.log(`  ✗ ${msg}`); process.exitCode = 1; }

const rawText = fs.readFileSync(TEST_INPUT, 'utf-8');
console.log(`Loaded ${rawText.length} chars\n`);

const chart = parseJHoraText(rawText, { sourceFile: 'meena_sample.txt' });

console.log('=== Sections Found ===');
console.log(chart.metadata.sectionsFound.join(', '));
console.log();

console.log('=== Native ===');
console.log(JSON.stringify(chart.native, null, 2));
if (chart.native.name === 'Meena 29') pass('Name = "Meena 29" (placeholder correctly excluded)');
else fail(`Name wrong: got "${chart.native.name}"`);
if (chart.native.dateOfBirth === '1976-07-29') pass('DOB correct');
else fail(`DOB wrong: got ${chart.native.dateOfBirth}`);

console.log('\n=== Bodies ===');
const expectedBodies = ['Lagna','Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn','Rahu','Ketu',
  'Maandi','Gulika','Bhava Lagna','Hora Lagna','Ghati Lagna','Vighati Lagna','Varnada Lagna','Sree Lagna'];
let bodiesFound = 0;
for (const name of expectedBodies) {
  if (chart.bodies[name]) bodiesFound++;
  else console.log(`  ${name}: NOT FOUND`);
}
if (bodiesFound === expectedBodies.length) pass(`All ${bodiesFound} bodies extracted`);
else fail(`Only ${bodiesFound}/${expectedBodies.length} bodies extracted`);
if (chart.bodies.Lagna?.signCode === 'Ta') pass('Lagna = Taurus');
else fail(`Lagna sign wrong: got ${chart.bodies.Lagna?.signCode}`);

console.log('\n=== Chara Karakas ===');
const expectedKarakas = { AK: 'Mercury', AmK: 'Venus', BK: 'Mars', MK: 'Rahu', PiK: 'Saturn', PK: 'Sun', GK: 'Moon', DK: 'Jupiter' };
let karakasOk = 0;
for (const [code, expected] of Object.entries(expectedKarakas)) {
  if (chart.charaKarakas[code] === expected) karakasOk++;
  else console.log(`  MISMATCH ${code}: expected ${expected}, got ${chart.charaKarakas[code]}`);
}
if (karakasOk === 8) pass('All 8 chara karakas correct');
else fail(`Only ${karakasOk}/8 chara karakas correct`);

console.log('\n=== Functional Nature (Taurus Lagna) ===');
const fn = chart.analysis.functionalNature;
for (const [planet, c] of Object.entries(fn.classifications)) {
  if (c.classification === 'Not classified') continue;
  console.log(`  ${planet.padEnd(8)} ${c.classification.padEnd(50)} houses: ${c.housesRuled}`);
}
if (fn.classifications.Saturn.classification === 'Yogakaraka') pass('Saturn = Yogakaraka for Taurus Lagna (classical)');
else fail(`Saturn should be Yogakaraka for Taurus, got: ${fn.classifications.Saturn.classification}`);
if (fn.classifications.Venus.classification.includes('Lagna lord')) pass('Venus correctly identified as Lagna lord (not mislabeled Yogakaraka)');
else fail(`Venus classification unexpected: ${fn.classifications.Venus.classification}`);

console.log('\n=== Relationships — Sun row ===');
console.log(JSON.stringify(chart.analysis.relationships.matrix.Sun, null, 2));
if (chart.analysis.relationships.matrix.Sun.Moon.panchadha === 'Adhi Mitra (Great Friend)')
  pass('Sun-Moon = Adhi Mitra (matches natural friend + temporal friend)');
else fail('Sun-Moon relationship unexpected');

console.log('\n=== Aspects — Saturn ===');
const satAspect = chart.analysis.aspects.outgoing.Saturn;
console.log(`  House ${satAspect.sourceHouse} aspects houses [${satAspect.housesAspected.join(',')}]`);
if (JSON.stringify(satAspect.housesAspected.sort()) === JSON.stringify([5,9,12].sort()))
  pass('Saturn aspects (3rd,7th,10th counted from its own house 3 → houses 5,9,12) computed correctly');
else fail(`Saturn aspected houses unexpected: ${satAspect.housesAspected}`);

console.log('\n=== Vimshottari ===');
console.log(`  ${chart.dashas.vimshottari.mahadashas.length} MDs found`);
if (chart.dashas.vimshottari.mahadashas.length === 9) pass('9 Vimshottari MDs found');
else fail(`Expected 9 MDs, got ${chart.dashas.vimshottari.mahadashas.length}`);

console.log('\n=== Narayana ===');
console.log(`  ${chart.dashas.narayana.periods.length} periods found`);

fs.writeFileSync(OUTPUT_FILE, JSON.stringify(chart, null, 2));
console.log(`\nSaved to ${OUTPUT_FILE}`);
